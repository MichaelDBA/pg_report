#!/bin/bash
###################################################################
# ./get_objectsizes.sh nts-gwyv-locus2-ple.cluster-ch8dxqx9cvci.us-east-1.rds.amazonaws.com gwyvlati dbadmin 5432
# ./get_objectsizes.sh nts-gwvy-prd-01.cl9vgbtolm5s.us-east-1.rds.amazonaws.com GWYVLATI dbadmin 5432
ARGS=$#
DBHOST=$1
DBNAME=$2
DBUSER=$3
DBPORT=$4
TOPN=$5
if [[ $ARGS -ne 5 ]]; then
    echo "ERROR Invalid parameters: expected dbhost, dbname, dbuser, dbport, TopN"
    exit 1   
fi	

echo "*** `date` Sizing results for database, ${DBNAME} ***"

# get cluster size
results=`psql -h ${DBHOST} -d ${DBNAME} -U ${DBUSER} -p ${DBPORT} -q -t -c "WITH dbs AS (SELECT d.datname as dbname, CASE WHEN pg_catalog.has_database_privilege(d.datname, 'CONNECT') THEN pg_catalog.pg_database_size(d.datname) ELSE '0' END as size FROM pg_catalog.pg_database d JOIN pg_catalog.pg_tablespace t on d.dattablespace = t.oid ORDER BY 1) select pg_size_pretty(sum(dbs.size)) from dbs;"`
echo "Cluster  size    : ${results}"

# get database size
results=`psql -h ${DBHOST} -d ${DBNAME} -U ${DBUSER} -p ${DBPORT} -q -t -c "SELECT pg_size_pretty(pg_database_size('${DBNAME}'));"`
echo "Database size    : ${results}"

# echo "gettting total schema size..."
# get total schema size
results=`psql -h ${DBHOST} ${DBNAME} -U ${DBUSER} -p ${DBPORT} -c "SELECT pg_size_pretty(sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)))::bigint) FROM pg_stat_all_tables t where schemaname not in ('pg_toast') order by sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)))::bigint desc;" --field-separator '***' --record-separator='@@@' --single-transaction --set AUTOCOMMIT=off --set ON_ERROR_STOP=on --no-align -t  --quiet`
echo "Total Schema size:  ${results}"

# echo "gettting individual schema sizes..."
# get schema sizes
results=`psql -h ${DBHOST} ${DBNAME} -U ${DBUSER} -p ${DBPORT} -c "SELECT RPAD(schemaname, 20),  pg_size_pretty(sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)))::bigint), sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)))::bigint FROM pg_stat_all_tables t where schemaname not in ('pg_toast') group by 1 order by sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)))::bigint desc;" --field-separator '***' --record-separator='@@@' --single-transaction --set AUTOCOMMIT=off --set ON_ERROR_STOP=on --no-align -t  --quiet`
IFS='@@@' read -r -a array1 <<< "${results[0]}"
rows=0
sum=0
for arow in "${array1[@]}"
do
  if [ "$arow" == "''" ] || [ -z "$arow" ]; then
     continue
  fi
  let "rows=rows+1"
  IFS='***' read -r -a array2 <<< "${arow}"
  cols=0
  for afield in "${array2[@]}"
  do
     if [ "$afield" == "''" ] || [ -z "$afield" ]; then
        continue
     fi
     let "cols=cols+1"
     if [ "$cols" -eq 1 ]; then
         schema=$afield
     elif [ "$cols" -eq 2 ]; then
         echo "${schema}: ${afield}"
     elif [ "$cols" -eq 3 ]; then		 
	     let "sum=sum+${afield}"
     else
         echo "nada"
     fi    
  done
done

#echo "Sum=${sum}"
#if [ ${sum} -gt (1024*1024*1024) ]; then
if [ ${sum} -gt 1073741824 ]; then
	echo "Schema Total        : $((${sum} / (1024*1024*1024))) GB"
elif [ ${sum} -gt 1048576 ]; then
	echo "Schema Total        : $((${sum} / (1024*1024*1024))) MB"	
elif [ ${sum} -gt 1024 ]; then
	echo "Schema Total        : $((${sum} / (1024*1024*1024))) KB"		
else
	echo "Schema Total        : ${sum} bytes"	
fi	

# For each schema list topN sized tables
results=`psql -h ${DBHOST} ${DBNAME} -U ${DBUSER} -p ${DBPORT} -c "SELECT RPAD(schemaname || '.' || relname,50) as tablename, pg_size_pretty(sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname)))::bigint),  sum(pg_total_relation_size(quote_ident(schemaname) || '.' || quote_ident(relname))) FROM pg_stat_all_tables WHERE schemaname not in ('pg_toast') group by 1 order by 3 desc limit ${TOPN};" --field-separator '***' --record-separator='@@@' --single-transaction --set AUTOCOMMIT=off --set ON_ERROR_STOP=on --no-align -t  --quiet`
IFS='@@@' read -r -a array1 <<< "${results[0]}"
rows=0
sum=0
echo ""
echo "Top ${TOPN} tables:"
for arow in "${array1[@]}"
do
  if [ "$arow" == "''" ] || [ -z "$arow" ]; then
     continue
  fi
  let "rows=rows+1"
  IFS='***' read -r -a array2 <<< "${arow}"
  cols=0
  for afield in "${array2[@]}"
  do
     if [ "$afield" == "''" ] || [ -z "$afield" ]; then
        continue
     fi
     let "cols=cols+1"
     if [ "$cols" -eq 1 ]; then
         schematable=$afield
     elif [ "$cols" -eq 2 ]; then
         echo "${schematable}: ${afield}"
     elif [ "$cols" -eq 3 ]; then		 
	     let "sum=sum+${afield}"
     else
         echo "nada"
     fi    
  done
done

exit 0



