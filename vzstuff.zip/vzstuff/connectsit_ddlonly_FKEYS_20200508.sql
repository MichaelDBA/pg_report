--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


ALTER TABLE ONLY activn.t_blocking_locations
    ADD CONSTRAINT t_blocking_locations_blocking_id_fkey FOREIGN KEY (blocking_id) REFERENCES activn.t_call_blocking(blocking_id);


--
-- Name: t_cps_option_reference t_cps_option_reference_t_country_fk; Type: FK CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cps_option_reference
    ADD CONSTRAINT t_cps_option_reference_t_country_fk FOREIGN KEY (country_alpha2_code) REFERENCES config.t_country(country_alpha2_code);


--
-- Name: t_cps_request_reference t_cps_request_reference_country_fk; Type: FK CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cps_request_reference
    ADD CONSTRAINT t_cps_request_reference_country_fk FOREIGN KEY (country_alpha2_code) REFERENCES config.t_country(country_alpha2_code);


--
-- Name: t_cps_request_reference t_cps_request_reference_t_cli_type_fk; Type: FK CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cps_request_reference
    ADD CONSTRAINT t_cps_request_reference_t_cli_type_fk FOREIGN KEY (cli_type_id) REFERENCES config.t_cli_type(cli_type_id);


--
-- Name: t_cps_request_reference t_cps_request_reference_t_retail_type_fk; Type: FK CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cps_request_reference
    ADD CONSTRAINT t_cps_request_reference_t_retail_type_fk FOREIGN KEY (retail_type_id) REFERENCES config.t_retail_type(retail_type_id);


--
-- Name: t_province t_province_country_fk; Type: FK CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_province
    ADD CONSTRAINT t_province_country_fk FOREIGN KEY (country_alpha2_code) REFERENCES config.t_country(country_alpha2_code);


--
-- Name: t_milestone_manager t_milestone_manager_t_milestone_config_fk; Type: FK CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_milestone_manager
    ADD CONSTRAINT t_milestone_manager_t_milestone_config_fk FOREIGN KEY (milestone_id) REFERENCES infra.t_milestone_config(milsetone_config_id);


--
-- Name: t_transaction_error_manager t_transaction_error_maneger_t_transaction_error_fk; Type: FK CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_transaction_error_manager
    ADD CONSTRAINT t_transaction_error_maneger_t_transaction_error_fk FOREIGN KEY (transaction_error_id) REFERENCES infra.t_transaction_error(transaction_error_id);


--
-- Name: t_validation_param_map t_validation_param_map_t_generic_validation_rule_fk; Type: FK CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_param_map
    ADD CONSTRAINT t_validation_param_map_t_generic_validation_rule_fk FOREIGN KEY (gen_rule_id) REFERENCES infra.t_generic_validation_rule(rule_id);


--
-- Name: t_entity_order_details fkjy415akmpb6du3n1pgvxtq29v; Type: FK CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_entity_order_details
    ADD CONSTRAINT fkjy415akmpb6du3n1pgvxtq29v FOREIGN KEY (entity_order_id) REFERENCES ordng.t_entity_order(entity_order_id);


--
-- Name: t_entity_order t_entity_order_master_order_id_fkey; Type: FK CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_entity_order
    ADD CONSTRAINT t_entity_order_master_order_id_fkey FOREIGN KEY (master_order_id) REFERENCES ordng.t_master_order(master_order_id);


--
-- Name: t_parent_orders t_parent_orders_entity_order_detail_id_fkey; Type: FK CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_parent_orders
    ADD CONSTRAINT t_parent_orders_entity_order_detail_id_fkey FOREIGN KEY (entity_order_detail_id) REFERENCES ordng.t_entity_order_details(entity_order_detail_id);


--
-- Name: t_parent_orders t_parent_orders_parent_order_detail_id_fkey; Type: FK CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_parent_orders
    ADD CONSTRAINT t_parent_orders_parent_order_detail_id_fkey FOREIGN KEY (parent_order_detail_id) REFERENCES ordng.t_entity_order_details(entity_order_detail_id);



--
-- PostgreSQL database dump complete
--
