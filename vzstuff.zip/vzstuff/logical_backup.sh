#!/bin/bash
# The following script backs up globals and a specific database in -Fd mode
# Script:        nightly_logical_backup.sh
# Created:       July 23, 2020
# Last Modified: July 23, 2020
# Creator:       Michael Vitale
# sample cronjob that runs every morning at 2am
# 0 2 * * * /apps/opt/postgres/scripts/logical_backup.sh

# Backup location.
BACKUP_DIR=/apps/opt/postgres/backups

# Current date.
CURRENT_DATE="$(date +%Y%m%d)"
YESTERDAY_DATE="$(date -d yesterday +%Y%m%d)"

DBHOST=localhost
DBNAME=connectdb
DBPORT=25432
DBUSER=dbadmin
DUMPNAME="${BACKUP_DIR}/${DBNAME}_${CURRENT_DATE}_dump"
GLOBALSNAME="${BACKUP_DIR}/${DBNAME}_${CURRENT_DATE}_globals.sql"
LOGFILE="${BACKUP_DIR}/${DBNAME}_${CURRENT_DATE}.log"

echo "`date`: Backing up Globals and database, $DBNAME"
-- echo "host=$DBHOST  port=$DBPORT  user=$DBUSER  db=$DBNAME  location=$GLOBALSNAME"
pg_dumpall -h $DBHOST -p $DBPORT -U $DBUSER -g > $GLOBALSNAME
RC=$?
if [ $RC -ne 0 ]; then
    echo "`date`: Error exporting globals"
    exit 1    
fi

pg_dump -h $DBHOST -p $DBPORT  -U $DBUSER -d $DBNAME -C -Fd -j 6 -v -b -f  ${DUMPNAME} >> $LOGFILE 2>&1
RC=$?
if [ $RC -ne 0 ]; then
    echo "`date`: Error dumping database"
    exit 1    
fi

echo "`date`: Backup completed successfully"
exit 0