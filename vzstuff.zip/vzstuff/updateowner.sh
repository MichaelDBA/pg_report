#!/bin/bash
###########################################################################
# updateowner.sh
# This script updates the owner of objects for a given database and schema.
#
# ./updateowner.sh  localhost sysdba mydb myschema new_owner;
#
# assume fn_updatefuncowner() function is created in the public schema
###########################################################################
args=$#

if [ $args -ne 5 ]; then
    echo "ERROR `date`: Invalid arguments provided: ${args}. Expected HOST, USER, DATABASE, SCHEMA and new OWNER."
    exit 1
fi

HOST=$1
USER=$2
DB=`echo "$3" | tr '[:lower:]' '[:upper:]'`
DBL=`echo "$DB" | tr '[:upper:]' '[:lower:]'`
SCHEMA=`echo "$4" | tr '[:lower:]' '[:upper:]'`
SCHEMAL=`echo "$SCHEMA" | tr '[:upper:]' '[:lower:]'`
OWNER=`echo "$5" | tr '[:lower:]' '[:upper:]'`
OWNERL=`echo "$OWNER" | tr '[:upper:]' '[:lower:]'`

echo "INFO  `date`: ******* Updating objects: host(${HOST}) user(${USER}) database(${DBL}) schema(${SCHEMAL}) with new owner(${OWNERL})..."

# update schema
echo "INFO  `date`: ******* updating schema owner..."
psql -h ${HOST} -U ${USER} -a ${DBL} -c "alter schema ${SCHEMAL} owner to ${OWNERL}"
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating table owner..."
for tbl in `psql -h ${HOST} -U ${USER} -qAt -c "select tablename from pg_tables where schemaname = '${SCHEMAL}';" ${DBL}` ;                             do  psql -h ${HOST} -U ${USER} -c "alter table ${SCHEMAL}.\"$tbl\" owner to ${OWNERL}" ${DBL} ; done
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating sequence owner..."
for tbl in `psql -h ${HOST} -U ${USER} -qAt -c "select sequence_name from information_schema.sequences where sequence_schema = '${SCHEMAL}';" ${DBL}` ; do  psql -h ${HOST} -U ${USER} -c "alter sequence ${SCHEMAL}.\"$tbl\" owner to ${OWNERL}" ${DBL} ; done
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating view owner..."
for tbl in `psql -h ${HOST} -U ${USER} -qAt -c "SELECT c.relname FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('v','s','') and n.nspname = '${SCHEMAL}' order by 1;" ${DBL}` ; do  psql -h ${HOST} -U ${USER} -c "alter view ${SCHEMAL}.\"$tbl\" owner to ${OWNERL}" ${DBL} ; done
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating materialized view owner..."
for tbl in `psql -h ${HOST} -U ${USER} -qAt -c "SELECT c.relname FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('m','s','') AND n.nspname = '${SCHEMAL}' ORDER BY 1;" ${DBL}` ; do  psql -h ${HOST} -U ${USER} -c "alter materialized view ${SCHEMAL}.\"$tbl\" owner to ${OWNERL}" ${DBL} ; done
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating type owner..."
for tbl in `psql -h ${HOST} -U ${USER} -qAt -c "SELECT pg_catalog.format_type(t.oid, NULL) AS "Name" FROM pg_catalog.pg_type t LEFT JOIN pg_catalog.pg_namespace n ON n.oid = t.typnamespace WHERE (t.typrelid = 0 OR (SELECT c.relkind = 'c' FROM pg_catalog.pg_class c WHERE c.oid = t.typrelid))   AND NOT EXISTS(SELECT 1 FROM pg_catalog.pg_type el WHERE el.oid = t.typelem AND el.typarray = t.oid) AND n.nspname = '${SCHEMAL}' order by 1;" ${DBL}` ; do  psql -h ${HOST} -U ${USER} -c "alter type $tbl owner to ${OWNERL}" ${DBL} ; done
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating function/trigger owner..."
psql -h ${HOST} -U ${USER} -at ${DBL} -c "SELECT public.fn_updatefuncowner('${SCHEMAL}', '${OWNERL}')"
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* updating foreign table owner..."
for tbl in `psql -h ${HOST} -U ${USER} -qAt -c "SELECT c.relname FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('s','f','')  AND n.nspname = '${SCHEMAL}' ORDER BY 1;" ${DBL}` ; do  psql -h ${HOST} -U ${USER} -c "alter foreign table ${SCHEMAL}.\"$tbl\" owner to ${OWNERL}" ${DBL} ; done
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode"; exit 1; fi
echo "INFO  `date`: ******* Finished Successfully"
exit 0

