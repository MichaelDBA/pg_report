-- >pg_dump -h techtab-cluster.cluster-calku0teekje.us-west-2.rds.amazonaws.com -U dbadmin --format plain --create --clean --encoding UTF8 --verbose --schema-only --schema ng_orchestration -d ng_orchestration > ./prvgwy_ng_orchestration_schema.sql

-- >pg_dump -h techtab-cluster.cluster-calku0teekje.us-west-2.rds.amazonaws.com -U dbadmin --format plain --create --clean --encoding UTF8 --verbose --schema-only --schema ng_orchestration -d ng_orchestration > ./prvgwy_ng_orchestration_schema.sql

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.12
-- Dumped by pg_dump version 10.12

-- Started on 2020-04-24 12:27:43 EDT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 68 (class 2615 OID 212906)
-- Name: ng_orchestration; Type: SCHEMA; Schema: -; Owner: prvgwy
--

CREATE SCHEMA ng_orchestration;


ALTER SCHEMA ng_orchestration OWNER TO prvgwy;

--
-- TOC entry 1007 (class 1255 OID 214450)
-- Name: after_project_delete$project(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration."after_project_delete$project"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM ng_orchestration.project_cmd_cache
        WHERE project_id = OLD.project_id;
    RETURN NULL;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
            END;
END;
$$;


ALTER FUNCTION ng_orchestration."after_project_delete$project"() OWNER TO dbadmin;

--
-- TOC entry 1008 (class 1255 OID 214451)
-- Name: after_project_insert$project(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration."after_project_insert$project"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM ng_orchestration.replace_into_project_cmd_cache(NEW.project_id);
    RETURN NULL;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
            END;
END;
$$;


ALTER FUNCTION ng_orchestration."after_project_insert$project"() OWNER TO dbadmin;

--
-- TOC entry 1009 (class 1255 OID 214452)
-- Name: after_project_update$project(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration."after_project_update$project"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM ng_orchestration.replace_into_project_cmd_cache(NEW.project_id);
    RETURN NULL;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
            END;
END;
$$;


ALTER FUNCTION ng_orchestration."after_project_update$project"() OWNER TO dbadmin;

--
-- TOC entry 1065 (class 1255 OID 214467)
-- Name: alphanum(character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.alphanum(par_input character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    var_result VARCHAR(4000) DEFAULT '';
    var_i INTEGER DEFAULT 1;
    var_a CHAR(1);
    var_len INTEGER;
BEGIN
    var_len := CHAR_LENGTH(par_input::VARCHAR);

    IF (par_input <> NULL::VARCHAR(4000) OR LOWER(par_input) <> LOWER(''::VARCHAR(4000)) OR LOWER(par_input) <> LOWER(' '::VARCHAR(4000))) THEN
        LOOP
            BEGIN
                /*
                [9996 - Severity CRITICAL - Transformer error occurred. Please submit report to developers.]
                set a = substring(input, i, 1)
                */
                IF var_a::VARCHAR ~* '[[:alnum:]]'::VARCHAR THEN
                    var_result := CONCAT(var_result, var_a)::VARCHAR(4000);
                ELSE
                    var_result := CONCAT(var_result, ' ')::VARCHAR(4000);
                END IF;
                var_i := (var_i::NUMERIC + 1::NUMERIC)::INTEGER;
            END;
            EXIT WHEN var_i > var_len;
        END LOOP;
    END IF;
    RETURN var_result;
END;
$$;


ALTER FUNCTION ng_orchestration.alphanum(par_input character varying) OWNER TO dbadmin;

--
-- TOC entry 1133 (class 1255 OID 468793)
-- Name: charindex(text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.charindex(text, text) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
begin
return position($1 in $2);
end;
$_$;


ALTER FUNCTION ng_orchestration.charindex(text, text) OWNER TO prvgwy;

--
-- TOC entry 1134 (class 1255 OID 233784)
-- Name: checkentityexist(regclass, bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexist(_tbl regclass, entity_id bigint) RETURNS SETOF boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN QUERY
  EXECUTE format('SELECT (EXISTS (SELECT 1 FROM %I WHERE entity_id = $1))::boolean',_tbl) USING entity_id;
END
$_$;


ALTER FUNCTION ng_orchestration.checkentityexist(_tbl regclass, entity_id bigint) OWNER TO prvgwy;

--
-- TOC entry 1135 (class 1255 OID 214453)
-- Name: checkentityexistold(character varying, bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexistold(par_tab_name character varying, par_entity_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    /*
    [8828 - Severity CRITICAL - User-defined variables is not supported in PostgreSQL. Perform a manual conversion.]
    set @qry=concat('select * from ',tab_name,' where entity_id=',entity_id)
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    prepare stment from @qry
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    execute stment
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    deallocate prepare stment
    */
    BEGIN
    END;
END;
$$;


ALTER FUNCTION ng_orchestration.checkentityexistold(par_tab_name character varying, par_entity_id bigint) OWNER TO prvgwy;

--
-- TOC entry 1047 (class 1255 OID 233495)
-- Name: checkentityexistold2(anyelement, integer); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexistold2(tb3_type anyelement, entity_id integer) RETURNS SETOF anyelement
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN QUERY EXECUTE format('SELECT * FROM  %s WHERE  entity_id = $1'
  , pg_typeof(tb3_type)) USING entity_id;
END

$_$;


ALTER FUNCTION ng_orchestration.checkentityexistold2(tb3_type anyelement, entity_id integer) OWNER TO prvgwy;

--
-- TOC entry 1048 (class 1255 OID 233785)
-- Name: checkentityexistold2(character varying, integer, anyelement); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexistold2(tb3_type character varying, entity_id integer, tb2_type anyelement) RETURNS SETOF anyelement
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN QUERY EXECUTE format('SELECT * FROM  %s WHERE  entity_id = $1'
  , pg_typeof(tb3_type)) USING entity_id;
END

$_$;


ALTER FUNCTION ng_orchestration.checkentityexistold2(tb3_type character varying, entity_id integer, tb2_type anyelement) OWNER TO prvgwy;

--
-- TOC entry 1049 (class 1255 OID 233782)
-- Name: checkentityexistold3(regclass, integer); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexistold3(_tbl regclass, entity_id integer) RETURNS SETOF boolean
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN QUERY
  EXECUTE format('SELECT (EXISTS (SELECT 1 FROM %I WHERE entity_id = $1))::boolean',_tbl) USING entity_id;
END
$_$;


ALTER FUNCTION ng_orchestration.checkentityexistold3(_tbl regclass, entity_id integer) OWNER TO prvgwy;

--
-- TOC entry 1127 (class 1255 OID 233781)
-- Name: checkentityexistold4(anyelement, bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexistold4(tb3_type anyelement, entity_id bigint) RETURNS SETOF anyelement
    LANGUAGE plpgsql
    AS $_$

BEGIN
RETURN QUERY EXECUTE format('SELECT * FROM  %s WHERE  entity_id = $1'
  , pg_typeof(tb3_type)) USING entity_id;
END

$_$;


ALTER FUNCTION ng_orchestration.checkentityexistold4(tb3_type anyelement, entity_id bigint) OWNER TO prvgwy;

--
-- TOC entry 1128 (class 1255 OID 233786)
-- Name: checkentityexistold5(character varying, integer, anyelement); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.checkentityexistold5(tb3_type character varying, entity_id integer, tb2_type anyelement) RETURNS SETOF anyelement
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN QUERY EXECUTE format('SELECT * FROM  %s WHERE  entity_id = $1'
  , pg_typeof(tb3_type)) USING entity_id;
END

$_$;


ALTER FUNCTION ng_orchestration.checkentityexistold5(tb3_type character varying, entity_id integer, tb2_type anyelement) OWNER TO prvgwy;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 728 (class 1259 OID 592437)
-- Name: orders_count_due; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.orders_count_due (
    due bigint
);


ALTER TABLE ng_orchestration.orders_count_due OWNER TO prvgwy;

--
-- TOC entry 1169 (class 1255 OID 603646)
-- Name: count_orders_due(text, text, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.count_orders_due(o_source text, milestone text, o_region text, o_product text, business_type text) RETURNS SETOF ng_orchestration.orders_count_due
    LANGUAGE sql STABLE
    AS $$
    SELECT COUNT(*) AS due FROM(
    SELECT T1.* from ng_orchestration.tbl_order AS T1,
    jsonb_array_elements(T1.attributes) AS T2,
    jsonb_array_elements(T1.attributes) AS T3,
        jsonb_array_elements(T1.attributes) AS T4
    WHERE order_source=COALESCE(NULLIF(o_source, ''), order_source)
    AND order_status=COALESCE(NULLIF(milestone, ''), order_status)
    AND region = COALESCE(NULLIF(o_region, ''), region)
    AND order_status NOT IN ('ORDER COMPLETED','CANCEL COMPLETED')
    AND jsonb_typeof(T1.attributes)='array'
    AND T2->>'name'='dueDate'
    AND T2->>'value' SIMILAR TO '[12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])%'
    AND to_timestamp(T2->>'value', 'YYYY/MM/DD')=CURRENT_DATE
    AND T3 ->> 'name' = 'product'
        AND T3 ->> 'value' LIKE ISNULL(o_product, '') +'%'
        AND T4 ->> 'name' = 'businessType'
        AND T4 ->> 'value' LIKE ISNULL(business_type, '') +'%'
    ) AS derivedTable;
$$;


ALTER FUNCTION ng_orchestration.count_orders_due(o_source text, milestone text, o_region text, o_product text, business_type text) OWNER TO prvgwy;

--
-- TOC entry 733 (class 1259 OID 603655)
-- Name: orders_count; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.orders_count (
    due bigint,
    pastdue bigint,
    upcoming bigint
);


ALTER TABLE ng_orchestration.orders_count OWNER TO prvgwy;

--
-- TOC entry 1151 (class 1255 OID 603658)
-- Name: count_orders_fn(text, text, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.count_orders_fn(o_source text, milestone text, o_region text, o_product text, business_type text) RETURNS SETOF ng_orchestration.orders_count
    LANGUAGE sql STABLE
    AS $$
    SELECT
    (SELECT COUNT(*)  FROM(
    SELECT T1.* from ng_orchestration.tbl_order AS T1,
    jsonb_array_elements(T1.attributes) AS T2,
    jsonb_array_elements(T1.attributes) AS T3,
        jsonb_array_elements(T1.attributes) AS T4
    WHERE order_source=COALESCE(NULLIF(o_source, ''), order_source)
    AND order_status=COALESCE(NULLIF(milestone, ''), order_status)
    AND region = COALESCE(NULLIF(o_region, ''), region)
    AND order_status NOT IN ('ORDER COMPLETED','CANCEL COMPLETED')
    AND jsonb_typeof(T1.attributes)='array'
    AND T2->>'name'='dueDate'
    AND T2->>'value' SIMILAR TO '[12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])%'
    AND to_timestamp(T2->>'value', 'YYYY/MM/DD')=CURRENT_DATE
    AND T3 ->> 'name' = 'product'
        AND T3 ->> 'value' LIKE ISNULL(o_product, '') +'%'
        AND T4 ->> 'name' = 'businessType'
        AND T4 ->> 'value' LIKE ISNULL(business_type, '') +'%'
    ) AS derivedTable) AS due,
    (SELECT COUNT(*)  FROM(
    SELECT T1.* from ng_orchestration.tbl_order AS T1,
    jsonb_array_elements(T1.attributes) AS T2,
    jsonb_array_elements(T1.attributes) AS T3,
        jsonb_array_elements(T1.attributes) AS T4
    WHERE order_source=COALESCE(NULLIF(o_source, ''), order_source)
    AND order_status=COALESCE(NULLIF(milestone, ''), order_status)
    AND region = COALESCE(NULLIF(o_region, ''), region)
    AND order_status NOT IN ('ORDER COMPLETED','CANCEL COMPLETED')
    AND jsonb_typeof(T1.attributes)='array'
    AND T2->>'name'='dueDate'
    AND T2->>'value' SIMILAR TO '[12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])%'
    AND to_timestamp(T2->>'value', 'YYYY/MM/DD')<CURRENT_DATE
    AND T3 ->> 'name' = 'product'
        AND T3 ->> 'value' LIKE ISNULL(o_product, '') +'%'
        AND T4 ->> 'name' = 'businessType'
        AND T4 ->> 'value' LIKE ISNULL(business_type, '') +'%'
    ) AS derivedTable) AS pastdue,
     (SELECT COUNT(*)  FROM(
    SELECT T1.* from ng_orchestration.tbl_order AS T1,
    jsonb_array_elements(T1.attributes) AS T2,
    jsonb_array_elements(T1.attributes) AS T3,
        jsonb_array_elements(T1.attributes) AS T4
    WHERE order_source=COALESCE(NULLIF(o_source, ''), order_source)
    AND order_status=COALESCE(NULLIF(milestone, ''), order_status)
    AND region = COALESCE(NULLIF(o_region, ''), region)
    AND order_status NOT IN ('ORDER COMPLETED','CANCEL COMPLETED')
    AND jsonb_typeof(T1.attributes)='array'
    AND T2->>'name'='dueDate'
    AND T2->>'value' SIMILAR TO '[12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])%'
    AND to_timestamp(T2->>'value', 'YYYY/MM/DD')>CURRENT_DATE
    AND T3 ->> 'name' = 'product'
        AND T3 ->> 'value' LIKE ISNULL(o_product, '') +'%'
        AND T4 ->> 'name' = 'businessType'
        AND T4 ->> 'value' LIKE ISNULL(business_type, '') +'%'
    ) AS derivedTable) AS upcoming
    ;
$$;


ALTER FUNCTION ng_orchestration.count_orders_fn(o_source text, milestone text, o_region text, o_product text, business_type text) OWNER TO prvgwy;

--
-- TOC entry 1095 (class 1255 OID 603648)
-- Name: count_orders_past_due(text, text, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.count_orders_past_due(o_source text, milestone text, o_region text, o_product text, business_type text) RETURNS SETOF ng_orchestration.orders_count_due
    LANGUAGE sql STABLE
    AS $$
    SELECT COUNT(*) AS past_due FROM(
    SELECT T1.* from ng_orchestration.tbl_order AS T1,
    jsonb_array_elements(T1.attributes) AS T2,
    jsonb_array_elements(T1.attributes) AS T3,
        jsonb_array_elements(T1.attributes) AS T4
    WHERE order_source=COALESCE(NULLIF(o_source, ''), order_source)
    AND order_status=COALESCE(NULLIF(milestone, ''), order_status)
    AND region = COALESCE(NULLIF(o_region, ''), region)
    AND order_status NOT IN ('ORDER COMPLETED','CANCEL COMPLETED')
    AND jsonb_typeof(T1.attributes)='array'
    AND T2->>'name'='dueDate'
    AND T2->>'value' SIMILAR TO '[12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])%'
    AND to_timestamp(T2->>'value', 'YYYY/MM/DD')<CURRENT_DATE
    AND T3 ->> 'name' = 'product'
        AND T3 ->> 'value' LIKE ISNULL(o_product, '') +'%'
        AND T4 ->> 'name' = 'businessType'
        AND T4 ->> 'value' LIKE ISNULL(business_type, '') +'%'
    ) AS derivedTable;
$$;


ALTER FUNCTION ng_orchestration.count_orders_past_due(o_source text, milestone text, o_region text, o_product text, business_type text) OWNER TO prvgwy;

--
-- TOC entry 1152 (class 1255 OID 603647)
-- Name: count_orders_upcoming(text, text, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.count_orders_upcoming(o_source text, milestone text, o_region text, o_product text, business_type text) RETURNS SETOF ng_orchestration.orders_count_due
    LANGUAGE sql STABLE
    AS $$
    SELECT COUNT(*) AS upcoming FROM(
    SELECT T1.* from ng_orchestration.tbl_order AS T1,
    jsonb_array_elements(T1.attributes) AS T2,
    jsonb_array_elements(T1.attributes) AS T3,
        jsonb_array_elements(T1.attributes) AS T4
    WHERE order_source=COALESCE(NULLIF(o_source, ''), order_source)
    AND order_status=COALESCE(NULLIF(milestone, ''), order_status)
    AND region = COALESCE(NULLIF(o_region, ''), region)
    AND order_status NOT IN ('ORDER COMPLETED','CANCEL COMPLETED')
    AND jsonb_typeof(T1.attributes)='array'
    AND T2->>'name'='dueDate'
    AND T2->>'value' SIMILAR TO '[12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])%'
    AND to_timestamp(T2->>'value', 'YYYY/MM/DD')>CURRENT_DATE
    AND T3 ->> 'name' = 'product'
        AND T3 ->> 'value' LIKE ISNULL(o_product, '') +'%'
        AND T4 ->> 'name' = 'businessType'
        AND T4 ->> 'value' LIKE ISNULL(business_type, '') +'%'
    ) AS derivedTable;
$$;


ALTER FUNCTION ng_orchestration.count_orders_upcoming(o_source text, milestone text, o_region text, o_product text, business_type text) OWNER TO prvgwy;

--
-- TOC entry 1145 (class 1255 OID 542335)
-- Name: cr_id_to_string(); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.cr_id_to_string() RETURNS character varying
    LANGUAGE plpgsql
    AS $$

DECLARE
        string_cr_id varchar(6);
        cr_id BIGINT;
        db_count NUMERIC := 0;
        digit_char CHAR;
        digit_val NUMERIC;
        status NUMERIC := 0;
BEGIN
        LOOP
                --SELECT cr_id_seq.nextval INTO cr_id FROM DUAL;
                select nextval('ng_orchestration."cr_id_seq"') into cr_id;
                Select id_to_string(cr_id) into string_cr_id;
                db_count := char_length(string_cr_id);
                IF(db_count <= 0)THEN
                        EXIT;
                END IF;
                FOR ind IN 1..db_count LOOP
                        digit_char := SUBSTR(string_cr_id, ind, 1);
                        digit_val := ASCII(digit_char);
                        IF(cr_id < 1000000) THEN
                                status := 1;
                                EXIT;
                        END IF;
                        IF(digit_val BETWEEN 65 AND 91) THEN
                                status := 1;
                                EXIT;
                        END IF;
                END LOOP;
                IF(status = 1) THEN
                        EXIT;
                END IF;
        END LOOP;
        RETURN (string_cr_id);
END;
$$;


ALTER FUNCTION ng_orchestration.cr_id_to_string() OWNER TO prvgwy;

--
-- TOC entry 1050 (class 1255 OID 214454)
-- Name: deletemanifest(bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.deletemanifest(par_entityid bigint) RETURNS void
    LANGUAGE plpgsql
    AS $_X$DECLARE
    var_existingManifest INTEGER DEFAULT 0;
    var_manifestid INTEGER DEFAULT 0;
BEGIN
    SELECT
        COUNT(*)
        INTO var_existingManifest
        FROM ng_orchestration.tbl_manifest
        WHERE LOWER(active) = LOWER('N'::CHAR(1)) AND entity_id = par_entityid;
    /*
    [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
    start transaction
    */

    IF var_existingManifest > 0::INTEGER THEN
        SELECT
            manifest_id::INTEGER
            INTO var_manifestid
            FROM ng_orchestration.tbl_manifest
            WHERE LOWER(active) = LOWER('N'::CHAR(1)) AND entity_id = par_entityid;
        UPDATE ng_orchestration.tbl_manifest_docs
        SET doc_name = '$_DEL_$'::VARCHAR(64)
            WHERE document_id IN (SELECT
                document_id
                FROM ng_orchestration.tbl_manifest_map
                WHERE manifest_id = var_manifestid::BIGINT);
        DELETE FROM ng_orchestration.tbl_manifest_map
            WHERE manifest_id = var_manifestid::BIGINT;
        DELETE FROM ng_orchestration.tbl_manifest_docs
            WHERE LOWER(doc_name) = LOWER('$_DEL_$'::VARCHAR(64));
        DELETE FROM ng_orchestration.tbl_manifest
            WHERE manifest_id = var_manifestid::BIGINT;
    ELSE
        UPDATE ng_orchestration.tbl_manifest
        SET active = 'N'::CHAR(1)
            WHERE LOWER(active) = LOWER('Y'::CHAR(1)) AND entity_id = par_entityid;
    END IF
    /*
    [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
    commit
    */;
    COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                /*
                [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
                rollback
                */
                RAISE;
            END;
END;
$_X$;


ALTER FUNCTION ng_orchestration.deletemanifest(par_entityid bigint) OWNER TO prvgwy;

--
-- TOC entry 1066 (class 1255 OID 214455)
-- Name: dml_table_sync_utl_purge_dml_monitor_data(bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.dml_table_sync_utl_purge_dml_monitor_data(par_p_event_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM ng_orchestration.dml_monitor
        WHERE dml_event_id = par_p_event_id;
END;
$$;


ALTER FUNCTION ng_orchestration.dml_table_sync_utl_purge_dml_monitor_data(par_p_event_id bigint) OWNER TO dbadmin;

--
-- TOC entry 1051 (class 1255 OID 214456)
-- Name: dml_table_sync_utl_sync_cmd_search_cache(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.dml_table_sync_utl_sync_cmd_search_cache(par_p_table_name character varying, par_p_key_name character varying, par_p_key_value character varying, par_p_dml_type character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO ng_orchestration.search_cache_event_monitor (table_name, key_name, key_value, mod_type, creation_date, modify_date, status, remarks)
    VALUES (CONCAT('SEARCH_', par_p_table_name), par_p_key_name, par_p_key_value, par_p_dml_type, clock_timestamp()::TIMESTAMP, clock_timestamp()::TIMESTAMP, 'NEW', '');
END;
$$;


ALTER FUNCTION ng_orchestration.dml_table_sync_utl_sync_cmd_search_cache(par_p_table_name character varying, par_p_key_name character varying, par_p_key_value character varying, par_p_dml_type character varying) OWNER TO dbadmin;

--
-- TOC entry 1052 (class 1255 OID 214457)
-- Name: dml_table_sync_utl_sync_dml_monitor_data(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.dml_table_sync_utl_sync_dml_monitor_data() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM ng_orchestration.dml_table_sync_utl_sync_project()
    /*
    [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
    commit
    */;
END;
$$;


ALTER FUNCTION ng_orchestration.dml_table_sync_utl_sync_dml_monitor_data() OWNER TO dbadmin;

--
-- TOC entry 1055 (class 1255 OID 214458)
-- Name: dml_table_sync_utl_sync_project(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.dml_table_sync_utl_sync_project() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    var_v_event_id BIGINT;
    var_v_dml_type VARCHAR(1);
    var_v_dml_table VARCHAR(100);
    var_v_dml_key_name VARCHAR(100);
    var_v_dml_key_value VARCHAR(100);
    var_v_date TIMESTAMP WITHOUT TIME ZONE;
    var_v_val_attr_inst_id BIGINT;
    var_project_exit_loop BOOLEAN;
    project_data_cursor CURSOR FOR
    SELECT
        *
        FROM ng_orchestration.dml_monitor
        WHERE LOWER(dml_table) = LOWER('PROJECT'::VARCHAR(100))
        ORDER BY dml_ts ASC NULLS FIRST;
BEGIN
    OPEN project_data_cursor;

    <<project_read_loop>>
    LOOP
        FETCH project_data_cursor INTO var_v_event_id, var_v_date, var_v_dml_type, var_v_dml_table, var_v_dml_key_name, var_v_dml_key_value, var_v_val_attr_inst_id;

        IF NOT FOUND THEN
            EXIT project_read_loop;
        END IF;
        PERFORM ng_orchestration.dml_table_sync_utl_sync_cmd_search_cache(var_v_dml_table, var_v_dml_key_name, var_v_dml_key_value, var_v_dml_type);
        PERFORM ng_orchestration.dml_table_sync_utl_purge_dml_monitor_data(var_v_event_id);
    END LOOP project_read_loop;
    CLOSE project_data_cursor;
END;
$$;


ALTER FUNCTION ng_orchestration.dml_table_sync_utl_sync_project() OWNER TO dbadmin;

--
-- TOC entry 1114 (class 1255 OID 357319)
-- Name: dton(date); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.dton(p_date date) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
        dtDays                          DATE;
        numDays                         INTEGER;
        numDaysFlt          INTEGER;
BEGIN
        SELECT p_date - to_date('19700101000000', 'YYYYMMDDHH24MISS') INTO  numDaysFlt ;


        RETURN (numDaysFlt*24*60*60);
END;

$$;


ALTER FUNCTION ng_orchestration.dton(p_date date) OWNER TO prvgwy;

--
-- TOC entry 1105 (class 1255 OID 2708241)
-- Name: dton_iEN(character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration."dton_iEN"(p_date character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$

DECLARE
        dtDays                          DATE;
        numDays                         INTEGER;
        numDaysFlt          INTEGER;
BEGIN
        SELECT p_date - to_date('19700101000000', 'YYYYMMDDHH24MISS') INTO  numDaysFlt ;


        RETURN (numDaysFlt*24*60*60);
END;

$$;


ALTER FUNCTION ng_orchestration."dton_iEN"(p_date character varying) OWNER TO prvgwy;

--
-- TOC entry 1025 (class 1255 OID 445506)
-- Name: example(); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.example() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE 'SELECT * FROM cbscne.tabletest';
END;
$$;


ALTER FUNCTION ng_orchestration.example() OWNER TO prvgwy;

--
-- TOC entry 1129 (class 1255 OID 461633)
-- Name: get_two_users_from_school(bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.get_two_users_from_school(schoolid bigint) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
    begin

     return query
      SELECT "CaseId", "CustNm" FROM cbscne."EngrCase";

    end;
    $$;


ALTER FUNCTION ng_orchestration.get_two_users_from_school(schoolid bigint) OWNER TO prvgwy;

--
-- TOC entry 1156 (class 1255 OID 214468)
-- Name: getalldocuments(bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.getalldocuments(par_entityid bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    var_docName VARCHAR(60000);
BEGIN
    SELECT
        STRING_AGG(d.doc_name, ', ')::VARCHAR(60000)
        INTO var_docName
        FROM ng_orchestration.tbl_manifest_docs AS d, ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
        WHERE d.document_id = map.document_id AND map.manifest_id = m.manifest_id AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1));
    RETURN var_docName;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                RAISE;
            END;
END;
$$;


ALTER FUNCTION ng_orchestration.getalldocuments(par_entityid bigint) OWNER TO dbadmin;

--
-- TOC entry 1136 (class 1255 OID 468786)
-- Name: getdate(); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getdate() RETURNS timestamp with time zone
    LANGUAGE plpgsql
    AS $$
begin
return now();
end;
$$;


ALTER FUNCTION ng_orchestration.getdate() OWNER TO prvgwy;

--
-- TOC entry 1056 (class 1255 OID 214469)
-- Name: getmanifest(bigint, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmanifest(par_entityid bigint, par_docname character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$DECLARE
    var_manifestdoc VARCHAR(60000);
BEGIN
    SELECT
        d.document::VARCHAR(60000)
        INTO var_manifestdoc
        FROM ng_orchestration.tbl_manifest_docs AS d, ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
        WHERE LOWER(d.doc_name) = LOWER(par_docname) AND d.document_id = map.document_id AND map.manifest_id = m.manifest_id AND
                LOWER(map.doc_name) = LOWER(par_docname) AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1));
    RETURN var_manifestdoc;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                RAISE;
            END;
END;$$;


ALTER FUNCTION ng_orchestration.getmanifest(par_entityid bigint, par_docname character varying) OWNER TO prvgwy;

--
-- TOC entry 1057 (class 1255 OID 214470)
-- Name: getmanifesttest(bigint, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.getmanifesttest(par_entityid bigint, par_docname character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    var_manifestdoc VARCHAR(60000);
BEGIN
    SELECT
        d.document::VARCHAR(60000)
        INTO var_manifestdoc
        FROM ng_orchestration.tbl_manifest_docs AS d, ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
        WHERE LOWER(d.doc_name) = LOWER(par_docname) AND d.document_id = map.document_id AND map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1));
    RETURN var_manifestdoc;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                RAISE;
            END;
END;
$$;


ALTER FUNCTION ng_orchestration.getmanifesttest(par_entityid bigint, par_docname character varying) OWNER TO dbadmin;

--
-- TOC entry 1058 (class 1255 OID 233890)
-- Name: getmetadata(text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmetadata(t_name text, s_name text) RETURNS TABLE(cname information_schema.sql_identifier, dtype information_schema.character_data)
    LANGUAGE plpgsql
    AS $$


    BEGIN
      RETURN QUERY SELECT COLUMN_NAME AS cname ,DATA_TYPE AS dtype FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = s_name AND TABLE_NAME =t_name ORDER BY ORDINAL_POSITION ASC;
    END;

$$;


ALTER FUNCTION ng_orchestration.getmetadata(t_name text, s_name text) OWNER TO prvgwy;

--
-- TOC entry 1059 (class 1255 OID 233476)
-- Name: getmetadatanew(character varying, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmetadatanew(table_schema character varying, table_name character varying) RETURNS void
    LANGUAGE sql
    AS $_$DO $$
DECLARE
  table_schema varchar(20) := 'pg_catalog';
  table_name   varchar(20) := 'pg_proc';
BEGIN
PREPARE stment AS (select COLUMN_NAME,DATA_TYPE from information_schema.COLUMNS
where TABLE_SCHEMA = $1 and TABLE_NAME = $2
order by ORDINAL_POSITION ASC);
 EXECUTE ng_orchestration.stment (table_schema,table_name);
 DEALLOCATE PREPARE stment;
END $$;
$_$;


ALTER FUNCTION ng_orchestration.getmetadatanew(table_schema character varying, table_name character varying) OWNER TO prvgwy;

--
-- TOC entry 1125 (class 1255 OID 214459)
-- Name: getmetadataold(character varying, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmetadataold(par_tab_name character varying, par_schema_name character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    /*
    [8828 - Severity CRITICAL - User-defined variables is not supported in PostgreSQL. Perform a manual conversion.]
    SET @qry =CONCAT('select COLUMN_NAME,DATA_TYPE from information_schema.COLUMNS where TABLE_SCHEMA =',schema_name,' and TABLE_NAME =',tab_name,' order by ORDINAL_POSITION ASC')
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    PREPARE stment FROM @qry
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    EXECUTE stment
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    DEALLOCATE PREPARE stment
    */
    BEGIN
    END;
END;
$$;


ALTER FUNCTION ng_orchestration.getmetadataold(par_tab_name character varying, par_schema_name character varying) OWNER TO prvgwy;

--
-- TOC entry 1060 (class 1255 OID 233518)
-- Name: getmetadataold1(text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmetadataold1(s_name text, t_name text) RETURNS TABLE(cname information_schema.sql_identifier, dtype information_schema.character_data)
    LANGUAGE plpgsql
    AS $$

    BEGIN
      RETURN QUERY SELECT COLUMN_NAME AS cname ,DATA_TYPE AS dtype FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = s_name AND TABLE_NAME =t_name ORDER BY ORDINAL_POSITION ASC;
    END;
    $$;


ALTER FUNCTION ng_orchestration.getmetadataold1(s_name text, t_name text) OWNER TO prvgwy;

--
-- TOC entry 1061 (class 1255 OID 214460)
-- Name: getmetadatatest(character varying, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmetadatatest(par_tab_name character varying, par_schema_name character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    /*
    [8828 - Severity CRITICAL - User-defined variables is not supported in PostgreSQL. Perform a manual conversion.]
    SET @qry =CONCAT('select COLUMN_NAME,DATA_TYPE from information_schema.COLUMNS where TABLE_SCHEMA =',schema_name,' and TABLE_NAME =',tab_name,' order by ORDINAL_POSITION ASC')
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    PREPARE stment FROM @qry
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    EXECUTE stment
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    DEALLOCATE PREPARE stment
    */
    BEGIN
    END;
END;
$$;


ALTER FUNCTION ng_orchestration.getmetadatatest(par_tab_name character varying, par_schema_name character varying) OWNER TO prvgwy;

--
-- TOC entry 1053 (class 1255 OID 276442)
-- Name: getmetadatatest2(text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.getmetadatatest2(t_name text, s_name text) RETURNS TABLE(cname information_schema.sql_identifier, dtype information_schema.character_data)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY
        SELECT COLUMN_NAME AS cname ,DATA_TYPE AS dtype
        FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = s_name
        AND TABLE_NAME =t_name
        ORDER BY ORDINAL_POSITION ASC;
END

$$;


ALTER FUNCTION ng_orchestration.getmetadatatest2(t_name text, s_name text) OWNER TO prvgwy;

--
-- TOC entry 1144 (class 1255 OID 542358)
-- Name: id_to_string(bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.id_to_string(cr_id bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

DECLARE
        string_cr_id varchar(6);
        base_number BIGINT = 36;
        mod_value INTEGER;
        quotient BIGINT;
        db_count BIGINT = 0;

BEGIN

        IF(cr_id < 1000000) THEN
                Select CAST(cr_id as varchar) into string_cr_id;
                 RAISE NOTICE '%', string_cr_id;
        ELSE
                 quotient := cr_id;
                LOOP
                        db_count :=  db_count + 1 ;
                        RAISE NOTICE '%D', db_count;
                        Select MOD(quotient, base_number) into mod_value;
                        Select FLOOR(quotient/base_number) into quotient;
                        RAISE NOTICE '%M', mod_value;
                        IF(mod_value < 10) THEN
                                --Select CHR(mod_value + 48) || string_cr_id into string_cr_id;
                                 Select concat(CHR(mod_value + 48),string_cr_id) into string_cr_id;
                        ELSE
                                 --Select CHR(mod_value + 55) || string_cr_id into string_cr_id;
                                 Select concat(CHR(mod_value + 55),string_cr_id) into string_cr_id;
                                RAISE NOTICE '%S', string_cr_id;
                        END IF;
                        IF(quotient <= 0) THEN
                                EXIT;
                        END IF;
                END LOOP;
                Select LPAD(string_cr_id, 6, '0') into string_cr_id;
                RAISE NOTICE '%LS', string_cr_id;
        END IF;

        RETURN (string_cr_id);
END;
$$;


ALTER FUNCTION ng_orchestration.id_to_string(cr_id bigint) OWNER TO prvgwy;

--
-- TOC entry 1010 (class 1255 OID 542362)
-- Name: id_to_string_notUsed(character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration."id_to_string_notUsed"(cr_id character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

DECLARE
        string_cr_id varchar(6);
        base_number BIGINT = 36;
        mod_value BIGINT;
        quotient INT;
        db_count BIGINT = 0;

BEGIN

        IF(CAST (cr_id AS INTEGER) < 1000000) THEN
                string_cr_id := cr_id;
        ELSE
                quotient := cr_id;
                LOOP
                        db_count := db_count + 1;
                        mod_value := MOD(quotient, base_number);
                        quotient := FLOOR(quotient/base_number);
                        IF(mod_value < 10) THEN
                                string_cr_id := CHR(mod_value + 48) || string_cr_id;
                        ELSE
                                string_cr_id := CHR(mod_value + 55) || string_cr_id;
                        END IF;
                        IF(quotient <= 0) THEN
                                EXIT;
                        END IF;
                END LOOP;
                string_cr_id := LPAD(string_cr_id, 6, '0');
        END IF;

        RETURN (string_cr_id);
END;
$$;


ALTER FUNCTION ng_orchestration."id_to_string_notUsed"(cr_id character varying) OWNER TO prvgwy;

--
-- TOC entry 1011 (class 1255 OID 542359)
-- Name: id_to_string_not_Used(numeric); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration."id_to_string_not_Used"(cr_id numeric) RETURNS character varying
    LANGUAGE plpgsql
    AS $$

DECLARE
        string_cr_id varchar(6);
        base_number BIGINT = 36;
        mod_value BIGINT;
        quotient INT;
        db_count BIGINT = 0;

BEGIN

        IF(cr_id < 1000000) THEN
                string_cr_id := to_char(cr_id);
        ELSE
                quotient := cr_id;
                LOOP
                        db_count := db_count + 1;
                        mod_value := MOD(quotient, base_number);
                        quotient := FLOOR(quotient/base_number);
                        IF(mod_value < 10) THEN
                                string_cr_id := CHR(mod_value + 48) || string_cr_id;
                        ELSE
                                string_cr_id := CHR(mod_value + 55) || string_cr_id;
                        END IF;
                        IF(quotient <= 0) THEN
                                EXIT;
                        END IF;
                END LOOP;
                string_cr_id := LPAD(string_cr_id, 6, '0');
        END IF;

        RETURN (string_cr_id);
END;
$$;


ALTER FUNCTION ng_orchestration."id_to_string_not_Used"(cr_id numeric) OWNER TO prvgwy;

--
-- TOC entry 1067 (class 1255 OID 234117)
-- Name: insertentitydata(regclass, bigint, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydata(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$


  DECLARE

    val text;
    colvalues text[] := string_to_array(valueString,',');
    valarrtoString text := '';

  BEGIN

   FOREACH val IN ARRAY colvalues

       LOOP
             if ( SUBSTR(val,1,1) ='"') then
                    val = replace(val,'"','');
            valarrtoString := valarrtoString ||quote_literal(val)|| ',';
                 else
                    valarrtoString := valarrtoString || val || ',';
             END IF;

       END LOOP;

        valarrtoString := RTRIM(valarrtoString, ',');

        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date'|| _columnstring||') VALUES($1,$2,CURRENT_TIMESTAMP'|| valarrtoString ||')', _tbl) USING entity_id, app_id::BIGINT;
      END;

$_$;


ALTER FUNCTION ng_orchestration.insertentitydata(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1126 (class 1255 OID 233900)
-- Name: insertentitydataold(regclass, bigint, bigint, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
  DECLARE
   cstring varchar;
  right_now timestamp;
      BEGIN
      cstring := _columnstring::varchar;
        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date,%I) VALUES($1,$2,CURRENT_TIMESTAMP,$3)', _tbl,cstring) USING entity_id, app_id, valuestring;
      END;
$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1157 (class 1255 OID 214461)
-- Name: insertentitydataold(character varying, bigint, bigint, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold(par_tab_name character varying, par_entity_id bigint, par_app_id bigint, par_columnstring text, par_valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    /*
    [8828 - Severity CRITICAL - User-defined variables is not supported in PostgreSQL. Perform a manual conversion.]
    set @qry=concat( 'insert into ',tab_name,'(entity_id,app_id,create_date',columnString,') values(',entity_id,',',app_id,',now()',valueString,')' )
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    prepare stment from @qry
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    execute stment
    */
    /*
    [8672 - Severity CRITICAL - Automatic conversion of this command is not supported. Perform a manual conversion.]
    deallocate prepare stment
    */
    BEGIN
    END;
END;
$$;


ALTER FUNCTION ng_orchestration.insertentitydataold(par_tab_name character varying, par_entity_id bigint, par_app_id bigint, par_columnstring text, par_valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1158 (class 1255 OID 233888)
-- Name: insertentitydataold1(regclass, bigint, bigint, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold1(_tbl regclass, entity_id bigint, app_id bigint, columnstring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$

  DECLARE
  right_now timestamp;
      BEGIN
        EXECUTE format('INSERT INTO  %I VALUES($1,$2,CURRENT_TIMESTAMP,$3)', _tbl) USING entity_id, app_id,  columnString ;

      END;

$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold1(_tbl regclass, entity_id bigint, app_id bigint, columnstring text) OWNER TO prvgwy;

--
-- TOC entry 1068 (class 1255 OID 233891)
-- Name: insertentitydataold2(regclass, bigint, text, regclass, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold2(_tbl regclass, entity_id bigint, app_id text, columnstring regclass, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$

  DECLARE
  right_now timestamp;
      BEGIN
        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date,%I) VALUES($1,$2,CURRENT_TIMESTAMP,$3)', _tbl,columnstring) USING entity_id, app_id, valuestring;

      END;


$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold2(_tbl regclass, entity_id bigint, app_id text, columnstring regclass, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1069 (class 1255 OID 233889)
-- Name: insertentitydataold3(regclass, bigint, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold3(_tbl regclass, entity_id bigint, app_id text, columnstring text, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$

  DECLARE
  right_now timestamp;
      BEGIN
        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date,%I) VALUES($1,$2,CURRENT_TIMESTAMP,$3)', _tbl,columnstring) USING entity_id, app_id, valuestring;

      END;

$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold3(_tbl regclass, entity_id bigint, app_id text, columnstring text, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1070 (class 1255 OID 233894)
-- Name: insertentitydataold4(regclass, bigint, text, character varying, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold4(_tbl regclass, entity_id bigint, app_id text, _columnstring character varying, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
  DECLARE
  right_now timestamp;
      BEGIN
        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date,%I) VALUES($1,$2,CURRENT_TIMESTAMP,$3)', _tbl,quote_nullable(_columnstring)) USING entity_id, app_id, valuestring;
      END;
$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold4(_tbl regclass, entity_id bigint, app_id text, _columnstring character varying, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1071 (class 1255 OID 234109)
-- Name: insertentitydataold5(regclass, bigint, bigint, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold5(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
  DECLARE
   cstring varchar;
  right_now timestamp;
      BEGIN
     cstring := COALESCE(_columnstring);

        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date,'|| cstring||') VALUES($1,$2,CURRENT_TIMESTAMP,'|| valuestring||')', _tbl) USING entity_id, app_id;
      END;
$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold5(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1072 (class 1255 OID 234111)
-- Name: insertentitydataold6(regclass, bigint, text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydataold6(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$


  DECLARE
   cstring varchar;
  right_now timestamp;
      BEGIN
     cstring := COALESCE(_columnstring);

        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date'|| cstring||') VALUES($1,$2,CURRENT_TIMESTAMP'|| valuestring ||')', _tbl) USING entity_id, app_id::BIGINT;
      END;

$_$;


ALTER FUNCTION ng_orchestration.insertentitydataold6(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1083 (class 1255 OID 233902)
-- Name: insertentitydatatest(regclass, bigint, bigint, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.insertentitydatatest(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) RETURNS void
    LANGUAGE plpgsql
    AS $_$
  DECLARE
   cstring varchar;
  right_now timestamp;
      BEGIN
     cstring := COALESCE(_columnstring);

        EXECUTE format('INSERT INTO  %I(entity_id,app_id,create_date,'|| cstring||') VALUES($1,$2,CURRENT_TIMESTAMP,'|| valuestring||')', _tbl) USING entity_id, app_id;
      END;
$_$;


ALTER FUNCTION ng_orchestration.insertentitydatatest(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) OWNER TO prvgwy;

--
-- TOC entry 1132 (class 1255 OID 468787)
-- Name: isnull(anyelement, anyelement); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration."isnull"(anyelement, anyelement) RETURNS anyelement
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
begin
return coalesce($1,$2);
end;
$_$;


ALTER FUNCTION ng_orchestration."isnull"(anyelement, anyelement) OWNER TO prvgwy;

--
-- TOC entry 1108 (class 1255 OID 3525358)
-- Name: json_object_delete_keys(json, text[]); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.json_object_delete_keys(json json, VARIADIC keys_to_delete text[]) RETURNS json
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT COALESCE(
  (SELECT ('{' || string_agg(to_json("key") || ':' || "value", ',') || '}')
   FROM json_each("json")
   WHERE "key" <> ALL ("keys_to_delete")),
  '{}'
)::json
$$;


ALTER FUNCTION ng_orchestration.json_object_delete_keys(json json, VARIADIC keys_to_delete text[]) OWNER TO prvgwy;

--
-- TOC entry 1137 (class 1255 OID 468795)
-- Name: left(text, integer); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration."left"(text, integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
begin
return substr($1, 0, $2);
end;
$_$;


ALTER FUNCTION ng_orchestration."left"(text, integer) OWNER TO prvgwy;

--
-- TOC entry 1159 (class 1255 OID 468794)
-- Name: len(text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.len(text) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
begin
return char_length($1);
end;
$_$;


ALTER FUNCTION ng_orchestration.len(text) OWNER TO prvgwy;

--
-- TOC entry 1093 (class 1255 OID 577804)
-- Name: local_dton_not_Used(character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration."local_dton_not_Used"(p_date character varying) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    GMTDate             DATE;
    numDaysFlt          NUMERIC;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           DATE;
    octoberDate         DATE;
    TZStr               VARCHAR(5);
        floor_apr           NUMERIC;
        floor_oct           NUMERIC;
        trunc_value         Date;
        p_timestamp         timestamp;
        p_date_str          VARCHAR;
        p_date_TS           date;

BEGIN

    --yr := to_number(to_char(p_date, 'yyyy'),'9999');
        SELECT to_timestamp(p_date,'DD-MON-YYYY') into p_date_TS;
        Select extract(YEAR from p_date_TS) into yr;
        --SELECT date_trunc('year', p_date) into trunc_value;
        SELECT to_char(date_trunc('YEAR', p_date),'dd-MON-yy') into trunc_value;
        Select FLOOR(yr/4) into floor_apr;
        IF yr < 2007 THEN


        Select FLOOR(yr*5/4) into floor_oct;

        aprilDay := MOD((2 + 6*yr - floor_apr),7) + 1;
    octoberDay := 31 - MOD((floor_oct + 1),7);
        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

        ELSE

         aprilDay := MOD((5 + 6*yr - floor_apr),7) + 8;
         octoberDay := MOD((5 + 6*yr - floor_apr),7) + 1;

         aprilDate := trunc_value + interval '2 months' + aprilDay * interval '1 day';
         octoberDate := trunc_value + interval '10 months' + octoberDay * interval '1 day';
        END IF;

  IF p_date > aprilDate AND p_date < octoberDate THEN
        TZStr := 'EDT';
    ELSE
        TZStr := 'EST';
    END IF;
        Select to_char (p_date, 'DD-MON-YYYY') into p_date_str;
        SELECT to_timestamp(p_date_str,'DD-MON-YYYY') into p_timestamp;
   SELECT EXTRACT(EPOCH from ((p_timestamp  AT TIME ZONE TZStr) AT TIME ZONE 'GMT')) into numDaysFlt;


        RETURN numDaysFlt;
END;
$$;


ALTER FUNCTION ng_orchestration."local_dton_not_Used"(p_date character varying) OWNER TO prvgwy;

--
-- TOC entry 1160 (class 1255 OID 558552)
-- Name: local_dton_not_used(date); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_dton_not_used(p_date date) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    GMTDate             DATE;
    numDaysFlt          NUMERIC;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           DATE;
    octoberDate         DATE;
    TZStr               VARCHAR(5);
        floor_apr           NUMERIC;
        floor_oct           NUMERIC;
        trunc_value         Date;
        p_timestamp         timestamp;
        p_date_str          VARCHAR;

BEGIN

    --yr := to_number(to_char(p_date, 'yyyy'),'9999');
        Select extract(YEAR from p_date) into yr;
        --SELECT date_trunc('year', p_date) into trunc_value;
        SELECT to_char(date_trunc('YEAR', p_date),'dd-MON-yy') into trunc_value;
        Select FLOOR(yr/4) into floor_apr;
        IF yr < 2007 THEN


        Select FLOOR(yr*5/4) into floor_oct;

        aprilDay := MOD((2 + 6*yr - floor_apr),7) + 1;
    octoberDay := 31 - MOD((floor_oct + 1),7);
        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

        ELSE

         aprilDay := MOD((5 + 6*yr - floor_apr),7) + 8;
         octoberDay := MOD((5 + 6*yr - floor_apr),7) + 1;

         aprilDate := trunc_value + interval '2 months' + aprilDay * interval '1 day';
         octoberDate := trunc_value + interval '10 months' + octoberDay * interval '1 day';
        END IF;

  IF p_date > aprilDate AND p_date < octoberDate THEN
        TZStr := 'EDT';
    ELSE
        TZStr := 'EST';
    END IF;
        Select to_char (p_date, 'DD-MON-YYYY') into p_date_str;
        SELECT to_timestamp(p_date_str,'DD-MON-YYYY') into p_timestamp;
   SELECT EXTRACT(EPOCH from ((p_timestamp  AT TIME ZONE TZStr) AT TIME ZONE 'GMT')) into numDaysFlt;


        RETURN numDaysFlt;
END;
$$;


ALTER FUNCTION ng_orchestration.local_dton_not_used(p_date date) OWNER TO prvgwy;

--
-- TOC entry 1091 (class 1255 OID 577811)
-- Name: local_dton_pg(character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_dton_pg(p_date_ts character varying) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    GMTDate             DATE;
    numDaysFlt          NUMERIC;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           DATE;
    octoberDate         DATE;
    TZStr               VARCHAR(5);
        floor_apr           NUMERIC;
        floor_oct           NUMERIC;
        trunc_value         Date;
        p_timestamp         timestamp;
        p_date_str          VARCHAR;
        p_date              date;

BEGIN

    --yr := to_number(to_char(p_date, 'yyyy'),'9999');
        SELECT to_timestamp(p_date_TS,'DD-MON-YYYY') into p_date;
        Select extract(YEAR from p_date) into yr;
        --SELECT date_trunc('year', p_date) into trunc_value;
        SELECT to_char(date_trunc('YEAR', p_date),'dd-MON-yy') into trunc_value;
        Select FLOOR(yr/4) into floor_apr;
        IF yr < 2007 THEN


        Select FLOOR(yr*5/4) into floor_oct;

        aprilDay := MOD((2 + 6*yr - floor_apr),7) + 1;
    octoberDay := 31 - MOD((floor_oct + 1),7);
        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

        ELSE

         aprilDay := MOD((5 + 6*yr - floor_apr),7) + 8;
         octoberDay := MOD((5 + 6*yr - floor_apr),7) + 1;

         aprilDate := trunc_value + interval '2 months' + aprilDay * interval '1 day';
         octoberDate := trunc_value + interval '10 months' + octoberDay * interval '1 day';
        END IF;

  IF p_date > aprilDate AND p_date < octoberDate THEN
        TZStr := 'EDT';
    ELSE
        TZStr := 'EST';
    END IF;
        Select to_char (p_date, 'DD-MON-YYYY') into p_date_str;
        SELECT to_timestamp(p_date_str,'DD-MON-YYYY') into p_timestamp;
   SELECT EXTRACT(EPOCH from ((p_timestamp  AT TIME ZONE TZStr) AT TIME ZONE 'GMT')) into numDaysFlt;


        RETURN numDaysFlt;
END;
$$;


ALTER FUNCTION ng_orchestration.local_dton_pg(p_date_ts character varying) OWNER TO prvgwy;

--
-- TOC entry 1094 (class 1255 OID 1395071)
-- Name: local_dton_test(character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_dton_test(p_date character varying) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    GMTDate             DATE;
    numDaysFlt          NUMERIC;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           DATE;
    octoberDate         DATE;
    TZStr               VARCHAR(5);
        floor_apr           NUMERIC;
        floor_oct           NUMERIC;
        trunc_value         Date;
        p_timestamp         timestamp;
        p_date_str          VARCHAR;

BEGIN

   -- yr := to_number(to_char(p_date, 'YYYY'),'9999');
        SELECT to_timestamp(p_date_TS,'DD-MON-YYYY') into p_date;
        Select extract(YEAR from p_date) into yr;
        --SELECT date_trunc('year', p_date) into trunc_value;
        SELECT to_char(date_trunc('YEAR', p_date),'dd-MON-yy') into trunc_value;
        Select FLOOR(yr/4) into floor_apr;
        IF yr < 2007 THEN


        Select FLOOR(yr*5/4) into floor_oct;

        aprilDay := MOD((2 + 6*yr - floor_apr),7) + 1;
    octoberDay := 31 - MOD((floor_oct + 1),7);
        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

        ELSE

         aprilDay := MOD((5 + 6*yr - floor_apr),7) + 8;
         octoberDay := MOD((5 + 6*yr - floor_apr),7) + 1;

         aprilDate := trunc_value + interval '2 months' + aprilDay * interval '1 day';
         octoberDate := trunc_value + interval '10 months' + octoberDay * interval '1 day';
        END IF;

  IF p_date > aprilDate AND p_date < octoberDate THEN
        TZStr := 'EDT';
    ELSE
        TZStr := 'EST';
    END IF;
        Select to_char (p_date, 'DD-MON-YYYY') into p_date_str;
        SELECT to_timestamp(p_date_str,'DD-MON-YYYY') into p_timestamp;
   SELECT EXTRACT(EPOCH from ((p_timestamp  AT TIME ZONE TZStr) AT TIME ZONE 'GMT')) into numDaysFlt;

        RETURN numDaysFlt;
END;

$$;


ALTER FUNCTION ng_orchestration.local_dton_test(p_date character varying) OWNER TO prvgwy;

--
-- TOC entry 1012 (class 1255 OID 573776)
-- Name: local_dton_test_ien(date); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_dton_test_ien(p_date date) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    GMTDate             DATE;
    numDaysFlt          NUMERIC;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           DATE;
    octoberDate         DATE;
    TZStr               VARCHAR(5);
        floor_apr           NUMERIC;
        floor_oct           NUMERIC;
        trunc_value         Date;
        p_timestamp         timestamp;
        p_date_str          VARCHAR;

BEGIN

    yr := to_number(to_char(p_date, 'YYYY'),'9999');

        --SELECT date_trunc('year', p_date) into trunc_value;
        SELECT to_char(date_trunc('YEAR', p_date),'dd-MON-yy') into trunc_value;
        Select FLOOR(yr/4) into floor_apr;
        IF yr < 2007 THEN


        Select FLOOR(yr*5/4) into floor_oct;

        aprilDay := MOD((2 + 6*yr - floor_apr),7) + 1;
    octoberDay := 31 - MOD((floor_oct + 1),7);
        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

        ELSE

         aprilDay := MOD((5 + 6*yr - floor_apr),7) + 8;
         octoberDay := MOD((5 + 6*yr - floor_apr),7) + 1;

         aprilDate := trunc_value + interval '2 months' + aprilDay * interval '1 day';
         octoberDate := trunc_value + interval '10 months' + octoberDay * interval '1 day';
        END IF;

  IF p_date > aprilDate AND p_date < octoberDate THEN
        TZStr := 'EDT';
    ELSE
        TZStr := 'EST';
    END IF;
        Select to_char (p_date, 'DD-MON-YYYY') into p_date_str;
        SELECT to_timestamp(p_date_str,'DD-MON-YYYY') into p_timestamp;
   SELECT EXTRACT(EPOCH from ((p_timestamp  AT TIME ZONE TZStr) AT TIME ZONE 'GMT')) into numDaysFlt;
-- SELECT to_char(((p_date AT TIME ZONE TZStr) AT TIME ZONE 'GMT'),'dd-MON-yy') into GMTDate;
 --SELECT GMTDate - to_char(to_date('19700101000000', 'YYYYMMDDHH24MISS'),'dd-MON-yy') into numDaysFlt;

        RETURN numDaysFlt;
END;
$$;


ALTER FUNCTION ng_orchestration.local_dton_test_ien(p_date date) OWNER TO prvgwy;

--
-- TOC entry 1149 (class 1255 OID 558557)
-- Name: local_ntod(numeric); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_ntod(p_num numeric) RETURNS date
    LANGUAGE plpgsql IMMUTABLE
    AS $$


DECLARE
    dtDays              TIMESTAMP WITH TIME ZONE;
    numDaysFlt          INTEGER;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           TIMESTAMP WITH TIME ZONE;
    octoberDate         TIMESTAMP WITH TIME ZONE;
    TZStr               VARCHAR(3);
        result_date         TIMESTAMP WITH TIME ZONE;
        floor_apr           NUMERIC;
        floor_oct           NUMERIC;
        trunc_value         TIMESTAMP WITH TIME ZONE;
        --p_timestamp         Date;
BEGIN

    IF p_num <= 0 THEN
        RETURN NULL;
        END IF;

    numDaysFlt := p_num/(24*60*60);

        SELECT to_date('19700101000000', 'YYYYMMDDHH24MISS') + numDaysFlt * interval '1 day' INTO dtDays;
        yr := to_number(to_char(dtDays, 'YYYY'),'9999');
        Select FLOOR(yr/4) into floor_apr;
        Select FLOOR(yr*5/4) into floor_oct;
        SELECT to_char(date_trunc('YEAR', dtDays),'dd-MON-yy') into trunc_value;

        IF yr < 2007 THEN

        aprilDay := MOD((2 + 6*yr - floor_apr),7) + 1;
        octoberDay := 31 - MOD((floor_oct + 1),7);

        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

        ELSE

        aprilDay := MOD((5 + 6*yr - floor_apr),7) + 8;
         octoberDay := MOD((5 + 6*yr - floor_apr),7) + 1;

        aprilDate := trunc_value + interval '3 months' + aprilDay * interval '1 day';
        octoberDate := trunc_value + interval '9 months' +  octoberDay * interval '1 day';

         aprilDate := trunc_value + interval '2 months' + aprilDay * interval '1 day';
         octoberDate := trunc_value + interval '10 months' + octoberDay * interval '1 day';
        END IF;

        IF dtDays > aprilDate AND dtDays < octoberDate THEN
        TZStr := 'EDT';
    ELSE
        TZStr := 'EST';
    END IF;

        SELECT (dtDays AT TIME ZONE 'GMT') AT TIME ZONE TZStr into result_date;

 RETURN result_date;

END;
$$;


ALTER FUNCTION ng_orchestration.local_ntod(p_num numeric) OWNER TO prvgwy;

--
-- TOC entry 1150 (class 1255 OID 571742)
-- Name: local_ntod_tes_ien(numeric); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_ntod_tes_ien(p_num numeric) RETURNS date
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    dtDays              TIMESTAMP WITH TIME ZONE;
    numDaysFlt          INTEGER;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           TIMESTAMP WITH TIME ZONE;
    octoberDate         TIMESTAMP WITH TIME ZONE;
    TZStr               VARCHAR(3);
mod_value           INTEGER;
floor_value         BIGINT;
floor_value2        BIGINT;
trunc_value         TIMESTAMP WITH TIME ZONE;
april_date TIMESTAMP WITH TIME ZONE;
october_date TIMESTAMP WITH TIME ZONE;
OldStr VARCHAR(3);
result_date TIMESTAMP WITH TIME ZONE;

BEGIN

    IF p_num <= 0 THEN RETURN NULL; END IF;

    numDaysFlt := p_num/(24*60*60);

    SELECT to_date('19700101000000', 'YYYYMMDDHH24MISS') + numDaysFlt * interval '1 day' INTO dtDays;


    yr := to_number(to_char(dtDays, 'YYYY'),'9999');
   Select FLOOR(yr/4) into floor_value;
   select FLOOR(yr*5/4) into floor_Value2;

IF yr < 2007 THEN

    aprilDay := MOD((2 + 6*yr - floor_value),7) + 1;
    octoberDay := 31 - MOD((floor_Value2 + 1),7);

    select date_trunc('YEAR', dtDays) into trunc_value;
    select trunc_value + interval '3 month' into april_date;
    select trunc_value + interval '9 month' into october_date;

    aprilDate := april_date + aprilDay * interval '1 day';
    octoberDate := october_date + octoberDay * interval '1 day';

ELSE

    aprilDay := MOD((5 + 6*yr - floor_value),7) + 8;
    octoberDay := MOD((5 + 6*yr - floor_value),7) + 1;

    select date_trunc('YEAR', dtDays) into trunc_value;
    select trunc_value + interval '2 month' into april_date;
    select trunc_value + interval '10 month' into october_date;

    aprilDate := april_date + aprilDay * interval '1 day';
    octoberDate := october_date + octoberDay * interval '1 day';

END IF;

    IF dtDays > aprilDate AND dtDays < octoberDate THEN
        TZStr := 'EDT';
        OldStr := 'GMT';
    ELSE
        TZStr := 'EST';
        OldStr := 'GMT';
    END IF;

SELECT timezone(TZStr,timezone(OldStr, dtDays)) into result_date;

    RETURN dtDays;

        END;
$$;


ALTER FUNCTION ng_orchestration.local_ntod_tes_ien(p_num numeric) OWNER TO prvgwy;

--
-- TOC entry 1147 (class 1255 OID 564828)
-- Name: local_ntod_test(integer); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_ntod_test(p_num integer) RETURNS date
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    dtDays              TIMESTAMP WITH TIME ZONE;
    numDaysFlt          INTEGER;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           TIMESTAMP WITH TIME ZONE;
    octoberDate         TIMESTAMP WITH TIME ZONE;
    TZStr               VARCHAR(3);
        mod_value           INTEGER;
        floor_value         BIGINT;
        floor_value2        BIGINT;
        trunc_value         TIMESTAMP WITH TIME ZONE;
        april_date                      TIMESTAMP WITH TIME ZONE;
        october_date            TIMESTAMP WITH TIME ZONE;
        OldStr                          VARCHAR(3);
        result_date             TIMESTAMP WITH TIME ZONE;

BEGIN

    IF p_num <= 0 THEN RETURN NULL; END IF;

    numDaysFlt := p_num/(24*60*60);

    SELECT to_date('19700101000000', 'YYYYMMDDHH24MISS') + numDaysFlt * interval '1 day' INTO dtDays;
        --SELECT to_timestamp('1970JAN01', 'YYYYMONDD') + numDaysFlt * interval '1 day' INTO dtDays;
        RAISE NOTICE 'Value: %', dtDays;

    yr := to_number(to_char(dtDays, 'YYYY'),'9999');
        Select FLOOR(yr/4) into floor_value;
        select FLOOR(yr*5/4) into floor_Value2;

IF yr < 2007 THEN

    aprilDay := MOD((2 + 6*yr - floor_value),7) + 1;
    octoberDay := 31 - MOD((floor_Value2 + 1),7);

        select date_trunc('YEAR', dtDays) into trunc_value;
        select trunc_value + interval '3 month' into april_date;
        select trunc_value + interval '9 month' into october_date;

        aprilDate := april_date + aprilDay * interval '1 day';
    octoberDate := october_date + octoberDay * interval '1 day';

ELSE

        aprilDay := MOD((5 + 6*yr - floor_value),7) + 8;
    octoberDay := MOD((5 + 6*yr - floor_value),7) + 1;

        select date_trunc('YEAR', dtDays) into trunc_value;
        select trunc_value + interval '2 month' into april_date;
        select trunc_value + interval '10 month' into october_date;

    aprilDate := april_date + aprilDay * interval '1 day';
    octoberDate := october_date + octoberDay * interval '1 day';

END IF;

    IF dtDays > aprilDate AND dtDays < octoberDate THEN
        TZStr := 'EDT';
                OldStr := 'GMT';
    ELSE
        TZStr := 'EST';
                OldStr := 'GMT';
    END IF;
        --result_date := new_time(dtDays,OldStr,TZStr);
        --SELECT CONVERT_TIMEZONE ( OldStr, TZStr, dtDays) into result_date;
        SELECT timezone(TZStr,timezone(OldStr, dtDays)) into result_date;
        -- select new_time(dtDays,OldStr,TZStr) into result_date;
    RETURN result_date;
END;

$$;


ALTER FUNCTION ng_orchestration.local_ntod_test(p_num integer) OWNER TO prvgwy;

--
-- TOC entry 1148 (class 1255 OID 561838)
-- Name: local_ntod_test(numeric); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.local_ntod_test(p_num numeric) RETURNS date
    LANGUAGE plpgsql IMMUTABLE
    AS $$

DECLARE
    dtDays              TIMESTAMP WITH TIME ZONE;
    numDaysFlt          INTEGER;
    yr                  INTEGER;
    aprilDay            INTEGER;
    octoberDay          INTEGER;
    aprilDate           TIMESTAMP WITH TIME ZONE;
    octoberDate         TIMESTAMP WITH TIME ZONE;
    TZStr               VARCHAR(3);
mod_value           INTEGER;
floor_value         BIGINT;
floor_value2        BIGINT;
trunc_value         TIMESTAMP WITH TIME ZONE;
april_date TIMESTAMP WITH TIME ZONE;
october_date TIMESTAMP WITH TIME ZONE;
OldStr VARCHAR(3);
result_date TIMESTAMP WITH TIME ZONE;

BEGIN

    IF p_num <= 0 THEN RETURN NULL; END IF;

    numDaysFlt := p_num/(24*60*60);

    SELECT to_date('19700101000000', 'YYYYMMDDHH24MISS') + numDaysFlt * interval '1 day' INTO dtDays;
--SELECT to_timestamp('1970JAN01', 'YYYYMONDD') + numDaysFlt * interval '1 day' INTO dtDays;
RAISE NOTICE 'Value: %', dtDays;

    yr := to_number(to_char(dtDays, 'YYYY'),'9999');
Select FLOOR(yr/4) into floor_value;
select FLOOR(yr*5/4) into floor_Value2;

IF yr < 2007 THEN

    aprilDay := MOD((2 + 6*yr - floor_value),7) + 1;
    octoberDay := 31 - MOD((floor_Value2 + 1),7);

select date_trunc('YEAR', dtDays) into trunc_value;
select trunc_value + interval '3 month' into april_date;
select trunc_value + interval '9 month' into october_date;

aprilDate := april_date + aprilDay * interval '1 day';
    octoberDate := october_date + octoberDay * interval '1 day';

ELSE

aprilDay := MOD((5 + 6*yr - floor_value),7) + 8;
    octoberDay := MOD((5 + 6*yr - floor_value),7) + 1;

select date_trunc('YEAR', dtDays) into trunc_value;
select trunc_value + interval '2 month' into april_date;
select trunc_value + interval '10 month' into october_date;

    aprilDate := april_date + aprilDay * interval '1 day';
    octoberDate := october_date + octoberDay * interval '1 day';

END IF;

    IF dtDays > aprilDate AND dtDays < octoberDate THEN
        TZStr := 'EDT';
OldStr := 'GMT';
    ELSE
        TZStr := 'EST';
OldStr := 'GMT';
    END IF;
--result_date := new_time(dtDays,OldStr,TZStr);
--SELECT CONVERT_TIMEZONE ( OldStr, TZStr, dtDays) into result_date;
SELECT timezone(TZStr,timezone(OldStr, dtDays)) into result_date;
-- select new_time(dtDays,OldStr,TZStr) into result_date;
    RETURN result_date;
END;

$$;


ALTER FUNCTION ng_orchestration.local_ntod_test(p_num numeric) OWNER TO prvgwy;

--
-- TOC entry 1146 (class 1255 OID 602364)
-- Name: manifest_backup_config_docs(); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.manifest_backup_config_docs() RETURNS bigint
    LANGUAGE plpgsql
    AS $$

DECLARE
        row_count bigint;
        table_name character varying(42);
        old_table character varying(42);
BEGIN
        table_name:= 'manifest_document_backup_config_' || to_char(CURRENT_DATE, 'YYYY_MM_DD');
        old_table:='manifest_document_backup_config_' || to_char((CURRENT_DATE-'4 days'::interval), 'YYYY_MM_DD');
        EXECUTE format('CREATE TABLE IF NOT EXISTS %s as select * from manifest_document where app_id in (select app_id from manifest_app_config where app_key like ''%%IEN_PROV%%'')', table_name);
        EXECUTE 'select count(doc_id) from manifest_document where app_id in (select app_id from manifest_app_config where app_key like ''%%IEN_PROV%%'')' into row_count;
        EXECUTE format('DROP TABLE IF EXISTS %s;', old_table);
        RETURN row_count;
END;
$$;


ALTER FUNCTION ng_orchestration.manifest_backup_config_docs() OWNER TO prvgwy;

--
-- TOC entry 1084 (class 1255 OID 468789)
-- Name: month(timestamp without time zone); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.month(timestamp without time zone) RETURNS integer
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
begin
return extract(month from $1);
end;
$_$;


ALTER FUNCTION ng_orchestration.month(timestamp without time zone) OWNER TO prvgwy;

--
-- TOC entry 1085 (class 1255 OID 461614)
-- Name: my_function(anyelement); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.my_function(_rowtype anyelement) RETURNS SETOF anyelement
    LANGUAGE plpgsql
    AS $$
BEGIN
   RETURN QUERY EXECUTE format(
     'SELECT * FROM %s LIMIT 10'
    , pg_typeof(_rowtype)  -- pg_typeof() returns regtype, quoted where necessary
      );
END
$$;


ALTER FUNCTION ng_orchestration.my_function(_rowtype anyelement) OWNER TO prvgwy;

--
-- TOC entry 1113 (class 1255 OID 357326)
-- Name: ntod(integer); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.ntod(p_num integer) RETURNS date
    LANGUAGE plpgsql
    AS $$
DECLARE
        dtDays              DATE;
        numDaysFlt          INTEGER;
BEGIN
        numDaysFlt := p_num/(24*60*60);

        SELECT to_date('19700101000000', 'YYYYMMDDHH24MISS') + numDaysFlt
        INTO dtDays;

 RETURN (dtDays);
END;
$$;


ALTER FUNCTION ng_orchestration.ntod(p_num integer) OWNER TO prvgwy;

--
-- TOC entry 1086 (class 1255 OID 234110)
-- Name: postmanifest(bigint, character varying, integer, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.postmanifest(par_entityid bigint, par_docname character varying, par_append integer, par_manifestdoc character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$DECLARE
    var_existingManifest INTEGER DEFAULT 0;
    var_existingDoc INTEGER DEFAULT 0;
    var_local_manifest_id INTEGER DEFAULT 0;
    var_local_doc_id INTEGER DEFAULT 0;
    var_par_ent BIGINT := par_entityid;
    var_map_doc_id INTEGER DEFAULT 0;
BEGIN
    SELECT
        count(m.entity_id)::INTEGER
        INTO var_existingDoc
        FROM ng_orchestration.tbl_manifest AS m
        WHERE LOWER(m.active) = LOWER('N'::CHAR(1)) AND m.entity_id = var_par_ent;

    IF var_existingDoc > 0::INTEGER THEN
        PERFORM ng_orchestration.deletemanifest(var_par_ent);
    END IF;
    SELECT
        count(map.document_id)::INTEGER
        INTO var_existingDoc
        FROM ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
        WHERE m.entity_id = var_par_ent AND map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND LOWER(m.active) = LOWER('Y'::CHAR(1))
    /*
    [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
    start transaction
    */;


    IF var_existingDoc > 0::INTEGER THEN
        IF par_append > 0::INTEGER THEN
            UPDATE ng_orchestration.tbl_manifest_docs
            SET document = par_manifestdoc::VARCHAR(65000)
                WHERE LOWER(doc_name) = LOWER(par_docname) AND document_id IN (SELECT
                    map.document_id
                    FROM ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
                    WHERE map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1)));
        ELSE
            UPDATE ng_orchestration.tbl_manifest_docs
            SET document = par_manifestdoc::VARCHAR(65000)
                WHERE LOWER(doc_name) = LOWER(par_docname) AND document_id IN (SELECT
                    map.document_id
                    FROM ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
                    WHERE map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1)));
        END IF;
    ELSE
        SELECT
            COUNT(*)
            INTO var_existingManifest
            FROM ng_orchestration.tbl_manifest AS m
            WHERE m.entity_id = var_par_ent;

        IF var_existingManifest > 0::INTEGER THEN
            SELECT
                manifest_id::INTEGER
                INTO var_local_manifest_id
                FROM ng_orchestration.tbl_manifest
                WHERE entity_id = var_par_ent AND LOWER(active) = LOWER('Y'::CHAR(1));
        ELSE

            insert into tbl_manifest values (DEFAULT, var_par_ent, 'Y', current_date);
            SELECT currval('tbl_manifest_seq') into var_local_manifest_id;
            /*
            [8811 - Severity CRITICAL - PostgreSQL doesn't support the LAST_INSERT_ID() function. Create a user-defined function.]
            select LAST_INSERT_ID() into var_local_manifest_id
            */
                        --select max(manifest_id) into var_local_manifest_id from ng_orchestration.tbl_manifest;
            --SELECT CURRVAL(pg_get_serial_sequence('tbl_manifest','manifest_id')) into var_local_manifest_id;

            /*BEGIN
            END; */
        END IF;

        INSERT INTO ng_orchestration.tbl_manifest_docs
        VALUES (DEFAULT, par_docname, par_manifestdoc);
        SELECT currval('tbl_manifest_docs_seq') into var_local_doc_id;
       /* INSERT INTO ng_orchestration.tbl_manifest_docs
        VALUES (NULL, par_docname, par_manifestdoc);

        [8811 - Severity CRITICAL - PostgreSQL doesn't support the LAST_INSERT_ID() function. Create a user-defined function.]
        select LAST_INSERT_ID() into var_local_doc_id
        */
                --select max(document_id) into var_local_doc_id from ng_orchestration.tbl_manifest_docs;

        --SELECT CURRVAL(pg_get_serial_sequence('tbl_manifest_docs','document_id')) into var_local_doc_id;
        --var_local_doc_id = pg_query("SELECT CURRVAL(pg_get_serial_sequence('tbl_manifest_docs','document_id'))");

        INSERT INTO ng_orchestration.tbl_manifest_map
        VALUES (DEFAULT, var_local_doc_id, var_local_manifest_id, par_docname);
    END IF;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                /*
                [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
                rollback
                */
                RAISE ;
            END;

END;
$$;


ALTER FUNCTION ng_orchestration.postmanifest(par_entityid bigint, par_docname character varying, par_append integer, par_manifestdoc character varying) OWNER TO prvgwy;

--
-- TOC entry 1087 (class 1255 OID 214462)
-- Name: postmanifestold(bigint, character varying, smallint, character varying); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.postmanifestold(par_entityid bigint, par_docname character varying, par_append smallint, par_manifestdoc character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$DECLARE
    var_existingManifest INTEGER DEFAULT 0;
    var_existingDoc INTEGER DEFAULT 0;
    var_local_manifest_id INTEGER DEFAULT 0;
    var_local_doc_id INTEGER DEFAULT 0;
BEGIN
    SELECT
        count(m.entity_id)::INTEGER
        INTO var_existingDoc
        FROM ng_orchestration.tbl_manifest AS m
        WHERE LOWER(m.active) = LOWER('N'::CHAR(1)) AND m.entity_id = par_entityid;

    IF var_existingDoc > 0::INTEGER THEN
        PERFORM ng_orchestration.deletemanifest(par_entityid);
    END IF;
    SELECT
        count(map.document_id)::INTEGER
        INTO var_existingDoc
        FROM ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
        WHERE m.entity_id = par_entityid AND map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND LOWER(m.active) = LOWER('Y'::CHAR(1))
    /*
    [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
    start transaction
    */;


    IF var_existingDoc > 0::INTEGER THEN
        IF par_append > 0::SMALLINT THEN
            UPDATE ng_orchestration.tbl_manifest_docs
            SET document = par_manifestdoc::VARCHAR(65000)
                WHERE LOWER(doc_name) = LOWER(par_docname) AND document_id IN (SELECT
                    map.document_id
                    FROM ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
                    WHERE map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1)));
        ELSE
            UPDATE ng_orchestration.tbl_manifest_docs
            SET document = par_manifestdoc::VARCHAR(65000)
                WHERE LOWER(doc_name) = LOWER(par_docname) AND document_id IN (SELECT
                    map.document_id
                    FROM ng_orchestration.tbl_manifest_map AS map, ng_orchestration.tbl_manifest AS m
                    WHERE map.manifest_id = m.manifest_id AND LOWER(map.doc_name) = LOWER(par_docname) AND m.entity_id = par_entityid AND LOWER(m.active) = LOWER('Y'::CHAR(1)));
        END IF;
    ELSE
        SELECT
            COUNT(*)
            INTO var_existingManifest
            FROM ng_orchestration.tbl_manifest
            WHERE entity_id = par_entityid;

        IF var_existingManifest > 0::INTEGER THEN
            SELECT
                manifest_id::INTEGER
                INTO var_local_manifest_id
                FROM ng_orchestration.tbl_manifest
                WHERE entity_id = par_entityid AND LOWER(active) = LOWER('Y'::CHAR(1));
        ELSE

            insert into tbl_manifest values (null, entityid, 'Y', current_date);

            /*
            [8811 - Severity CRITICAL - PostgreSQL doesn't support the LAST_INSERT_ID() function. Create a user-defined function.]
            select LAST_INSERT_ID() into var_local_manifest_id
            */
                        select max(manifest_id) into var_local_manifest_id from ng_orchestration.tbl_manifest;

            /*BEGIN
            END; */
        END IF;
        INSERT INTO ng_orchestration.tbl_manifest_docs
        VALUES (NULL, par_docname, par_manifestdoc);
        /*
        [8811 - Severity CRITICAL - PostgreSQL doesn't support the LAST_INSERT_ID() function. Create a user-defined function.]
        select LAST_INSERT_ID() into var_local_doc_id
        */
                select max(doc_id) into var_local_doc_id from ng_orchestration.tbl_manifest_docs;

        INSERT INTO ng_orchestration.tbl_manifest_map
        VALUES (NULL, var_local_doc_id, var_local_manifest_id, par_docname);
    END IF;
    COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                /*
                [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
                rollback
                */
                RAISE;
            END;
END;$$;


ALTER FUNCTION ng_orchestration.postmanifestold(par_entityid bigint, par_docname character varying, par_append smallint, par_manifestdoc character varying) OWNER TO prvgwy;

--
-- TOC entry 1092 (class 1255 OID 214477)
-- Name: replace_into_project_cmd_cache(integer); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.replace_into_project_cmd_cache(par_project_details_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
-- Converted with error!
END;
$$;


ALTER FUNCTION ng_orchestration.replace_into_project_cmd_cache(par_project_details_id integer) OWNER TO dbadmin;

--
-- TOC entry 1138 (class 1255 OID 468792)
-- Name: space(integer); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.space(integer) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
begin
return repeat(' ',$1);
end;
$_$;


ALTER FUNCTION ng_orchestration.space(integer) OWNER TO prvgwy;

--
-- TOC entry 1168 (class 1255 OID 468788)
-- Name: strcat(text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.strcat(text, text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
begin
return $1 || $2;
end;
$_$;


ALTER FUNCTION ng_orchestration.strcat(text, text) OWNER TO prvgwy;

--
-- TOC entry 1122 (class 1255 OID 214464)
-- Name: sync_project_search_cache_purge_search_cache_event(bigint); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.sync_project_search_cache_purge_search_cache_event(par_p_event_id bigint) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM ng_orchestration.search_cache_event_monitor
        WHERE event_id = par_p_event_id;
END;
$$;


ALTER FUNCTION ng_orchestration.sync_project_search_cache_purge_search_cache_event(par_p_event_id bigint) OWNER TO dbadmin;

--
-- TOC entry 1005 (class 1255 OID 214465)
-- Name: sync_project_search_cache_sync_project_search_cache_inst(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_inst() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    var_v_event_id BIGINT;
    var_v_mod_type VARCHAR(1);
    var_v_table_name VARCHAR(100);
    var_v_key_name VARCHAR(100);
    var_v_key_value VARCHAR(100);
    var_v_status VARCHAR(50);
    var_v_trail_name VARCHAR(5000);
    var_cache_project_exit_loop BOOLEAN;
    cache_project_data_cursor CURSOR FOR
    SELECT
        event_id, table_name, key_name, key_value, mod_type, status
        FROM ng_orchestration.search_cache_event_monitor AS m
        WHERE LOWER(m.table_name) = LOWER('SEARCH_PROJECT'::VARCHAR(100));
BEGIN
    OPEN cache_project_data_cursor;

    <<cache_project_exit_loop>>
    LOOP
        FETCH cache_project_data_cursor INTO var_v_event_id, var_v_table_name, var_v_key_name, var_v_key_value, var_v_mod_type, var_v_status;

        IF NOT FOUND THEN
            EXIT cache_project_exit_loop;
        END IF;
        DELETE FROM ng_orchestration.project_cmd_cache
            WHERE project_id = var_v_key_value::INTEGER;
        SELECT
            trailobj.trail_name::VARCHAR(5000)
            INTO var_v_trail_name
            FROM (SELECT
                project_id, STRING_AGG(trail_name) AS trail_name
                FROM ng_orchestration.project_details
                WHERE project_id = var_v_key_value::INTEGER
                GROUP BY project_id) AS trailobj;

        IF LOWER(var_v_mod_type) IN (LOWER('U'), LOWER('I')) THEN
            INSERT INTO ng_orchestration.project_cmd_cache (project_id, command_cache)
            SELECT DISTINCT
                p.project_id, CONCAT_WS(' ', 'PROJECT_ID', REPLACE(p.project_id::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'NAME', REPLACE(p.name::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'COMMENTS', REPLACE(p.comments::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'PROJECT_NUMBER', REPLACE(p.project_number::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'TYPE', REPLACE(p.type::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'OWNER', REPLACE(p.owner::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'CONTACT', REPLACE(p.contact::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'START_DATE', REPLACE(p.start_date::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'CUT_OVER_DATE', REPLACE(p.cut_over_date::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'STATUS', REPLACE(p.status::VARCHAR, ' '::VARCHAR, ''::VARCHAR), 'TRAIL_NAME', var_v_trail_name) AS command_cache
                FROM ng_orchestration.project AS p
                WHERE p.project_id = var_v_key_value::INTEGER;
        END IF;
        PERFORM ng_orchestration.sync_project_search_cache_purge_search_cache_event(var_v_event_id);
    END LOOP cache_project_exit_loop;
    CLOSE cache_project_data_cursor;
END;
$$;


ALTER FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_inst() OWNER TO dbadmin;

--
-- TOC entry 1006 (class 1255 OID 214466)
-- Name: sync_project_search_cache_sync_project_search_cache_main(); Type: FUNCTION; Schema: ng_orchestration; Owner: dbadmin
--

CREATE FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_main() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM ng_orchestration.sync_project_search_cache_sync_project_search_cache_inst()
    /*
    [8807 - Severity CRITICAL - Transactions in functions PostgreSQL doesn't support. Perform a manual conversion.]
    commit
    */;
END;
$$;


ALTER FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_main() OWNER TO dbadmin;

--
-- TOC entry 1054 (class 1255 OID 468796)
-- Name: xp_sendmail(text, text, text); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.xp_sendmail(tofield text, message text, subject text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
begin
return 0;
end;
$$;


ALTER FUNCTION ng_orchestration.xp_sendmail(tofield text, message text, subject text) OWNER TO prvgwy;

--
-- TOC entry 1139 (class 1255 OID 468791)
-- Name: year(timestamp without time zone); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.year(timestamp without time zone) RETURNS integer
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
begin
return extract(year from $1);
end;
$_$;


ALTER FUNCTION ng_orchestration.year(timestamp without time zone) OWNER TO prvgwy;

--
-- TOC entry 1123 (class 1255 OID 468790)
-- Name: year(timestamp with time zone); Type: FUNCTION; Schema: ng_orchestration; Owner: prvgwy
--

CREATE FUNCTION ng_orchestration.year(timestamp with time zone) RETURNS integer
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
begin
return extract(year from $1);
end;
$_$;


ALTER FUNCTION ng_orchestration.year(timestamp with time zone) OWNER TO prvgwy;

--
-- TOC entry 3926 (class 2617 OID 468781)
-- Name: +; Type: OPERATOR; Schema: ng_orchestration; Owner: prvgwy
--

CREATE OPERATOR ng_orchestration.+ (
    PROCEDURE = cbscne.strcat,
    LEFTARG = text,
    RIGHTARG = text
);


ALTER OPERATOR ng_orchestration.+ (text, text) OWNER TO prvgwy;

--
-- TOC entry 714 (class 1259 OID 538710)
-- Name: SR_ID_SEQ; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration."SR_ID_SEQ"
    START WITH 946011935
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 99999999999999999
    CACHE 1
    CYCLE;


ALTER TABLE ng_orchestration."SR_ID_SEQ" OWNER TO prvgwy;

--
-- TOC entry 920 (class 1259 OID 6115574)
-- Name: SequelizeMeta; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE ng_orchestration."SequelizeMeta" OWNER TO dbadmin;

--
-- TOC entry 719 (class 1259 OID 547838)
-- Name: add_contacts_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.add_contacts_id_seq
    START WITH 479170
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ng_orchestration.add_contacts_id_seq OWNER TO prvgwy;

--
-- TOC entry 537 (class 1259 OID 357105)
-- Name: address_conversion; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.address_conversion (
    street_suffix character varying(100) NOT NULL,
    standard_name character varying(100),
    alias_type integer NOT NULL
);


ALTER TABLE ng_orchestration.address_conversion OWNER TO dbadmin;

--
-- TOC entry 503 (class 1259 OID 351637)
-- Name: admin_document_store; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.admin_document_store (
    app_key character varying(32) NOT NULL,
    document_store_name character varying(64) NOT NULL,
    seed_info character varying(64)[] NOT NULL
);


ALTER TABLE ng_orchestration.admin_document_store OWNER TO prvgwy;

--
-- TOC entry 700 (class 1259 OID 526204)
-- Name: aqm_task; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.aqm_task (
    task_id numeric(9,0) NOT NULL,
    queue_id numeric(9,0) NOT NULL,
    workstep_id numeric(9,0) NOT NULL,
    work_id numeric(9,0) NOT NULL,
    output character varying(255),
    start_date numeric(10,0) NOT NULL,
    date_ended numeric(10,0),
    due_date numeric(10,0) NOT NULL,
    orig_due_date numeric(10,0) NOT NULL,
    ready_status numeric(9,0) NOT NULL,
    lock_status numeric(9,0) NOT NULL,
    lock_owner_id numeric(9,0),
    enable_status numeric(9,0) NOT NULL,
    no_dependents numeric(9,0) NOT NULL,
    output_optional character varying(255),
    moved_from_q_id numeric(9,0) NOT NULL,
    completion_status numeric(9,0) NOT NULL,
    accept_status numeric(9,0) NOT NULL,
    optional_status numeric(9,0) NOT NULL,
    est_comp_date numeric(10,0) NOT NULL,
    completed_by numeric(9,0),
    no_deps_taken numeric(9,0) NOT NULL,
    required_status numeric(9,0),
    rollback character varying(255),
    completion_ind numeric(9,0) NOT NULL,
    sequence_id numeric(9,0),
    parent_task_id numeric(9,0),
    timeout_count numeric(9,0) NOT NULL,
    repeat_count numeric(9,0) NOT NULL,
    nested_template_id numeric(9,0) NOT NULL,
    instance_numeric numeric(9,0) NOT NULL,
    duration numeric(9,0) NOT NULL
);


ALTER TABLE ng_orchestration.aqm_task OWNER TO prvgwy;

--
-- TOC entry 701 (class 1259 OID 526210)
-- Name: aqm_wftemplate; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.aqm_wftemplate (
    wf_template_id numeric(9,0) NOT NULL,
    name character varying(60) NOT NULL,
    config_id numeric(9,0) NOT NULL,
    duration numeric(9,0),
    start_step_id numeric(9,0) NOT NULL,
    def_error_queue_id numeric(9,0),
    obsolete numeric(9,0),
    type numeric(9,0)
);


ALTER TABLE ng_orchestration.aqm_wftemplate OWNER TO prvgwy;

--
-- TOC entry 699 (class 1259 OID 526200)
-- Name: aqm_workstep; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.aqm_workstep (
    workstep_id numeric(9,0) NOT NULL,
    wf_template_id numeric(9,0) NOT NULL,
    name character varying(40),
    duration numeric(9,0) NOT NULL,
    template_ind numeric(9,0) NOT NULL,
    pre_comp_svr_id numeric(9,0)
);


ALTER TABLE ng_orchestration.aqm_workstep OWNER TO prvgwy;

--
-- TOC entry 249 (class 1259 OID 212907)
-- Name: atoll_temp_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.atoll_temp_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.atoll_temp_seq OWNER TO dbadmin;

--
-- TOC entry 346 (class 1259 OID 213103)
-- Name: atoll_temp; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.atoll_temp (
    pk bigint DEFAULT nextval('ng_orchestration.atoll_temp_seq'::regclass) NOT NULL,
    market character varying(45) NOT NULL,
    status character varying(45) DEFAULT 'NEW'::character varying NOT NULL,
    enodeb_id character varying(45),
    cell_id integer,
    band integer,
    antenna_degree integer,
    azimuth integer,
    latitude numeric(15,9),
    longitude numeric(15,9),
    kml text
);


ALTER TABLE ng_orchestration.atoll_temp OWNER TO dbadmin;

--
-- TOC entry 250 (class 1259 OID 212909)
-- Name: attachment_download_auth_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.attachment_download_auth_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.attachment_download_auth_seq OWNER TO dbadmin;

--
-- TOC entry 347 (class 1259 OID 213111)
-- Name: attachment_download_auth; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.attachment_download_auth (
    auth_pk bigint DEFAULT nextval('ng_orchestration.attachment_download_auth_seq'::regclass) NOT NULL,
    vzid character varying(50) NOT NULL,
    auth_key character varying(200) NOT NULL,
    generated_ts timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.attachment_download_auth OWNER TO dbadmin;

--
-- TOC entry 348 (class 1259 OID 213116)
-- Name: attachment_entity_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.attachment_entity_map (
    entity_id character varying(32) NOT NULL,
    entity_type character varying(32) NOT NULL,
    attachment_id bigint NOT NULL
);


ALTER TABLE ng_orchestration.attachment_entity_map OWNER TO dbadmin;

--
-- TOC entry 742 (class 1259 OID 1370918)
-- Name: attachment_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.attachment_id_seq OWNER TO prvgwy;

--
-- TOC entry 743 (class 1259 OID 1370920)
-- Name: audit_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.audit_id_seq OWNER TO prvgwy;

--
-- TOC entry 855 (class 1259 OID 1415953)
-- Name: auth_users; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.auth_users (
    id integer NOT NULL,
    enabled integer NOT NULL,
    password text NOT NULL,
    username text NOT NULL,
    role text NOT NULL
);


ALTER TABLE ng_orchestration.auth_users OWNER TO prvgwy;

--
-- TOC entry 744 (class 1259 OID 1370922)
-- Name: bam_task_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.bam_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.bam_task_id_seq OWNER TO prvgwy;

--
-- TOC entry 745 (class 1259 OID 1370924)
-- Name: booleanexpr_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.booleanexpr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.booleanexpr_id_seq OWNER TO prvgwy;

--
-- TOC entry 698 (class 1259 OID 526190)
-- Name: cafe_bases_service_type; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.cafe_bases_service_type (
    service_type_id numeric(9,0) NOT NULL,
    service_category_cd character varying(8),
    service_type_cd character varying(30),
    all_nc_apply numeric(9,0)
);


ALTER TABLE ng_orchestration.cafe_bases_service_type OWNER TO prvgwy;

--
-- TOC entry 746 (class 1259 OID 1370926)
-- Name: case_file_data_log_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.case_file_data_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.case_file_data_log_id_seq OWNER TO prvgwy;

--
-- TOC entry 747 (class 1259 OID 1370928)
-- Name: case_id_info_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.case_id_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.case_id_info_id_seq OWNER TO prvgwy;

--
-- TOC entry 748 (class 1259 OID 1370930)
-- Name: case_role_assign_log_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.case_role_assign_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.case_role_assign_log_id_seq OWNER TO prvgwy;

--
-- TOC entry 510 (class 1259 OID 354864)
-- Name: cbscne_laser_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.cbscne_laser_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.cbscne_laser_seq OWNER TO prvgwy;

--
-- TOC entry 511 (class 1259 OID 354866)
-- Name: cbscne_laser; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.cbscne_laser (
    cbscne_laser_id integer DEFAULT nextval('ng_orchestration.cbscne_laser_seq'::regclass) NOT NULL,
    switch_type integer,
    tls_speed integer,
    iof_feed_type integer,
    mileage integer,
    nid_co_media character varying(50),
    laser_type character varying(50),
    notes character varying(200)
);


ALTER TABLE ng_orchestration.cbscne_laser OWNER TO prvgwy;

--
-- TOC entry 691 (class 1259 OID 525193)
-- Name: cfa_failed_validation; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.cfa_failed_validation (
    validation_id numeric(9,0) NOT NULL,
    sr_id numeric(9,0),
    ckl_type numeric(9,0),
    state_id numeric(9,0),
    val_failed_date numeric(10,0) NOT NULL,
    cfa character varying(58) NOT NULL,
    order_source character varying(32) NOT NULL,
    server_name character varying(32) NOT NULL,
    order_id character varying(30),
    sales_contact_id character varying(32) NOT NULL,
    assigned_to character varying(32),
    purge_ind numeric(9,0),
    ccna character varying(3),
    pon character varying(16),
    ord character varying(11),
    message_sent numeric(9,0),
    cafe_status character varying(8),
    cafe_chg_status character varying(7),
    asr_id character varying(18),
    validation_type numeric(9,0)
);


ALTER TABLE ng_orchestration.cfa_failed_validation OWNER TO prvgwy;

--
-- TOC entry 749 (class 1259 OID 1370932)
-- Name: comment_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.comment_id_seq OWNER TO prvgwy;

--
-- TOC entry 520 (class 1259 OID 356898)
-- Name: config_parameters; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.config_parameters (
    config_name character varying(50) NOT NULL,
    value character varying(300) NOT NULL
);


ALTER TABLE ng_orchestration.config_parameters OWNER TO prvgwy;

--
-- TOC entry 750 (class 1259 OID 1370934)
-- Name: content_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.content_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.content_id_seq OWNER TO prvgwy;

--
-- TOC entry 751 (class 1259 OID 1370936)
-- Name: context_mapping_info_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.context_mapping_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.context_mapping_info_id_seq OWNER TO prvgwy;

--
-- TOC entry 752 (class 1259 OID 1370938)
-- Name: correlation_key_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.correlation_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.correlation_key_id_seq OWNER TO prvgwy;

--
-- TOC entry 753 (class 1259 OID 1370940)
-- Name: correlation_prop_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.correlation_prop_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.correlation_prop_id_seq OWNER TO prvgwy;

--
-- TOC entry 713 (class 1259 OID 537194)
-- Name: cr_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.cr_id_seq
    START WITH 2174785199
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 2176782010
    CACHE 1;


ALTER TABLE ng_orchestration.cr_id_seq OWNER TO prvgwy;

--
-- TOC entry 718 (class 1259 OID 547653)
-- Name: customer_project_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.customer_project_id_seq
    START WITH 591456
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 1000000000000000
    CACHE 1;


ALTER TABLE ng_orchestration.customer_project_id_seq OWNER TO prvgwy;

--
-- TOC entry 689 (class 1259 OID 525163)
-- Name: customer_request; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.customer_request (
    cr_id character varying(20) NOT NULL,
    customer_project_id numeric(9,0),
    cr_title character varying(60) NOT NULL,
    cr_status_cd numeric(9,0) NOT NULL,
    cr_desc character varying(2000),
    group_id_sales numeric(9,0) NOT NULL,
    priority numeric(9,0) NOT NULL,
    related_cr_id character varying(20),
    ccna character varying(3),
    userid_created character varying(32) NOT NULL,
    date_created numeric(10,0) NOT NULL,
    asr_id character varying(20),
    catc_status_id numeric(9,0),
    catc_date_complete numeric(10,0),
    pon character varying(16),
    catc_special numeric(9,0),
    security_enabled_flag numeric(9,0) NOT NULL,
    modified_date numeric(10,0),
    was_expedite numeric(9,0) NOT NULL,
    expedite_failure_msg character varying(50),
    pava_ind numeric(9,0),
    esg_case_id character varying(25),
    esg_order_index character varying(10),
    basis_case_number character varying(16),
    dts numeric(9,0),
    sp_routing character varying(100),
    tsp_indicator numeric(9,0),
    quantity numeric(9,0),
    sp_indicator numeric(9,0),
    quote_auth numeric(9,0),
    ckl1_ncon numeric(9,0),
    ckl2_ncon numeric(9,0),
    noof_ind numeric(9,0),
    tro numeric(9,0),
    proj_qty_exc_ind numeric(9,0),
    vadi_ind numeric(9,0),
    accord_asr_id character varying(20),
    ds0_qty numeric(9,0),
    bert_id character varying(20),
    bert_version character varying(3),
    bundled_fast_packet numeric(9,0),
    ckl1_meetpoint_flag numeric(9,0),
    ckl2_meetpoint_flag numeric(9,0),
    expedite_approved_date numeric(10,0),
    fiberconnect_flag numeric(9,0),
    far_end_nid numeric(9,0),
    cap_push numeric(1,0),
    reset_expedite numeric(1,0),
    micro_site_location numeric(9,0),
    mated_pair numeric(9,0),
    mated_pair_quantity numeric(9,0)
);


ALTER TABLE ng_orchestration.customer_request OWNER TO prvgwy;

--
-- TOC entry 536 (class 1259 OID 357102)
-- Name: date_rule_milestones; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.date_rule_milestones (
    rule_name character varying(20) NOT NULL,
    date_name character varying(30) NOT NULL,
    rule character varying(30)
);


ALTER TABLE ng_orchestration.date_rule_milestones OWNER TO prvgwy;

--
-- TOC entry 715 (class 1259 OID 542391)
-- Name: db_count; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.db_count (
    length integer
);


ALTER TABLE ng_orchestration.db_count OWNER TO prvgwy;

--
-- TOC entry 754 (class 1259 OID 1370942)
-- Name: deadline_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.deadline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.deadline_id_seq OWNER TO prvgwy;

--
-- TOC entry 755 (class 1259 OID 1370944)
-- Name: deploy_store_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.deploy_store_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.deploy_store_id_seq OWNER TO prvgwy;

--
-- TOC entry 349 (class 1259 OID 213119)
-- Name: dir_foreign_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.dir_foreign_entity (
    entity_type character varying(32) NOT NULL,
    description character varying(300) NOT NULL,
    referenced_column_name character varying(100) NOT NULL,
    referenced_table_name character varying(100) NOT NULL,
    referenced_domain_name character varying(100) NOT NULL
);


ALTER TABLE ng_orchestration.dir_foreign_entity OWNER TO dbadmin;

--
-- TOC entry 251 (class 1259 OID 212911)
-- Name: dir_project_action_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.dir_project_action_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.dir_project_action_seq OWNER TO dbadmin;

--
-- TOC entry 350 (class 1259 OID 213125)
-- Name: dir_project_action; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.dir_project_action (
    action_id integer DEFAULT nextval('ng_orchestration.dir_project_action_seq'::regclass) NOT NULL,
    action character varying(50) NOT NULL,
    description character varying(50) NOT NULL
);


ALTER TABLE ng_orchestration.dir_project_action OWNER TO dbadmin;

--
-- TOC entry 252 (class 1259 OID 212913)
-- Name: dir_project_status_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.dir_project_status_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.dir_project_status_seq OWNER TO dbadmin;

--
-- TOC entry 351 (class 1259 OID 213129)
-- Name: dir_project_status; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.dir_project_status (
    project_status_id integer DEFAULT nextval('ng_orchestration.dir_project_status_seq'::regclass) NOT NULL,
    status character varying(100) NOT NULL
);


ALTER TABLE ng_orchestration.dir_project_status OWNER TO dbadmin;

--
-- TOC entry 253 (class 1259 OID 212915)
-- Name: dir_project_type_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.dir_project_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.dir_project_type_seq OWNER TO dbadmin;

--
-- TOC entry 352 (class 1259 OID 213133)
-- Name: dir_project_type; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.dir_project_type (
    project_type_id integer DEFAULT nextval('ng_orchestration.dir_project_type_seq'::regclass) NOT NULL,
    project_type character varying(100) NOT NULL,
    description character varying(100)
);


ALTER TABLE ng_orchestration.dir_project_type OWNER TO dbadmin;

--
-- TOC entry 254 (class 1259 OID 212917)
-- Name: dml_monitor_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.dml_monitor_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.dml_monitor_seq OWNER TO dbadmin;

--
-- TOC entry 353 (class 1259 OID 213137)
-- Name: dml_monitor; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.dml_monitor (
    dml_event_id bigint DEFAULT nextval('ng_orchestration.dml_monitor_seq'::regclass) NOT NULL,
    dml_ts timestamp without time zone NOT NULL,
    dml_type character varying(1) NOT NULL,
    dml_table character varying(100),
    dml_key_name character varying(100),
    dml_key_value character varying(100),
    val_attr_inst_id bigint
);


ALTER TABLE ng_orchestration.dml_monitor OWNER TO dbadmin;

--
-- TOC entry 756 (class 1259 OID 1370946)
-- Name: emailnotifhead_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.emailnotifhead_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.emailnotifhead_id_seq OWNER TO prvgwy;

--
-- TOC entry 255 (class 1259 OID 212919)
-- Name: entity_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.entity_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.entity_map_seq OWNER TO dbadmin;

--
-- TOC entry 354 (class 1259 OID 213141)
-- Name: entity_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.entity_map (
    entity_map_id bigint DEFAULT nextval('ng_orchestration.entity_map_seq'::regclass) NOT NULL,
    entity_name character varying(255) NOT NULL,
    entity_source character varying(255) NOT NULL,
    entity_source_value bigint NOT NULL,
    entity_target character varying(255),
    entity_target_value bigint,
    parent_map_id bigint
);


ALTER TABLE ng_orchestration.entity_map OWNER TO dbadmin;

--
-- TOC entry 757 (class 1259 OID 1370948)
-- Name: error_info_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.error_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.error_info_id_seq OWNER TO prvgwy;

--
-- TOC entry 758 (class 1259 OID 1370950)
-- Name: escalation_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.escalation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.escalation_id_seq OWNER TO prvgwy;

--
-- TOC entry 740 (class 1259 OID 1161331)
-- Name: eu_clli_codes; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.eu_clli_codes (
    eu_clli_id numeric(9,0) NOT NULL,
    eu_clli character varying(11) NOT NULL,
    eu_name character varying(50) NOT NULL,
    address character varying(100) NOT NULL,
    city character varying(30) NOT NULL,
    state numeric(9,0) NOT NULL,
    zip numeric(5,0) NOT NULL,
    last_modified numeric(10,0)
);


ALTER TABLE ng_orchestration.eu_clli_codes OWNER TO prvgwy;

--
-- TOC entry 759 (class 1259 OID 1370952)
-- Name: exec_error_info_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.exec_error_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.exec_error_info_id_seq OWNER TO prvgwy;

--
-- TOC entry 531 (class 1259 OID 357016)
-- Name: facility_check_rules_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.facility_check_rules_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.facility_check_rules_seq OWNER TO prvgwy;

--
-- TOC entry 532 (class 1259 OID 357018)
-- Name: facility_check_rules; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.facility_check_rules (
    fac_check_rule_id integer DEFAULT nextval('ng_orchestration.facility_check_rules_seq'::regclass) NOT NULL,
    category character varying(60) NOT NULL,
    speed character varying(300) NOT NULL,
    rules_name character varying(60) NOT NULL,
    rule character varying(2000) NOT NULL,
    ckltype character varying(5) NOT NULL,
    rule_type character varying(10) NOT NULL,
    work_type character varying(200) NOT NULL,
    rule_no integer
);


ALTER TABLE ng_orchestration.facility_check_rules OWNER TO prvgwy;

--
-- TOC entry 256 (class 1259 OID 212921)
-- Name: file_attachment_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.file_attachment_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.file_attachment_seq OWNER TO dbadmin;

--
-- TOC entry 355 (class 1259 OID 213148)
-- Name: file_attachment; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.file_attachment (
    file_id bigint DEFAULT nextval('ng_orchestration.file_attachment_seq'::regclass) NOT NULL,
    attachment_id bigint,
    is_latest smallint,
    version integer,
    name character varying(200) NOT NULL,
    extension character varying(12),
    description character varying(1000),
    last_modified_by character varying(100) NOT NULL,
    last_modified_ts timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    created_by character varying(100) NOT NULL,
    created_ts timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    fr_ref_key_name character varying(32),
    fr_ref_key_value character varying(32)
);


ALTER TABLE ng_orchestration.file_attachment OWNER TO dbadmin;

--
-- TOC entry 356 (class 1259 OID 213157)
-- Name: file_data; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.file_data (
    file_id bigint NOT NULL,
    data bytea
);


ALTER TABLE ng_orchestration.file_data OWNER TO dbadmin;

--
-- TOC entry 721 (class 1259 OID 558630)
-- Name: floor_val; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.floor_val (
    floor double precision
);


ALTER TABLE ng_orchestration.floor_val OWNER TO prvgwy;

--
-- TOC entry 732 (class 1259 OID 598513)
-- Name: flyway_schema_history; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE ng_orchestration.flyway_schema_history OWNER TO prvgwy;

--
-- TOC entry 905 (class 1259 OID 2988329)
-- Name: flywaytable1; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.flywaytable1 (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    email character varying(355) NOT NULL,
    created_on timestamp without time zone NOT NULL,
    last_login timestamp without time zone
);


ALTER TABLE ng_orchestration.flywaytable1 OWNER TO prvgwy;

--
-- TOC entry 904 (class 1259 OID 2988327)
-- Name: flywaytable1_user_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.flywaytable1_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.flywaytable1_user_id_seq OWNER TO prvgwy;

--
-- TOC entry 6802 (class 0 OID 0)
-- Dependencies: 904
-- Name: flywaytable1_user_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.flywaytable1_user_id_seq OWNED BY ng_orchestration.flywaytable1.user_id;


--
-- TOC entry 697 (class 1259 OID 526143)
-- Name: functional_area; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.functional_area (
    function_area_id numeric(9,0) NOT NULL,
    function_area_cd character varying(6) NOT NULL,
    function_area_desc character varying(30)
);


ALTER TABLE ng_orchestration.functional_area OWNER TO prvgwy;

--
-- TOC entry 484 (class 1259 OID 242251)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.hibernate_sequence OWNER TO prvgwy;

--
-- TOC entry 514 (class 1259 OID 356851)
-- Name: holiday_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.holiday_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.holiday_seq OWNER TO prvgwy;

--
-- TOC entry 515 (class 1259 OID 356853)
-- Name: holiday; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.holiday (
    holiday_id integer DEFAULT nextval('ng_orchestration.holiday_seq'::regclass) NOT NULL,
    plan_id integer NOT NULL,
    begin_time integer NOT NULL,
    end_time integer NOT NULL,
    holiday_admin_id integer
);


ALTER TABLE ng_orchestration.holiday OWNER TO prvgwy;

--
-- TOC entry 541 (class 1259 OID 357291)
-- Name: holiday_admin; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.holiday_admin (
    hd_admin_id integer NOT NULL,
    hd_begin_time integer NOT NULL,
    hd_name_id integer NOT NULL,
    hd_state_list character varying(200) NOT NULL,
    hd_edit integer NOT NULL,
    hd_is_excellence integer
);


ALTER TABLE ng_orchestration.holiday_admin OWNER TO prvgwy;

--
-- TOC entry 513 (class 1259 OID 356832)
-- Name: holiday_admin_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.holiday_admin_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.holiday_admin_seq OWNER TO prvgwy;

--
-- TOC entry 760 (class 1259 OID 1370954)
-- Name: i18ntext_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.i18ntext_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.i18ntext_id_seq OWNER TO prvgwy;

--
-- TOC entry 358 (class 1259 OID 213166)
-- Name: if_onenetwork_qe_automationcheck; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.if_onenetwork_qe_automationcheck (
    cno character varying(22) NOT NULL,
    orderparser character varying(2),
    ordervalidation character varying(2),
    orderprocess character varying(2),
    servicequalification character varying(2)
);


ALTER TABLE ng_orchestration.if_onenetwork_qe_automationcheck OWNER TO dbadmin;

--
-- TOC entry 357 (class 1259 OID 213163)
-- Name: if_onenetwork_qeautomation; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.if_onenetwork_qeautomation (
    cno character varying(12) NOT NULL,
    region character varying(8),
    nc character varying(8),
    nci character varying(8),
    alocaddress character varying(60),
    zlocaddress character varying(60),
    aclli character varying(12),
    zclli character varying(12),
    pon character varying(20) NOT NULL,
    asrid bigint,
    refnum integer,
    ccna character varying(4),
    so character varying(12),
    sr character varying(12),
    cktid character varying(20)
);


ALTER TABLE ng_orchestration.if_onenetwork_qeautomation OWNER TO dbadmin;

--
-- TOC entry 705 (class 1259 OID 526718)
-- Name: ind_npa_nxx; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ind_npa_nxx (
    ind_npa_nxx_id numeric(9,0) NOT NULL,
    npa character varying(3) NOT NULL,
    nxx character varying(3) NOT NULL,
    ind_switch_id numeric(9,0),
    ocn character varying(4),
    modified_date numeric(10,0),
    switch_type numeric(9,0),
    lata_id numeric(9,0)
);


ALTER TABLE ng_orchestration.ind_npa_nxx OWNER TO prvgwy;

--
-- TOC entry 704 (class 1259 OID 526261)
-- Name: ind_switch; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ind_switch (
    ind_switch_id numeric(9,0) NOT NULL,
    wirecenter_id numeric(9,0),
    switch_clli character varying(11) NOT NULL,
    obsolete_flag numeric(9,0),
    modified_date numeric(10,0),
    region_ind numeric(9,0) NOT NULL
);


ALTER TABLE ng_orchestration.ind_switch OWNER TO prvgwy;

--
-- TOC entry 716 (class 1259 OID 542396)
-- Name: int; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration."int" (
    length integer
);


ALTER TABLE ng_orchestration."int" OWNER TO prvgwy;

--
-- TOC entry 543 (class 1259 OID 366627)
-- Name: interval_mapping; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.interval_mapping (
    minimum_interval_id integer NOT NULL,
    service_category_cd character varying(100) NOT NULL,
    service_type_cd character varying(100) NOT NULL,
    source character varying(50) NOT NULL,
    region character varying(50) NOT NULL,
    activity integer NOT NULL,
    order_type integer NOT NULL,
    minimum_interval integer,
    expedite_interval integer,
    lam_interval integer,
    fttc_minimum_interval integer,
    gpon_interval integer,
    e2e_std_interval integer,
    e2e_exp_interval integer,
    states character varying(500),
    directors character varying(1024)
);


ALTER TABLE ng_orchestration.interval_mapping OWNER TO prvgwy;

--
-- TOC entry 495 (class 1259 OID 293712)
-- Name: jeop_config_param_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.jeop_config_param_seq
    START WITH 18
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jeop_config_param_seq OWNER TO prvgwy;

--
-- TOC entry 496 (class 1259 OID 293715)
-- Name: jeop_config_param; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.jeop_config_param (
    param_id integer DEFAULT nextval('ng_orchestration.jeop_config_param_seq'::regclass) NOT NULL,
    param_key character varying(500) NOT NULL,
    type character varying(500) NOT NULL,
    name character varying(16000),
    value character varying(32000)
);


ALTER TABLE ng_orchestration.jeop_config_param OWNER TO prvgwy;

--
-- TOC entry 502 (class 1259 OID 351623)
-- Name: oldjeopardy_admin_docs; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.oldjeopardy_admin_docs (
    document_misc jsonb,
    app_key character varying(128),
    doc_name character varying,
    jeopcodes jsonb,
    jeop_admin_doc_id integer NOT NULL
);


ALTER TABLE ng_orchestration.oldjeopardy_admin_docs OWNER TO prvgwy;

--
-- TOC entry 504 (class 1259 OID 352260)
-- Name: jeopardy_admin_docs_jeop_admin_doc_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq OWNER TO prvgwy;

--
-- TOC entry 6820 (class 0 OID 0)
-- Dependencies: 504
-- Name: jeopardy_admin_docs_jeop_admin_doc_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq OWNED BY ng_orchestration.oldjeopardy_admin_docs.jeop_admin_doc_id;


--
-- TOC entry 505 (class 1259 OID 352302)
-- Name: jeopardy_admin_docs; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.jeopardy_admin_docs (
    doc_id integer DEFAULT nextval('ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq'::regclass) NOT NULL,
    document_misc jsonb,
    app_key character varying(128),
    doc_name character varying,
    jeopcodes jsonb
);


ALTER TABLE ng_orchestration.jeopardy_admin_docs OWNER TO prvgwy;

--
-- TOC entry 493 (class 1259 OID 293694)
-- Name: jeopardy_transaction_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.jeopardy_transaction_seq
    START WITH 18
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jeopardy_transaction_seq OWNER TO prvgwy;

--
-- TOC entry 494 (class 1259 OID 293700)
-- Name: jeopardy_transaction; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.jeopardy_transaction (
    jeopardy_transaction_id integer DEFAULT nextval('ng_orchestration.jeopardy_transaction_seq'::regclass) NOT NULL,
    title character varying(128),
    title_version character varying(50),
    task_name character varying(128) NOT NULL,
    jeop_code character varying(128) NOT NULL,
    applied_by character varying(50),
    created_time timestamp without time zone,
    last_modified_time timestamp without time zone,
    jeopardy_status character varying(15),
    jeop_attributes character varying(4000),
    qcode character varying(128),
    external_task_id character varying,
    jeop_desc character varying(512),
    qcode_desc character varying(512)
);


ALTER TABLE ng_orchestration.jeopardy_transaction OWNER TO prvgwy;

--
-- TOC entry 257 (class 1259 OID 212923)
-- Name: jv_cdo_class_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.jv_cdo_class_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jv_cdo_class_seq OWNER TO dbadmin;

--
-- TOC entry 906 (class 1259 OID 3406676)
-- Name: jv_commit_property; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.jv_commit_property (
    property_name character varying(191) NOT NULL,
    property_value character varying(600),
    commit_fk bigint NOT NULL
);


ALTER TABLE ng_orchestration.jv_commit_property OWNER TO prvgwy;

--
-- TOC entry 258 (class 1259 OID 212925)
-- Name: jv_commit_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.jv_commit_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jv_commit_seq OWNER TO dbadmin;

--
-- TOC entry 259 (class 1259 OID 212927)
-- Name: jv_global_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.jv_global_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jv_global_id_seq OWNER TO dbadmin;

--
-- TOC entry 260 (class 1259 OID 212929)
-- Name: jv_snapshot_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.jv_snapshot_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.jv_snapshot_seq OWNER TO dbadmin;

--
-- TOC entry 542 (class 1259 OID 366624)
-- Name: lam_interval; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.lam_interval (
    lam_interval_id integer NOT NULL,
    trid_date integer,
    rid_date integer,
    dva_date integer,
    wot_date integer,
    fcd_date integer,
    ptd_date integer,
    dd_date integer,
    modified_date integer,
    gpon integer
);


ALTER TABLE ng_orchestration.lam_interval OWNER TO prvgwy;

--
-- TOC entry 500 (class 1259 OID 342073)
-- Name: lci_admin_docs; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.lci_admin_docs (
    doc_name character varying(64) NOT NULL,
    document jsonb,
    "appKey" character varying(128)
);


ALTER TABLE ng_orchestration.lci_admin_docs OWNER TO prvgwy;

--
-- TOC entry 499 (class 1259 OID 342051)
-- Name: lci_admin_docs_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.lci_admin_docs_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.lci_admin_docs_seq OWNER TO prvgwy;

--
-- TOC entry 501 (class 1259 OID 342125)
-- Name: lci_admin_docs_testlarge; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.lci_admin_docs_testlarge (
    document_id bigint DEFAULT nextval('ng_orchestration.lci_admin_docs_seq'::regclass) NOT NULL,
    appkey character varying(64) NOT NULL,
    doc_name character varying(64) NOT NULL,
    document jsonb
);


ALTER TABLE ng_orchestration.lci_admin_docs_testlarge OWNER TO prvgwy;

--
-- TOC entry 507 (class 1259 OID 354784)
-- Name: lci_document_store; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.lci_document_store (
    id integer NOT NULL,
    order_number character varying(64) NOT NULL,
    order_version character varying(64) NOT NULL,
    document_level character varying(64) NOT NULL,
    document_name character varying(64) NOT NULL,
    document jsonb
);


ALTER TABLE ng_orchestration.lci_document_store OWNER TO prvgwy;

--
-- TOC entry 506 (class 1259 OID 354782)
-- Name: lci_document_store_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.lci_document_store_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.lci_document_store_seq OWNER TO prvgwy;

--
-- TOC entry 6835 (class 0 OID 0)
-- Dependencies: 506
-- Name: lci_document_store_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.lci_document_store_seq OWNED BY ng_orchestration.lci_document_store.id;


--
-- TOC entry 649 (class 1259 OID 445416)
-- Name: lookup_values; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.lookup_values (
    lv_id bigint NOT NULL,
    last_mod_dt date,
    last_mod_user_id character varying(255),
    lv_description character varying(255),
    lv_status character varying(255),
    lv_type character varying(255),
    lv_value character varying(255)
);


ALTER TABLE ng_orchestration.lookup_values OWNER TO prvgwy;

--
-- TOC entry 554 (class 1259 OID 412131)
-- Name: manifest_app_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_app_config (
    app_id integer NOT NULL,
    app_key character varying(25) NOT NULL,
    app_name character varying(128) NOT NULL,
    app_entity_tbl_name character varying(30) NOT NULL,
    app_poc_name character varying(100) NOT NULL,
    active character(1) NOT NULL,
    attribute_header jsonb NOT NULL,
    create_date timestamp without time zone NOT NULL,
    search_value character varying(17),
    doc_config character varying(1) DEFAULT 'N'::character varying NOT NULL
);


ALTER TABLE ng_orchestration.manifest_app_config OWNER TO prvgwy;

--
-- TOC entry 553 (class 1259 OID 412129)
-- Name: manifest_app_config_app_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.manifest_app_config_app_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.manifest_app_config_app_id_seq OWNER TO prvgwy;

--
-- TOC entry 6839 (class 0 OID 0)
-- Dependencies: 553
-- Name: manifest_app_config_app_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.manifest_app_config_app_id_seq OWNED BY ng_orchestration.manifest_app_config.app_id;


--
-- TOC entry 922 (class 1259 OID 6115715)
-- Name: manifest_app_config_test; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_app_config_test (
    id integer NOT NULL,
    app_key character varying(255),
    app_name character varying(255),
    app_entity_tbl_name character varying(255),
    app_poc_name character varying(255),
    active character varying(255),
    attribute_header jsonb,
    create_date timestamp with time zone,
    search_value character varying(255),
    doc_config character varying(255)
);


ALTER TABLE ng_orchestration.manifest_app_config_test OWNER TO prvgwy;

--
-- TOC entry 921 (class 1259 OID 6115713)
-- Name: manifest_app_config_test_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.manifest_app_config_test_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.manifest_app_config_test_id_seq OWNER TO prvgwy;

--
-- TOC entry 6841 (class 0 OID 0)
-- Dependencies: 921
-- Name: manifest_app_config_test_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.manifest_app_config_test_id_seq OWNED BY ng_orchestration.manifest_app_config_test.id;


--
-- TOC entry 924 (class 1259 OID 6115726)
-- Name: manifest_app_configs; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_app_configs (
    id integer NOT NULL,
    app_key character varying(255),
    app_name character varying(255),
    app_entity_tbl_name character varying(255),
    app_poc_name character varying(255),
    active character varying(255),
    attribute_header jsonb,
    create_date timestamp with time zone,
    search_value character varying(255),
    doc_config character varying(255)
);


ALTER TABLE ng_orchestration.manifest_app_configs OWNER TO prvgwy;

--
-- TOC entry 923 (class 1259 OID 6115724)
-- Name: manifest_app_configs_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.manifest_app_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.manifest_app_configs_id_seq OWNER TO prvgwy;

--
-- TOC entry 6842 (class 0 OID 0)
-- Dependencies: 923
-- Name: manifest_app_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.manifest_app_configs_id_seq OWNED BY ng_orchestration.manifest_app_configs.id;


--
-- TOC entry 556 (class 1259 OID 412145)
-- Name: manifest_doc_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_doc_config (
    doc_id bigint NOT NULL,
    app_id bigint NOT NULL,
    doc_name character varying(100) NOT NULL,
    doc_type character varying(8) NOT NULL,
    header_key jsonb,
    create_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.manifest_doc_config OWNER TO prvgwy;

--
-- TOC entry 555 (class 1259 OID 412143)
-- Name: manifest_doc_config_doc_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.manifest_doc_config_doc_id_seq OWNER TO prvgwy;

--
-- TOC entry 6844 (class 0 OID 0)
-- Dependencies: 555
-- Name: manifest_doc_config_doc_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq OWNED BY ng_orchestration.manifest_doc_config.doc_id;


--
-- TOC entry 560 (class 1259 OID 412182)
-- Name: manifest_document; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.manifest_document (
    doc_id bigint NOT NULL,
    app_id bigint NOT NULL,
    entity_id bigint NOT NULL,
    doc_name character varying(64) NOT NULL,
    document_headers jsonb,
    document jsonb NOT NULL,
    status character(1) NOT NULL,
    create_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.manifest_document OWNER TO dbadmin;

--
-- TOC entry 727 (class 1259 OID 590830)
-- Name: manifest_document_backup_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_backup_config (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_backup_config OWNER TO prvgwy;

--
-- TOC entry 928 (class 1259 OID 7803526)
-- Name: manifest_document_backup_config_2020_04_20; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_backup_config_2020_04_20 (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_backup_config_2020_04_20 OWNER TO prvgwy;

--
-- TOC entry 929 (class 1259 OID 7878236)
-- Name: manifest_document_backup_config_2020_04_21; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_backup_config_2020_04_21 (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_backup_config_2020_04_21 OWNER TO prvgwy;

--
-- TOC entry 930 (class 1259 OID 7954696)
-- Name: manifest_document_backup_config_2020_04_22; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_backup_config_2020_04_22 (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_backup_config_2020_04_22 OWNER TO prvgwy;

--
-- TOC entry 933 (class 1259 OID 8031574)
-- Name: manifest_document_backup_config_2020_04_23; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_backup_config_2020_04_23 (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_backup_config_2020_04_23 OWNER TO prvgwy;

--
-- TOC entry 657 (class 1259 OID 496739)
-- Name: manifest_document_bkup_05_07_19; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_bkup_05_07_19 (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_bkup_05_07_19 OWNER TO prvgwy;

--
-- TOC entry 559 (class 1259 OID 412180)
-- Name: manifest_document_doc_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.manifest_document_doc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.manifest_document_doc_id_seq OWNER TO dbadmin;

--
-- TOC entry 6849 (class 0 OID 0)
-- Dependencies: 559
-- Name: manifest_document_doc_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: dbadmin
--

ALTER SEQUENCE ng_orchestration.manifest_document_doc_id_seq OWNED BY ng_orchestration.manifest_document.doc_id;


--
-- TOC entry 654 (class 1259 OID 468133)
-- Name: manifest_document_ordvalid_bkup_04_03; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 (
    doc_id bigint,
    app_id bigint,
    entity_id bigint,
    doc_name character varying(64),
    document_headers jsonb,
    document jsonb,
    status character(1),
    create_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 OWNER TO prvgwy;

--
-- TOC entry 558 (class 1259 OID 412163)
-- Name: manifest_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.manifest_entity (
    entity_id bigint NOT NULL,
    entity_hash character varying(65) NOT NULL,
    entity_string character varying(256) NOT NULL,
    app_id bigint NOT NULL,
    entity_details jsonb NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.manifest_entity OWNER TO dbadmin;

--
-- TOC entry 557 (class 1259 OID 412161)
-- Name: manifest_entity_entity_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.manifest_entity_entity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.manifest_entity_entity_id_seq OWNER TO dbadmin;

--
-- TOC entry 6853 (class 0 OID 0)
-- Dependencies: 557
-- Name: manifest_entity_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: dbadmin
--

ALTER SEQUENCE ng_orchestration.manifest_entity_entity_id_seq OWNED BY ng_orchestration.manifest_entity.entity_id;


--
-- TOC entry 910 (class 1259 OID 5312510)
-- Name: manifest_entity_test; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.manifest_entity_test (
    entity_id bigint,
    entity_hash character varying(65),
    entity_string character varying(256),
    app_id bigint,
    entity_details jsonb,
    create_date timestamp without time zone
);


ALTER TABLE ng_orchestration.manifest_entity_test OWNER TO prvgwy;

--
-- TOC entry 932 (class 1259 OID 8029547)
-- Name: metrics_v3_completions; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.metrics_v3_completions (
    unique_id bigint NOT NULL,
    task character varying(255) NOT NULL,
    application character varying(255) NOT NULL,
    city character varying(255),
    completion_date timestamp without time zone NOT NULL,
    date_attribute_1 timestamp without time zone,
    date_attribute_2 timestamp without time zone,
    first_name character varying(255),
    last_name character varying(255),
    integer_attribute_1 bigint,
    integer_attribute_2 bigint,
    task_id character varying(255),
    state character varying(255),
    task_name character varying(255) NOT NULL,
    text_attribute_2 character varying(255),
    text_attribute_1 character varying(255) NOT NULL,
    assignee_display_name character varying(255) NOT NULL,
    version character varying(255) NOT NULL
);


ALTER TABLE ng_orchestration.metrics_v3_completions OWNER TO prvgwy;

--
-- TOC entry 931 (class 1259 OID 8029545)
-- Name: metrics_v3_completions_unique_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.metrics_v3_completions_unique_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.metrics_v3_completions_unique_id_seq OWNER TO prvgwy;

--
-- TOC entry 518 (class 1259 OID 356889)
-- Name: micro_service_tracker_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.micro_service_tracker_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.micro_service_tracker_seq OWNER TO prvgwy;

--
-- TOC entry 519 (class 1259 OID 356891)
-- Name: micro_service_tracker; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.micro_service_tracker (
    micro_service_tracker_id integer DEFAULT nextval('ng_orchestration.micro_service_tracker_seq'::regclass) NOT NULL,
    micro_service_name character varying(50),
    sr_id integer,
    pon character varying(50),
    ccna character varying(10),
    asr_id character varying(50),
    remark character varying(50),
    request_recd character varying(10),
    response_sent character varying(50),
    date_processed timestamp without time zone
);


ALTER TABLE ng_orchestration.micro_service_tracker OWNER TO prvgwy;

--
-- TOC entry 544 (class 1259 OID 366817)
-- Name: micro_service_tracker_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.micro_service_tracker_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.micro_service_tracker_id_seq OWNER TO prvgwy;

--
-- TOC entry 261 (class 1259 OID 212931)
-- Name: milestone_order_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_order_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_order_seq OWNER TO dbadmin;

--
-- TOC entry 359 (class 1259 OID 213189)
-- Name: milestone_order; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_order (
    milestone_order_id bigint DEFAULT nextval('ng_orchestration.milestone_order_seq'::regclass) NOT NULL,
    milestone_template_id bigint NOT NULL,
    milestone_level character varying(60) NOT NULL,
    milestone_status character varying(60),
    order_ref_id bigint NOT NULL,
    obj_date timestamp without time zone,
    comp_date timestamp without time zone,
    completed_by character varying(25),
    jeop_code character varying(30),
    mfc character varying(20),
    lob character varying(30),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    order_source character varying(20) NOT NULL
);


ALTER TABLE ng_orchestration.milestone_order OWNER TO dbadmin;

--
-- TOC entry 262 (class 1259 OID 212933)
-- Name: milestone_order_bak_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_order_bak_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_order_bak_seq OWNER TO dbadmin;

--
-- TOC entry 360 (class 1259 OID 213197)
-- Name: milestone_order_bak; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_order_bak (
    milestone_order_id bigint DEFAULT nextval('ng_orchestration.milestone_order_bak_seq'::regclass) NOT NULL,
    milestone_name character varying(128) NOT NULL,
    milestone_level character varying(128) NOT NULL,
    milestone_category bigint,
    obj_date timestamp without time zone,
    start_date timestamp without time zone,
    comp_date timestamp without time zone,
    jeop_code character varying(30),
    completed_by character varying(128),
    mfc character varying(128),
    lob character varying(128),
    order_number character varying(128) NOT NULL,
    circuit_id character varying(100),
    region character varying(64) NOT NULL,
    status character varying(64)
);


ALTER TABLE ng_orchestration.milestone_order_bak OWNER TO dbadmin;

--
-- TOC entry 263 (class 1259 OID 212935)
-- Name: milestone_order_new_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_order_new_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_order_new_seq OWNER TO dbadmin;

--
-- TOC entry 361 (class 1259 OID 213204)
-- Name: milestone_order_new; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_order_new (
    milestone_order_id bigint DEFAULT nextval('ng_orchestration.milestone_order_new_seq'::regclass) NOT NULL,
    milestone_template_id bigint NOT NULL,
    milestone_level character varying(60) NOT NULL,
    milestone_status character varying(60),
    order_ref_id bigint NOT NULL,
    obj_date timestamp without time zone,
    comp_date timestamp without time zone,
    completed_by character varying(25),
    jeop_code character varying(30),
    mfc character varying(20),
    lob character varying(30),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    order_source character varying(20) NOT NULL
);


ALTER TABLE ng_orchestration.milestone_order_new OWNER TO dbadmin;

--
-- TOC entry 264 (class 1259 OID 212937)
-- Name: milestone_template_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_template_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_template_seq OWNER TO dbadmin;

--
-- TOC entry 362 (class 1259 OID 213211)
-- Name: milestone_template; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_template (
    milestone_template_id bigint DEFAULT nextval('ng_orchestration.milestone_template_seq'::regclass) NOT NULL,
    milestone_template_name character varying(120) NOT NULL,
    milestone_name character varying(120) NOT NULL,
    milestone_category character varying(25) NOT NULL,
    milestone_seq integer NOT NULL,
    milestone_event_name character varying(250),
    acronym character varying(30),
    status character varying(60),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    notify_ext_sys text,
    qualifier character varying(120),
    notify_ext_jeop text
);


ALTER TABLE ng_orchestration.milestone_template OWNER TO dbadmin;

--
-- TOC entry 265 (class 1259 OID 212939)
-- Name: milestone_template_bak_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_template_bak_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_template_bak_seq OWNER TO dbadmin;

--
-- TOC entry 363 (class 1259 OID 213221)
-- Name: milestone_template_bak; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_template_bak (
    milestone_template_id bigint DEFAULT nextval('ng_orchestration.milestone_template_bak_seq'::regclass) NOT NULL,
    product_type character varying(128) NOT NULL,
    milestone_name character varying(128) NOT NULL,
    milestone_level character varying(128) NOT NULL,
    milestone_category bigint,
    lob character varying(128),
    acronym character varying(128),
    milestone_seq integer NOT NULL
);


ALTER TABLE ng_orchestration.milestone_template_bak OWNER TO dbadmin;

--
-- TOC entry 266 (class 1259 OID 212941)
-- Name: milestone_template_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_template_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_template_map_seq OWNER TO dbadmin;

--
-- TOC entry 364 (class 1259 OID 213228)
-- Name: milestone_template_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_template_map (
    milestone_template_map_id bigint DEFAULT nextval('ng_orchestration.milestone_template_map_seq'::regclass) NOT NULL,
    milestone_template_name character varying(120) NOT NULL,
    milestone_level character varying(60) NOT NULL,
    product_type character varying(30) NOT NULL,
    order_type character varying(30) NOT NULL,
    order_supp_type character varying(30) NOT NULL,
    lob character varying(30),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    qualifier character varying(120)
);


ALTER TABLE ng_orchestration.milestone_template_map OWNER TO dbadmin;

--
-- TOC entry 267 (class 1259 OID 212943)
-- Name: milestone_template_new_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.milestone_template_new_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.milestone_template_new_seq OWNER TO dbadmin;

--
-- TOC entry 365 (class 1259 OID 213235)
-- Name: milestone_template_new; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.milestone_template_new (
    milestone_template_id bigint DEFAULT nextval('ng_orchestration.milestone_template_new_seq'::regclass) NOT NULL,
    milestone_template_name character varying(120) NOT NULL,
    milestone_name character varying(120) NOT NULL,
    milestone_category character varying(25) NOT NULL,
    milestone_seq integer NOT NULL,
    milestone_event_name character varying(250),
    acronym character varying(30),
    status character varying(60),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    notify_ext_sys text,
    qualifier character varying(120),
    notify_ext_jeop text
);


ALTER TABLE ng_orchestration.milestone_template_new OWNER TO dbadmin;

--
-- TOC entry 687 (class 1259 OID 525118)
-- Name: nci_code; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.nci_code (
    nci_id numeric(9,0) NOT NULL,
    nci_code character varying(12) NOT NULL,
    nci_desc character varying(2000)
);


ALTER TABLE ng_orchestration.nci_code OWNER TO prvgwy;

--
-- TOC entry 708 (class 1259 OID 529517)
-- Name: network_channel; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.network_channel (
    network_channel_id numeric(9,0) NOT NULL,
    service_type_id numeric(9,0),
    network_channel_cd numeric(9,0) NOT NULL,
    ckl1nci numeric(9,0),
    ckl2nci numeric(9,0),
    service_cd character varying(4),
    line_cd numeric(9,0),
    framing_choice_cd numeric(9,0),
    product_cd numeric(9,0),
    nci_display numeric(9,0) NOT NULL,
    active_ind numeric(9,0),
    modified_date numeric(10,0),
    access_service_type numeric(9,0),
    cafe numeric(9,0) NOT NULL,
    exact numeric(9,0) NOT NULL,
    basis numeric(9,0) NOT NULL,
    obsolete numeric(9,0) NOT NULL,
    region_ind numeric(9,0)
);


ALTER TABLE ng_orchestration.network_channel OWNER TO prvgwy;

--
-- TOC entry 508 (class 1259 OID 354841)
-- Name: nid_automation_ext_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.nid_automation_ext_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.nid_automation_ext_seq OWNER TO prvgwy;

--
-- TOC entry 509 (class 1259 OID 354854)
-- Name: nid_automation_ext; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.nid_automation_ext (
    nid_ext_id integer DEFAULT nextval('ng_orchestration.nid_automation_ext_seq'::regclass) NOT NULL,
    tls_flavor_nid integer,
    tls_speed integer,
    tls_type integer,
    nid_power_req character varying(30),
    nid_environment integer,
    tot_miles_tls integer,
    link_aggregation integer,
    tot_db_loss integer,
    nid_value character varying(30),
    feed_type integer,
    handoff_type integer,
    reusable_ems integer,
    nid_value2 character varying(30),
    gpon_nid character varying(30),
    nid_co_media character varying(50),
    lag integer,
    ciena_nid_value character varying(30),
    ciena_gpon_nid character varying(30),
    ciena_kit character varying(50),
    ciena_network_sfp character varying(50),
    ciena_user_sfp character varying(50),
    cisco_nid_value character varying(30),
    cisco_gpon_nid character varying(30),
    cisco_kit character varying(50),
    cisco_network_sfp character varying(50),
    cisco_user_sfp character varying(50),
    rack_mount integer,
    cisco_gpon_kit character varying(50),
    cisco_gpon_network_sfp character varying(50),
    cisco_gpon_user_sfp character varying(50),
    ciena_gpon_kit character varying(50),
    ciena_gpon_network_sfp character varying(50),
    ciena_gpon_user_sfp character varying(50)
);


ALTER TABLE ng_orchestration.nid_automation_ext OWNER TO prvgwy;

--
-- TOC entry 761 (class 1259 OID 1370956)
-- Name: node_inst_log_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.node_inst_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.node_inst_log_id_seq OWNER TO prvgwy;

--
-- TOC entry 762 (class 1259 OID 1370958)
-- Name: notification_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.notification_id_seq OWNER TO prvgwy;

--
-- TOC entry 702 (class 1259 OID 526249)
-- Name: npa_nxx; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.npa_nxx (
    npa_nxx_id numeric(9,0) NOT NULL,
    npa character varying(3) NOT NULL,
    nxx character varying(3) NOT NULL,
    switch_id numeric(9,0),
    lata_id numeric(9,0),
    modified_date numeric(10,0)
);


ALTER TABLE ng_orchestration.npa_nxx OWNER TO prvgwy;

--
-- TOC entry 561 (class 1259 OID 412979)
-- Name: ntwk_channel_codes; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ntwk_channel_codes (
    nc_id numeric(9,0) NOT NULL,
    nc_code character varying(5) NOT NULL,
    nc_desc character varying(2000)
);


ALTER TABLE ng_orchestration.ntwk_channel_codes OWNER TO prvgwy;

--
-- TOC entry 903 (class 1259 OID 2708142)
-- Name: numdaysflt; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.numdaysflt (
    "?column?" integer
);


ALTER TABLE ng_orchestration.numdaysflt OWNER TO prvgwy;

--
-- TOC entry 725 (class 1259 OID 574003)
-- Name: numeric; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration."numeric" (
    "?column?" interval
);


ALTER TABLE ng_orchestration."numeric" OWNER TO prvgwy;

--
-- TOC entry 908 (class 1259 OID 4892539)
-- Name: ods_book_test; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_book_test (
    book_id integer NOT NULL,
    name character varying(255),
    details jsonb
);


ALTER TABLE ng_orchestration.ods_book_test OWNER TO prvgwy;

--
-- TOC entry 528 (class 1259 OID 356995)
-- Name: ods_document_store; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_document_store (
    id integer NOT NULL,
    application_key character varying(64) NOT NULL,
    data_type character varying(64) NOT NULL,
    document_level character varying(64) NOT NULL,
    document_name character varying(64) NOT NULL,
    document jsonb
);


ALTER TABLE ng_orchestration.ods_document_store OWNER TO prvgwy;

--
-- TOC entry 527 (class 1259 OID 356993)
-- Name: ods_document_store_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_document_store_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_document_store_seq OWNER TO prvgwy;

--
-- TOC entry 6884 (class 0 OID 0)
-- Dependencies: 527
-- Name: ods_document_store_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.ods_document_store_seq OWNED BY ng_orchestration.ods_document_store.id;


--
-- TOC entry 268 (class 1259 OID 212945)
-- Name: ods_interface_request_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_interface_request_seq
    START WITH 1
    INCREMENT BY 100
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_interface_request_seq OWNER TO prvgwy;

--
-- TOC entry 366 (class 1259 OID 213245)
-- Name: ods_interface_request; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.ods_interface_request (
    id integer DEFAULT nextval('ng_orchestration.ods_interface_request_seq'::regclass) NOT NULL,
    transaction_id text NOT NULL,
    request_key text,
    corelation_payload text,
    manifest_payload text,
    request text,
    request_time timestamp with time zone,
    response text,
    response_time timestamp with time zone,
    status text NOT NULL,
    response_config_param text,
    task_id text DEFAULT NULL::character varying,
    source text,
    target_end_point_url text
);


ALTER TABLE ng_orchestration.ods_interface_request OWNER TO dbadmin;

--
-- TOC entry 731 (class 1259 OID 592614)
-- Name: ods_interface_request_temp; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_interface_request_temp (
    id integer,
    transaction_id character varying(500),
    request_key character varying(500),
    corelation_payload character varying(4096),
    manifest_payload character varying(4096),
    request text,
    request_time timestamp with time zone,
    response text,
    response_time timestamp with time zone,
    status character varying(45),
    response_config_param character varying(4000),
    task_id character varying(128),
    source character varying,
    target_end_point_url character varying
);


ALTER TABLE ng_orchestration.ods_interface_request_temp OWNER TO prvgwy;

--
-- TOC entry 269 (class 1259 OID 212947)
-- Name: ods_mandatory_attrs_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_mandatory_attrs_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_mandatory_attrs_seq OWNER TO prvgwy;

--
-- TOC entry 367 (class 1259 OID 213252)
-- Name: ods_mandatory_attrs; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_mandatory_attrs (
    validation_id integer DEFAULT nextval('ng_orchestration.ods_mandatory_attrs_seq'::regclass) NOT NULL,
    attr_key character varying(500),
    json_path character varying(5000)
);


ALTER TABLE ng_orchestration.ods_mandatory_attrs OWNER TO prvgwy;

--
-- TOC entry 270 (class 1259 OID 212949)
-- Name: ods_milestone_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_milestone_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_milestone_config_seq OWNER TO prvgwy;

--
-- TOC entry 368 (class 1259 OID 213259)
-- Name: ods_milestone_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_milestone_config (
    ods_milestone_config_id integer DEFAULT nextval('ng_orchestration.ods_milestone_config_seq'::regclass) NOT NULL,
    milestone_name character varying(45) NOT NULL,
    flow_node_process_name character varying(500) NOT NULL,
    flow_node_step_name character varying(500) NOT NULL,
    send_milestone character varying(45),
    send_fallout_notification character varying(45),
    send_onentry_notification character varying(15)
);


ALTER TABLE ng_orchestration.ods_milestone_config OWNER TO prvgwy;

--
-- TOC entry 271 (class 1259 OID 212951)
-- Name: ods_milestone_transaction_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_milestone_transaction_seq
    START WITH 1
    INCREMENT BY 100
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_milestone_transaction_seq OWNER TO prvgwy;

--
-- TOC entry 369 (class 1259 OID 213266)
-- Name: ods_milestone_transaction; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_milestone_transaction (
    ods_milestone_transaction_id integer DEFAULT nextval('ng_orchestration.ods_milestone_transaction_seq'::regclass) NOT NULL,
    root_case_id text NOT NULL,
    process_name text NOT NULL,
    step_name text NOT NULL,
    ods_milestone_config_id integer NOT NULL,
    last_modified_ts timestamp with time zone,
    ods_notification_transaction_id integer
);


ALTER TABLE ng_orchestration.ods_milestone_transaction OWNER TO prvgwy;

--
-- TOC entry 489 (class 1259 OID 293188)
-- Name: ods_notification_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_notification_config_seq
    START WITH 18
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_notification_config_seq OWNER TO prvgwy;

--
-- TOC entry 490 (class 1259 OID 293192)
-- Name: ods_notification_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_notification_config (
    ods_notification_config_id integer DEFAULT nextval('ng_orchestration.ods_notification_config_seq'::regclass) NOT NULL,
    notification_name character varying(45),
    destination_app_name character varying(500),
    target_end_point_url character varying(500),
    username character varying(50),
    password character varying(100),
    request_schema character varying(70000),
    request_document_name character varying(500),
    transformation_type character varying(45),
    route_protocol character varying(45)
);


ALTER TABLE ng_orchestration.ods_notification_config OWNER TO prvgwy;

--
-- TOC entry 491 (class 1259 OID 293202)
-- Name: ods_notification_transaction_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_notification_transaction_seq
    START WITH 18
    INCREMENT BY 100
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_notification_transaction_seq OWNER TO prvgwy;

--
-- TOC entry 492 (class 1259 OID 293204)
-- Name: ods_notification_transaction; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_notification_transaction (
    ods_notification_transaction_id integer DEFAULT nextval('ng_orchestration.ods_notification_transaction_seq'::regclass) NOT NULL,
    ods_notification_config_id integer NOT NULL,
    request_payload text,
    status text NOT NULL,
    status_desc text,
    manifest_payload text,
    last_modified_ts timestamp with time zone DEFAULT now()
);


ALTER TABLE ng_orchestration.ods_notification_transaction OWNER TO prvgwy;

--
-- TOC entry 272 (class 1259 OID 212953)
-- Name: ods_param_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_param_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_param_config_seq OWNER TO prvgwy;

--
-- TOC entry 370 (class 1259 OID 213273)
-- Name: ods_param_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_param_config (
    param_id integer DEFAULT nextval('ng_orchestration.ods_param_config_seq'::regclass) NOT NULL,
    param_key character varying(500) NOT NULL,
    type character varying(500) NOT NULL,
    name character varying(16000),
    value character varying(32000)
);


ALTER TABLE ng_orchestration.ods_param_config OWNER TO prvgwy;

--
-- TOC entry 735 (class 1259 OID 621470)
-- Name: ods_request_log_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_request_log_seq
    START WITH 6501
    INCREMENT BY 100
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_request_log_seq OWNER TO prvgwy;

--
-- TOC entry 486 (class 1259 OID 246443)
-- Name: ods_request_log; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_request_log (
    ods_request_log_id integer DEFAULT nextval('ng_orchestration.ods_request_log_seq'::regclass) NOT NULL,
    title text DEFAULT NULL::character varying,
    title_version text DEFAULT NULL::character varying,
    wf_task_id text NOT NULL,
    wf_task_name text NOT NULL,
    wf_request_payload text NOT NULL,
    wf_task_status text DEFAULT NULL::character varying,
    response_status text DEFAULT NULL::character varying,
    wf_task_completion_payload text DEFAULT NULL::character varying,
    user_id text DEFAULT NULL::character varying,
    created_time timestamp with time zone,
    expiry_time timestamp with time zone,
    last_modified_time timestamp with time zone,
    completion_time timestamp with time zone,
    source text
);


ALTER TABLE ng_orchestration.ods_request_log OWNER TO prvgwy;

--
-- TOC entry 485 (class 1259 OID 246441)
-- Name: ods_request_log_ods_request_log_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_request_log_ods_request_log_id_seq OWNER TO prvgwy;

--
-- TOC entry 6903 (class 0 OID 0)
-- Dependencies: 485
-- Name: ods_request_log_ods_request_log_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq OWNED BY ng_orchestration.ods_request_log.ods_request_log_id;


--
-- TOC entry 739 (class 1259 OID 1037256)
-- Name: ods_request_log_temp; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_request_log_temp (
    ods_request_log_id integer,
    title text,
    title_version text,
    wf_task_id text,
    wf_task_name text,
    wf_request_payload text,
    wf_task_status text,
    response_status text,
    wf_task_completion_payload text,
    user_id text,
    created_time timestamp without time zone,
    expiry_time timestamp without time zone,
    last_modified_time timestamp without time zone,
    completion_time timestamp without time zone,
    source character varying,
    workstep_closure_retry_counter integer DEFAULT 0
);


ALTER TABLE ng_orchestration.ods_request_log_temp OWNER TO prvgwy;

--
-- TOC entry 273 (class 1259 OID 212955)
-- Name: ods_request_transaction_id_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_request_transaction_id_map_seq OWNER TO prvgwy;

--
-- TOC entry 371 (class 1259 OID 213280)
-- Name: ods_request_transaction_id_map; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_request_transaction_id_map (
    id integer DEFAULT nextval('ng_orchestration.ods_request_transaction_id_map_seq'::regclass) NOT NULL,
    flow_node_process_name character varying(500) NOT NULL,
    flow_node_step_name character varying(500) NOT NULL,
    transaction_id_key character varying(16000) NOT NULL
);


ALTER TABLE ng_orchestration.ods_request_transaction_id_map OWNER TO prvgwy;

--
-- TOC entry 497 (class 1259 OID 294826)
-- Name: ods_response_param_map; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_response_param_map (
    key character varying(255) NOT NULL,
    document_param character varying(255),
    response_param character varying(255)
);


ALTER TABLE ng_orchestration.ods_response_param_map OWNER TO prvgwy;

--
-- TOC entry 274 (class 1259 OID 212957)
-- Name: ods_response_transaction_id_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_response_transaction_id_map_seq OWNER TO prvgwy;

--
-- TOC entry 372 (class 1259 OID 213287)
-- Name: ods_response_transaction_id_map; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_response_transaction_id_map (
    id integer DEFAULT nextval('ng_orchestration.ods_response_transaction_id_map_seq'::regclass) NOT NULL,
    root_tag_name character varying(255),
    transaction_id_key character varying(255)
);


ALTER TABLE ng_orchestration.ods_response_transaction_id_map OWNER TO prvgwy;

--
-- TOC entry 487 (class 1259 OID 280734)
-- Name: ods_scheduler_lock_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_scheduler_lock_seq
    START WITH 18
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_scheduler_lock_seq OWNER TO prvgwy;

--
-- TOC entry 488 (class 1259 OID 280736)
-- Name: ods_scheduler_lock; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_scheduler_lock (
    lock_id integer DEFAULT nextval('ng_orchestration.ods_scheduler_lock_seq'::regclass) NOT NULL,
    lock_key character varying(128),
    lock_value character varying(10)
);


ALTER TABLE ng_orchestration.ods_scheduler_lock OWNER TO prvgwy;

--
-- TOC entry 275 (class 1259 OID 212959)
-- Name: ods_service_route_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_service_route_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_service_route_map_seq OWNER TO prvgwy;

--
-- TOC entry 373 (class 1259 OID 213294)
-- Name: ods_service_route_map; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_service_route_map (
    id integer DEFAULT nextval('ng_orchestration.ods_service_route_map_seq'::regclass) NOT NULL,
    app_key character varying(100),
    flow_node_process_name character varying(500) NOT NULL,
    flow_node_step_name character varying(500) NOT NULL,
    target_end_point_url character varying(500),
    username character varying(50),
    password character varying(100),
    request_document_name character varying(600),
    request_schema character varying(70000),
    response_document_name character varying(100),
    transformation_type character varying(45),
    route_protocol character varying(45),
    reply_to_queue_name character varying(150),
    send_milestone_enabled character varying(45),
    region character varying(45),
    src_system_name character varying(128),
    dest_system_name character varying(128),
    request_method character varying(150),
    supp_action character varying(50),
    service_mode character varying(5)
);


ALTER TABLE ng_orchestration.ods_service_route_map OWNER TO prvgwy;

--
-- TOC entry 276 (class 1259 OID 212961)
-- Name: ods_transformer_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_transformer_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_transformer_config_seq OWNER TO prvgwy;

--
-- TOC entry 374 (class 1259 OID 213301)
-- Name: ods_transformer_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_transformer_config (
    ods_transformer_config_id integer DEFAULT nextval('ng_orchestration.ods_transformer_config_seq'::regclass) NOT NULL,
    transformer_key character varying(128) NOT NULL,
    transformer_type character varying(64) NOT NULL,
    transformer_schema text NOT NULL
);


ALTER TABLE ng_orchestration.ods_transformer_config OWNER TO prvgwy;

--
-- TOC entry 498 (class 1259 OID 294834)
-- Name: ods_wf_correlation_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_wf_correlation_config (
    correlation_key character varying(255) NOT NULL,
    content_schema character varying(255),
    correlation_schema character varying(255)
);


ALTER TABLE ng_orchestration.ods_wf_correlation_config OWNER TO prvgwy;

--
-- TOC entry 277 (class 1259 OID 212963)
-- Name: ods_workflow_fallout_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_workflow_fallout_seq
    START WITH 1
    INCREMENT BY 100
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_workflow_fallout_seq OWNER TO prvgwy;

--
-- TOC entry 375 (class 1259 OID 213308)
-- Name: ods_workflow_fallout; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_workflow_fallout (
    id integer DEFAULT nextval('ng_orchestration.ods_workflow_fallout_seq'::regclass) NOT NULL,
    case_id text NOT NULL,
    workflow_retry_counter integer,
    workflow_process_name text,
    workflow_step_name text,
    status text,
    workflow_fallout_error_code text,
    workflow_fallout_error_desc text,
    workflow_fallout_error_category text,
    root_case_id text,
    wf_task_id text DEFAULT NULL::character varying,
    expiry_time timestamp with time zone,
    title text,
    title_version text,
    source text,
    external_task_id text,
    ute_task_info text,
    created_time timestamp with time zone DEFAULT now(),
    last_modified_time timestamp with time zone DEFAULT now()
);


ALTER TABLE ng_orchestration.ods_workflow_fallout OWNER TO prvgwy;

--
-- TOC entry 278 (class 1259 OID 212965)
-- Name: ods_workflow_fallout_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ods_workflow_fallout_config_seq OWNER TO prvgwy;

--
-- TOC entry 376 (class 1259 OID 213315)
-- Name: ods_workflow_fallout_config; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_workflow_fallout_config (
    id integer DEFAULT nextval('ng_orchestration.ods_workflow_fallout_config_seq'::regclass) NOT NULL,
    workflow_process_name character varying(500) NOT NULL,
    workflow_stepname character varying(500) NOT NULL,
    max_retry_counter character varying(45) NOT NULL,
    retry_interval character varying(45) NOT NULL,
    workflow_fallout_error_code character varying(45) NOT NULL,
    workflow_fallout_error_category character varying(128)
);


ALTER TABLE ng_orchestration.ods_workflow_fallout_config OWNER TO prvgwy;

--
-- TOC entry 907 (class 1259 OID 3564698)
-- Name: ods_workflow_fallout_temp; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.ods_workflow_fallout_temp (
    id integer,
    case_id character varying(200),
    workflow_retry_counter integer,
    workflow_process_name character varying(500),
    workflow_step_name character varying(500),
    status character varying(45),
    workflow_fallout_error_code character varying(45),
    workflow_fallout_error_desc text,
    workflow_fallout_error_category character varying(128),
    root_case_id character varying(128),
    wf_task_id character varying(128),
    expiry_time timestamp without time zone,
    title character varying(128),
    title_version character varying(50),
    source character varying(128),
    external_task_id character varying(128),
    ute_task_info text,
    created_time timestamp with time zone,
    last_modified_time timestamp without time zone
);


ALTER TABLE ng_orchestration.ods_workflow_fallout_temp OWNER TO prvgwy;

--
-- TOC entry 279 (class 1259 OID 212967)
-- Name: onenet_common_parameter_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.onenet_common_parameter_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.onenet_common_parameter_seq OWNER TO dbadmin;

--
-- TOC entry 377 (class 1259 OID 213322)
-- Name: onenet_common_parameter; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.onenet_common_parameter (
    id integer DEFAULT nextval('ng_orchestration.onenet_common_parameter_seq'::regclass) NOT NULL,
    param_key character varying(128) NOT NULL,
    param_value character varying(128) NOT NULL,
    param1 character varying(128),
    param2 character varying(128),
    param3 character varying(128),
    param4 character varying(128),
    created_by character varying(64),
    created_time date,
    description character varying(256)
);


ALTER TABLE ng_orchestration.onenet_common_parameter OWNER TO dbadmin;

--
-- TOC entry 280 (class 1259 OID 212969)
-- Name: onenet_holiday_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.onenet_holiday_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.onenet_holiday_seq OWNER TO dbadmin;

--
-- TOC entry 378 (class 1259 OID 213329)
-- Name: onenet_holiday; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.onenet_holiday (
    holiday_id integer DEFAULT nextval('ng_orchestration.onenet_holiday_seq'::regclass) NOT NULL,
    country character varying(2) NOT NULL,
    holiday_date date NOT NULL,
    category character varying(8) DEFAULT 'VZB'::character varying,
    name character varying(64) NOT NULL,
    last_update_time timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.onenet_holiday OWNER TO dbadmin;

--
-- TOC entry 281 (class 1259 OID 212971)
-- Name: onenet_milestone_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.onenet_milestone_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.onenet_milestone_seq OWNER TO dbadmin;

--
-- TOC entry 379 (class 1259 OID 213335)
-- Name: onenet_milestone; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.onenet_milestone (
    onenet_milestone_id integer DEFAULT nextval('ng_orchestration.onenet_milestone_seq'::regclass) NOT NULL,
    inventory_service_id integer,
    order_number character varying(32),
    order_version character varying(8),
    milestone_name character varying(64) NOT NULL,
    milestone_status character varying(64),
    site_type character varying(45),
    obsolete character varying(8) DEFAULT 'N'::character varying,
    create_date date NOT NULL
);


ALTER TABLE ng_orchestration.onenet_milestone OWNER TO dbadmin;

--
-- TOC entry 282 (class 1259 OID 212973)
-- Name: onenet_order_build_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.onenet_order_build_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.onenet_order_build_seq OWNER TO dbadmin;

--
-- TOC entry 380 (class 1259 OID 213340)
-- Name: onenet_order_build; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.onenet_order_build (
    onenet_order_build_id integer DEFAULT nextval('ng_orchestration.onenet_order_build_seq'::regclass) NOT NULL,
    order_number character varying(32) NOT NULL,
    order_id integer,
    order_source character varying(32),
    locationind character varying(32),
    child_seed_id character varying(20) DEFAULT 'N'::character varying,
    nfid_version character varying(32),
    assigned_engineer character varying(4),
    inventory_service_id integer,
    clli character varying(16),
    parent_case_id integer,
    case_id integer,
    nfid character varying(32),
    fad_date date,
    design_complete character varying(4),
    build_complete character varying(4),
    obsolete character varying(2) DEFAULT 'N'::character varying,
    create_date date,
    last_modified_date date,
    order_version character varying(30),
    nfid_type character varying(30),
    loc_review_complete character varying(4),
    eng_review_complete character varying(4)
);


ALTER TABLE ng_orchestration.onenet_order_build OWNER TO dbadmin;

--
-- TOC entry 283 (class 1259 OID 212975)
-- Name: onenet_order_data_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.onenet_order_data_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.onenet_order_data_seq OWNER TO dbadmin;

--
-- TOC entry 381 (class 1259 OID 213346)
-- Name: onenet_order_data; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.onenet_order_data (
    onenet_order_id integer DEFAULT nextval('ng_orchestration.onenet_order_data_seq'::regclass) NOT NULL,
    order_number character varying(32) NOT NULL,
    order_version character varying(8) NOT NULL,
    order_source character varying(24) NOT NULL,
    circuit_id character varying(24) NOT NULL,
    order_group_id character varying(32) NOT NULL,
    product_family character varying(16) NOT NULL,
    product_category character varying(24) NOT NULL,
    work_order_type character varying(24) NOT NULL,
    inventory_service_id integer,
    order_status character varying(64),
    case_id integer NOT NULL,
    obsolete character varying(2) DEFAULT 'N'::character varying,
    cust_req_due_date date,
    due_date_type character varying(10),
    supp_type character varying(120),
    a_site_id character varying(20),
    z_site_id character varying(20),
    commit_date date,
    creation_date date NOT NULL,
    last_update_date date NOT NULL,
    trail_id integer DEFAULT 0,
    svc_desc_name character varying(120)
);


ALTER TABLE ng_orchestration.onenet_order_data OWNER TO dbadmin;

--
-- TOC entry 284 (class 1259 OID 212977)
-- Name: onenet_transaction_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.onenet_transaction_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.onenet_transaction_seq OWNER TO dbadmin;

--
-- TOC entry 382 (class 1259 OID 213355)
-- Name: onenet_transaction; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.onenet_transaction (
    onenet_trans_id integer DEFAULT nextval('ng_orchestration.onenet_transaction_seq'::regclass) NOT NULL,
    order_number character varying(32) NOT NULL,
    order_version character varying(8) NOT NULL,
    order_source character varying(24) NOT NULL,
    trans_type character varying(16) NOT NULL,
    source_sys character varying(32) NOT NULL,
    dest_sys character varying(32) NOT NULL,
    trans_data text,
    trans_date date NOT NULL,
    task_name character varying(96)
);


ALTER TABLE ng_orchestration.onenet_transaction OWNER TO dbadmin;

--
-- TOC entry 285 (class 1259 OID 212979)
-- Name: ordchange_msg_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.ordchange_msg_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.ordchange_msg_config_seq OWNER TO dbadmin;

--
-- TOC entry 383 (class 1259 OID 213362)
-- Name: ordchange_msg_config; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.ordchange_msg_config (
    ordchange_msg_config_id integer DEFAULT nextval('ng_orchestration.ordchange_msg_config_seq'::regclass) NOT NULL,
    case_name text NOT NULL,
    bonita_url text NOT NULL,
    bonita_process_name text,
    bonita_flownode_name text,
    bonita_message_name text,
    request_payload text
);


ALTER TABLE ng_orchestration.ordchange_msg_config OWNER TO dbadmin;

--
-- TOC entry 465 (class 1259 OID 219305)
-- Name: orders; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.orders (
    order_id bigint NOT NULL,
    creationdate character varying(255),
    orequestjsonb character varying(255),
    product character varying(255),
    orderrequest jsonb
);


ALTER TABLE ng_orchestration.orders OWNER TO dbadmin;

--
-- TOC entry 729 (class 1259 OID 592441)
-- Name: orders_count_past_due; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.orders_count_past_due (
    past_due bigint
);


ALTER TABLE ng_orchestration.orders_count_past_due OWNER TO prvgwy;

--
-- TOC entry 730 (class 1259 OID 592445)
-- Name: orders_count_upcoming; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.orders_count_upcoming (
    upcoming bigint
);


ALTER TABLE ng_orchestration.orders_count_upcoming OWNER TO prvgwy;

--
-- TOC entry 695 (class 1259 OID 526116)
-- Name: organization; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.organization (
    organization_id numeric(9,0) NOT NULL,
    lob_id numeric(9,0),
    org_short_name character varying(15),
    function_area_id numeric(9,0) NOT NULL,
    org_display_name character varying(70) NOT NULL
);


ALTER TABLE ng_orchestration.organization OWNER TO prvgwy;

--
-- TOC entry 775 (class 1259 OID 1392740)
-- Name: organizationalentity; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.organizationalentity (
    dtype character varying(31) NOT NULL,
    id character varying(255) NOT NULL
);


ALTER TABLE ng_orchestration.organizationalentity OWNER TO prvgwy;

--
-- TOC entry 722 (class 1259 OID 558639)
-- Name: p_date; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.p_date (
    date date
);


ALTER TABLE ng_orchestration.p_date OWNER TO prvgwy;

--
-- TOC entry 660 (class 1259 OID 498108)
-- Name: pipeline_setting; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.pipeline_setting (
    pipeline_id integer NOT NULL,
    vz_id character varying(20),
    pipeline_setting jsonb
);


ALTER TABLE ng_orchestration.pipeline_setting OWNER TO prvgwy;

--
-- TOC entry 659 (class 1259 OID 498106)
-- Name: pipeline_setting_pipeline_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.pipeline_setting_pipeline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.pipeline_setting_pipeline_id_seq OWNER TO prvgwy;

--
-- TOC entry 6944 (class 0 OID 0)
-- Dependencies: 659
-- Name: pipeline_setting_pipeline_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.pipeline_setting_pipeline_id_seq OWNED BY ng_orchestration.pipeline_setting.pipeline_id;


--
-- TOC entry 523 (class 1259 OID 356932)
-- Name: pn_region_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.pn_region_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.pn_region_seq OWNER TO prvgwy;

--
-- TOC entry 524 (class 1259 OID 356934)
-- Name: pn_region; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.pn_region (
    region_id integer DEFAULT nextval('ng_orchestration.pn_region_seq'::regclass) NOT NULL,
    region_name character varying(30) NOT NULL,
    region_ind integer,
    modified_date integer
);


ALTER TABLE ng_orchestration.pn_region OWNER TO prvgwy;

--
-- TOC entry 525 (class 1259 OID 356962)
-- Name: pn_state_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.pn_state_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.pn_state_seq OWNER TO prvgwy;

--
-- TOC entry 526 (class 1259 OID 356964)
-- Name: pn_state; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.pn_state (
    state_id integer DEFAULT nextval('ng_orchestration.pn_state_seq'::regclass) NOT NULL,
    state_code character varying(2) NOT NULL,
    state_name character varying(30),
    time_zone integer,
    pn_region_id integer
);


ALTER TABLE ng_orchestration.pn_state OWNER TO prvgwy;

--
-- TOC entry 902 (class 1259 OID 2217534)
-- Name: preference_group; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.preference_group (
    preference_group_id numeric(9,0) NOT NULL,
    module character varying(32),
    sub_module character varying(32),
    name character varying(100),
    type numeric(10,0),
    default_value character varying(255),
    dialog_no numeric(9,0),
    is_group numeric(9,0),
    preference_label character varying(32),
    param_desc character varying(255),
    display_width character(18),
    data_source character varying(255),
    multi_select numeric(9,0),
    data_source_type character varying(255)
);


ALTER TABLE ng_orchestration.preference_group OWNER TO prvgwy;

--
-- TOC entry 548 (class 1259 OID 378166)
-- Name: prism_seq_id; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.prism_seq_id
    START WITH 1000000000
    INCREMENT BY 1
    MINVALUE 1000000000
    MAXVALUE 9999999999
    CACHE 1;


ALTER TABLE ng_orchestration.prism_seq_id OWNER TO prvgwy;

--
-- TOC entry 763 (class 1259 OID 1370960)
-- Name: proc_inst_log_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.proc_inst_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.proc_inst_log_id_seq OWNER TO prvgwy;

--
-- TOC entry 764 (class 1259 OID 1370962)
-- Name: process_instance_info_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.process_instance_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.process_instance_info_id_seq OWNER TO prvgwy;

--
-- TOC entry 741 (class 1259 OID 1161334)
-- Name: product_unbld; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.product_unbld (
    product_unbld_id numeric(9,0) NOT NULL,
    product_cd character varying(15) NOT NULL,
    product_desc character varying(50),
    disconnect numeric(9,0)
);


ALTER TABLE ng_orchestration.product_unbld OWNER TO prvgwy;

--
-- TOC entry 286 (class 1259 OID 212981)
-- Name: project_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.project_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.project_seq OWNER TO dbadmin;

--
-- TOC entry 384 (class 1259 OID 213369)
-- Name: project; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.project (
    project_id integer DEFAULT nextval('ng_orchestration.project_seq'::regclass) NOT NULL,
    name character varying(100) NOT NULL,
    comments character varying(4000),
    project_number character varying(100) NOT NULL,
    type character varying(100) NOT NULL,
    owner character varying(100) NOT NULL,
    contact character varying(100),
    start_date date NOT NULL,
    cut_over_date date NOT NULL,
    status character varying(100) NOT NULL
);


ALTER TABLE ng_orchestration.project OWNER TO dbadmin;

--
-- TOC entry 385 (class 1259 OID 213376)
-- Name: project_cmd_cache; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.project_cmd_cache (
    project_id integer NOT NULL,
    command_cache character varying(4000)
);


ALTER TABLE ng_orchestration.project_cmd_cache OWNER TO dbadmin;

--
-- TOC entry 287 (class 1259 OID 212983)
-- Name: project_details_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.project_details_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.project_details_seq OWNER TO dbadmin;

--
-- TOC entry 386 (class 1259 OID 213382)
-- Name: project_details; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.project_details (
    project_details_id integer DEFAULT nextval('ng_orchestration.project_details_seq'::regclass) NOT NULL,
    project_id integer NOT NULL,
    action character varying(50) NOT NULL,
    trail_name character varying(100) NOT NULL,
    trail_id integer NOT NULL,
    src_trail_id integer NOT NULL,
    component_id integer,
    src_component_id integer NOT NULL,
    order_number character varying(100) NOT NULL,
    svc_order_id integer NOT NULL,
    service_id integer NOT NULL,
    element_id integer NOT NULL,
    sequence integer NOT NULL,
    a_site_id integer NOT NULL,
    a_site_name character varying(300) NOT NULL,
    a_site_state character varying(2),
    z_site_id integer NOT NULL,
    z_site_name character varying(300) NOT NULL,
    z_site_state character varying(2),
    is_rider character varying(1) DEFAULT 'N'::character varying NOT NULL,
    explicit_route_name character varying(100)
);


ALTER TABLE ng_orchestration.project_details OWNER TO dbadmin;

--
-- TOC entry 387 (class 1259 OID 213390)
-- Name: qrtz_blob_triggers; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE ng_orchestration.qrtz_blob_triggers OWNER TO dbadmin;

--
-- TOC entry 388 (class 1259 OID 213396)
-- Name: qrtz_calendars; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE ng_orchestration.qrtz_calendars OWNER TO dbadmin;

--
-- TOC entry 389 (class 1259 OID 213402)
-- Name: qrtz_cron_triggers; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(200) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE ng_orchestration.qrtz_cron_triggers OWNER TO dbadmin;

--
-- TOC entry 390 (class 1259 OID 213408)
-- Name: qrtz_fired_triggers; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    sched_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent character varying(8),
    requests_recovery character varying(8)
);


ALTER TABLE ng_orchestration.qrtz_fired_triggers OWNER TO dbadmin;

--
-- TOC entry 391 (class 1259 OID 213414)
-- Name: qrtz_job_details; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable character varying(10) NOT NULL,
    is_nonconcurrent character varying(10) NOT NULL,
    is_update_data character varying(10) NOT NULL,
    requests_recovery character varying(10) NOT NULL,
    job_data bytea
);


ALTER TABLE ng_orchestration.qrtz_job_details OWNER TO dbadmin;

--
-- TOC entry 392 (class 1259 OID 213420)
-- Name: qrtz_locks; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


ALTER TABLE ng_orchestration.qrtz_locks OWNER TO dbadmin;

--
-- TOC entry 393 (class 1259 OID 213423)
-- Name: qrtz_paused_trigger_grps; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


ALTER TABLE ng_orchestration.qrtz_paused_trigger_grps OWNER TO dbadmin;

--
-- TOC entry 394 (class 1259 OID 213426)
-- Name: qrtz_scheduler_state; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE ng_orchestration.qrtz_scheduler_state OWNER TO dbadmin;

--
-- TOC entry 395 (class 1259 OID 213429)
-- Name: qrtz_simple_triggers; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE ng_orchestration.qrtz_simple_triggers OWNER TO dbadmin;

--
-- TOC entry 396 (class 1259 OID 213436)
-- Name: qrtz_simprop_triggers; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 character varying(8),
    bool_prop_2 character varying(8)
);


ALTER TABLE ng_orchestration.qrtz_simprop_triggers OWNER TO dbadmin;

--
-- TOC entry 397 (class 1259 OID 213442)
-- Name: qrtz_triggers; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.qrtz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr smallint,
    job_data bytea
);


ALTER TABLE ng_orchestration.qrtz_triggers OWNER TO dbadmin;

--
-- TOC entry 765 (class 1259 OID 1370964)
-- Name: query_def_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.query_def_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.query_def_id_seq OWNER TO prvgwy;

--
-- TOC entry 470 (class 1259 OID 233530)
-- Name: raj; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.raj (
    name character(4)
);


ALTER TABLE ng_orchestration.raj OWNER TO prvgwy;

--
-- TOC entry 481 (class 1259 OID 234123)
-- Name: rajtest; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.rajtest (
    id bigint NOT NULL,
    name character(1)
);


ALTER TABLE ng_orchestration.rajtest OWNER TO dbadmin;

--
-- TOC entry 480 (class 1259 OID 234121)
-- Name: rajtest_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.rajtest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.rajtest_id_seq OWNER TO dbadmin;

--
-- TOC entry 6974 (class 0 OID 0)
-- Dependencies: 480
-- Name: rajtest_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: dbadmin
--

ALTER SEQUENCE ng_orchestration.rajtest_id_seq OWNED BY ng_orchestration.rajtest.id;


--
-- TOC entry 776 (class 1259 OID 1392781)
-- Name: reassignment; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.reassignment (
    id bigint NOT NULL,
    escalation_reassignments_id bigint
);


ALTER TABLE ng_orchestration.reassignment OWNER TO prvgwy;

--
-- TOC entry 766 (class 1259 OID 1370966)
-- Name: reassignment_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.reassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.reassignment_id_seq OWNER TO prvgwy;

--
-- TOC entry 538 (class 1259 OID 357129)
-- Name: region_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.region_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.region_seq OWNER TO prvgwy;

--
-- TOC entry 539 (class 1259 OID 357131)
-- Name: region; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.region (
    region_id integer DEFAULT nextval('ng_orchestration.region_seq'::regclass) NOT NULL,
    region_name character varying(30) NOT NULL,
    region_ind integer,
    modified_date integer,
    time_zone character varying(50)
);


ALTER TABLE ng_orchestration.region OWNER TO prvgwy;

--
-- TOC entry 767 (class 1259 OID 1370968)
-- Name: request_info_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.request_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.request_info_id_seq OWNER TO prvgwy;

--
-- TOC entry 706 (class 1259 OID 527336)
-- Name: rn_line_code; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.rn_line_code (
    linecode_id numeric(9,0) NOT NULL,
    request_category numeric(9,0) NOT NULL,
    line_code character varying(25) NOT NULL
);


ALTER TABLE ng_orchestration.rn_line_code OWNER TO prvgwy;

--
-- TOC entry 696 (class 1259 OID 526129)
-- Name: rn_user_ext; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.rn_user_ext (
    user_ext_id numeric(9,0) NOT NULL,
    sales_code character varying(20),
    uu_code character varying(7),
    avail_assign numeric(9,0),
    active_flag numeric(9,0),
    modified_date numeric(10,0),
    last_login numeric(10,0),
    inactive_date numeric(10,0),
    access_team numeric(9,0),
    spocnet numeric(9,0),
    login_time numeric(10,0),
    logout_time numeric(10,0)
);


ALTER TABLE ng_orchestration.rn_user_ext OWNER TO prvgwy;

--
-- TOC entry 530 (class 1259 OID 357004)
-- Name: rqn_document_store; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.rqn_document_store (
    id integer NOT NULL,
    sr_number character varying(64) NOT NULL,
    document_name character varying(64) NOT NULL,
    document jsonb
);


ALTER TABLE ng_orchestration.rqn_document_store OWNER TO prvgwy;

--
-- TOC entry 529 (class 1259 OID 357002)
-- Name: rqn_document_store_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.rqn_document_store_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.rqn_document_store_seq OWNER TO prvgwy;

--
-- TOC entry 6984 (class 0 OID 0)
-- Dependencies: 529
-- Name: rqn_document_store_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.rqn_document_store_seq OWNED BY ng_orchestration.rqn_document_store.id;


--
-- TOC entry 662 (class 1259 OID 498119)
-- Name: saved_columns; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.saved_columns (
    saved_column_id integer NOT NULL,
    vz_id character varying(20),
    pipeline_id integer,
    saved_columns_json jsonb
);


ALTER TABLE ng_orchestration.saved_columns OWNER TO prvgwy;

--
-- TOC entry 661 (class 1259 OID 498117)
-- Name: saved_columns_saved_column_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.saved_columns_saved_column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.saved_columns_saved_column_id_seq OWNER TO prvgwy;

--
-- TOC entry 6987 (class 0 OID 0)
-- Dependencies: 661
-- Name: saved_columns_saved_column_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.saved_columns_saved_column_id_seq OWNED BY ng_orchestration.saved_columns.saved_column_id;


--
-- TOC entry 288 (class 1259 OID 212985)
-- Name: search_cache_event_monitor_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.search_cache_event_monitor_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.search_cache_event_monitor_seq OWNER TO dbadmin;

--
-- TOC entry 398 (class 1259 OID 213448)
-- Name: search_cache_event_monitor; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.search_cache_event_monitor (
    event_id bigint DEFAULT nextval('ng_orchestration.search_cache_event_monitor_seq'::regclass) NOT NULL,
    table_name character varying(100) NOT NULL,
    key_name character varying(100),
    key_value character varying(60) NOT NULL,
    mod_type character varying(15),
    creation_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    modify_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone,
    status character varying(50),
    remarks character varying(300)
);


ALTER TABLE ng_orchestration.search_cache_event_monitor OWNER TO dbadmin;

--
-- TOC entry 694 (class 1259 OID 526106)
-- Name: sec_groups; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sec_groups (
    sec_group_id numeric(9,0) NOT NULL,
    sec_group_name character varying(32) NOT NULL,
    grp_abbreviation character varying(16),
    parent_group_id numeric(9,0),
    group_type numeric(9,0) NOT NULL,
    schedule_id numeric(9,0) NOT NULL
);


ALTER TABLE ng_orchestration.sec_groups OWNER TO prvgwy;

--
-- TOC entry 692 (class 1259 OID 525903)
-- Name: sec_users; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sec_users (
    sec_user_id numeric(9,0) NOT NULL,
    sec_login_id character varying(32) NOT NULL,
    sec_user_ssn character varying(12),
    sec_user_firstname character varying(32),
    sec_user_lastname character varying(32) NOT NULL,
    sec_user_phone character varying(20) NOT NULL,
    sec_user_email character varying(120),
    sec_user_status character varying(1),
    sec_supervisor numeric(9,0),
    sec_mother_name character varying(32) NOT NULL,
    sec_password character varying(18),
    sec_cpasswd_time date,
    sec_passwd_age numeric(9,0),
    sec_fst_login_flag character varying(1) NOT NULL,
    sec_suspend_flag character varying(1) NOT NULL,
    sec_susp_reason character varying(80),
    sec_failed_attmpts numeric(9,0),
    sec_fst_fail_time date,
    sec_start_date date,
    sec_end_date date,
    primary_group_id numeric(9,0),
    primary_role_id numeric(9,0),
    middle_initial character varying(1),
    fax_number character varying(14),
    obsolete_flag numeric(9,0) NOT NULL,
    sec_vz_id character varying(7) NOT NULL
);


ALTER TABLE ng_orchestration.sec_users OWNER TO prvgwy;

--
-- TOC entry 663 (class 1259 OID 519197)
-- Name: service_determination_details; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.service_determination_details (
    ccna character varying(3) NOT NULL,
    pon character varying(16) NOT NULL,
    asr_id character varying(13) NOT NULL,
    service_type_cd character varying(50),
    service_category_cd character varying(8),
    ckl1_termination character varying(20),
    ckl2_termination character varying(20),
    speed_nc_map_id bigint,
    tls_speed bigint,
    nc_code character varying(5),
    nci_code character varying(12),
    sec_nci_code character varying(12),
    obsolete_flag bigint,
    handoff bigint,
    duplex bigint,
    tls_type bigint,
    ers_type bigint,
    transport_nci character varying(12),
    transport_sec_nci character varying(12),
    spec character varying(10),
    tls_termination bigint,
    transport_nc character varying(5),
    date_created bigint,
    last_modified bigint,
    refnum character varying(10)
);


ALTER TABLE ng_orchestration.service_determination_details OWNER TO prvgwy;

--
-- TOC entry 552 (class 1259 OID 397892)
-- Name: service_flavor; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.service_flavor (
    flavor_id integer NOT NULL,
    service_type_id integer NOT NULL,
    fx integer,
    itc integer,
    ixc integer,
    coloc integer,
    mux integer,
    ckl1 integer NOT NULL,
    ckl2 integer,
    fmc_ckl1 integer,
    fmc_ckl2 integer,
    psm_clli integer,
    handoff_reqd integer,
    pri_type_reqd integer,
    channel_svc_reqd integer,
    iof integer,
    sysid_reqd integer,
    tks_reqd integer,
    line_code_reqd integer,
    framing_reqd integer,
    cne integer,
    roc integer,
    modified_date integer NOT NULL,
    cfa integer,
    noc integer,
    iroc integer,
    e2e integer,
    enterprise integer,
    nrs integer,
    dual_homing integer,
    hub_conn_id integer,
    ckl2_hub_conn_id integer,
    universal_enterprise integer,
    cne2 integer,
    iof2 integer,
    flas integer,
    flas_ckl1 integer,
    flas_ckl2 integer,
    sonet integer,
    ibt integer,
    idsr integer,
    ief integer,
    ctx integer,
    iof_plan integer,
    wireless integer,
    flavor_group integer,
    virtual_cea integer,
    mtso integer,
    cell_site integer,
    intellinet_flag integer,
    host_remote integer,
    on_ring integer,
    custom_connect integer,
    spec_const_cand integer,
    bod integer,
    offring_oc768 integer,
    fttc integer,
    cap_chk_cand integer
);


ALTER TABLE ng_orchestration.service_flavor OWNER TO prvgwy;

--
-- TOC entry 512 (class 1259 OID 356821)
-- Name: service_request; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.service_request (
    sr_id numeric NOT NULL,
    cr_id character varying(20) NOT NULL,
    service_type_id numeric(4,0),
    corridor_id integer,
    sr_cancel_id integer,
    sr_seq character varying(3),
    sr_status numeric(4,0),
    sr_order_type numeric(4,0),
    date_created integer,
    service_order_no character varying(32),
    date_closed integer,
    customer_name character varying(30),
    modified_date integer,
    noc_service_category_id integer,
    ent integer,
    nrs integer,
    ican_type character varying(2),
    uent integer,
    flas integer,
    sonet character varying(10),
    was_inquiry integer,
    change_flag character varying(1),
    invoke_indicator character varying(1),
    buildnet_indicator integer,
    onepass_indicator integer,
    opi_status_code character varying(1),
    opi_modified_date integer,
    lob_id integer,
    work_id integer,
    sales_lob_id integer,
    asr_ind integer,
    date_issued integer,
    response_req_by integer,
    cafe_key integer,
    std_interval_days integer,
    apot character varying(11),
    channel_capacity integer,
    rqmanager_ver character varying(2),
    exp_dd_accepted integer,
    sn_fmc_date_sent integer,
    interval_given integer,
    cyber_trax_id integer,
    ct_req_type character varying(15),
    sn_button_used integer,
    sn_date_used integer,
    sn_button_exists integer,
    sn_button_used_by character varying(32),
    sent_to_sn integer,
    send_sn_count integer,
    sent_to_bldnet integer,
    spectrum_flag integer,
    intellinet_flag integer,
    esg_case_id character varying(25),
    esg_item_no character varying(5),
    esg_status integer,
    exact_refnum character varying(6),
    fx integer,
    df_flag integer,
    iof_send_sn_count numeric(4,0),
    aswc_ind integer,
    psc_ind character varying(1),
    prev_onepass_indicator integer,
    vad_service_order_no character varying(17),
    wireless_inq_ind integer,
    req_type character varying(2),
    lspan_rerouted integer,
    can_bypass_js integer,
    sr_label character varying(70),
    mcp_reply_to character varying(255),
    has_intermediate_cfa integer,
    qa_ind integer,
    cafe_esg_ind integer,
    activity_ind integer,
    cbscne_case_id integer,
    baais_event_id character varying(70),
    une_pf_rn character varying(1),
    eel_eng_ind integer,
    eel_eng_btn_status integer,
    inq_sr_id integer,
    expedite_failure_msg character varying(50),
    related_sr_id integer,
    accord_conversion_flag integer,
    source_system character varying(12),
    ds_reservation_id integer,
    qcode_offset_time integer,
    total_duration integer,
    sn_request_type integer,
    case_expiration_date integer,
    transport_service_order_no character varying(32),
    cloned_from_sr_id integer,
    lqp_message_id character varying(35),
    ief_indicator integer,
    facility_ver_flag integer,
    spec_const_case_id character varying(12),
    bod_flag integer,
    symp_query_id character varying(15),
    multiple_tirks integer,
    corr integer,
    sent_to_vbuild integer,
    checking_cap integer,
    sent_to_vnpo integer,
    apf_flag integer,
    cw_order_id character varying(25),
    access_loop_type character varying(25),
    fttc_cand integer,
    no_engg_design character varying(10),
    traffic_type character varying(10),
    budget_lob_name character varying(15),
    threshold_exceeded integer,
    cross_region integer,
    sec_rgn_order_no character varying(32),
    agg_device_flag integer,
    pc_order_id character varying(25),
    vrd_order_ind integer,
    ess_flag integer,
    exp_sr_duration integer,
    exp_qcode_offset_time integer,
    network_ready_date integer,
    vps_special_sla integer,
    baais_assignment integer,
    parallel_provisioning integer,
    single_dispatch integer,
    pp_date_calculation_flag integer,
    smart_box_ind character varying(1),
    fac_check_ms_flag integer,
    optical_extension integer,
    calc_by_vzot_flag integer,
    ewa_tweak integer,
    vbuild_lookup_ms_flag integer,
    vzot_transaction_id character varying(20),
    support_done integer,
    onenetwork_qualified integer,
    nf_id_flag integer,
    cno character varying(20),
    pg_order_number character varying(32),
    pg_order_version character varying(5)
);


ALTER TABLE ng_orchestration.service_request OWNER TO prvgwy;

--
-- TOC entry 551 (class 1259 OID 397861)
-- Name: service_type; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.service_type (
    service_type_id numeric(9,0) NOT NULL,
    svc_type_cat_id integer NOT NULL,
    service_type_cd character varying(50) NOT NULL,
    service_type_desc character varying(50),
    request_category integer,
    stage integer,
    service_type_indicator integer,
    disconnect integer
);


ALTER TABLE ng_orchestration.service_type OWNER TO prvgwy;

--
-- TOC entry 550 (class 1259 OID 397818)
-- Name: service_type_category; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.service_type_category (
    svc_type_cat_id integer NOT NULL,
    service_category_cd character varying(8) NOT NULL
);


ALTER TABLE ng_orchestration.service_type_category OWNER TO prvgwy;

--
-- TOC entry 768 (class 1259 OID 1370970)
-- Name: sessioninfo_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.sessioninfo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.sessioninfo_id_seq OWNER TO prvgwy;

--
-- TOC entry 658 (class 1259 OID 497945)
-- Name: spog_user_settings; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.spog_user_settings (
    vz_id character varying(32) NOT NULL,
    ui_object_name character varying(128) NOT NULL,
    setting jsonb,
    last_modified_by character varying(40),
    last_modified_date date
);


ALTER TABLE ng_orchestration.spog_user_settings OWNER TO prvgwy;

--
-- TOC entry 717 (class 1259 OID 542486)
-- Name: sr_address_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.sr_address_id_seq
    START WITH 13169718
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 99999999999999999
    CACHE 20
    CYCLE;


ALTER TABLE ng_orchestration.sr_address_id_seq OWNER TO prvgwy;

--
-- TOC entry 710 (class 1259 OID 531079)
-- Name: sr_address_info; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_address_info (
    sr_address_id numeric(10,0) NOT NULL,
    name character varying(50),
    contact character varying(50),
    address character varying(100),
    phone character varying(20),
    fax character varying(15),
    mobile character varying(15),
    pager character varying(25),
    internet_address character varying(75),
    room character varying(25),
    floor character varying(80),
    building character varying(15),
    city character varying(50),
    state_id numeric(9,0),
    zip character varying(5),
    zip4 character varying(4),
    email_id character varying(40),
    sapr character varying(6),
    sano character varying(10),
    sasf character varying(4),
    sasd character varying(2),
    sasn character varying(60),
    sath character varying(7),
    sass character varying(6),
    alt_contact character varying(50),
    alt_phone character varying(20),
    ld1 character varying(50),
    ld2 character varying(50),
    ld3 character varying(50),
    cust_contacted_name character varying(30),
    cust_contacted_phone character varying(14),
    alt_sec_phone character varying(14),
    alt_email_id character varying(40),
    lcon_email character varying(60),
    alcon_email character varying(60),
    aai character varying(150),
    aft character varying(1),
    valid_address_flag numeric(1,0),
    aalcon_tel character varying(20),
    addl_alcon_tel character varying(20),
    address_id numeric(9,0),
    wirecenter_id character varying(10),
    address_change_flag numeric(1,0),
    ahn character varying(10),
    latitude character varying(11),
    longitude character varying(11)
);


ALTER TABLE ng_orchestration.sr_address_info OWNER TO prvgwy;

--
-- TOC entry 690 (class 1259 OID 525172)
-- Name: sr_ckl_fmc; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_ckl_fmc (
    sr_id numeric(9,0) NOT NULL,
    ckl_type numeric(9,0) NOT NULL,
    facility_avail_flag numeric(9,0),
    local_clli character varying(11),
    local_pdac character varying(25),
    ewo character varying(18),
    dsx_ind numeric(9,0),
    edsx_clli character varying(16),
    date_avail numeric(10,0),
    feed_type numeric(9,0),
    tax_district_id character varying(4),
    fmc_eng_wks_sendable numeric(10,0),
    asw numeric(9,0),
    local_pdac_pop_by numeric(10,0),
    work_type numeric(9,0),
    fmc_ican character varying(15),
    fmc_scid character varying(10),
    lopp_not_q numeric(9,0),
    loop_length character varying(10),
    fac_test_pair character varying(10),
    fac_test_cable character varying(10),
    loop_qualified numeric(9,0),
    fac_type character varying(10),
    sccxr character varying(23),
    sysid character varying(10),
    fmc_plant numeric(10,0),
    fmc_ewo character varying(18),
    osp_eng character varying(7),
    fmc_special_con numeric(9,0),
    fmc_sonet_scid character varying(7),
    dual_ent numeric(9,0),
    fmc_sonet_pass numeric(9,0),
    fmc_sysid character varying(50),
    fmc_sys_clo character varying(12),
    ccr character varying(18),
    teo character varying(18),
    anom character varying(18),
    clo character varying(18),
    modified_date numeric(10,0),
    director_name character varying(50),
    ewo_note character varying(255),
    date_sent numeric(10,0),
    fmc_eng_assigned character varying(32),
    fmc_adslc numeric(9,0),
    fmc_adslr numeric(9,0),
    bn_resend_flag numeric(9,0),
    fmc_teo character varying(18),
    f1_cable character varying(10),
    f1_pair character varying(5),
    f1_terminal character varying(50),
    f2_cable character varying(10),
    f2_pair character varying(5),
    f2_terminal character varying(50),
    f3_cable character varying(10),
    f3_pair character varying(5),
    f3_terminal character varying(50),
    bldnet_reroute_ind numeric(9,0),
    tls_select_nm numeric(9,0),
    miles_tls_swc numeric(9,0),
    vertical_flr_to_flr numeric(9,0),
    estimated_db_loss character varying(7),
    intellinet_flag numeric(9,0),
    overall_port numeric(9,0),
    overall_spare numeric(9,0),
    ewo_confirmed numeric(9,0),
    tot_mile_tls_swc character varying(7),
    sys_id_copy character varying(50),
    sys_clo_copy character varying(12),
    osp_interval numeric(9,0),
    cable_frame character varying(15),
    rt_clli character varying(11),
    terminal_address character varying(50),
    lspan_status numeric(9,0),
    send_status numeric(9,0),
    aswc_clli character varying(11),
    co_card_type numeric(9,0),
    co_mounting_shelf numeric(9,0),
    co_in_place_card numeric(9,0),
    cust_card_type numeric(9,0),
    cust_mounting_shelf numeric(9,0),
    cust_in_place_card numeric(9,0),
    engineer_name character varying(31),
    fmc_parts_qualified numeric(9,0),
    pg character varying(8),
    pair1 numeric(5,0),
    pair2 numeric(5,0),
    mid_span_rep_req numeric(9,0),
    unload_pairs numeric(9,0),
    rem_bridge_taps numeric(9,0),
    reason_not_qual numeric(9,0),
    loop_qual_with_cond numeric(9,0),
    alert_code character varying(6),
    alert_desc character varying(255),
    remote_clli character varying(11),
    fmc_rerouted numeric(9,0),
    fmc_rerouted2 numeric(9,0),
    alternate_feed character varying(11),
    reroute_alerted numeric(9,0),
    orb_rr character varying(10),
    orb_sh_sl character varying(6),
    orb_dsx_rr character varying(10),
    orb_dsx_pl_jk character varying(6),
    clli_popby_lq numeric(9,0),
    fni character varying(20),
    e2e_pdac character varying(25),
    mcp_bypass_id numeric(9,0),
    div_fiber_protection numeric(9,0),
    reason numeric(9,0),
    sn_button_used_by character varying(32),
    sent_to_sn numeric(9,0),
    send_sn_count numeric(9,0),
    sn_button_used numeric(9,0),
    sn_sent_1 numeric(9,0),
    sn_sent_2 numeric(9,0),
    sn_sent_3 numeric(9,0),
    sn_sent_4 numeric(9,0),
    new_ewo numeric(9,0),
    eng_analysis_finish_flag numeric(9,0),
    bypass_selectnet numeric(9,0),
    dgf_processed_flag numeric(9,0),
    dwid character varying(7),
    accept_e2e_pdac numeric(9,0),
    e2e_overall_pdac character varying(7),
    lfrnt_exception_type numeric(9,0),
    dcs_clli character varying(11),
    spec_const_type numeric(9,0),
    accept_lfrnt_cable numeric(9,0),
    est_adr character varying(1),
    ethernet_compatibility numeric(9,0),
    ethernet_software_ver character varying(20),
    ethernet_mapping numeric(9,0),
    osp_review_done numeric(9,0),
    ethernet_dcc_compatibility numeric(9,0),
    lfacs_lc_indicator_removed numeric(9,0),
    loop_not_qualified_reason numeric(9,0),
    fmc_mcp_pdac character varying(25),
    fmc_mcp_overall_pdac character varying(25),
    sc_modified_date numeric(10,0),
    sent_to_sn_count numeric(9,0),
    lst_status numeric(9,0),
    lspan_modified numeric(9,0),
    nid_ordered numeric(9,0),
    eucr_status numeric(9,0),
    eu_contingency numeric(9,0),
    build numeric(9,0),
    cost character varying(10),
    nid_environment numeric(9,0),
    nid_required numeric(1,0),
    teo_project_id character varying(7),
    handoff_type numeric(9,0),
    bypass_fiber_cable numeric(1,0),
    design_compliant numeric(1,0),
    purchase_order_no character varying(100),
    nid_teo character varying(20),
    jumper_mid character varying(18),
    harness_mid character varying(18),
    relay_rack character varying(12),
    entrance_cfa_scfa numeric(1,0),
    vbuild_work_ord_num character varying(150),
    nid_ccr numeric(10,0),
    vbuild_eng_name character varying(100),
    vbuild_eng_tel character varying(20),
    vbuild_eng_email character varying(50),
    bay_type numeric(9,0),
    floor character varying(3),
    lineup character varying(50),
    bay character varying(25),
    bay_name character varying(25),
    unit character varying(6),
    interface_type numeric(9,0),
    hecig_code character varying(15),
    dpea character varying(50),
    nid_info character varying(500),
    auto_callout numeric(1,0),
    wire_center character varying(10),
    remote_code character varying(10),
    control_numeric character varying(10),
    override_interval numeric(1,0),
    override_interval_reason character varying(50),
    gpon numeric(2,0),
    gpon_btn_used numeric(9,0),
    non_gpon_reason character varying(20),
    site_walk_required numeric(2,0),
    date_calculated numeric(1,0),
    char_osp_eng character varying(7),
    legacy_project_id character varying(7),
    main_work_type numeric(9,0),
    osp_ciat_completed numeric(9,0),
    inq_essm numeric(9,0),
    sfp_xfp numeric(9,0),
    director_id numeric(9,0),
    no_site_survey_reason numeric(9,0),
    alt_feed_lso character varying(6),
    iof_issued_date numeric(10,0),
    optical_order_issue_date numeric(10,0),
    network_rsd character varying(30),
    optical_rate character varying(30),
    node_ring character varying(20),
    speed_requirement character varying(20),
    copper_avail numeric(1,0),
    budget_code character varying(30),
    request_triggered numeric(1,0),
    parallel_routing_enabled numeric(1,0),
    parallel_provisioning numeric(1,0),
    planning_package_required numeric(1,0),
    pp_system_determined numeric(1,0),
    clli_lookup_status numeric(9,0),
    smart_box numeric(9,0),
    smart_box_work_type character varying(40),
    adva_enclosure numeric(9,0),
    adva_co_equip numeric(9,0),
    adva_enclosure_desc character varying(200),
    adva_reflector_type numeric(9,0),
    ta_5000_clli character varying(11),
    bau_facility_avail numeric(9,0),
    bau_work_type character varying(40),
    fios_facility_avail numeric(9,0),
    fios_work_type character varying(40),
    sb_facility_check numeric(9,0),
    site_readiness numeric(9,0),
    no_site_readiness_reason numeric(9,0),
    general_comments character varying(3000),
    site_quote_provided numeric(2,0),
    quote_status numeric(1,0),
    wr_nf_id character varying(50),
    auto_gpon_select numeric(1,0),
    ewo_nf_id character varying(50)
);


ALTER TABLE ng_orchestration.sr_ckl_fmc OWNER TO prvgwy;

--
-- TOC entry 709 (class 1259 OID 530790)
-- Name: sr_ckl_sales; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_ckl_sales (
    sr_id numeric(15,0) NOT NULL,
    ckl_type numeric(9,0) NOT NULL,
    sr_equipment_id numeric(9,0),
    co_type numeric(9,0),
    sales_noc_send_flag numeric(9,0),
    central_office character varying(30),
    co_clli character varying(16),
    cust_contact_id numeric(9,0),
    enduser_customer_name character varying(50),
    additional_co character varying(30),
    additional_clli character varying(11),
    working_tn character varying(17),
    hub_clli character varying(11),
    additional_hub_clli character varying(11),
    nrs_hub_clli_sales character varying(11),
    co_termination numeric(9,0),
    lso character varying(6),
    flas_sysid character varying(50),
    flas_scid character varying(10),
    scid character varying(6),
    nci character varying(12),
    cust_req_hub character varying(11),
    service_config numeric(9,0),
    port_interface character varying(10),
    ctx_cust character varying(25),
    ctx_btn_ckl character varying(17),
    ctx_related_ord character varying(17),
    spot character varying(11),
    tnt character varying(10),
    loc character varying(46),
    ixc_order_no character varying(25),
    meet_pt character varying(25),
    npa character varying(3),
    nxx character varying(3),
    cable_distance character varying(12),
    contracting_services character varying(12),
    cable_amount character varying(12),
    contracting_services_amt character varying(12),
    bill_customer_amt character varying(12),
    contingencies character varying(2100),
    connection_charge character varying(12),
    bill_customer numeric(9,0),
    mtso_clli character varying(11),
    cust_eng_contact_id numeric(9,0),
    cell_clli character varying(11),
    modified_date numeric(10,0),
    sn_cfa character varying(50),
    pri_circuit character varying(50),
    ixc_circuit_no character varying(25),
    cfa_type numeric(9,0),
    vz_cklt character varying(11),
    clli_revise_flag numeric(9,0),
    router character varying(2),
    clei numeric(9,0),
    edsx_clli character varying(11),
    ind_lso character varying(6),
    cust_spec_cons_cost numeric(9,0),
    cust_infc_dev numeric(9,0),
    loc_ntwk_interface character varying(20),
    intellinet_flag numeric(9,0),
    ixc_coloc_order_no character varying(25),
    ixc_coloc_circuit_no character varying(25),
    loc_clli_meet_point character varying(16),
    ups numeric(9,0),
    xpp_6000_rack numeric(9,0),
    isp_cfa character varying(20),
    cpe_mounting numeric(9,0),
    sent_to_aard_wolf numeric(9,0),
    aswc_lso character varying(6),
    wireless_inq_remark character varying(500),
    wireless_inq_addr character varying(500),
    wireless_inq_exp_date numeric(10,0),
    wrls_inq_addtl_charges numeric(9,0),
    send_to_locquest numeric(9,0),
    locquest_success numeric(9,0),
    noc_so character varying(20),
    pri_type numeric(9,0),
    aswc_clli character varying(11),
    unique_dn_number character varying(12),
    dmsltid_assignment character varying(15),
    tsc character varying(8),
    co_node_clli character varying(11),
    flexgrow_sys_id character varying(35),
    flexgrow_so_no character varying(17),
    mux_provided_by numeric(9,0),
    ckt_id_prefix character varying(2),
    ckt_id_svc_cd_mdfr character varying(4),
    ckt_id_serial_number character varying(6),
    ckt_id_suffix character varying(3),
    ckt_id_ec_code character varying(4),
    demark_location character varying(20),
    fiber_distance_to_demark character varying(20),
    optical_connector_type character varying(4),
    ncon numeric(9,0),
    port character varying(60),
    install_clo character varying(18),
    tail_date_due numeric(10,0),
    tail_order character varying(17),
    tail_circuit character varying(53),
    tail_fni character varying(13),
    mux_config_id numeric(9,0),
    dcs_clli_success numeric(9,0),
    transport_nci character varying(12),
    adr_val character varying(1),
    svc_addr_link_used numeric(9,0),
    access_meet_point numeric(9,0),
    related_access_cfa character varying(50),
    pri_type_changed_flag numeric(9,0),
    gwc character varying(12),
    alias character varying(8),
    meet_point character varying(60),
    disc_noc_review_done numeric(9,0),
    suggested_aswc_clli character varying(11),
    existing_nid character varying(30),
    reusable_ems numeric(9,0),
    equipment_model_nid character varying(30),
    wirecenter_qualified numeric(2,0),
    rdlock_success numeric(9,0),
    om_scheduled_site_survey character varying(20),
    appointment_window_start_date character varying(15),
    appointment_window_end_date character varying(15),
    om_remarks character varying(250),
    degree_match character varying(300),
    site_survey_reservation_id character varying(10),
    gpon_host_wirecenter character varying(11),
    ntas_address_id1 character varying(20),
    ntas_address_id2 character varying(20),
    network_transformation numeric(19,0),
    pg_order_number character varying,
    pg_order_version character varying
);


ALTER TABLE ng_orchestration.sr_ckl_sales OWNER TO prvgwy;

--
-- TOC entry 724 (class 1259 OID 562193)
-- Name: sr_equipment_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.sr_equipment_id_seq
    START WITH 29913387
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 20;


ALTER TABLE ng_orchestration.sr_equipment_id_seq OWNER TO prvgwy;

--
-- TOC entry 688 (class 1259 OID 525154)
-- Name: sr_essm_info; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_essm_info (
    sr_id numeric(9,0) NOT NULL,
    ckl_type numeric(9,0) NOT NULL,
    cust_call_disp numeric(9,0),
    call_comments character varying(500),
    initial_call_date numeric(10,0),
    cust_contacted_date numeric(10,0),
    site_survey_date numeric(10,0),
    scheduling_comments character varying(500),
    special_ins character varying(500),
    assigned_to character varying(7),
    site_survey_disp numeric(9,0),
    survey_comments character varying(500),
    ss_assigned_to character varying(7),
    contact_initiated numeric(9,0),
    prb_disp_code numeric(9,0),
    send_email numeric(9,0),
    essm_completed numeric(9,0),
    snapshot_done numeric(9,0),
    site_survey_reschedule_reason numeric(9,0),
    auto_dialer_status numeric(9,0)
);


ALTER TABLE ng_orchestration.sr_essm_info OWNER TO prvgwy;

--
-- TOC entry 707 (class 1259 OID 529500)
-- Name: sr_milestones; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_milestones (
    sr_id numeric(9,0) NOT NULL,
    milestone_id numeric(9,0) NOT NULL,
    lam_date numeric(10,0),
    app_date numeric(10,0),
    sid_date numeric(10,0),
    trid_date numeric(10,0),
    rid_date numeric(10,0),
    dva_date numeric(10,0),
    wot_date numeric(10,0),
    fcd_date numeric(10,0),
    ptd_date numeric(10,0),
    dd_date numeric(10,0),
    dlrd_date numeric(10,0),
    modified_date numeric(10,0)
);


ALTER TABLE ng_orchestration.sr_milestones OWNER TO prvgwy;

--
-- TOC entry 720 (class 1259 OID 550941)
-- Name: sr_problem_code; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_problem_code (
    sr_problem_id numeric(9,0) NOT NULL,
    sr_problem_cd character varying(6) NOT NULL,
    sr_problem_desc character varying(256),
    sr_problem_severity numeric(9,0) NOT NULL,
    clock_stops_flag numeric(9,0) NOT NULL,
    reroute_flag numeric(9,0) NOT NULL,
    active numeric(9,0),
    all_org_flag numeric(9,0),
    internal numeric(9,0),
    essm_flag numeric(9,0)
);


ALTER TABLE ng_orchestration.sr_problem_code OWNER TO prvgwy;

--
-- TOC entry 723 (class 1259 OID 562185)
-- Name: sr_remark_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.sr_remark_id_seq
    START WITH 108934064
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 20;


ALTER TABLE ng_orchestration.sr_remark_id_seq OWNER TO prvgwy;

--
-- TOC entry 516 (class 1259 OID 356873)
-- Name: sr_sales; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.sr_sales (
    sr_id integer NOT NULL,
    region_id integer,
    state_id integer,
    network_channel_id integer,
    sales_cd character varying(20),
    sales_tier integer,
    cust_req_svc_date integer,
    billing_tn character varying(15),
    city character varying(50),
    mcn character varying(50),
    userid_created character varying(32),
    groupid_sales integer,
    circuit_id character varying(50),
    actual_service_date integer,
    modified_date integer,
    rerouted integer,
    handoff_type_cd integer,
    line_code integer,
    framing_choice_cd integer,
    nc_code integer,
    host_co character varying(50),
    host_clli character varying(11),
    cfa_sales_sendable integer,
    wisdom_msg_id character varying(100),
    aecn character varying(10),
    rtr character varying(40),
    bus_nc_code character varying(5),
    ckt_ordered_num integer,
    fac_reuse_flag integer,
    additional_fac_num integer,
    tls_speed integer,
    vlan character varying(15),
    cust_alrdy_tls_ckts integer,
    quantity integer,
    cable_doc_rqd integer,
    lata character varying(3),
    email_id character varying(40),
    agr_includes_reservation integer,
    reserve_fac_on_inq integer,
    host_co2 character varying(50),
    host_clli2 character varying(11),
    date_submitted_to_vz integer,
    date_reply_to_clec integer,
    fx_co character varying(50),
    fx_clli character varying(11),
    transport_type integer,
    email_sent_date integer,
    dedicated_inet_access_flag integer,
    tsp character varying(12),
    act character varying(10),
    existing_sys_id character varying(56),
    associated_with_vlan integer,
    vlan_on_omni_or_cisco integer,
    tls_require_linkaggregration integer,
    aswc_swc_clli character varying(11),
    customer_consider_other_aswc integer,
    circuitid_existing_tls character varying(50),
    corridor_selection integer,
    circuitid_existing_corridor character varying(50),
    customer_purchased integer,
    vad_circuit_id character varying(50),
    interm_office_routing integer,
    avail_num_pairs integer,
    carrier_email character varying(60),
    trunk_wk_type character varying(1),
    intercon_offering integer,
    aeng integer,
    assigned_to character varying(32),
    resv_terms integer,
    resv_inq_fac integer,
    ckt_id_prefix character varying(2),
    ckt_id_svc_cd_mdfr character varying(4),
    ckt_id_serial_number character varying(6),
    ckt_id_suffix character varying(3),
    ckt_id_ec_code character varying(4),
    pre_assigned_sysid character varying(50),
    lec_order character varying(17),
    integrated_access_flag integer,
    fast_pakt_access_flag integer,
    div_fiber_protection integer,
    custom_bid integer,
    custom_bid_case_no character varying(20),
    duplex integer,
    tls_handoff_type_cd integer,
    tls_type integer,
    ers_type integer,
    supp integer,
    special_const_authorization integer,
    construction_type_baseline integer,
    construction_type_network integer,
    construction_type_special integer,
    add_chg_card_flag integer,
    handoff_type_cd_to integer,
    chg_bandwidth_flag integer,
    spec_code character varying(10),
    lec_date_due integer,
    icsc character varying(4),
    dcs_clli_success integer,
    swc_build_on integer,
    tls_swc_clli character varying(11),
    bert_fac_type character varying(10),
    bert_svc_type character varying(50),
    bert_tech_type character varying(15),
    best_avail_date integer,
    bert_region character varying(5),
    bert_work_order_no character varying(120),
    bert_cbit integer,
    bert_channel_qty integer,
    bert_multi_carrier character varying(60),
    dpeaz character varying(50),
    fniz character varying(6),
    eprs_uni_selection integer,
    csm_clli character varying(11),
    init character varying(15),
    init_tel character varying(20),
    pending_sold_status character varying(25),
    svc_edge_router integer,
    ser_clli_req character varying(11),
    ipvpn_bandwidth integer,
    construction_type_excessive integer,
    trunk_clo character varying(12),
    ethernet_speed integer,
    custom_bid_oaf_case character varying(20),
    ethernet_sp_routing integer,
    von_prjmgr_vzid character varying(10),
    von_prjmgr_name character varying(50),
    series integer,
    fac_use_code character varying(5),
    sub_rate integer,
    tariff_jurisdiction integer,
    sales_agent_name character varying(50),
    center_id integer,
    fb_cno character varying(20),
    transport_nc character varying(5),
    dpeaa character varying(50),
    dtclo character varying(12),
    ntclo character varying(12),
    tls_termination integer,
    fpd integer,
    ows_bandwidth integer,
    link_aggregation integer,
    transport_ckt_id character varying(46),
    ddd_crunch integer,
    sp_routing_type integer,
    conference_bridge_tel character varying(12),
    conference_passcode character varying(15),
    conference_time character varying(15),
    pre_build_cand integer,
    cbscne_alert_exist integer,
    ckr character varying(53),
    mated_pair integer,
    div_pon character varying(16),
    div_ckt character varying(50),
    div_symphony_id character varying(20),
    dual_entrance integer,
    dispatchable_flag integer,
    ruid character varying(28),
    vi_circuit_id character varying(46),
    cust_acceptance_dtl character varying(80),
    vzb_contact_name character varying(40),
    vzb_contact_phone character varying(15),
    vzb_contact_email character varying(60),
    jpr character varying(30),
    eda integer,
    nag character varying(1),
    nasp_id character varying(18),
    reqn_rsend character varying(2),
    vanilla_10g integer,
    emux_speed integer,
    om_contact_name character varying(60),
    om_contact_phone character varying(30),
    om_contact_email character varying(60),
    nid_type character varying(10),
    om_data_updated integer,
    cno_wr character varying(30),
    tls_swc_clli_requested character varying(11),
    quote_contract character varying(7),
    wfm_quote_status integer,
    ptv character varying(20),
    supp_count integer,
    sr_nf_id character varying(50),
    pg_order_number character varying,
    pg_order_version character varying
);


ALTER TABLE ng_orchestration.sr_sales OWNER TO prvgwy;

--
-- TOC entry 533 (class 1259 OID 357075)
-- Name: state_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.state_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.state_seq OWNER TO prvgwy;

--
-- TOC entry 534 (class 1259 OID 357077)
-- Name: state; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.state (
    state_id integer DEFAULT nextval('ng_orchestration.state_seq'::regclass) NOT NULL,
    state_code character varying(2) NOT NULL,
    state_name character varying(30),
    time_zone integer
);


ALTER TABLE ng_orchestration.state OWNER TO prvgwy;

--
-- TOC entry 535 (class 1259 OID 357086)
-- Name: state_plan_map; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.state_plan_map (
    plan_id integer NOT NULL,
    state_id integer NOT NULL
);


ALTER TABLE ng_orchestration.state_plan_map OWNER TO prvgwy;

--
-- TOC entry 540 (class 1259 OID 357143)
-- Name: state_region; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.state_region (
    region_id integer NOT NULL,
    state_id integer NOT NULL,
    modified_date integer
);


ALTER TABLE ng_orchestration.state_region OWNER TO prvgwy;

--
-- TOC entry 545 (class 1259 OID 367550)
-- Name: std_interval_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.std_interval_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.std_interval_seq OWNER TO prvgwy;

--
-- TOC entry 546 (class 1259 OID 367552)
-- Name: std_interval; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.std_interval (
    std_interval_days integer DEFAULT nextval('ng_orchestration.std_interval_seq'::regclass) NOT NULL,
    lam_days integer NOT NULL,
    trid_days integer NOT NULL,
    rid_days integer,
    dva_days integer,
    wot_days integer,
    fcd_days integer,
    ptd_days integer,
    dd_days integer,
    gpon integer DEFAULT 0,
    expedite_ind integer
);


ALTER TABLE ng_orchestration.std_interval OWNER TO prvgwy;

--
-- TOC entry 703 (class 1259 OID 526256)
-- Name: switch; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.switch (
    switch_id numeric(9,0) NOT NULL,
    wirecenter_id numeric(9,0),
    switch_type character varying(25),
    modified_date numeric(10,0),
    switch_clli character varying(11) NOT NULL,
    obsolete_flag numeric(9,0) DEFAULT 0 NOT NULL,
    host_clli character varying(11),
    region_ind numeric(9,0) NOT NULL,
    mts_server character varying(50),
    mts_scc character varying(20)
);


ALTER TABLE ng_orchestration.switch OWNER TO prvgwy;

--
-- TOC entry 562 (class 1259 OID 412991)
-- Name: switch_cotype; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.switch_cotype (
    switch_cotype_id numeric(9,0) NOT NULL,
    switch_type character varying(7) NOT NULL,
    co_type numeric(9,0) NOT NULL
);


ALTER TABLE ng_orchestration.switch_cotype OWNER TO prvgwy;

--
-- TOC entry 769 (class 1259 OID 1370972)
-- Name: task_def_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.task_def_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.task_def_id_seq OWNER TO prvgwy;

--
-- TOC entry 770 (class 1259 OID 1370974)
-- Name: task_event_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.task_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.task_event_id_seq OWNER TO prvgwy;

--
-- TOC entry 771 (class 1259 OID 1370976)
-- Name: task_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.task_id_seq OWNER TO prvgwy;

--
-- TOC entry 772 (class 1259 OID 1370978)
-- Name: task_var_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.task_var_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.task_var_id_seq OWNER TO prvgwy;

--
-- TOC entry 399 (class 1259 OID 213457)
-- Name: tbl_access_order; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_access_order (
    product_type character varying(30) NOT NULL,
    region character varying(20) NOT NULL,
    order_number character varying(32) NOT NULL,
    order_version character varying(3) NOT NULL,
    order_type integer NOT NULL,
    supp_type integer,
    service_type integer,
    order_status integer NOT NULL,
    prov_status integer NOT NULL,
    due_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    house_no character varying(32),
    street character varying(80) NOT NULL,
    sub_loc character varying(32),
    city character varying(32) NOT NULL,
    state character varying(32) NOT NULL,
    zip character varying(32),
    circuit_id character varying(64),
    customer_name character varying(64),
    sr_number character varying(32),
    case_id character varying(32),
    ngpon_flag character varying(3) DEFAULT 'NO'::character varying,
    asr_id character varying(32) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_access_order OWNER TO dbadmin;

--
-- TOC entry 289 (class 1259 OID 212988)
-- Name: tbl_application_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_application_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_application_seq OWNER TO dbadmin;

--
-- TOC entry 400 (class 1259 OID 213465)
-- Name: tbl_application; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_application (
    app_id bigint DEFAULT nextval('ng_orchestration.tbl_application_seq'::regclass) NOT NULL,
    app_key character varying(25) NOT NULL,
    app_name character varying(128) NOT NULL,
    app_entity_tbl_name character varying(30) NOT NULL,
    app_poc_name character varying(100),
    active character(1) DEFAULT 'Y'::bpchar,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_application OWNER TO dbadmin;

--
-- TOC entry 290 (class 1259 OID 212990)
-- Name: tbl_application_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_application_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_application_config_seq OWNER TO dbadmin;

--
-- TOC entry 401 (class 1259 OID 213471)
-- Name: tbl_application_config; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_application_config (
    tbl_otm_osb_config_id bigint DEFAULT nextval('ng_orchestration.tbl_application_config_seq'::regclass) NOT NULL,
    param_name character varying(100),
    param_value character varying(250),
    category character varying(60) NOT NULL,
    vzid character varying(60),
    service_name character varying(60) NOT NULL,
    created_date timestamp without time zone,
    modified_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_application_config OWNER TO dbadmin;

--
-- TOC entry 292 (class 1259 OID 212994)
-- Name: tbl_baais_orch_trace_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_baais_orch_trace_entity_seq OWNER TO dbadmin;

--
-- TOC entry 403 (class 1259 OID 213483)
-- Name: tbl_baais_orch_trace_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_baais_orch_trace_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_baais_orch_trace_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    hash_value character varying(256) NOT NULL,
    trace_source character varying(64) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_baais_orch_trace_entity OWNER TO dbadmin;

--
-- TOC entry 291 (class 1259 OID 212992)
-- Name: tbl_baaisn_cem_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_baaisn_cem_entity_seq OWNER TO dbadmin;

--
-- TOC entry 402 (class 1259 OID 213478)
-- Name: tbl_baaisn_cem_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_baaisn_cem_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_baaisn_cem_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    order_id character varying(128) NOT NULL,
    system_name character varying(128) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_baaisn_cem_entity OWNER TO dbadmin;

--
-- TOC entry 293 (class 1259 OID 212996)
-- Name: tbl_bonita_dynamic_flow_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_bonita_dynamic_flow_seq OWNER TO dbadmin;

--
-- TOC entry 404 (class 1259 OID 213488)
-- Name: tbl_bonita_dynamic_flow; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_bonita_dynamic_flow (
    dynamic_flow_id bigint DEFAULT nextval('ng_orchestration.tbl_bonita_dynamic_flow_seq'::regclass) NOT NULL,
    root_case_id bigint NOT NULL,
    call_activity_id bigint,
    child_root_case_id bigint NOT NULL,
    flow_type character varying(64),
    entity_value character varying(128),
    order_ref_id bigint NOT NULL,
    status character varying(32),
    user_id character varying(25) DEFAULT 'SYSTEM'::character varying NOT NULL,
    title character varying(90),
    lob character varying(25) NOT NULL,
    remark character varying(255),
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_bonita_dynamic_flow OWNER TO dbadmin;

--
-- TOC entry 294 (class 1259 OID 212998)
-- Name: tbl_chronic_circuit_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_chronic_circuit_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_chronic_circuit_seq OWNER TO dbadmin;

--
-- TOC entry 405 (class 1259 OID 213498)
-- Name: tbl_chronic_circuit; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_chronic_circuit (
    chronic_circuit_id bigint DEFAULT nextval('ng_orchestration.tbl_chronic_circuit_seq'::regclass) NOT NULL,
    chronic_site_id bigint NOT NULL,
    circuit_id character varying(128) NOT NULL,
    aend_clli character varying(64),
    zend_clli character varying(64),
    ivapp_order_number character varying(64)
);


ALTER TABLE ng_orchestration.tbl_chronic_circuit OWNER TO dbadmin;

--
-- TOC entry 295 (class 1259 OID 213000)
-- Name: tbl_chronic_site_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_chronic_site_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_chronic_site_seq OWNER TO dbadmin;

--
-- TOC entry 406 (class 1259 OID 213502)
-- Name: tbl_chronic_site; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_chronic_site (
    chronic_site_id bigint DEFAULT nextval('ng_orchestration.tbl_chronic_site_seq'::regclass) NOT NULL,
    lcon_title character varying(64) NOT NULL,
    lcon_name character varying(64) NOT NULL,
    lcon_number character varying(64) NOT NULL,
    wf_id character varying(64),
    status character varying(64),
    status_description character varying(256),
    zip character varying(64),
    serving_co_clli character varying(64),
    region character varying(64),
    house_num character varying(256),
    street character varying(256),
    sub_loc character varying(256),
    city character varying(256),
    state character varying(64),
    ewo_number character varying(64),
    requested_estimated_cost integer,
    approval_status character varying(64),
    reason character varying(64),
    solution_type integer,
    process_step character varying(64),
    create_date date NOT NULL,
    manifest_data character varying(60000)
);


ALTER TABLE ng_orchestration.tbl_chronic_site OWNER TO dbadmin;

--
-- TOC entry 296 (class 1259 OID 213002)
-- Name: tbl_chronic_site_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_chronic_site_entity_seq OWNER TO dbadmin;

--
-- TOC entry 407 (class 1259 OID 213509)
-- Name: tbl_chronic_site_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_chronic_site_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_chronic_site_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    chronic_site_id character varying(128) NOT NULL,
    state character varying(64) NOT NULL,
    product_type character varying(64) NOT NULL,
    create_date date NOT NULL
);


ALTER TABLE ng_orchestration.tbl_chronic_site_entity OWNER TO dbadmin;

--
-- TOC entry 297 (class 1259 OID 213004)
-- Name: tbl_circuit_relation_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_circuit_relation_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_circuit_relation_seq OWNER TO dbadmin;

--
-- TOC entry 408 (class 1259 OID 213513)
-- Name: tbl_circuit_relation; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_circuit_relation (
    ckt_rel_id bigint DEFAULT nextval('ng_orchestration.tbl_circuit_relation_seq'::regclass) NOT NULL,
    order_number character varying(125) NOT NULL,
    circuit_id character varying(100),
    circuit_type character varying(60),
    related_circuit_id character varying(100),
    related_circuit_type character varying(60),
    lob character varying(30),
    vzid character varying(60) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_circuit_relation OWNER TO dbadmin;

--
-- TOC entry 298 (class 1259 OID 213006)
-- Name: tbl_clli_selection_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_clli_selection_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_clli_selection_seq OWNER TO dbadmin;

--
-- TOC entry 409 (class 1259 OID 213523)
-- Name: tbl_clli_selection; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_clli_selection (
    clli_select_id bigint DEFAULT nextval('ng_orchestration.tbl_clli_selection_seq'::regclass) NOT NULL,
    order_ref_id bigint,
    order_number character varying(100),
    order_version character varying(25),
    circuit_id character varying(100),
    request_source character varying(20) NOT NULL,
    location_ind character varying(10) NOT NULL,
    project_id character varying(25) NOT NULL,
    project_status character varying(25),
    sup_type character varying(5),
    case_id character varying(60),
    clli character varying(60),
    aac_clli_code character varying(60),
    aac_tid character varying(60),
    premise_type character varying(60),
    aac_type character varying(60),
    site_code character varying(25),
    build_type character varying(25),
    nid_type character varying(25),
    dispatch_lso character varying(25),
    service_instance_id character varying(30),
    address character varying(500),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_clli_selection OWNER TO dbadmin;

--
-- TOC entry 299 (class 1259 OID 213008)
-- Name: tbl_demo_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_demo_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_demo_entity_seq OWNER TO dbadmin;

--
-- TOC entry 410 (class 1259 OID 213533)
-- Name: tbl_demo_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_demo_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_demo_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    eda_1 character varying(128) NOT NULL,
    eda_2 character varying(128) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_demo_entity OWNER TO dbadmin;

--
-- TOC entry 300 (class 1259 OID 213010)
-- Name: tbl_dispatch_job_track_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_dispatch_job_track_seq OWNER TO dbadmin;

--
-- TOC entry 411 (class 1259 OID 213538)
-- Name: tbl_dispatch_job_track; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_dispatch_job_track (
    dispatch_job_track_id bigint DEFAULT nextval('ng_orchestration.tbl_dispatch_job_track_seq'::regclass) NOT NULL,
    order_id bigint,
    order_number character varying(120),
    location_ind character varying(20),
    circuit_end character varying(20),
    xnscid bigint NOT NULL,
    seq_no character varying(10) NOT NULL,
    job_id character varying(60) NOT NULL,
    job_track_status character varying(256) NOT NULL,
    ckt_work_loc character varying(256),
    job_type character varying(125),
    job_status character varying(125),
    jeop_code character varying(30),
    request_source character varying(125),
    order_version character varying(125),
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    region character varying(30),
    center character varying(30),
    job_location character varying(60),
    job_version character varying(45),
    dispatch_type character varying(64)
);


ALTER TABLE ng_orchestration.tbl_dispatch_job_track OWNER TO dbadmin;

--
-- TOC entry 301 (class 1259 OID 213012)
-- Name: tbl_ds1_migration_params_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_ds1_migration_params_seq OWNER TO dbadmin;

--
-- TOC entry 412 (class 1259 OID 213547)
-- Name: tbl_ds1_migration_params; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_ds1_migration_params (
    ds1_migration_params_id bigint DEFAULT nextval('ng_orchestration.tbl_ds1_migration_params_seq'::regclass) NOT NULL,
    param_key character varying(64) NOT NULL,
    value character varying(65000) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_ds1_migration_params OWNER TO dbadmin;

--
-- TOC entry 302 (class 1259 OID 213014)
-- Name: tbl_dynamic_flow_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_dynamic_flow_map_seq OWNER TO dbadmin;

--
-- TOC entry 413 (class 1259 OID 213554)
-- Name: tbl_dynamic_flow_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_dynamic_flow_map (
    dynamic_flow_map_id bigint DEFAULT nextval('ng_orchestration.tbl_dynamic_flow_map_seq'::regclass) NOT NULL,
    call_activity_name character varying(128) NOT NULL,
    sub_process_name character varying(128) NOT NULL,
    line_of_business character varying(16) NOT NULL,
    description character varying(256) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_dynamic_flow_map OWNER TO dbadmin;

--
-- TOC entry 303 (class 1259 OID 213016)
-- Name: tbl_ecost_batch_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_ecost_batch_entity_seq OWNER TO dbadmin;

--
-- TOC entry 414 (class 1259 OID 213561)
-- Name: tbl_ecost_batch_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_ecost_batch_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_ecost_batch_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    job_id bigint NOT NULL,
    job_type character varying(25) NOT NULL,
    job_owner character varying(100) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_ecost_batch_entity OWNER TO dbadmin;

--
-- TOC entry 304 (class 1259 OID 213018)
-- Name: tbl_engineering_issue_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_engineering_issue_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_engineering_issue_seq OWNER TO dbadmin;

--
-- TOC entry 415 (class 1259 OID 213566)
-- Name: tbl_engineering_issue; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_engineering_issue (
    tbl_eng_issue_id bigint DEFAULT nextval('ng_orchestration.tbl_engineering_issue_seq'::regclass) NOT NULL,
    order_source character varying(20) NOT NULL,
    order_number character varying(100),
    order_ref_id bigint,
    nf_id character varying(32),
    project_id character varying(25),
    sr_number character varying(60),
    issue_category character varying(125),
    issue_code character varying(125),
    remarks character varying(250),
    issue_id character varying(150),
    message_date timestamp without time zone,
    status character varying(100) NOT NULL,
    task_reference_id character varying(250),
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_engineering_issue OWNER TO dbadmin;

--
-- TOC entry 305 (class 1259 OID 213020)
-- Name: tbl_escalation_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_escalation_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_escalation_entity_seq OWNER TO dbadmin;

--
-- TOC entry 416 (class 1259 OID 213575)
-- Name: tbl_escalation_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_escalation_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_escalation_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    escalation_ticket_id bigint NOT NULL,
    sr_number character varying(32),
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_escalation_entity OWNER TO dbadmin;

--
-- TOC entry 306 (class 1259 OID 213022)
-- Name: tbl_escalation_ticket_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_escalation_ticket_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_escalation_ticket_seq OWNER TO dbadmin;

--
-- TOC entry 417 (class 1259 OID 213580)
-- Name: tbl_escalation_ticket; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_escalation_ticket (
    escalation_ticket_id bigint DEFAULT nextval('ng_orchestration.tbl_escalation_ticket_seq'::regclass) NOT NULL,
    sr_number character varying(32),
    so_number character varying(32),
    circuit_id character varying(32),
    clo character varying(32),
    ticket_type character varying(32),
    priority character varying(32),
    source character varying(32),
    status character varying(32),
    user_id character varying(32),
    ute_task_id bigint,
    crated_date timestamp without time zone,
    last_modified timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_escalation_ticket OWNER TO dbadmin;

--
-- TOC entry 482 (class 1259 OID 241644)
-- Name: tbl_event_fallout_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.tbl_event_fallout_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_event_fallout_seq OWNER TO prvgwy;

--
-- TOC entry 483 (class 1259 OID 241652)
-- Name: tbl_event_fallout; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_event_fallout (
    event_fallout_id bigint DEFAULT nextval('ng_orchestration.tbl_event_fallout_seq'::regclass) NOT NULL,
    lob character varying(32) NOT NULL,
    task_id bigint NOT NULL,
    task_name character varying(64),
    request_type character varying(64) NOT NULL,
    order_ref_id bigint,
    order_number character varying(64),
    order_version character varying(32),
    status character varying(32) DEFAULT 'New'::character varying,
    vzid character varying(16) DEFAULT 'System'::character varying NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_event_fallout OWNER TO dbadmin;

--
-- TOC entry 307 (class 1259 OID 213024)
-- Name: tbl_hack_demo_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_hack_demo_entity_seq OWNER TO dbadmin;

--
-- TOC entry 418 (class 1259 OID 213584)
-- Name: tbl_hack_demo_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_hack_demo_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_hack_demo_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    order_number character varying(128) NOT NULL,
    order_source character varying(128) NOT NULL,
    order_type character varying(128) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_hack_demo_entity OWNER TO dbadmin;

--
-- TOC entry 419 (class 1259 OID 213589)
-- Name: tbl_holiday; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_holiday (
    holiday_id integer NOT NULL,
    plan_id integer NOT NULL,
    begin_time bigint NOT NULL,
    end_time bigint NOT NULL,
    holiday_admin_id integer
);


ALTER TABLE ng_orchestration.tbl_holiday OWNER TO dbadmin;

--
-- TOC entry 712 (class 1259 OID 534958)
-- Name: tbl_ien_order; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_ien_order (
    ien_order_id bigint NOT NULL,
    order_number character varying(128),
    order_version character varying(8),
    order_source character varying(32),
    workflow_id character varying(16),
    region character varying(16),
    order_status character varying(64),
    created_date timestamp without time zone,
    modified_date timestamp without time zone,
    provisioning_version character varying(8),
    attributes jsonb,
    completion_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_ien_order OWNER TO prvgwy;

--
-- TOC entry 711 (class 1259 OID 534956)
-- Name: tbl_ien_order_ien_order_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.tbl_ien_order_ien_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_ien_order_ien_order_id_seq OWNER TO prvgwy;

--
-- TOC entry 7065 (class 0 OID 0)
-- Dependencies: 711
-- Name: tbl_ien_order_ien_order_id_seq; Type: SEQUENCE OWNED BY; Schema: ng_orchestration; Owner: prvgwy
--

ALTER SEQUENCE ng_orchestration.tbl_ien_order_ien_order_id_seq OWNED BY ng_orchestration.tbl_ien_order.ien_order_id;


--
-- TOC entry 549 (class 1259 OID 393239)
-- Name: tbl_ien_order_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.tbl_ien_order_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_ien_order_seq OWNER TO prvgwy;

--
-- TOC entry 420 (class 1259 OID 213592)
-- Name: tbl_interval_mapping; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_interval_mapping (
    minimum_interval_id integer NOT NULL,
    service_category_cd character varying(30) NOT NULL,
    service_type_cd character varying(50) NOT NULL,
    source character varying(50) NOT NULL,
    region character varying(50) NOT NULL,
    activity integer NOT NULL,
    order_type integer NOT NULL,
    minimum_interval integer,
    expedite_interval integer,
    lam_interval integer,
    fttc_minimum_interval integer,
    gpon_interval integer,
    e2e_std_interval integer,
    e2e_exp_interval integer,
    states character varying(250),
    directors character varying(500)
);


ALTER TABLE ng_orchestration.tbl_interval_mapping OWNER TO dbadmin;

--
-- TOC entry 308 (class 1259 OID 213026)
-- Name: tbl_jeop_code_metadata_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_jeop_code_metadata_seq OWNER TO dbadmin;

--
-- TOC entry 421 (class 1259 OID 213598)
-- Name: tbl_jeop_code_metadata; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_jeop_code_metadata (
    jeop_code_id bigint DEFAULT nextval('ng_orchestration.tbl_jeop_code_metadata_seq'::regclass) NOT NULL,
    jeop_code character varying(125) NOT NULL,
    organization character varying(250),
    definition character varying(999),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    code_type character varying(125) NOT NULL,
    qcode character varying(125),
    lob character varying(32) DEFAULT 'VPS'::character varying NOT NULL,
    short_code character varying(32),
    irms_code character varying(30),
    task_type character varying(30)
);


ALTER TABLE ng_orchestration.tbl_jeop_code_metadata OWNER TO dbadmin;

--
-- TOC entry 422 (class 1259 OID 213609)
-- Name: tbl_lam_interval; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_lam_interval (
    lam_interval_id integer NOT NULL,
    trid_date integer,
    rid_date integer,
    dva_date integer,
    wot_date integer,
    fcd_date integer,
    ptd_date integer,
    dd_date integer,
    modified_date integer,
    gpon integer
);


ALTER TABLE ng_orchestration.tbl_lam_interval OWNER TO dbadmin;

--
-- TOC entry 309 (class 1259 OID 213028)
-- Name: tbl_lci_manifest_docs_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_lci_manifest_docs_seq OWNER TO dbadmin;

--
-- TOC entry 423 (class 1259 OID 213612)
-- Name: tbl_lci_manifest_docs; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_lci_manifest_docs (
    document_id bigint DEFAULT nextval('ng_orchestration.tbl_lci_manifest_docs_seq'::regclass) NOT NULL,
    order_number character varying(30) NOT NULL,
    order_version character varying(30),
    doc_name character varying(30) NOT NULL,
    req_document text,
    res_document text
);


ALTER TABLE ng_orchestration.tbl_lci_manifest_docs OWNER TO dbadmin;

--
-- TOC entry 310 (class 1259 OID 213030)
-- Name: tbl_manifest_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_manifest_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_manifest_seq OWNER TO dbadmin;

--
-- TOC entry 424 (class 1259 OID 213619)
-- Name: tbl_manifest; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_manifest (
    manifest_id bigint DEFAULT nextval('ng_orchestration.tbl_manifest_seq'::regclass) NOT NULL,
    entity_id bigint NOT NULL,
    active character(1) NOT NULL,
    activity_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_manifest OWNER TO dbadmin;

--
-- TOC entry 311 (class 1259 OID 213032)
-- Name: tbl_manifest_docs_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_manifest_docs_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_manifest_docs_seq OWNER TO dbadmin;

--
-- TOC entry 425 (class 1259 OID 213624)
-- Name: tbl_manifest_docs; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_manifest_docs (
    document_id bigint DEFAULT nextval('ng_orchestration.tbl_manifest_docs_seq'::regclass) NOT NULL,
    doc_name character varying(64) NOT NULL,
    document character varying(65000)
);


ALTER TABLE ng_orchestration.tbl_manifest_docs OWNER TO dbadmin;

--
-- TOC entry 312 (class 1259 OID 213034)
-- Name: tbl_manifest_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_manifest_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_manifest_map_seq OWNER TO dbadmin;

--
-- TOC entry 426 (class 1259 OID 213631)
-- Name: tbl_manifest_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_manifest_map (
    map_id bigint DEFAULT nextval('ng_orchestration.tbl_manifest_map_seq'::regclass) NOT NULL,
    document_id bigint NOT NULL,
    manifest_id bigint NOT NULL,
    doc_name character varying(64) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_manifest_map OWNER TO dbadmin;

--
-- TOC entry 313 (class 1259 OID 213036)
-- Name: tbl_message_config_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_message_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_message_config_seq OWNER TO dbadmin;

--
-- TOC entry 427 (class 1259 OID 213635)
-- Name: tbl_message_config; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_message_config (
    msg_config_id bigint DEFAULT nextval('ng_orchestration.tbl_message_config_seq'::regclass) NOT NULL,
    product character varying(64) NOT NULL,
    lob character varying(64) NOT NULL,
    message_name character varying(128) NOT NULL,
    process_name character varying(128) NOT NULL,
    flow_node_name character varying(128) NOT NULL,
    request_type character varying(128) NOT NULL,
    adhoc_process_name character varying(128),
    vzid character varying(128) DEFAULT 'SYSTEM'::character varying NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    category character varying(128)
);


ALTER TABLE ng_orchestration.tbl_message_config OWNER TO dbadmin;

--
-- TOC entry 314 (class 1259 OID 213038)
-- Name: tbl_nid_audit_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_nid_audit_entity_seq OWNER TO dbadmin;

--
-- TOC entry 428 (class 1259 OID 213645)
-- Name: tbl_nid_audit_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_nid_audit_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_nid_audit_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    uni_circuit_id character varying(128) NOT NULL,
    nid_clli character varying(128) NOT NULL,
    audit_create_ts character varying(64) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_nid_audit_entity OWNER TO dbadmin;

--
-- TOC entry 564 (class 1259 OID 413153)
-- Name: tbl_order; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_order (
    order_id bigint DEFAULT nextval('ng_orchestration.tbl_ien_order_seq'::regclass) NOT NULL,
    order_number character varying(128) NOT NULL,
    order_version character varying(8) NOT NULL,
    order_source character varying(32) NOT NULL,
    workflow_id character varying(16),
    region character varying(16),
    order_status character varying(64) NOT NULL,
    created_date timestamp without time zone NOT NULL,
    modified_date timestamp without time zone NOT NULL,
    provisioning_version character varying(8),
    attributes jsonb,
    completion_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_order OWNER TO prvgwy;

--
-- TOC entry 925 (class 1259 OID 6298652)
-- Name: tbl_order_backup_04022020; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_order_backup_04022020 (
    order_id bigint,
    order_number character varying(128),
    order_version character varying(8),
    order_source character varying(32),
    workflow_id character varying(16),
    region character varying(16),
    order_status character varying(64),
    created_date timestamp without time zone,
    modified_date timestamp without time zone,
    provisioning_version character varying(8),
    attributes jsonb,
    completion_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_order_backup_04022020 OWNER TO prvgwy;

--
-- TOC entry 927 (class 1259 OID 6298692)
-- Name: tbl_order_backup_04022020_01; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_order_backup_04022020_01 (
    order_id bigint,
    order_number character varying(128),
    order_version character varying(8),
    order_source character varying(32),
    workflow_id character varying(16),
    region character varying(16),
    order_status character varying(64),
    created_date timestamp without time zone,
    modified_date timestamp without time zone,
    provisioning_version character varying(8),
    attributes jsonb,
    completion_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_order_backup_04022020_01 OWNER TO prvgwy;

--
-- TOC entry 316 (class 1259 OID 213042)
-- Name: tbl_order_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_entity_seq OWNER TO dbadmin;

--
-- TOC entry 429 (class 1259 OID 213655)
-- Name: tbl_order_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_order_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    region character varying(20) NOT NULL,
    product_type character varying(30) NOT NULL,
    order_number character varying(32) NOT NULL,
    order_version character varying(3) NOT NULL,
    supp_type character varying(32) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_order_entity OWNER TO dbadmin;

--
-- TOC entry 317 (class 1259 OID 213044)
-- Name: tbl_order_jeopardy_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_jeopardy_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_jeopardy_seq OWNER TO dbadmin;

--
-- TOC entry 430 (class 1259 OID 213660)
-- Name: tbl_order_jeopardy; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_jeopardy (
    order_jeopardy_id bigint DEFAULT nextval('ng_orchestration.tbl_order_jeopardy_seq'::regclass) NOT NULL,
    milestone_order_id bigint,
    jeop_code_id bigint NOT NULL,
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying NOT NULL,
    notification character varying(30) DEFAULT ''::character varying NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    task_name character varying(255),
    status character varying(64),
    task_info character varying(1500),
    lob character varying(32),
    remark character varying(524),
    order_id bigint,
    order_version character varying(20),
    source_system character varying(30)
);


ALTER TABLE ng_orchestration.tbl_order_jeopardy OWNER TO dbadmin;

--
-- TOC entry 318 (class 1259 OID 213046)
-- Name: tbl_order_notes_remarks_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_notes_remarks_seq OWNER TO dbadmin;

--
-- TOC entry 431 (class 1259 OID 213671)
-- Name: tbl_order_notes_remarks; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_notes_remarks (
    info_id bigint DEFAULT nextval('ng_orchestration.tbl_order_notes_remarks_seq'::regclass) NOT NULL,
    order_number character varying(128) NOT NULL,
    region character varying(64) NOT NULL,
    user_id character varying(128) NOT NULL,
    info_type character varying(128) NOT NULL,
    info text NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_order_notes_remarks OWNER TO dbadmin;

--
-- TOC entry 319 (class 1259 OID 213048)
-- Name: tbl_order_request_fallout_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_request_fallout_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_request_fallout_seq OWNER TO dbadmin;

--
-- TOC entry 432 (class 1259 OID 213680)
-- Name: tbl_order_request_fallout; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_request_fallout (
    ord_req_fout_id bigint DEFAULT nextval('ng_orchestration.tbl_order_request_fallout_seq'::regclass) NOT NULL,
    request_category character varying(150) NOT NULL,
    order_ref_id bigint,
    sr_number character varying(60),
    order_number character varying(128) NOT NULL,
    circuit_id character varying(128),
    region character varying(64),
    order_version character varying(25),
    request_src character varying(25) NOT NULL,
    milestone_name character varying(250),
    notify_system character varying(60),
    end_point character varying(256) NOT NULL,
    operation_type character varying(64) DEFAULT 'POST'::character varying,
    auth_username character varying(450),
    auth_password character varying(450),
    request_body text,
    status character varying(128) DEFAULT 'Open'::character varying NOT NULL,
    error_reason text,
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_order_request_fallout OWNER TO dbadmin;

--
-- TOC entry 926 (class 1259 OID 6298665)
-- Name: tbl_order_restore; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_restore (
    order_id bigint,
    order_number character varying(128),
    order_version character varying(8),
    order_source character varying(32),
    workflow_id character varying(16),
    region character varying(16),
    order_status character varying(64),
    created_date timestamp without time zone,
    modified_date timestamp without time zone,
    provisioning_version character varying(8),
    attributes jsonb,
    completion_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_order_restore OWNER TO dbadmin;

--
-- TOC entry 320 (class 1259 OID 213050)
-- Name: tbl_order_search_index_store_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_search_index_store_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_search_index_store_seq OWNER TO dbadmin;

--
-- TOC entry 433 (class 1259 OID 213692)
-- Name: tbl_order_search_index_store; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_search_index_store (
    index_store_id bigint DEFAULT nextval('ng_orchestration.tbl_order_search_index_store_seq'::regclass) NOT NULL,
    system_name character varying(40) NOT NULL,
    max_index_retrieved integer NOT NULL
);


ALTER TABLE ng_orchestration.tbl_order_search_index_store OWNER TO dbadmin;

--
-- TOC entry 315 (class 1259 OID 213040)
-- Name: tbl_order_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_seq OWNER TO dbadmin;

--
-- TOC entry 321 (class 1259 OID 213052)
-- Name: tbl_order_status_metadata_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_order_status_metadata_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_order_status_metadata_seq OWNER TO dbadmin;

--
-- TOC entry 434 (class 1259 OID 213696)
-- Name: tbl_order_status_metadata; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_order_status_metadata (
    order_status_id bigint DEFAULT nextval('ng_orchestration.tbl_order_status_metadata_seq'::regclass) NOT NULL,
    seq_no integer NOT NULL,
    status character varying(60) DEFAULT 'Received'::character varying NOT NULL,
    vzid character varying(60),
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_order_status_metadata OWNER TO dbadmin;

--
-- TOC entry 651 (class 1259 OID 451152)
-- Name: tbl_pg_ordering_messages; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_pg_ordering_messages (
    msg_id character varying(25) NOT NULL,
    msg_type character varying(20) NOT NULL,
    msg_sequence integer,
    msg text,
    msg_status character varying(20) NOT NULL,
    date_sent timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    pon character varying(16),
    ccna character varying(3) NOT NULL,
    asr_id character varying(18) NOT NULL,
    order_number character varying(125) NOT NULL,
    order_version character varying(20) NOT NULL,
    region character varying(20) NOT NULL,
    msg_direction character varying(10) NOT NULL,
    ordering_system character varying(10) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_pg_ordering_messages OWNER TO prvgwy;

--
-- TOC entry 737 (class 1259 OID 882650)
-- Name: tbl_pg_ordering_messages_uat_temp_for_migration; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration (
    msg_id character varying(25),
    msg_type character varying(20),
    msg_sequence integer,
    msg text,
    msg_status character varying(20),
    date_sent timestamp without time zone,
    pon character varying(16),
    ccna character varying(3),
    asr_id character varying(18),
    order_number character varying(125),
    order_version character varying(20),
    region character varying(20),
    msg_direction character varying(10),
    ordering_system character varying(10)
);


ALTER TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration OWNER TO prvgwy;

--
-- TOC entry 322 (class 1259 OID 213054)
-- Name: tbl_pon_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_pon_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_pon_entity_seq OWNER TO dbadmin;

--
-- TOC entry 435 (class 1259 OID 213710)
-- Name: tbl_pon_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_pon_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_pon_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    unique_id character varying(50) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    status character varying(100),
    error_code character varying(2000)
);


ALTER TABLE ng_orchestration.tbl_pon_entity OWNER TO dbadmin;

--
-- TOC entry 323 (class 1259 OID 213056)
-- Name: tbl_reschedule_task_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_reschedule_task_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_reschedule_task_seq OWNER TO dbadmin;

--
-- TOC entry 436 (class 1259 OID 213718)
-- Name: tbl_reschedule_task; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_reschedule_task (
    reschedule_task_id bigint DEFAULT nextval('ng_orchestration.tbl_reschedule_task_seq'::regclass) NOT NULL,
    order_source character varying(128) NOT NULL,
    order_number character varying(64),
    order_version character varying(30),
    order_ref_id bigint,
    activity_id bigint NOT NULL,
    external_task_id character varying(64) NOT NULL,
    expiry_date bigint NOT NULL,
    status character varying(32) NOT NULL,
    task_name character varying(128) NOT NULL,
    remarks character varying(256) NOT NULL,
    task_source character varying(128) DEFAULT 'NONE'::character varying NOT NULL,
    line_of_business character varying(256) DEFAULT 'OPTIONLESS'::character varying NOT NULL
);


ALTER TABLE ng_orchestration.tbl_reschedule_task OWNER TO dbadmin;

--
-- TOC entry 324 (class 1259 OID 213058)
-- Name: tbl_rqnorder_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_rqnorder_entity_seq OWNER TO dbadmin;

--
-- TOC entry 437 (class 1259 OID 213727)
-- Name: tbl_rqnorder_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_rqnorder_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_rqnorder_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    sr_number character varying(50) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_rqnorder_entity OWNER TO dbadmin;

--
-- TOC entry 325 (class 1259 OID 213060)
-- Name: tbl_ruggedization_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_ruggedization_entity_seq OWNER TO dbadmin;

--
-- TOC entry 438 (class 1259 OID 213732)
-- Name: tbl_ruggedization_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_ruggedization_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_ruggedization_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    file_name character varying(120),
    job_id character varying(32),
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_ruggedization_entity OWNER TO dbadmin;

--
-- TOC entry 326 (class 1259 OID 213062)
-- Name: tbl_rule_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_rule_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_rule_seq OWNER TO dbadmin;

--
-- TOC entry 439 (class 1259 OID 213737)
-- Name: tbl_rule; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_rule (
    rule_id bigint DEFAULT nextval('ng_orchestration.tbl_rule_seq'::regclass) NOT NULL,
    rule_set_id bigint,
    priority bigint,
    rule_name character varying(256) NOT NULL,
    rule_text text NOT NULL,
    rule_status character varying(64) NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_rule OWNER TO dbadmin;

--
-- TOC entry 327 (class 1259 OID 213065)
-- Name: tbl_rule_set_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_rule_set_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_rule_set_seq OWNER TO dbadmin;

--
-- TOC entry 440 (class 1259 OID 213746)
-- Name: tbl_rule_set; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_rule_set (
    rule_set_id bigint DEFAULT nextval('ng_orchestration.tbl_rule_set_seq'::regclass) NOT NULL,
    rule_set_name character varying(256) NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_rule_set OWNER TO dbadmin;

--
-- TOC entry 328 (class 1259 OID 213067)
-- Name: tbl_rule_set_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_rule_set_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_rule_set_map_seq OWNER TO dbadmin;

--
-- TOC entry 441 (class 1259 OID 213752)
-- Name: tbl_rule_set_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_rule_set_map (
    rule_set_map_id bigint DEFAULT nextval('ng_orchestration.tbl_rule_set_map_seq'::regclass) NOT NULL,
    rule_set_id bigint,
    lob character varying(64) NOT NULL,
    product character varying(256) NOT NULL,
    category character varying(256) NOT NULL,
    mapping_status character varying(64) NOT NULL,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_rule_set_map OWNER TO dbadmin;

--
-- TOC entry 329 (class 1259 OID 213069)
-- Name: tbl_service_route_map_table_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_service_route_map_table_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_service_route_map_table_seq OWNER TO dbadmin;

--
-- TOC entry 442 (class 1259 OID 213761)
-- Name: tbl_service_route_map_table; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_service_route_map_table (
    id integer DEFAULT nextval('ng_orchestration.tbl_service_route_map_table_seq'::regclass) NOT NULL,
    flow_node_process_name character varying(500) NOT NULL,
    flow_node_process_version character varying(10),
    flow_node_step_name character varying(500) NOT NULL,
    service_proxy_url character varying(500),
    json_request_schema text
);


ALTER TABLE ng_orchestration.tbl_service_route_map_table OWNER TO dbadmin;

--
-- TOC entry 330 (class 1259 OID 213071)
-- Name: tbl_sla_process_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_sla_process_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_sla_process_map_seq OWNER TO dbadmin;

--
-- TOC entry 443 (class 1259 OID 213768)
-- Name: tbl_sla_process_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_sla_process_map (
    sla_process_map_id bigint DEFAULT nextval('ng_orchestration.tbl_sla_process_map_seq'::regclass) NOT NULL,
    sla_task_name character varying(128) NOT NULL,
    process_name character varying(128) NOT NULL,
    ref_process_name character varying(256),
    line_of_business character varying(32) NOT NULL,
    created_by character varying(32) NOT NULL,
    duration_type character varying(32) NOT NULL,
    exp_value bigint NOT NULL,
    ute_task_url character varying(512),
    action character varying(32) NOT NULL,
    task_category character varying(64),
    service_username character varying(32),
    service_password character varying(32),
    service_method character varying(16),
    service_endpoint character varying(256)
);


ALTER TABLE ng_orchestration.tbl_sla_process_map OWNER TO dbadmin;

--
-- TOC entry 331 (class 1259 OID 213073)
-- Name: tbl_ssporder_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_ssporder_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_ssporder_entity_seq OWNER TO dbadmin;

--
-- TOC entry 444 (class 1259 OID 213775)
-- Name: tbl_ssporder_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_ssporder_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_ssporder_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    order_number character varying(50) NOT NULL,
    version character varying(3) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_ssporder_entity OWNER TO dbadmin;

--
-- TOC entry 445 (class 1259 OID 213780)
-- Name: tbl_state; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_state (
    state_id integer NOT NULL,
    state_code character varying(4),
    state_name character varying(30)
);


ALTER TABLE ng_orchestration.tbl_state OWNER TO dbadmin;

--
-- TOC entry 446 (class 1259 OID 213783)
-- Name: tbl_state_plan_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_state_plan_map (
    plan_id integer NOT NULL,
    state_id integer NOT NULL
);


ALTER TABLE ng_orchestration.tbl_state_plan_map OWNER TO dbadmin;

--
-- TOC entry 447 (class 1259 OID 213786)
-- Name: tbl_std_interval; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_std_interval (
    std_interval_days integer NOT NULL,
    lam_days integer NOT NULL,
    trid_days integer NOT NULL,
    rid_days integer,
    dva_days integer,
    wot_days integer,
    fcd_days integer,
    ptd_days integer,
    dd_days integer,
    gpon integer,
    expedite integer
);


ALTER TABLE ng_orchestration.tbl_std_interval OWNER TO dbadmin;

--
-- TOC entry 332 (class 1259 OID 213075)
-- Name: tbl_subprocess_mapping_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_subprocess_mapping_seq OWNER TO dbadmin;

--
-- TOC entry 448 (class 1259 OID 213789)
-- Name: tbl_subprocess_mapping; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_subprocess_mapping (
    mapping_id bigint DEFAULT nextval('ng_orchestration.tbl_subprocess_mapping_seq'::regclass) NOT NULL,
    lob character varying(255) NOT NULL,
    process_name character varying(255) NOT NULL,
    product character varying(255),
    step_name character varying(255),
    version character varying(50),
    subprocess_name character varying(255),
    vzid character varying(255) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    category character varying(60) DEFAULT 'auto_select'::character varying,
    description character varying(500),
    attribute text,
    contract text,
    product_category character varying(64),
    product_sub_category character varying(64),
    supp_type character varying(64),
    order_type character varying(64)
);


ALTER TABLE ng_orchestration.tbl_subprocess_mapping OWNER TO dbadmin;

--
-- TOC entry 333 (class 1259 OID 213077)
-- Name: tbl_task_sla_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_task_sla_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_task_sla_seq OWNER TO dbadmin;

--
-- TOC entry 449 (class 1259 OID 213800)
-- Name: tbl_task_sla; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_task_sla (
    task_sla_id bigint DEFAULT nextval('ng_orchestration.tbl_task_sla_seq'::regclass) NOT NULL,
    sla_process_map_id bigint NOT NULL,
    order_number character varying(64),
    order_version character varying(8),
    order_ref_id character varying(64),
    create_date bigint NOT NULL,
    expiry_date bigint NOT NULL,
    activity_id bigint NOT NULL,
    status character varying(32) NOT NULL,
    case_id bigint NOT NULL,
    task_reference_id character varying(64),
    contract character varying(2048)
);


ALTER TABLE ng_orchestration.tbl_task_sla OWNER TO dbadmin;

--
-- TOC entry 334 (class 1259 OID 213079)
-- Name: tbl_vps_order_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_order_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_order_seq OWNER TO dbadmin;

--
-- TOC entry 450 (class 1259 OID 213807)
-- Name: tbl_vps_order; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_order (
    order_id bigint DEFAULT nextval('ng_orchestration.tbl_vps_order_seq'::regclass) NOT NULL,
    order_number character varying(125) NOT NULL,
    order_version_latest character varying(25),
    order_status character varying(60),
    order_type character varying(30),
    region character varying(60) NOT NULL,
    sr_number character varying(60),
    product character varying(30),
    workflow_scheme character varying(25),
    asr character varying(40),
    lob character varying(30),
    cro character varying(40),
    pon character varying(30),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    prev_prov_order character varying(125),
    customer_name character varying(200),
    ccna character varying(30),
    pg_order character varying,
    pg_order_version_latest character varying,
    svc_order_latest character varying,
    svc_order_version_latest character varying,
    duedate timestamp without time zone,
    completed_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_vps_order OWNER TO dbadmin;

--
-- TOC entry 335 (class 1259 OID 213081)
-- Name: tbl_vps_order_bak_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_order_bak_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_order_bak_seq OWNER TO dbadmin;

--
-- TOC entry 451 (class 1259 OID 213817)
-- Name: tbl_vps_order_bak; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_order_bak (
    vps_order_id integer DEFAULT nextval('ng_orchestration.tbl_vps_order_bak_seq'::regclass) NOT NULL,
    order_number character varying(128) NOT NULL,
    order_version character varying(25),
    circuit_id character varying(100) NOT NULL,
    region character varying(64) NOT NULL,
    sr_number character varying(64),
    order_status character varying(64),
    wf_id character varying(64),
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    revision_seq integer NOT NULL,
    prov_version character varying(10) NOT NULL,
    proc_status character varying(10),
    service_id integer,
    qualified character(1),
    firm character(1),
    pon character varying(30),
    circuit_activity character varying(30),
    supp_type character varying(30),
    sr_version character varying(10),
    order_stage character varying(20) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_vps_order_bak OWNER TO dbadmin;

--
-- TOC entry 336 (class 1259 OID 213083)
-- Name: tbl_vps_order_circuit_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_order_circuit_seq OWNER TO dbadmin;

--
-- TOC entry 452 (class 1259 OID 213826)
-- Name: tbl_vps_order_circuit; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_order_circuit (
    order_circuit_id bigint DEFAULT nextval('ng_orchestration.tbl_vps_order_circuit_seq'::regclass) NOT NULL,
    order_id bigint NOT NULL,
    circuit_id character varying(100) NOT NULL,
    circuit_status character varying(60),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_vps_order_circuit OWNER TO dbadmin;

--
-- TOC entry 337 (class 1259 OID 213085)
-- Name: tbl_vps_order_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_order_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_order_entity_seq OWNER TO dbadmin;

--
-- TOC entry 453 (class 1259 OID 213833)
-- Name: tbl_vps_order_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_order_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_vps_order_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    order_number character varying(128) NOT NULL,
    order_version character varying(25) NOT NULL,
    circuit_id character varying(100) NOT NULL,
    region character varying(64) NOT NULL,
    prov_version character varying(10) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_vps_order_entity OWNER TO dbadmin;

--
-- TOC entry 565 (class 1259 OID 413949)
-- Name: tbl_vps_order_lambda_test; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_vps_order_lambda_test (
    order_id bigint,
    order_number character varying(125),
    order_version_latest character varying(25),
    order_status character varying(60),
    order_type character varying(30),
    region character varying(60),
    sr_number character varying(60),
    product character varying(30),
    workflow_scheme character varying(25),
    asr character varying(40),
    lob character varying(30),
    cro character varying(40),
    pon character varying(30),
    vzid character varying(25),
    created_date timestamp without time zone,
    modified_date timestamp without time zone,
    prev_prov_order character varying(125),
    customer_name character varying(200),
    ccna character varying(30),
    pg_order character varying,
    pg_order_version_latest character varying,
    svc_order_latest character varying,
    svc_order_version_latest character varying,
    duedate timestamp without time zone,
    completed_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_vps_order_lambda_test OWNER TO prvgwy;

--
-- TOC entry 338 (class 1259 OID 213087)
-- Name: tbl_vps_order_new_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_order_new_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_order_new_seq OWNER TO dbadmin;

--
-- TOC entry 454 (class 1259 OID 213838)
-- Name: tbl_vps_order_new; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_order_new (
    order_id bigint DEFAULT nextval('ng_orchestration.tbl_vps_order_new_seq'::regclass) NOT NULL,
    order_number character varying(125) NOT NULL,
    order_version_latest character varying(25),
    order_status character varying(60),
    order_type character varying(30),
    region character varying(60) NOT NULL,
    sr_number character varying(60),
    product character varying(30),
    asr character varying(40),
    lob character varying(30),
    cro character varying(40),
    pon character varying(30),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    prev_prov_order character varying(125),
    customer_name character varying(200)
);


ALTER TABLE ng_orchestration.tbl_vps_order_new OWNER TO dbadmin;

--
-- TOC entry 738 (class 1259 OID 1036708)
-- Name: tbl_vps_order_test; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.tbl_vps_order_test (
    order_id bigint,
    order_number character varying(125),
    order_version_latest character varying(25),
    order_status character varying(60),
    order_type character varying(30),
    region character varying(60),
    sr_number character varying(60),
    product character varying(30),
    workflow_scheme character varying(25),
    asr character varying(40),
    lob character varying(30),
    cro character varying(40),
    pon character varying(30),
    vzid character varying(25),
    created_date timestamp without time zone,
    modified_date timestamp without time zone,
    prev_prov_order character varying(125),
    customer_name character varying(200),
    ccna character varying(30),
    pg_order character varying,
    pg_order_version_latest character varying,
    svc_order_latest character varying,
    svc_order_version_latest character varying,
    duedate timestamp without time zone,
    completed_date timestamp without time zone
);


ALTER TABLE ng_orchestration.tbl_vps_order_test OWNER TO prvgwy;

--
-- TOC entry 339 (class 1259 OID 213089)
-- Name: tbl_vps_order_version_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_order_version_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_order_version_seq OWNER TO dbadmin;

--
-- TOC entry 455 (class 1259 OID 213848)
-- Name: tbl_vps_order_version; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_order_version (
    order_version_id bigint DEFAULT nextval('ng_orchestration.tbl_vps_order_version_seq'::regclass) NOT NULL,
    order_id bigint NOT NULL,
    order_circuit_id bigint NOT NULL,
    order_version character varying(25),
    order_stage character varying(20) NOT NULL,
    revision_seq integer NOT NULL,
    prov_version character varying(20) NOT NULL,
    order_supp_type character varying(30),
    prov_supp_type character varying(30),
    qualified character(1),
    firm character(1),
    circuit_activity character varying(30),
    sr_version character varying(20),
    proc_status character varying(25),
    service_id integer,
    wf_id character varying(60),
    vzid character varying(25) DEFAULT 'SYSTEM'::character varying,
    created_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    modified_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL,
    sr_number character varying(60),
    trail_id bigint,
    pg_order_version character varying,
    svc_order character varying,
    svc_order_version character varying
);


ALTER TABLE ng_orchestration.tbl_vps_order_version OWNER TO dbadmin;

--
-- TOC entry 340 (class 1259 OID 213091)
-- Name: tbl_vps_sr_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vps_sr_entity_seq OWNER TO dbadmin;

--
-- TOC entry 456 (class 1259 OID 213855)
-- Name: tbl_vps_sr_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vps_sr_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_vps_sr_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    sr_num character varying(256) NOT NULL,
    sr_version character varying(128) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_vps_sr_entity OWNER TO dbadmin;

--
-- TOC entry 341 (class 1259 OID 213093)
-- Name: tbl_vrd_order_entity_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_vrd_order_entity_seq OWNER TO dbadmin;

--
-- TOC entry 457 (class 1259 OID 213860)
-- Name: tbl_vrd_order_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vrd_order_entity (
    entity_id bigint DEFAULT nextval('ng_orchestration.tbl_vrd_order_entity_seq'::regclass) NOT NULL,
    app_id bigint NOT NULL,
    order_number character varying(128) NOT NULL,
    order_version character varying(125) NOT NULL,
    document_level character varying(100) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_vrd_order_entity OWNER TO dbadmin;

--
-- TOC entry 458 (class 1259 OID 213865)
-- Name: tbl_vzt_vzw_sharedpanel_entity; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity (
    entity_id bigint NOT NULL,
    app_id bigint NOT NULL,
    entity_type character varying(255) NOT NULL,
    entity_reference bigint NOT NULL,
    operation character varying(255) NOT NULL,
    create_date timestamp without time zone DEFAULT '1970-01-01 00:00:00'::timestamp without time zone NOT NULL
);


ALTER TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity OWNER TO dbadmin;

--
-- TOC entry 459 (class 1259 OID 213872)
-- Name: tbl_wf_decision_params; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_wf_decision_params (
    root_case_id integer NOT NULL,
    wf_param_name character varying(30) NOT NULL,
    wf_param_value character varying(16000) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_wf_decision_params OWNER TO dbadmin;

--
-- TOC entry 342 (class 1259 OID 213095)
-- Name: tbl_workflow_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_workflow_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_workflow_map_seq OWNER TO dbadmin;

--
-- TOC entry 460 (class 1259 OID 213878)
-- Name: tbl_workflow_map; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_workflow_map (
    workflow_map_id bigint DEFAULT nextval('ng_orchestration.tbl_workflow_map_seq'::regclass) NOT NULL,
    lob character varying(24) NOT NULL,
    order_source character varying(24) NOT NULL,
    product character varying(24) NOT NULL,
    order_type character varying(24) NOT NULL,
    case_name character varying(128)
);


ALTER TABLE ng_orchestration.tbl_workflow_map OWNER TO dbadmin;

--
-- TOC entry 343 (class 1259 OID 213097)
-- Name: tbl_workflow_map_ext_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_workflow_map_ext_seq OWNER TO dbadmin;

--
-- TOC entry 461 (class 1259 OID 213882)
-- Name: tbl_workflow_map_ext; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_workflow_map_ext (
    workflow_map_ext_id bigint DEFAULT nextval('ng_orchestration.tbl_workflow_map_ext_seq'::regclass) NOT NULL,
    workflow_map_id bigint NOT NULL,
    product_category character varying(64),
    product_sub_category character varying(64),
    prov_stage character varying(64),
    order_category character varying(64),
    scheme character varying(64),
    case_name character varying(128) NOT NULL,
    flow_action character varying(16) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_workflow_map_ext OWNER TO dbadmin;

--
-- TOC entry 344 (class 1259 OID 213099)
-- Name: tbl_workflow_template_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.tbl_workflow_template_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.tbl_workflow_template_seq OWNER TO dbadmin;

--
-- TOC entry 462 (class 1259 OID 213886)
-- Name: tbl_workflow_template; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.tbl_workflow_template (
    workflow_template_id bigint DEFAULT nextval('ng_orchestration.tbl_workflow_template_seq'::regclass) NOT NULL,
    case_name character varying(128) NOT NULL,
    payload character varying(1024) DEFAULT '{}'::character varying NOT NULL,
    process_name character varying(128) NOT NULL
);


ALTER TABLE ng_orchestration.tbl_workflow_template OWNER TO dbadmin;

--
-- TOC entry 909 (class 1259 OID 5199774)
-- Name: test_table; Type: TABLE; Schema: ng_orchestration; Owner: postgres
--

CREATE TABLE ng_orchestration.test_table (
    cust_id numeric(9,0) NOT NULL,
    cust_name character varying(15),
    cust_address character varying(15),
    cust_tel character varying(15),
    cust_age numeric(9,0)
);


ALTER TABLE ng_orchestration.test_table OWNER TO postgres;

--
-- TOC entry 919 (class 1259 OID 5821417)
-- Name: test_table_orders; Type: TABLE; Schema: ng_orchestration; Owner: postgres
--

CREATE TABLE ng_orchestration.test_table_orders (
    order_no numeric(9,0) NOT NULL,
    cust_id numeric(9,0),
    order_amount numeric(9,0),
    order_status character varying(25)
);


ALTER TABLE ng_orchestration.test_table_orders OWNER TO postgres;

--
-- TOC entry 547 (class 1259 OID 367680)
-- Name: testtable; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.testtable (
    id integer NOT NULL,
    name text NOT NULL,
    age integer NOT NULL,
    address character(50),
    salary real
);


ALTER TABLE ng_orchestration.testtable OWNER TO prvgwy;

--
-- TOC entry 726 (class 1259 OID 577799)
-- Name: trunc_value; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.trunc_value (
    date_trunc timestamp without time zone
);


ALTER TABLE ng_orchestration.trunc_value OWNER TO prvgwy;

--
-- TOC entry 901 (class 1259 OID 2102335)
-- Name: user_preference; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.user_preference (
    "USER_PREFERENCE_ID" numeric(9,0),
    "USER_ID" numeric(9,0),
    "PREFERENCE_GROUP_ID" numeric(9,0),
    "VALUE" character varying(255)
);


ALTER TABLE ng_orchestration.user_preference OWNER TO prvgwy;

--
-- TOC entry 345 (class 1259 OID 213101)
-- Name: users_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE SEQUENCE ng_orchestration.users_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.users_seq OWNER TO dbadmin;

--
-- TOC entry 463 (class 1259 OID 213894)
-- Name: users; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.users (
    id integer DEFAULT nextval('ng_orchestration.users_seq'::regclass) NOT NULL,
    email character varying(45),
    name character varying(45)
);


ALTER TABLE ng_orchestration.users OWNER TO dbadmin;

--
-- TOC entry 773 (class 1259 OID 1370980)
-- Name: var_inst_log_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.var_inst_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.var_inst_log_id_seq OWNER TO prvgwy;

--
-- TOC entry 479 (class 1259 OID 234112)
-- Name: var_local_doc_id; Type: TABLE; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TABLE ng_orchestration.var_local_doc_id (
    max bigint
);


ALTER TABLE ng_orchestration.var_local_doc_id OWNER TO dbadmin;

--
-- TOC entry 464 (class 1259 OID 213898)
-- Name: vdsi_view_onenet_order_data; Type: VIEW; Schema: ng_orchestration; Owner: dbadmin
--

CREATE VIEW ng_orchestration.vdsi_view_onenet_order_data AS
 SELECT 'xxxx' AS onenet_order_id,
    'xxxx' AS order_number,
    'xxxx' AS order_version,
    'xxxx' AS order_source,
    'xxxx' AS circuit_id,
    onenet_order_data.order_group_id,
    onenet_order_data.product_family,
    onenet_order_data.product_category,
    onenet_order_data.work_order_type,
    onenet_order_data.inventory_service_id,
    onenet_order_data.order_status,
    onenet_order_data.case_id,
    onenet_order_data.obsolete,
    onenet_order_data.cust_req_due_date,
    onenet_order_data.due_date_type,
    onenet_order_data.supp_type,
    'xxxx' AS a_site_id,
    'xxxx' AS z_site_id,
    onenet_order_data.commit_date,
    onenet_order_data.creation_date,
    onenet_order_data.last_update_date,
    onenet_order_data.trail_id,
    onenet_order_data.svc_desc_name
   FROM ng_orchestration.onenet_order_data;


ALTER TABLE ng_orchestration.vdsi_view_onenet_order_data OWNER TO dbadmin;

--
-- TOC entry 517 (class 1259 OID 356883)
-- Name: vzot_transaction_log; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.vzot_transaction_log (
    sr_id integer NOT NULL,
    sr_num character varying(23),
    req_xml character varying(4000),
    rsp_xml text,
    status character varying(200),
    request_type character varying(25),
    time_submitted integer,
    last_modified integer,
    service_order_numer character varying(32),
    vzot_reservation_id character varying(20),
    vzot_date character varying(15)
);


ALTER TABLE ng_orchestration.vzot_transaction_log OWNER TO prvgwy;

--
-- TOC entry 521 (class 1259 OID 356907)
-- Name: web_service_url_map_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.web_service_url_map_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.web_service_url_map_seq OWNER TO prvgwy;

--
-- TOC entry 522 (class 1259 OID 356909)
-- Name: web_service_url_map; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.web_service_url_map (
    web_service_url_map_id integer DEFAULT nextval('ng_orchestration.web_service_url_map_seq'::regclass) NOT NULL,
    app_name character varying(24) NOT NULL,
    service_name character varying(24),
    method_name character varying(24),
    url character varying(300),
    user_name character varying(50),
    password character varying(50)
);


ALTER TABLE ng_orchestration.web_service_url_map OWNER TO prvgwy;

--
-- TOC entry 563 (class 1259 OID 413077)
-- Name: wire_center; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.wire_center (
    wirecenter_id numeric(9,0) NOT NULL,
    wirecenter_name character varying(30) NOT NULL,
    street character varying(30),
    state_id integer NOT NULL,
    modified_date numeric(10,0)
);


ALTER TABLE ng_orchestration.wire_center OWNER TO prvgwy;

--
-- TOC entry 774 (class 1259 OID 1370982)
-- Name: workiteminfo_id_seq; Type: SEQUENCE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE SEQUENCE ng_orchestration.workiteminfo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ng_orchestration.workiteminfo_id_seq OWNER TO prvgwy;

--
-- TOC entry 693 (class 1259 OID 526098)
-- Name: zax_admin; Type: TABLE; Schema: ng_orchestration; Owner: prvgwy
--

CREATE TABLE ng_orchestration.zax_admin (
    user_ext_id numeric(9,0) NOT NULL,
    lob_id numeric(9,0) NOT NULL,
    eu_name character varying(50) NOT NULL
);


ALTER TABLE ng_orchestration.zax_admin OWNER TO prvgwy;

--
-- TOC entry 5796 (class 2604 OID 2988332)
-- Name: flywaytable1 user_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.flywaytable1 ALTER COLUMN user_id SET DEFAULT nextval('ng_orchestration.flywaytable1_user_id_seq'::regclass);


--
-- TOC entry 5767 (class 2604 OID 354787)
-- Name: lci_document_store id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.lci_document_store ALTER COLUMN id SET DEFAULT nextval('ng_orchestration.lci_document_store_seq'::regclass);


--
-- TOC entry 5782 (class 2604 OID 412134)
-- Name: manifest_app_config app_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_config ALTER COLUMN app_id SET DEFAULT nextval('ng_orchestration.manifest_app_config_app_id_seq'::regclass);


--
-- TOC entry 5797 (class 2604 OID 6115718)
-- Name: manifest_app_config_test id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_config_test ALTER COLUMN id SET DEFAULT nextval('ng_orchestration.manifest_app_config_test_id_seq'::regclass);


--
-- TOC entry 5798 (class 2604 OID 6115729)
-- Name: manifest_app_configs id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_configs ALTER COLUMN id SET DEFAULT nextval('ng_orchestration.manifest_app_configs_id_seq'::regclass);


--
-- TOC entry 5784 (class 2604 OID 412233)
-- Name: manifest_doc_config doc_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_doc_config ALTER COLUMN doc_id SET DEFAULT nextval('ng_orchestration.manifest_doc_config_doc_id_seq'::regclass);


--
-- TOC entry 5787 (class 2604 OID 412220)
-- Name: manifest_document doc_id; Type: DEFAULT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_document ALTER COLUMN doc_id SET DEFAULT nextval('ng_orchestration.manifest_document_doc_id_seq'::regclass);


--
-- TOC entry 5785 (class 2604 OID 412203)
-- Name: manifest_entity entity_id; Type: DEFAULT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_entity ALTER COLUMN entity_id SET DEFAULT nextval('ng_orchestration.manifest_entity_entity_id_seq'::regclass);


--
-- TOC entry 5775 (class 2604 OID 356998)
-- Name: ods_document_store id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_document_store ALTER COLUMN id SET DEFAULT nextval('ng_orchestration.ods_document_store_seq'::regclass);


--
-- TOC entry 5765 (class 2604 OID 352262)
-- Name: oldjeopardy_admin_docs jeop_admin_doc_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.oldjeopardy_admin_docs ALTER COLUMN jeop_admin_doc_id SET DEFAULT nextval('ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq'::regclass);


--
-- TOC entry 5790 (class 2604 OID 498111)
-- Name: pipeline_setting pipeline_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.pipeline_setting ALTER COLUMN pipeline_id SET DEFAULT nextval('ng_orchestration.pipeline_setting_pipeline_id_seq'::regclass);


--
-- TOC entry 5745 (class 2604 OID 234126)
-- Name: rajtest id; Type: DEFAULT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.rajtest ALTER COLUMN id SET DEFAULT nextval('ng_orchestration.rajtest_id_seq'::regclass);


--
-- TOC entry 5776 (class 2604 OID 357007)
-- Name: rqn_document_store id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.rqn_document_store ALTER COLUMN id SET DEFAULT nextval('ng_orchestration.rqn_document_store_seq'::regclass);


--
-- TOC entry 5791 (class 2604 OID 498122)
-- Name: saved_columns saved_column_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.saved_columns ALTER COLUMN saved_column_id SET DEFAULT nextval('ng_orchestration.saved_columns_saved_column_id_seq'::regclass);


--
-- TOC entry 5793 (class 2604 OID 534961)
-- Name: tbl_ien_order ien_order_id; Type: DEFAULT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.tbl_ien_order ALTER COLUMN ien_order_id SET DEFAULT nextval('ng_orchestration.tbl_ien_order_ien_order_id_seq'::regclass);


--
-- TOC entry 6480 (class 2606 OID 6115578)
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- TOC entry 5809 (class 2606 OID 218815)
-- Name: dir_project_action action_dir_project_action; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_project_action
    ADD CONSTRAINT action_dir_project_action UNIQUE (action);


--
-- TOC entry 6276 (class 2606 OID 351644)
-- Name: admin_document_store admin_document_store_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.admin_document_store
    ADD CONSTRAINT admin_document_store_pkey PRIMARY KEY (app_key);


--
-- TOC entry 6462 (class 2606 OID 1415960)
-- Name: auth_users auth_users_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.auth_users
    ADD CONSTRAINT auth_users_pkey PRIMARY KEY (id);


--
-- TOC entry 6433 (class 2606 OID 526194)
-- Name: cafe_bases_service_type cafe_bases_service_type_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.cafe_bases_service_type
    ADD CONSTRAINT cafe_bases_service_type_pkey PRIMARY KEY (service_type_id);


--
-- TOC entry 6278 (class 2606 OID 352310)
-- Name: jeopardy_admin_docs doc_id_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.jeopardy_admin_docs
    ADD CONSTRAINT doc_id_pkey PRIMARY KEY (doc_id);


--
-- TOC entry 6455 (class 2606 OID 598521)
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- TOC entry 6464 (class 2606 OID 2988338)
-- Name: flywaytable1 flywaytable1_email_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.flywaytable1
    ADD CONSTRAINT flywaytable1_email_key UNIQUE (email);


--
-- TOC entry 6466 (class 2606 OID 2988334)
-- Name: flywaytable1 flywaytable1_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.flywaytable1
    ADD CONSTRAINT flywaytable1_pkey PRIMARY KEY (user_id);


--
-- TOC entry 6468 (class 2606 OID 2988336)
-- Name: flywaytable1 flywaytable1_username_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.flywaytable1
    ADD CONSTRAINT flywaytable1_username_key UNIQUE (username);


--
-- TOC entry 6414 (class 2606 OID 413161)
-- Name: tbl_order ien_order_id_pk; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.tbl_order
    ADD CONSTRAINT ien_order_id_pk PRIMARY KEY (order_id);


--
-- TOC entry 6274 (class 2606 OID 352264)
-- Name: oldjeopardy_admin_docs jeopardy_admin_docs_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.oldjeopardy_admin_docs
    ADD CONSTRAINT jeopardy_admin_docs_pkey PRIMARY KEY (jeop_admin_doc_id);


--
-- TOC entry 6471 (class 2606 OID 3406683)
-- Name: jv_commit_property jv_commit_property_pk; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.jv_commit_property
    ADD CONSTRAINT jv_commit_property_pk PRIMARY KEY (commit_fk, property_name);


--
-- TOC entry 6416 (class 2606 OID 445423)
-- Name: lookup_values lookup_values_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.lookup_values
    ADD CONSTRAINT lookup_values_pkey PRIMARY KEY (lv_id);


--
-- TOC entry 6379 (class 2606 OID 412141)
-- Name: manifest_app_config manifest_app_config_ix2_manifest_app_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_config
    ADD CONSTRAINT manifest_app_config_ix2_manifest_app_config UNIQUE (app_key);


--
-- TOC entry 6381 (class 2606 OID 412139)
-- Name: manifest_app_config manifest_app_config_ix_manifest_app_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_config
    ADD CONSTRAINT manifest_app_config_ix_manifest_app_config PRIMARY KEY (app_id);


--
-- TOC entry 6482 (class 2606 OID 6115723)
-- Name: manifest_app_config_test manifest_app_config_test_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_config_test
    ADD CONSTRAINT manifest_app_config_test_pkey PRIMARY KEY (id);


--
-- TOC entry 6484 (class 2606 OID 6115734)
-- Name: manifest_app_configs manifest_app_configs_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_app_configs
    ADD CONSTRAINT manifest_app_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 6384 (class 2606 OID 3248922)
-- Name: manifest_doc_config manifest_doc_config_app_id_doc_name_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_doc_config
    ADD CONSTRAINT manifest_doc_config_app_id_doc_name_key UNIQUE (app_id, doc_name);


--
-- TOC entry 6388 (class 2606 OID 412235)
-- Name: manifest_doc_config manifest_doc_config_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_doc_config
    ADD CONSTRAINT manifest_doc_config_pkey PRIMARY KEY (doc_id);


--
-- TOC entry 6396 (class 2606 OID 498002)
-- Name: manifest_document manifest_document_entity_id_doc_name_document_headers_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_document
    ADD CONSTRAINT manifest_document_entity_id_doc_name_document_headers_key UNIQUE (entity_id, doc_name, document_headers);


--
-- TOC entry 6401 (class 2606 OID 412222)
-- Name: manifest_document manifest_document_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_document
    ADD CONSTRAINT manifest_document_pkey PRIMARY KEY (doc_id);


--
-- TOC entry 6391 (class 2606 OID 498369)
-- Name: manifest_entity manifest_entity_entity_string_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_entity
    ADD CONSTRAINT manifest_entity_entity_string_key UNIQUE (entity_string);


--
-- TOC entry 6394 (class 2606 OID 412205)
-- Name: manifest_entity manifest_entity_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_entity
    ADD CONSTRAINT manifest_entity_pkey PRIMARY KEY (entity_id);


--
-- TOC entry 6486 (class 2606 OID 8029554)
-- Name: metrics_v3_completions metrics_v3_completions_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.metrics_v3_completions
    ADD CONSTRAINT metrics_v3_completions_pkey PRIMARY KEY (unique_id);


--
-- TOC entry 6474 (class 2606 OID 4892546)
-- Name: ods_book_test ods_book_test_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_book_test
    ADD CONSTRAINT ods_book_test_pkey PRIMARY KEY (book_id);


--
-- TOC entry 5867 (class 2606 OID 218865)
-- Name: ods_milestone_config ods_milestone_config_id_unique_ods_milestone_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_milestone_config
    ADD CONSTRAINT ods_milestone_config_id_unique_ods_milestone_config UNIQUE (ods_milestone_config_id);


--
-- TOC entry 5873 (class 2606 OID 218869)
-- Name: ods_milestone_transaction ods_milestone_transaction_id_unique_ods_milestone_transaction; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_milestone_transaction
    ADD CONSTRAINT ods_milestone_transaction_id_unique_ods_milestone_transaction UNIQUE (ods_milestone_transaction_id);


--
-- TOC entry 6243 (class 2606 OID 246457)
-- Name: ods_request_log ods_request_log_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_request_log
    ADD CONSTRAINT ods_request_log_pkey PRIMARY KEY (ods_request_log_id);


--
-- TOC entry 6261 (class 2606 OID 294833)
-- Name: ods_response_param_map ods_response_param_map_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_response_param_map
    ADD CONSTRAINT ods_response_param_map_pkey PRIMARY KEY (key);


--
-- TOC entry 6263 (class 2606 OID 294841)
-- Name: ods_wf_correlation_config ods_wf_correlation_config_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_wf_correlation_config
    ADD CONSTRAINT ods_wf_correlation_config_pkey PRIMARY KEY (correlation_key);


--
-- TOC entry 6226 (class 2606 OID 219312)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- TOC entry 6457 (class 2606 OID 1392744)
-- Name: organizationalentity organizationalentity_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.organizationalentity
    ADD CONSTRAINT organizationalentity_pkey PRIMARY KEY (id);


--
-- TOC entry 6007 (class 2606 OID 218955)
-- Name: tbl_application_config param_name_unique_tbl_application_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application_config
    ADD CONSTRAINT param_name_unique_tbl_application_config UNIQUE (param_name);


--
-- TOC entry 6423 (class 2606 OID 498116)
-- Name: pipeline_setting pipeline_setting_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.pipeline_setting
    ADD CONSTRAINT pipeline_setting_pkey PRIMARY KEY (pipeline_id);


--
-- TOC entry 6435 (class 2606 OID 1415146)
-- Name: aqm_task pk_aqm_task; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.aqm_task
    ADD CONSTRAINT pk_aqm_task PRIMARY KEY (task_id);


--
-- TOC entry 5801 (class 2606 OID 218807)
-- Name: atoll_temp pk_atoll_temp; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.atoll_temp
    ADD CONSTRAINT pk_atoll_temp PRIMARY KEY (pk);


--
-- TOC entry 5803 (class 2606 OID 218809)
-- Name: attachment_download_auth pk_attachment_download_auth; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.attachment_download_auth
    ADD CONSTRAINT pk_attachment_download_auth PRIMARY KEY (auth_pk);


--
-- TOC entry 5805 (class 2606 OID 218811)
-- Name: attachment_entity_map pk_attachment_entity_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.attachment_entity_map
    ADD CONSTRAINT pk_attachment_entity_map PRIMARY KEY (entity_id, entity_type, attachment_id);


--
-- TOC entry 5807 (class 2606 OID 218813)
-- Name: dir_foreign_entity pk_dir_foreign_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_foreign_entity
    ADD CONSTRAINT pk_dir_foreign_entity PRIMARY KEY (entity_type);


--
-- TOC entry 5811 (class 2606 OID 218817)
-- Name: dir_project_action pk_dir_project_action; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_project_action
    ADD CONSTRAINT pk_dir_project_action PRIMARY KEY (action_id);


--
-- TOC entry 5813 (class 2606 OID 218819)
-- Name: dir_project_status pk_dir_project_status; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_project_status
    ADD CONSTRAINT pk_dir_project_status PRIMARY KEY (project_status_id);


--
-- TOC entry 5817 (class 2606 OID 218823)
-- Name: dir_project_type pk_dir_project_type; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_project_type
    ADD CONSTRAINT pk_dir_project_type PRIMARY KEY (project_type_id);


--
-- TOC entry 5821 (class 2606 OID 218827)
-- Name: dml_monitor pk_dml_monitor; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dml_monitor
    ADD CONSTRAINT pk_dml_monitor PRIMARY KEY (dml_event_id);


--
-- TOC entry 5823 (class 2606 OID 218829)
-- Name: entity_map pk_entity_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.entity_map
    ADD CONSTRAINT pk_entity_map PRIMARY KEY (entity_map_id);


--
-- TOC entry 5825 (class 2606 OID 218831)
-- Name: file_attachment pk_file_attachment; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.file_attachment
    ADD CONSTRAINT pk_file_attachment PRIMARY KEY (file_id);


--
-- TOC entry 5827 (class 2606 OID 218833)
-- Name: file_data pk_file_data; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.file_data
    ADD CONSTRAINT pk_file_data PRIMARY KEY (file_id);


--
-- TOC entry 5831 (class 2606 OID 218837)
-- Name: if_onenetwork_qe_automationcheck pk_if_onenetwork_qe_automationcheck; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.if_onenetwork_qe_automationcheck
    ADD CONSTRAINT pk_if_onenetwork_qe_automationcheck PRIMARY KEY (cno);


--
-- TOC entry 5829 (class 2606 OID 218835)
-- Name: if_onenetwork_qeautomation pk_if_onenetwork_qeautomation; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.if_onenetwork_qeautomation
    ADD CONSTRAINT pk_if_onenetwork_qeautomation PRIMARY KEY (cno, pon);


--
-- TOC entry 6259 (class 2606 OID 293723)
-- Name: jeop_config_param pk_jeop_config_param; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.jeop_config_param
    ADD CONSTRAINT pk_jeop_config_param PRIMARY KEY (param_id);


--
-- TOC entry 6255 (class 2606 OID 293708)
-- Name: jeopardy_transaction pk_jeopardy_transaction; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.jeopardy_transaction
    ADD CONSTRAINT pk_jeopardy_transaction PRIMARY KEY (jeopardy_transaction_id);


--
-- TOC entry 6270 (class 2606 OID 342133)
-- Name: lci_admin_docs_testlarge pk_lci_admin_docs_testlarge; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.lci_admin_docs_testlarge
    ADD CONSTRAINT pk_lci_admin_docs_testlarge PRIMARY KEY (document_id);


--
-- TOC entry 5834 (class 2606 OID 218847)
-- Name: milestone_order pk_milestone_order; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_order
    ADD CONSTRAINT pk_milestone_order PRIMARY KEY (milestone_order_id);


--
-- TOC entry 5836 (class 2606 OID 218849)
-- Name: milestone_order_bak pk_milestone_order_bak; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_order_bak
    ADD CONSTRAINT pk_milestone_order_bak PRIMARY KEY (milestone_order_id);


--
-- TOC entry 5838 (class 2606 OID 218851)
-- Name: milestone_order_new pk_milestone_order_new; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_order_new
    ADD CONSTRAINT pk_milestone_order_new PRIMARY KEY (milestone_order_id);


--
-- TOC entry 5841 (class 2606 OID 218853)
-- Name: milestone_template pk_milestone_template; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_template
    ADD CONSTRAINT pk_milestone_template PRIMARY KEY (milestone_template_id);


--
-- TOC entry 5843 (class 2606 OID 218855)
-- Name: milestone_template_bak pk_milestone_template_bak; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_template_bak
    ADD CONSTRAINT pk_milestone_template_bak PRIMARY KEY (milestone_template_id);


--
-- TOC entry 5848 (class 2606 OID 218857)
-- Name: milestone_template_map pk_milestone_template_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_template_map
    ADD CONSTRAINT pk_milestone_template_map PRIMARY KEY (milestone_template_map_id);


--
-- TOC entry 5850 (class 2606 OID 218859)
-- Name: milestone_template_new pk_milestone_template_new; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.milestone_template_new
    ADD CONSTRAINT pk_milestone_template_new PRIMARY KEY (milestone_template_id);


--
-- TOC entry 5862 (class 2606 OID 218861)
-- Name: ods_interface_request pk_ods_interface_request; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.ods_interface_request
    ADD CONSTRAINT pk_ods_interface_request PRIMARY KEY (id);


--
-- TOC entry 5865 (class 2606 OID 218863)
-- Name: ods_mandatory_attrs pk_ods_mandatory_attrs; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_mandatory_attrs
    ADD CONSTRAINT pk_ods_mandatory_attrs PRIMARY KEY (validation_id);


--
-- TOC entry 5869 (class 2606 OID 218867)
-- Name: ods_milestone_config pk_ods_milestone_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_milestone_config
    ADD CONSTRAINT pk_ods_milestone_config PRIMARY KEY (ods_milestone_config_id);


--
-- TOC entry 5876 (class 2606 OID 218873)
-- Name: ods_milestone_transaction pk_ods_milestone_transaction; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_milestone_transaction
    ADD CONSTRAINT pk_ods_milestone_transaction PRIMARY KEY (ods_milestone_transaction_id);


--
-- TOC entry 6249 (class 2606 OID 293200)
-- Name: ods_notification_config pk_ods_notification_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_notification_config
    ADD CONSTRAINT pk_ods_notification_config PRIMARY KEY (ods_notification_config_id);


--
-- TOC entry 6252 (class 2606 OID 293213)
-- Name: ods_notification_transaction pk_ods_notification_transaction; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_notification_transaction
    ADD CONSTRAINT pk_ods_notification_transaction PRIMARY KEY (ods_notification_transaction_id);


--
-- TOC entry 5882 (class 2606 OID 218875)
-- Name: ods_param_config pk_ods_param_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_param_config
    ADD CONSTRAINT pk_ods_param_config PRIMARY KEY (param_id);


--
-- TOC entry 5884 (class 2606 OID 218877)
-- Name: ods_request_transaction_id_map pk_ods_request_transaction_id_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_request_transaction_id_map
    ADD CONSTRAINT pk_ods_request_transaction_id_map PRIMARY KEY (id);


--
-- TOC entry 5889 (class 2606 OID 218881)
-- Name: ods_response_transaction_id_map pk_ods_response_transaction_id_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_response_transaction_id_map
    ADD CONSTRAINT pk_ods_response_transaction_id_map PRIMARY KEY (id);


--
-- TOC entry 6246 (class 2606 OID 280741)
-- Name: ods_scheduler_lock pk_ods_scheduler_lock; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_scheduler_lock
    ADD CONSTRAINT pk_ods_scheduler_lock PRIMARY KEY (lock_id);


--
-- TOC entry 5898 (class 2606 OID 218885)
-- Name: ods_service_route_map pk_ods_service_route_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_service_route_map
    ADD CONSTRAINT pk_ods_service_route_map PRIMARY KEY (id);


--
-- TOC entry 5906 (class 2606 OID 218889)
-- Name: ods_transformer_config pk_ods_transformer_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_transformer_config
    ADD CONSTRAINT pk_ods_transformer_config PRIMARY KEY (ods_transformer_config_id);


--
-- TOC entry 5928 (class 2606 OID 218893)
-- Name: ods_workflow_fallout pk_ods_workflow_fallout; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_workflow_fallout
    ADD CONSTRAINT pk_ods_workflow_fallout PRIMARY KEY (id);


--
-- TOC entry 5934 (class 2606 OID 218895)
-- Name: ods_workflow_fallout_config pk_ods_workflow_fallout_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_workflow_fallout_config
    ADD CONSTRAINT pk_ods_workflow_fallout_config PRIMARY KEY (id);


--
-- TOC entry 5941 (class 2606 OID 218899)
-- Name: onenet_common_parameter pk_onenet_common_parameter; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.onenet_common_parameter
    ADD CONSTRAINT pk_onenet_common_parameter PRIMARY KEY (id);


--
-- TOC entry 5943 (class 2606 OID 218901)
-- Name: onenet_holiday pk_onenet_holiday; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.onenet_holiday
    ADD CONSTRAINT pk_onenet_holiday PRIMARY KEY (holiday_id);


--
-- TOC entry 5945 (class 2606 OID 218903)
-- Name: onenet_milestone pk_onenet_milestone; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.onenet_milestone
    ADD CONSTRAINT pk_onenet_milestone PRIMARY KEY (onenet_milestone_id);


--
-- TOC entry 5947 (class 2606 OID 218905)
-- Name: onenet_order_build pk_onenet_order_build; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.onenet_order_build
    ADD CONSTRAINT pk_onenet_order_build PRIMARY KEY (onenet_order_build_id);


--
-- TOC entry 5949 (class 2606 OID 218907)
-- Name: onenet_order_data pk_onenet_order_data; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.onenet_order_data
    ADD CONSTRAINT pk_onenet_order_data PRIMARY KEY (onenet_order_id);


--
-- TOC entry 5951 (class 2606 OID 218909)
-- Name: onenet_transaction pk_onenet_transaction; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.onenet_transaction
    ADD CONSTRAINT pk_onenet_transaction PRIMARY KEY (onenet_trans_id);


--
-- TOC entry 5953 (class 2606 OID 218911)
-- Name: ordchange_msg_config pk_ordchange_msg_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.ordchange_msg_config
    ADD CONSTRAINT pk_ordchange_msg_config PRIMARY KEY (ordchange_msg_config_id);


--
-- TOC entry 5955 (class 2606 OID 218913)
-- Name: project pk_project; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project
    ADD CONSTRAINT pk_project PRIMARY KEY (project_id);


--
-- TOC entry 5961 (class 2606 OID 218917)
-- Name: project_cmd_cache pk_project_cmd_cache; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project_cmd_cache
    ADD CONSTRAINT pk_project_cmd_cache PRIMARY KEY (project_id);


--
-- TOC entry 5963 (class 2606 OID 218919)
-- Name: project_details pk_project_details; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project_details
    ADD CONSTRAINT pk_project_details PRIMARY KEY (project_details_id);


--
-- TOC entry 5966 (class 2606 OID 218921)
-- Name: qrtz_blob_triggers pk_qrtz_blob_triggers; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_blob_triggers
    ADD CONSTRAINT pk_qrtz_blob_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 5968 (class 2606 OID 218923)
-- Name: qrtz_calendars pk_qrtz_calendars; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_calendars
    ADD CONSTRAINT pk_qrtz_calendars PRIMARY KEY (sched_name, calendar_name);


--
-- TOC entry 5970 (class 2606 OID 218925)
-- Name: qrtz_cron_triggers pk_qrtz_cron_triggers; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_cron_triggers
    ADD CONSTRAINT pk_qrtz_cron_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 5972 (class 2606 OID 218927)
-- Name: qrtz_fired_triggers pk_qrtz_fired_triggers; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_fired_triggers
    ADD CONSTRAINT pk_qrtz_fired_triggers PRIMARY KEY (sched_name, entry_id);


--
-- TOC entry 5974 (class 2606 OID 218929)
-- Name: qrtz_job_details pk_qrtz_job_details; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_job_details
    ADD CONSTRAINT pk_qrtz_job_details PRIMARY KEY (sched_name, job_name, job_group);


--
-- TOC entry 5976 (class 2606 OID 218931)
-- Name: qrtz_locks pk_qrtz_locks; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_locks
    ADD CONSTRAINT pk_qrtz_locks PRIMARY KEY (sched_name, lock_name);


--
-- TOC entry 5978 (class 2606 OID 218933)
-- Name: qrtz_paused_trigger_grps pk_qrtz_paused_trigger_grps; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_paused_trigger_grps
    ADD CONSTRAINT pk_qrtz_paused_trigger_grps PRIMARY KEY (sched_name, trigger_group);


--
-- TOC entry 5980 (class 2606 OID 218935)
-- Name: qrtz_scheduler_state pk_qrtz_scheduler_state; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_scheduler_state
    ADD CONSTRAINT pk_qrtz_scheduler_state PRIMARY KEY (sched_name, instance_name);


--
-- TOC entry 5982 (class 2606 OID 218937)
-- Name: qrtz_simple_triggers pk_qrtz_simple_triggers; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_simple_triggers
    ADD CONSTRAINT pk_qrtz_simple_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 5984 (class 2606 OID 218939)
-- Name: qrtz_simprop_triggers pk_qrtz_simprop_triggers; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_simprop_triggers
    ADD CONSTRAINT pk_qrtz_simprop_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 5986 (class 2606 OID 218941)
-- Name: qrtz_triggers pk_qrtz_triggers; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_triggers
    ADD CONSTRAINT pk_qrtz_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- TOC entry 5989 (class 2606 OID 218943)
-- Name: search_cache_event_monitor pk_search_cache_event_monitor; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.search_cache_event_monitor
    ADD CONSTRAINT pk_search_cache_event_monitor PRIMARY KEY (event_id);


--
-- TOC entry 5996 (class 2606 OID 218945)
-- Name: tbl_access_order pk_tbl_access_order; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_access_order
    ADD CONSTRAINT pk_tbl_access_order PRIMARY KEY (order_number, order_version);


--
-- TOC entry 5998 (class 2606 OID 218947)
-- Name: tbl_application pk_tbl_application; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application
    ADD CONSTRAINT pk_tbl_application PRIMARY KEY (app_id);


--
-- TOC entry 6009 (class 2606 OID 218957)
-- Name: tbl_application_config pk_tbl_application_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application_config
    ADD CONSTRAINT pk_tbl_application_config PRIMARY KEY (tbl_otm_osb_config_id);


--
-- TOC entry 6017 (class 2606 OID 218965)
-- Name: tbl_baais_orch_trace_entity pk_tbl_baais_orch_trace_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_baais_orch_trace_entity
    ADD CONSTRAINT pk_tbl_baais_orch_trace_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6013 (class 2606 OID 218961)
-- Name: tbl_baaisn_cem_entity pk_tbl_baaisn_cem_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_baaisn_cem_entity
    ADD CONSTRAINT pk_tbl_baaisn_cem_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6021 (class 2606 OID 218969)
-- Name: tbl_bonita_dynamic_flow pk_tbl_bonita_dynamic_flow; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_bonita_dynamic_flow
    ADD CONSTRAINT pk_tbl_bonita_dynamic_flow PRIMARY KEY (dynamic_flow_id);


--
-- TOC entry 6025 (class 2606 OID 218971)
-- Name: tbl_chronic_circuit pk_tbl_chronic_circuit; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_chronic_circuit
    ADD CONSTRAINT pk_tbl_chronic_circuit PRIMARY KEY (chronic_circuit_id);


--
-- TOC entry 6027 (class 2606 OID 218973)
-- Name: tbl_chronic_site pk_tbl_chronic_site; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_chronic_site
    ADD CONSTRAINT pk_tbl_chronic_site PRIMARY KEY (chronic_site_id);


--
-- TOC entry 6029 (class 2606 OID 218975)
-- Name: tbl_chronic_site_entity pk_tbl_chronic_site_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_chronic_site_entity
    ADD CONSTRAINT pk_tbl_chronic_site_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6033 (class 2606 OID 218979)
-- Name: tbl_circuit_relation pk_tbl_circuit_relation; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_circuit_relation
    ADD CONSTRAINT pk_tbl_circuit_relation PRIMARY KEY (ckt_rel_id);


--
-- TOC entry 6035 (class 2606 OID 218981)
-- Name: tbl_clli_selection pk_tbl_clli_selection; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_clli_selection
    ADD CONSTRAINT pk_tbl_clli_selection PRIMARY KEY (clli_select_id);


--
-- TOC entry 6040 (class 2606 OID 218985)
-- Name: tbl_demo_entity pk_tbl_demo_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_demo_entity
    ADD CONSTRAINT pk_tbl_demo_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6044 (class 2606 OID 218989)
-- Name: tbl_dispatch_job_track pk_tbl_dispatch_job_track; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_dispatch_job_track
    ADD CONSTRAINT pk_tbl_dispatch_job_track PRIMARY KEY (dispatch_job_track_id);


--
-- TOC entry 6047 (class 2606 OID 218991)
-- Name: tbl_ds1_migration_params pk_tbl_ds1_migration_params; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ds1_migration_params
    ADD CONSTRAINT pk_tbl_ds1_migration_params PRIMARY KEY (ds1_migration_params_id);


--
-- TOC entry 6049 (class 2606 OID 218993)
-- Name: tbl_dynamic_flow_map pk_tbl_dynamic_flow_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_dynamic_flow_map
    ADD CONSTRAINT pk_tbl_dynamic_flow_map PRIMARY KEY (dynamic_flow_map_id);


--
-- TOC entry 6052 (class 2606 OID 218995)
-- Name: tbl_ecost_batch_entity pk_tbl_ecost_batch_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ecost_batch_entity
    ADD CONSTRAINT pk_tbl_ecost_batch_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6056 (class 2606 OID 218999)
-- Name: tbl_engineering_issue pk_tbl_engineering_issue; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_engineering_issue
    ADD CONSTRAINT pk_tbl_engineering_issue PRIMARY KEY (tbl_eng_issue_id);


--
-- TOC entry 6059 (class 2606 OID 219001)
-- Name: tbl_escalation_entity pk_tbl_escalation_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_escalation_entity
    ADD CONSTRAINT pk_tbl_escalation_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6063 (class 2606 OID 219005)
-- Name: tbl_escalation_ticket pk_tbl_escalation_ticket; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_escalation_ticket
    ADD CONSTRAINT pk_tbl_escalation_ticket PRIMARY KEY (escalation_ticket_id);


--
-- TOC entry 6230 (class 2606 OID 241661)
-- Name: tbl_event_fallout pk_tbl_event_fallout; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_event_fallout
    ADD CONSTRAINT pk_tbl_event_fallout PRIMARY KEY (event_fallout_id);


--
-- TOC entry 6065 (class 2606 OID 219007)
-- Name: tbl_hack_demo_entity pk_tbl_hack_demo_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_hack_demo_entity
    ADD CONSTRAINT pk_tbl_hack_demo_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6069 (class 2606 OID 219011)
-- Name: tbl_holiday pk_tbl_holiday; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_holiday
    ADD CONSTRAINT pk_tbl_holiday PRIMARY KEY (holiday_id);


--
-- TOC entry 6073 (class 2606 OID 219015)
-- Name: tbl_interval_mapping pk_tbl_interval_mapping; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_interval_mapping
    ADD CONSTRAINT pk_tbl_interval_mapping PRIMARY KEY (minimum_interval_id);


--
-- TOC entry 6077 (class 2606 OID 219019)
-- Name: tbl_jeop_code_metadata pk_tbl_jeop_code_metadata; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_jeop_code_metadata
    ADD CONSTRAINT pk_tbl_jeop_code_metadata PRIMARY KEY (jeop_code_id);


--
-- TOC entry 6079 (class 2606 OID 219021)
-- Name: tbl_lam_interval pk_tbl_lam_interval; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_lam_interval
    ADD CONSTRAINT pk_tbl_lam_interval PRIMARY KEY (lam_interval_id);


--
-- TOC entry 6083 (class 2606 OID 219025)
-- Name: tbl_lci_manifest_docs pk_tbl_lci_manifest_docs; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_lci_manifest_docs
    ADD CONSTRAINT pk_tbl_lci_manifest_docs PRIMARY KEY (document_id);


--
-- TOC entry 6086 (class 2606 OID 219027)
-- Name: tbl_manifest pk_tbl_manifest; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest
    ADD CONSTRAINT pk_tbl_manifest PRIMARY KEY (manifest_id);


--
-- TOC entry 6094 (class 2606 OID 219035)
-- Name: tbl_manifest_docs pk_tbl_manifest_docs; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest_docs
    ADD CONSTRAINT pk_tbl_manifest_docs PRIMARY KEY (document_id);


--
-- TOC entry 6097 (class 2606 OID 219037)
-- Name: tbl_manifest_map pk_tbl_manifest_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest_map
    ADD CONSTRAINT pk_tbl_manifest_map PRIMARY KEY (map_id);


--
-- TOC entry 6104 (class 2606 OID 219043)
-- Name: tbl_message_config pk_tbl_message_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_message_config
    ADD CONSTRAINT pk_tbl_message_config PRIMARY KEY (msg_config_id);


--
-- TOC entry 6108 (class 2606 OID 219047)
-- Name: tbl_nid_audit_entity pk_tbl_nid_audit_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_nid_audit_entity
    ADD CONSTRAINT pk_tbl_nid_audit_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6112 (class 2606 OID 219053)
-- Name: tbl_order_entity pk_tbl_order_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_entity
    ADD CONSTRAINT pk_tbl_order_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6116 (class 2606 OID 219057)
-- Name: tbl_order_jeopardy pk_tbl_order_jeopardy; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_jeopardy
    ADD CONSTRAINT pk_tbl_order_jeopardy PRIMARY KEY (order_jeopardy_id);


--
-- TOC entry 6118 (class 2606 OID 219059)
-- Name: tbl_order_notes_remarks pk_tbl_order_notes_remarks; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_notes_remarks
    ADD CONSTRAINT pk_tbl_order_notes_remarks PRIMARY KEY (info_id);


--
-- TOC entry 6121 (class 2606 OID 219061)
-- Name: tbl_order_request_fallout pk_tbl_order_request_fallout; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_request_fallout
    ADD CONSTRAINT pk_tbl_order_request_fallout PRIMARY KEY (ord_req_fout_id);


--
-- TOC entry 6124 (class 2606 OID 219063)
-- Name: tbl_order_search_index_store pk_tbl_order_search_index_store; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_search_index_store
    ADD CONSTRAINT pk_tbl_order_search_index_store PRIMARY KEY (index_store_id);


--
-- TOC entry 6126 (class 2606 OID 219065)
-- Name: tbl_order_status_metadata pk_tbl_order_status_metadata; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_status_metadata
    ADD CONSTRAINT pk_tbl_order_status_metadata PRIMARY KEY (order_status_id);


--
-- TOC entry 6418 (class 2606 OID 451160)
-- Name: tbl_pg_ordering_messages pk_tbl_pg_ordering_messages; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.tbl_pg_ordering_messages
    ADD CONSTRAINT pk_tbl_pg_ordering_messages PRIMARY KEY (msg_id);


--
-- TOC entry 6128 (class 2606 OID 219069)
-- Name: tbl_pon_entity pk_tbl_pon_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_pon_entity
    ADD CONSTRAINT pk_tbl_pon_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6133 (class 2606 OID 219073)
-- Name: tbl_reschedule_task pk_tbl_reschedule_task; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_reschedule_task
    ADD CONSTRAINT pk_tbl_reschedule_task PRIMARY KEY (reschedule_task_id);


--
-- TOC entry 6136 (class 2606 OID 219075)
-- Name: tbl_rqnorder_entity pk_tbl_rqnorder_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_rqnorder_entity
    ADD CONSTRAINT pk_tbl_rqnorder_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6141 (class 2606 OID 219079)
-- Name: tbl_ruggedization_entity pk_tbl_ruggedization_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ruggedization_entity
    ADD CONSTRAINT pk_tbl_ruggedization_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6145 (class 2606 OID 219083)
-- Name: tbl_rule pk_tbl_rule; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_rule
    ADD CONSTRAINT pk_tbl_rule PRIMARY KEY (rule_id);


--
-- TOC entry 6148 (class 2606 OID 219085)
-- Name: tbl_rule_set pk_tbl_rule_set; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_rule_set
    ADD CONSTRAINT pk_tbl_rule_set PRIMARY KEY (rule_set_id);


--
-- TOC entry 6150 (class 2606 OID 219087)
-- Name: tbl_rule_set_map pk_tbl_rule_set_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_rule_set_map
    ADD CONSTRAINT pk_tbl_rule_set_map PRIMARY KEY (rule_set_map_id);


--
-- TOC entry 6153 (class 2606 OID 219089)
-- Name: tbl_service_route_map_table pk_tbl_service_route_map_table; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_service_route_map_table
    ADD CONSTRAINT pk_tbl_service_route_map_table PRIMARY KEY (id, flow_node_process_name, flow_node_step_name);


--
-- TOC entry 6155 (class 2606 OID 219091)
-- Name: tbl_sla_process_map pk_tbl_sla_process_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_sla_process_map
    ADD CONSTRAINT pk_tbl_sla_process_map PRIMARY KEY (sla_process_map_id);


--
-- TOC entry 6157 (class 2606 OID 219093)
-- Name: tbl_ssporder_entity pk_tbl_ssporder_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ssporder_entity
    ADD CONSTRAINT pk_tbl_ssporder_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6162 (class 2606 OID 219097)
-- Name: tbl_subprocess_mapping pk_tbl_subprocess_mapping; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_subprocess_mapping
    ADD CONSTRAINT pk_tbl_subprocess_mapping PRIMARY KEY (mapping_id);


--
-- TOC entry 6164 (class 2606 OID 219099)
-- Name: tbl_task_sla pk_tbl_task_sla; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_task_sla
    ADD CONSTRAINT pk_tbl_task_sla PRIMARY KEY (task_sla_id);


--
-- TOC entry 6171 (class 2606 OID 219103)
-- Name: tbl_vps_order pk_tbl_vps_order; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order
    ADD CONSTRAINT pk_tbl_vps_order PRIMARY KEY (order_id);


--
-- TOC entry 6176 (class 2606 OID 219107)
-- Name: tbl_vps_order_bak pk_tbl_vps_order_bak; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_bak
    ADD CONSTRAINT pk_tbl_vps_order_bak PRIMARY KEY (vps_order_id);


--
-- TOC entry 6180 (class 2606 OID 219111)
-- Name: tbl_vps_order_circuit pk_tbl_vps_order_circuit; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_circuit
    ADD CONSTRAINT pk_tbl_vps_order_circuit PRIMARY KEY (order_circuit_id);


--
-- TOC entry 6185 (class 2606 OID 219115)
-- Name: tbl_vps_order_entity pk_tbl_vps_order_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_entity
    ADD CONSTRAINT pk_tbl_vps_order_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6189 (class 2606 OID 219119)
-- Name: tbl_vps_order_new pk_tbl_vps_order_new; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_new
    ADD CONSTRAINT pk_tbl_vps_order_new PRIMARY KEY (order_id);


--
-- TOC entry 6193 (class 2606 OID 219123)
-- Name: tbl_vps_order_version pk_tbl_vps_order_version; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_version
    ADD CONSTRAINT pk_tbl_vps_order_version PRIMARY KEY (order_version_id);


--
-- TOC entry 6196 (class 2606 OID 219125)
-- Name: tbl_vps_sr_entity pk_tbl_vps_sr_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_sr_entity
    ADD CONSTRAINT pk_tbl_vps_sr_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6199 (class 2606 OID 219127)
-- Name: tbl_vrd_order_entity pk_tbl_vrd_order_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vrd_order_entity
    ADD CONSTRAINT pk_tbl_vrd_order_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6203 (class 2606 OID 219131)
-- Name: tbl_vzt_vzw_sharedpanel_entity pk_tbl_vzt_vzw_sharedpanel_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vzt_vzw_sharedpanel_entity
    ADD CONSTRAINT pk_tbl_vzt_vzw_sharedpanel_entity PRIMARY KEY (entity_id);


--
-- TOC entry 6205 (class 2606 OID 219133)
-- Name: tbl_wf_decision_params pk_tbl_wf_decision_params; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_wf_decision_params
    ADD CONSTRAINT pk_tbl_wf_decision_params PRIMARY KEY (root_case_id, wf_param_name);


--
-- TOC entry 6211 (class 2606 OID 219137)
-- Name: tbl_workflow_map pk_tbl_workflow_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_workflow_map
    ADD CONSTRAINT pk_tbl_workflow_map PRIMARY KEY (workflow_map_id);


--
-- TOC entry 6216 (class 2606 OID 219141)
-- Name: tbl_workflow_map_ext pk_tbl_workflow_map_ext; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_workflow_map_ext
    ADD CONSTRAINT pk_tbl_workflow_map_ext PRIMARY KEY (workflow_map_ext_id);


--
-- TOC entry 6219 (class 2606 OID 219143)
-- Name: tbl_workflow_template pk_tbl_workflow_template; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_workflow_template
    ADD CONSTRAINT pk_tbl_workflow_template PRIMARY KEY (workflow_template_id);


--
-- TOC entry 6224 (class 2606 OID 219147)
-- Name: users pk_users; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- TOC entry 6335 (class 2606 OID 356969)
-- Name: pn_state pkpn_state; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.pn_state
    ADD CONSTRAINT pkpn_state PRIMARY KEY (state_id);


--
-- TOC entry 6106 (class 2606 OID 219045)
-- Name: tbl_message_config product_tbl_message_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_message_config
    ADD CONSTRAINT product_tbl_message_config UNIQUE (product, lob, request_type);


--
-- TOC entry 5957 (class 2606 OID 218915)
-- Name: project project_number_project; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project
    ADD CONSTRAINT project_number_project UNIQUE (project_number);


--
-- TOC entry 5819 (class 2606 OID 218825)
-- Name: dir_project_type project_type_dir_project_type; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_project_type
    ADD CONSTRAINT project_type_dir_project_type UNIQUE (project_type);


--
-- TOC entry 6228 (class 2606 OID 234128)
-- Name: rajtest rajtest_pk; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.rajtest
    ADD CONSTRAINT rajtest_pk PRIMARY KEY (id);


--
-- TOC entry 6460 (class 2606 OID 1392785)
-- Name: reassignment reassignment_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.reassignment
    ADD CONSTRAINT reassignment_pkey PRIMARY KEY (id);


--
-- TOC entry 5887 (class 2606 OID 218879)
-- Name: ods_request_transaction_id_map reqtransidmap_procnamestepname_uidx_ods_request_transaction_id_; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_request_transaction_id_map
    ADD CONSTRAINT reqtransidmap_procnamestepname_uidx_ods_request_transaction_id_ UNIQUE (flow_node_process_name, flow_node_step_name);


--
-- TOC entry 6425 (class 2606 OID 498127)
-- Name: saved_columns saved_columns_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.saved_columns
    ADD CONSTRAINT saved_columns_pkey PRIMARY KEY (saved_column_id);


--
-- TOC entry 6421 (class 2606 OID 497952)
-- Name: spog_user_settings spog_user_settings_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.spog_user_settings
    ADD CONSTRAINT spog_user_settings_pkey PRIMARY KEY (vz_id, ui_object_name);


--
-- TOC entry 6453 (class 2606 OID 602318)
-- Name: sr_address_info sr_address_info_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.sr_address_info
    ADD CONSTRAINT sr_address_info_pkey PRIMARY KEY (sr_address_id);


--
-- TOC entry 6451 (class 2606 OID 606463)
-- Name: sr_ckl_sales sr_ckl_sales_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.sr_ckl_sales
    ADD CONSTRAINT sr_ckl_sales_pkey PRIMARY KEY (ckl_type, sr_id);


--
-- TOC entry 5815 (class 2606 OID 218821)
-- Name: dir_project_status status_dir_project_status; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.dir_project_status
    ADD CONSTRAINT status_dir_project_status UNIQUE (status);


--
-- TOC entry 5902 (class 2606 OID 218887)
-- Name: ods_service_route_map svcroutemap_appkeyprocnamestepnameregion_uidx_ods_service_route; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_service_route_map
    ADD CONSTRAINT svcroutemap_appkeyprocnamestepnameregion_uidx_ods_service_route UNIQUE (app_key, flow_node_process_name, flow_node_step_name, region);


--
-- TOC entry 6114 (class 2606 OID 219055)
-- Name: tbl_order_entity tbl_access_order_entity_ix3_tbl_order_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_order_entity
    ADD CONSTRAINT tbl_access_order_entity_ix3_tbl_order_entity UNIQUE (region, product_type, order_number, order_version, supp_type);


--
-- TOC entry 6011 (class 2606 OID 218959)
-- Name: tbl_application_config tbl_application_config_uk_1_tbl_application_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application_config
    ADD CONSTRAINT tbl_application_config_uk_1_tbl_application_config UNIQUE (category, service_name, param_name);


--
-- TOC entry 6001 (class 2606 OID 218951)
-- Name: tbl_application tbl_application_ix2_tbl_application; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application
    ADD CONSTRAINT tbl_application_ix2_tbl_application UNIQUE (app_key);


--
-- TOC entry 6003 (class 2606 OID 218953)
-- Name: tbl_application tbl_application_ix3_tbl_application; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application
    ADD CONSTRAINT tbl_application_ix3_tbl_application UNIQUE (app_entity_tbl_name);


--
-- TOC entry 6005 (class 2606 OID 218949)
-- Name: tbl_application tbl_application_ix_tbl_application; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_application
    ADD CONSTRAINT tbl_application_ix_tbl_application UNIQUE (app_id);


--
-- TOC entry 6019 (class 2606 OID 218967)
-- Name: tbl_baais_orch_trace_entity tbl_baais_orch_trace_entity_ix3_tbl_baais_orch_trace_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_baais_orch_trace_entity
    ADD CONSTRAINT tbl_baais_orch_trace_entity_ix3_tbl_baais_orch_trace_entity UNIQUE (hash_value, trace_source);


--
-- TOC entry 6015 (class 2606 OID 218963)
-- Name: tbl_baaisn_cem_entity tbl_baaisn_cem_entity_ix3_tbl_baaisn_cem_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_baaisn_cem_entity
    ADD CONSTRAINT tbl_baaisn_cem_entity_ix3_tbl_baaisn_cem_entity UNIQUE (order_id);


--
-- TOC entry 6031 (class 2606 OID 218977)
-- Name: tbl_chronic_site_entity tbl_chronic_site_entity_ix3_tbl_chronic_site_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_chronic_site_entity
    ADD CONSTRAINT tbl_chronic_site_entity_ix3_tbl_chronic_site_entity UNIQUE (chronic_site_id, state, product_type);


--
-- TOC entry 6038 (class 2606 OID 218983)
-- Name: tbl_clli_selection tbl_clli_selection_uk1_tbl_clli_selection; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_clli_selection
    ADD CONSTRAINT tbl_clli_selection_uk1_tbl_clli_selection UNIQUE (request_source, project_id, location_ind);


--
-- TOC entry 6042 (class 2606 OID 218987)
-- Name: tbl_demo_entity tbl_demo_entity_ix3_tbl_demo_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_demo_entity
    ADD CONSTRAINT tbl_demo_entity_ix3_tbl_demo_entity UNIQUE (eda_1, eda_2);


--
-- TOC entry 6054 (class 2606 OID 218997)
-- Name: tbl_ecost_batch_entity tbl_ecost_batch_entity_ix3_tbl_ecost_batch_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ecost_batch_entity
    ADD CONSTRAINT tbl_ecost_batch_entity_ix3_tbl_ecost_batch_entity UNIQUE (job_id, job_type, job_owner);


--
-- TOC entry 6061 (class 2606 OID 219003)
-- Name: tbl_escalation_entity tbl_escalation_entity_ix3_tbl_escalation_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_escalation_entity
    ADD CONSTRAINT tbl_escalation_entity_ix3_tbl_escalation_entity UNIQUE (escalation_ticket_id);


--
-- TOC entry 6067 (class 2606 OID 219009)
-- Name: tbl_hack_demo_entity tbl_hack_demo_entity_ix3_tbl_hack_demo_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_hack_demo_entity
    ADD CONSTRAINT tbl_hack_demo_entity_ix3_tbl_hack_demo_entity UNIQUE (order_number, order_source, order_type);


--
-- TOC entry 6071 (class 2606 OID 219013)
-- Name: tbl_holiday tbl_holiday_ix_tbl_holiday; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_holiday
    ADD CONSTRAINT tbl_holiday_ix_tbl_holiday UNIQUE (holiday_id);


--
-- TOC entry 6075 (class 2606 OID 219017)
-- Name: tbl_interval_mapping tbl_interval_mapping_ix_tbl_interval_mapping; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_interval_mapping
    ADD CONSTRAINT tbl_interval_mapping_ix_tbl_interval_mapping UNIQUE (service_category_cd, service_type_cd, source, region, activity, order_type);


--
-- TOC entry 6081 (class 2606 OID 219023)
-- Name: tbl_lam_interval tbl_lam_interval_ix_tbl_lam_interval; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_lam_interval
    ADD CONSTRAINT tbl_lam_interval_ix_tbl_lam_interval UNIQUE (lam_interval_id);


--
-- TOC entry 6088 (class 2606 OID 219029)
-- Name: tbl_manifest tbl_manifest_idx1_tbl_manifest; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest
    ADD CONSTRAINT tbl_manifest_idx1_tbl_manifest UNIQUE (entity_id, active);


--
-- TOC entry 6090 (class 2606 OID 219031)
-- Name: tbl_manifest tbl_manifest_idx2_tbl_manifest; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest
    ADD CONSTRAINT tbl_manifest_idx2_tbl_manifest UNIQUE (entity_id);


--
-- TOC entry 6100 (class 2606 OID 219039)
-- Name: tbl_manifest_map tbl_manifest_map_udx1_tbl_manifest_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest_map
    ADD CONSTRAINT tbl_manifest_map_udx1_tbl_manifest_map UNIQUE (document_id);


--
-- TOC entry 6102 (class 2606 OID 219041)
-- Name: tbl_manifest_map tbl_manifest_map_udx2_tbl_manifest_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest_map
    ADD CONSTRAINT tbl_manifest_map_udx2_tbl_manifest_map UNIQUE (document_id, manifest_id, doc_name);


--
-- TOC entry 6092 (class 2606 OID 219033)
-- Name: tbl_manifest tbl_manifest_ux1_tbl_manifest; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest
    ADD CONSTRAINT tbl_manifest_ux1_tbl_manifest UNIQUE (entity_id);


--
-- TOC entry 6110 (class 2606 OID 219049)
-- Name: tbl_nid_audit_entity tbl_nid_audit_entity_ix3_tbl_nid_audit_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_nid_audit_entity
    ADD CONSTRAINT tbl_nid_audit_entity_ix3_tbl_nid_audit_entity UNIQUE (uni_circuit_id, nid_clli, audit_create_ts);


--
-- TOC entry 6131 (class 2606 OID 219071)
-- Name: tbl_pon_entity tbl_pon_entity_idx1_tbl_pon_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_pon_entity
    ADD CONSTRAINT tbl_pon_entity_idx1_tbl_pon_entity UNIQUE (unique_id);


--
-- TOC entry 6139 (class 2606 OID 219077)
-- Name: tbl_rqnorder_entity tbl_rqnorder_entity_idx1_tbl_rqnorder_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_rqnorder_entity
    ADD CONSTRAINT tbl_rqnorder_entity_idx1_tbl_rqnorder_entity UNIQUE (sr_number);


--
-- TOC entry 6143 (class 2606 OID 219081)
-- Name: tbl_ruggedization_entity tbl_ruggedization_entity_ix3_tbl_ruggedization_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ruggedization_entity
    ADD CONSTRAINT tbl_ruggedization_entity_ix3_tbl_ruggedization_entity UNIQUE (file_name, job_id);


--
-- TOC entry 6160 (class 2606 OID 219095)
-- Name: tbl_ssporder_entity tbl_ssporder_entity_idx1_tbl_ssporder_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ssporder_entity
    ADD CONSTRAINT tbl_ssporder_entity_idx1_tbl_ssporder_entity UNIQUE (order_number, version);


--
-- TOC entry 6167 (class 2606 OID 397908)
-- Name: tbl_task_sla tbl_task_sla_case_id_activity_id_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_task_sla
    ADD CONSTRAINT tbl_task_sla_case_id_activity_id_key UNIQUE (case_id, activity_id);


--
-- TOC entry 6169 (class 2606 OID 219101)
-- Name: tbl_task_sla tbl_task_sla_uk_1_tbl_task_sla; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_task_sla
    ADD CONSTRAINT tbl_task_sla_uk_1_tbl_task_sla UNIQUE (activity_id, status);


--
-- TOC entry 6183 (class 2606 OID 219113)
-- Name: tbl_vps_order_circuit tbl_vps_order_circuit_uk1_tbl_vps_order_circuit; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_circuit
    ADD CONSTRAINT tbl_vps_order_circuit_uk1_tbl_vps_order_circuit UNIQUE (order_id, circuit_id);


--
-- TOC entry 6187 (class 2606 OID 219117)
-- Name: tbl_vps_order_entity tbl_vps_order_entity_ix3_tbl_vps_order_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_entity
    ADD CONSTRAINT tbl_vps_order_entity_ix3_tbl_vps_order_entity UNIQUE (order_number, order_version, circuit_id, region, prov_version);


--
-- TOC entry 6178 (class 2606 OID 219109)
-- Name: tbl_vps_order_bak tbl_vps_order_ix4_tbl_vps_order_bak; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_bak
    ADD CONSTRAINT tbl_vps_order_ix4_tbl_vps_order_bak UNIQUE (order_number, circuit_id, region, prov_version);


--
-- TOC entry 6191 (class 2606 OID 219121)
-- Name: tbl_vps_order_new tbl_vps_order_new_uk1_tbl_vps_order_new; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_new
    ADD CONSTRAINT tbl_vps_order_new_uk1_tbl_vps_order_new UNIQUE (order_number, region);


--
-- TOC entry 6174 (class 2606 OID 219105)
-- Name: tbl_vps_order tbl_vps_order_uk1_tbl_vps_order; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order
    ADD CONSTRAINT tbl_vps_order_uk1_tbl_vps_order UNIQUE (order_number, region);


--
-- TOC entry 6201 (class 2606 OID 219129)
-- Name: tbl_vrd_order_entity tbl_vrd_order_entity_uk1_tbl_vrd_order_entity; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vrd_order_entity
    ADD CONSTRAINT tbl_vrd_order_entity_uk1_tbl_vrd_order_entity UNIQUE (order_number, order_version, document_level);


--
-- TOC entry 6214 (class 2606 OID 219139)
-- Name: tbl_workflow_map tbl_workflow_map_uk1_tbl_workflow_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_workflow_map
    ADD CONSTRAINT tbl_workflow_map_uk1_tbl_workflow_map UNIQUE (lob, order_source, product, order_type);


--
-- TOC entry 6222 (class 2606 OID 219145)
-- Name: tbl_workflow_template tbl_workflow_template_uk1_tbl_workflow_template; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_workflow_template
    ADD CONSTRAINT tbl_workflow_template_uk1_tbl_workflow_template UNIQUE (case_name, process_name);


--
-- TOC entry 6478 (class 2606 OID 5821421)
-- Name: test_table_orders test_table_orders_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: postgres
--

ALTER TABLE ONLY ng_orchestration.test_table_orders
    ADD CONSTRAINT test_table_orders_pkey PRIMARY KEY (order_no);


--
-- TOC entry 6476 (class 2606 OID 5764091)
-- Name: test_table test_table_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: postgres
--

ALTER TABLE ONLY ng_orchestration.test_table
    ADD CONSTRAINT test_table_pkey PRIMARY KEY (cust_id);


--
-- TOC entry 6370 (class 2606 OID 367687)
-- Name: testtable testtable_pkey; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.testtable
    ADD CONSTRAINT testtable_pkey PRIMARY KEY (id);


--
-- TOC entry 5909 (class 2606 OID 218891)
-- Name: ods_transformer_config transformercfg_key_uidx_ods_transformer_config; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_transformer_config
    ADD CONSTRAINT transformercfg_key_uidx_ods_transformer_config UNIQUE (transformer_key);


--
-- TOC entry 6352 (class 2606 OID 357112)
-- Name: address_conversion unique_address_conversion; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.address_conversion
    ADD CONSTRAINT unique_address_conversion UNIQUE (street_suffix);


--
-- TOC entry 6282 (class 2606 OID 354633)
-- Name: jeopardy_admin_docs unique_app_key; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.jeopardy_admin_docs
    ADD CONSTRAINT unique_app_key UNIQUE (app_key);


--
-- TOC entry 6324 (class 2606 OID 356905)
-- Name: config_parameters unique_config_name; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.config_parameters
    ADD CONSTRAINT unique_config_name UNIQUE (config_name);


--
-- TOC entry 6340 (class 2606 OID 357029)
-- Name: facility_check_rules unique_facility_check_rules; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.facility_check_rules
    ADD CONSTRAINT unique_facility_check_rules UNIQUE (fac_check_rule_id);


--
-- TOC entry 6364 (class 2606 OID 357298)
-- Name: holiday_admin unique_holiday_admin; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.holiday_admin
    ADD CONSTRAINT unique_holiday_admin UNIQUE (hd_admin_id);


--
-- TOC entry 6311 (class 2606 OID 356861)
-- Name: holiday unique_holiday_id; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.holiday
    ADD CONSTRAINT unique_holiday_id UNIQUE (holiday_id);


--
-- TOC entry 6357 (class 2606 OID 357139)
-- Name: region unique_region; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.region
    ADD CONSTRAINT unique_region UNIQUE (region_id);


--
-- TOC entry 6345 (class 2606 OID 357085)
-- Name: state unique_state; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state
    ADD CONSTRAINT unique_state UNIQUE (state_id);


--
-- TOC entry 6337 (class 2606 OID 356972)
-- Name: pn_state unique_statecd; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.pn_state
    ADD CONSTRAINT unique_statecd UNIQUE (state_code);


--
-- TOC entry 6208 (class 2606 OID 219135)
-- Name: tbl_wf_decision_params wf_param_caseidparamname_uidx_tbl_wf_decision_params; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_wf_decision_params
    ADD CONSTRAINT wf_param_caseidparamname_uidx_tbl_wf_decision_params UNIQUE (root_case_id, wf_param_name);


--
-- TOC entry 5937 (class 2606 OID 218897)
-- Name: ods_workflow_fallout_config wffalloutcfg_pname_sname_errcode_uidx_ods_workflow_fallout_conf; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_workflow_fallout_config
    ADD CONSTRAINT wffalloutcfg_pname_sname_errcode_uidx_ods_workflow_fallout_conf UNIQUE (workflow_process_name, workflow_stepname, workflow_fallout_error_code);


--
-- TOC entry 6313 (class 2606 OID 356863)
-- Name: holiday xak1holiday; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.holiday
    ADD CONSTRAINT xak1holiday UNIQUE (plan_id, begin_time, end_time);


--
-- TOC entry 6368 (class 2606 OID 367558)
-- Name: std_interval xak1std_interval; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.std_interval
    ADD CONSTRAINT xak1std_interval UNIQUE (std_interval_days, gpon, expedite_ind);


--
-- TOC entry 6354 (class 2606 OID 357109)
-- Name: address_conversion xpkaddress_conversion; Type: CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.address_conversion
    ADD CONSTRAINT xpkaddress_conversion PRIMARY KEY (street_suffix);


--
-- TOC entry 6293 (class 2606 OID 354871)
-- Name: cbscne_laser xpkcbscne_laser; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.cbscne_laser
    ADD CONSTRAINT xpkcbscne_laser PRIMARY KEY (cbscne_laser_id);


--
-- TOC entry 6326 (class 2606 OID 356902)
-- Name: config_parameters xpkconfig_parameters; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.config_parameters
    ADD CONSTRAINT xpkconfig_parameters PRIMARY KEY (config_name);


--
-- TOC entry 6429 (class 2606 OID 538701)
-- Name: customer_request xpkcustomer_request; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.customer_request
    ADD CONSTRAINT xpkcustomer_request PRIMARY KEY (cr_id);


--
-- TOC entry 6342 (class 2606 OID 357026)
-- Name: facility_check_rules xpkfacility_check_rules; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.facility_check_rules
    ADD CONSTRAINT xpkfacility_check_rules PRIMARY KEY (fac_check_rule_id);


--
-- TOC entry 6315 (class 2606 OID 356858)
-- Name: holiday xpkholiday; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.holiday
    ADD CONSTRAINT xpkholiday PRIMARY KEY (holiday_id);


--
-- TOC entry 6366 (class 2606 OID 357295)
-- Name: holiday_admin xpkholiday_admin; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.holiday_admin
    ADD CONSTRAINT xpkholiday_admin PRIMARY KEY (hd_admin_id);


--
-- TOC entry 6439 (class 2606 OID 1415159)
-- Name: ind_npa_nxx xpkind_npa_nxx; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ind_npa_nxx
    ADD CONSTRAINT xpkind_npa_nxx PRIMARY KEY (ind_npa_nxx_id);


--
-- TOC entry 6437 (class 2606 OID 1415157)
-- Name: ind_switch xpkind_switch; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ind_switch
    ADD CONSTRAINT xpkind_switch PRIMARY KEY (ind_switch_id);


--
-- TOC entry 6321 (class 2606 OID 356896)
-- Name: micro_service_tracker xpkmicro_service_tracker; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.micro_service_tracker
    ADD CONSTRAINT xpkmicro_service_tracker PRIMARY KEY (micro_service_tracker_id);


--
-- TOC entry 6427 (class 2606 OID 529602)
-- Name: nci_code xpknci_id; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.nci_code
    ADD CONSTRAINT xpknci_id PRIMARY KEY (nci_id);


--
-- TOC entry 6449 (class 2606 OID 529541)
-- Name: network_channel xpknetwork_channel; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.network_channel
    ADD CONSTRAINT xpknetwork_channel PRIMARY KEY (network_channel_id);


--
-- TOC entry 6290 (class 2606 OID 354862)
-- Name: nid_automation_ext xpknid_automation_ext; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.nid_automation_ext
    ADD CONSTRAINT xpknid_automation_ext PRIMARY KEY (nid_ext_id);


--
-- TOC entry 6404 (class 2606 OID 412988)
-- Name: ntwk_channel_codes xpkntwk_channel_codes; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ntwk_channel_codes
    ADD CONSTRAINT xpkntwk_channel_codes PRIMARY KEY (nc_id);


--
-- TOC entry 6431 (class 2606 OID 1415188)
-- Name: organization xpkorganization; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.organization
    ADD CONSTRAINT xpkorganization PRIMARY KEY (organization_id);


--
-- TOC entry 6332 (class 2606 OID 356939)
-- Name: pn_region xpkpn_region; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.pn_region
    ADD CONSTRAINT xpkpn_region PRIMARY KEY (region_id);


--
-- TOC entry 6359 (class 2606 OID 357136)
-- Name: region xpkregion; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.region
    ADD CONSTRAINT xpkregion PRIMARY KEY (region_id);


--
-- TOC entry 6376 (class 2606 OID 397896)
-- Name: service_flavor xpkservice_flavor; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.service_flavor
    ADD CONSTRAINT xpkservice_flavor PRIMARY KEY (flavor_id);


--
-- TOC entry 6308 (class 2606 OID 532808)
-- Name: service_request xpkservice_request; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.service_request
    ADD CONSTRAINT xpkservice_request PRIMARY KEY (sr_id);


--
-- TOC entry 6374 (class 2606 OID 529544)
-- Name: service_type xpkservice_type; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.service_type
    ADD CONSTRAINT xpkservice_type PRIMARY KEY (service_type_id);


--
-- TOC entry 6372 (class 2606 OID 397822)
-- Name: service_type_category xpkservice_type_category; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.service_type_category
    ADD CONSTRAINT xpkservice_type_category UNIQUE (svc_type_cat_id);


--
-- TOC entry 6442 (class 2606 OID 529506)
-- Name: sr_milestones xpksr_milestones; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.sr_milestones
    ADD CONSTRAINT xpksr_milestones PRIMARY KEY (sr_id, milestone_id);


--
-- TOC entry 6318 (class 2606 OID 356880)
-- Name: sr_sales xpksr_sales; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.sr_sales
    ADD CONSTRAINT xpksr_sales PRIMARY KEY (sr_id);


--
-- TOC entry 6347 (class 2606 OID 357082)
-- Name: state xpkstate; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state
    ADD CONSTRAINT xpkstate PRIMARY KEY (state_id);


--
-- TOC entry 6349 (class 2606 OID 357090)
-- Name: state_plan_map xpkstate_plan_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state_plan_map
    ADD CONSTRAINT xpkstate_plan_map PRIMARY KEY (plan_id, state_id);


--
-- TOC entry 6361 (class 2606 OID 357147)
-- Name: state_region xpkstate_region; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state_region
    ADD CONSTRAINT xpkstate_region PRIMARY KEY (region_id, state_id);


--
-- TOC entry 6407 (class 2606 OID 412995)
-- Name: switch_cotype xpkswitch_cotype; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.switch_cotype
    ADD CONSTRAINT xpkswitch_cotype PRIMARY KEY (switch_cotype_id);


--
-- TOC entry 6329 (class 2606 OID 356914)
-- Name: web_service_url_map xpkweb_service_url_map; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.web_service_url_map
    ADD CONSTRAINT xpkweb_service_url_map PRIMARY KEY (web_service_url_map_id);


--
-- TOC entry 6411 (class 2606 OID 413089)
-- Name: wire_center xpkwire_center; Type: CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.wire_center
    ADD CONSTRAINT xpkwire_center PRIMARY KEY (wirecenter_id);


--
-- TOC entry 6023 (class 1259 OID 218779)
-- Name: chronic_site_id_idx_tbl_chronic_circuit; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX chronic_site_id_idx_tbl_chronic_circuit ON ng_orchestration.tbl_chronic_circuit USING btree (chronic_site_id);


--
-- TOC entry 5799 (class 1259 OID 218732)
-- Name: enodeb_id_atoll_temp; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX enodeb_id_atoll_temp ON ng_orchestration.atoll_temp USING btree (enodeb_id);


--
-- TOC entry 5910 (class 1259 OID 7456016)
-- Name: fallout_index_ext_task_id; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX fallout_index_ext_task_id ON ng_orchestration.ods_workflow_fallout USING btree (external_task_id, status, created_time);


--
-- TOC entry 5911 (class 1259 OID 7456013)
-- Name: fallout_index_task_id; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX fallout_index_task_id ON ng_orchestration.ods_workflow_fallout USING btree (wf_task_id, source, status, created_time);


--
-- TOC entry 5912 (class 1259 OID 7456015)
-- Name: fallout_index_title; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX fallout_index_title ON ng_orchestration.ods_workflow_fallout USING btree (title, title_version, workflow_step_name, external_task_id, status, created_time);


--
-- TOC entry 5913 (class 1259 OID 7456014)
-- Name: fallout_index_title_diff_order; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX fallout_index_title_diff_order ON ng_orchestration.ods_workflow_fallout USING btree (title, title_version, workflow_step_name, status, external_task_id, created_time);


--
-- TOC entry 6264 (class 1259 OID 342211)
-- Name: idx1_lci_admin_docs_document; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx1_lci_admin_docs_document ON ng_orchestration.lci_admin_docs USING gin (document);


--
-- TOC entry 6350 (class 1259 OID 357110)
-- Name: idx_address_conversion; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_address_conversion ON ng_orchestration.address_conversion USING btree (street_suffix);


--
-- TOC entry 6291 (class 1259 OID 354873)
-- Name: idx_cbscne_laser_id_cbscne_laser; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_cbscne_laser_id_cbscne_laser ON ng_orchestration.cbscne_laser USING btree (cbscne_laser_id);


--
-- TOC entry 6322 (class 1259 OID 356903)
-- Name: idx_config_name_config_parameters; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_config_name_config_parameters ON ng_orchestration.config_parameters USING btree (config_name);


--
-- TOC entry 5914 (class 1259 OID 7456012)
-- Name: idx_expiry_time; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_expiry_time ON ng_orchestration.ods_workflow_fallout USING btree (expiry_time);


--
-- TOC entry 6338 (class 1259 OID 357027)
-- Name: idx_facility_check_rules; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_facility_check_rules ON ng_orchestration.facility_check_rules USING btree (fac_check_rule_id);


--
-- TOC entry 5891 (class 1259 OID 218754)
-- Name: idx_flow_node_process_name_ods_service_route_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_flow_node_process_name_ods_service_route_map ON ng_orchestration.ods_service_route_map USING btree (flow_node_process_name);


--
-- TOC entry 5892 (class 1259 OID 218755)
-- Name: idx_flow_node_step_name_ods_service_route_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_flow_node_step_name_ods_service_route_map ON ng_orchestration.ods_service_route_map USING btree (flow_node_step_name);


--
-- TOC entry 6362 (class 1259 OID 357296)
-- Name: idx_holiday_admin; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_holiday_admin ON ng_orchestration.holiday_admin USING btree (hd_admin_id);


--
-- TOC entry 6309 (class 1259 OID 356859)
-- Name: idx_holiday_id_holiday; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_holiday_id_holiday ON ng_orchestration.holiday USING btree (holiday_id);


--
-- TOC entry 6253 (class 1259 OID 293711)
-- Name: idx_jeop_code_jeopardy_transaction; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_jeop_code_jeopardy_transaction ON ng_orchestration.jeopardy_transaction USING btree (jeop_code);


--
-- TOC entry 6271 (class 1259 OID 351657)
-- Name: idx_jeopardy_admin_docs_jeop_code; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_jeopardy_admin_docs_jeop_code ON ng_orchestration.oldjeopardy_admin_docs USING gin (jeopcodes);


--
-- TOC entry 6267 (class 1259 OID 342135)
-- Name: idx_lci_admin_docs_testlarge_document_jeopcodes; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_lci_admin_docs_testlarge_document_jeopcodes ON ng_orchestration.lci_admin_docs_testlarge USING gin ((((document -> 'ZZZDE-RQN'::text) -> 'jeopCodes'::text)));


--
-- TOC entry 6268 (class 1259 OID 342134)
-- Name: idx_lci_admin_docs_testlarges_document; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_lci_admin_docs_testlarges_document ON ng_orchestration.lci_admin_docs_testlarge USING gin (document);


--
-- TOC entry 6244 (class 1259 OID 280742)
-- Name: idx_lock_key_ods_scheduler_lock; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_lock_key_ods_scheduler_lock ON ng_orchestration.ods_scheduler_lock USING btree (lock_key);


--
-- TOC entry 6319 (class 1259 OID 356897)
-- Name: idx_micro_service_tracker_id_micro_service_tracker; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_micro_service_tracker_id_micro_service_tracker ON ng_orchestration.micro_service_tracker USING btree (micro_service_tracker_id);


--
-- TOC entry 6288 (class 1259 OID 354863)
-- Name: idx_nid_ext_id_nid_automation_ext; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_nid_ext_id_nid_automation_ext ON ng_orchestration.nid_automation_ext USING btree (nid_ext_id);


--
-- TOC entry 5851 (class 1259 OID 5201592)
-- Name: idx_ods_interface_request_taskid; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_request_taskid ON ng_orchestration.ods_interface_request USING btree (task_id);


--
-- TOC entry 5852 (class 1259 OID 5201591)
-- Name: idx_ods_interface_request_taskid_and_id; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_request_taskid_and_id ON ng_orchestration.ods_interface_request USING btree (task_id, id);


--
-- TOC entry 5853 (class 1259 OID 7802271)
-- Name: idx_ods_interface_request_taskid_source; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_request_taskid_source ON ng_orchestration.ods_interface_request USING btree (task_id, source);


--
-- TOC entry 5854 (class 1259 OID 7455979)
-- Name: idx_ods_interface_request_taskid_status; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_request_taskid_status ON ng_orchestration.ods_interface_request USING btree (task_id, status);


--
-- TOC entry 5855 (class 1259 OID 7455980)
-- Name: idx_ods_interface_request_taskid_status_and_id; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_request_taskid_status_and_id ON ng_orchestration.ods_interface_request USING btree (task_id, status, id);


--
-- TOC entry 5856 (class 1259 OID 7455978)
-- Name: idx_ods_interface_request_txnid_status; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_request_txnid_status ON ng_orchestration.ods_interface_request USING btree (transaction_id, status);


--
-- TOC entry 5857 (class 1259 OID 7456046)
-- Name: idx_ods_interface_txnid_reqtime; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_ods_interface_txnid_reqtime ON ng_orchestration.ods_interface_request USING btree (transaction_id, request_time);


--
-- TOC entry 5870 (class 1259 OID 669717)
-- Name: idx_ods_milestone_transaction_by_id; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_milestone_transaction_by_id ON ng_orchestration.ods_milestone_transaction USING btree (ods_milestone_transaction_id);


--
-- TOC entry 5871 (class 1259 OID 7455982)
-- Name: idx_ods_mlestne_txn_rootcaseid_process_step_name_configid_combi; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_mlestne_txn_rootcaseid_process_step_name_configid_combi ON ng_orchestration.ods_milestone_transaction USING btree (root_case_id, process_name, step_name, ods_milestone_config_id);


--
-- TOC entry 6247 (class 1259 OID 293201)
-- Name: idx_ods_notification_config_id_ods_notification_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_notification_config_id_ods_notification_config ON ng_orchestration.ods_notification_config USING btree (ods_notification_config_id);


--
-- TOC entry 6250 (class 1259 OID 293214)
-- Name: idx_ods_notification_transaction_id_ods_notification_transactio; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_notification_transaction_id_ods_notification_transactio ON ng_orchestration.ods_notification_transaction USING btree (ods_notification_transaction_id);


--
-- TOC entry 5915 (class 1259 OID 7455977)
-- Name: idx_ods_workflow_fallout_cid_error_code; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_cid_error_code ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_fallout_error_code);


--
-- TOC entry 5916 (class 1259 OID 7455972)
-- Name: idx_ods_workflow_fallout_cid_pname_sname_errcd_sts; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_cid_pname_sname_errcd_sts ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_process_name, workflow_step_name, workflow_fallout_error_code, status);


--
-- TOC entry 5917 (class 1259 OID 7455971)
-- Name: idx_ods_workflow_fallout_cid_sname_errcd_sts; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_cid_sname_errcd_sts ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_step_name, workflow_fallout_error_code, status);


--
-- TOC entry 5918 (class 1259 OID 7455969)
-- Name: idx_ods_workflow_fallout_cid_sname_errcd_sts_pname; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_cid_sname_errcd_sts_pname ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_step_name, workflow_fallout_error_code, status, workflow_process_name);


--
-- TOC entry 5919 (class 1259 OID 7455970)
-- Name: idx_ods_workflow_fallout_cid_sname_sts_pname; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_cid_sname_sts_pname ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_step_name, status, workflow_process_name);


--
-- TOC entry 5920 (class 1259 OID 7456011)
-- Name: idx_ods_workflow_fallout_rcid_sts_exptme; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_rcid_sts_exptme ON ng_orchestration.ods_workflow_fallout USING btree (root_case_id, status, expiry_time);


--
-- TOC entry 5921 (class 1259 OID 7455973)
-- Name: idx_ods_workflow_fallout_sts_cid_sname; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_sts_cid_sname ON ng_orchestration.ods_workflow_fallout USING btree (status, case_id, workflow_step_name);


--
-- TOC entry 5922 (class 1259 OID 7455967)
-- Name: idx_ods_workflow_fallout_sts_ercd_taskid; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_sts_ercd_taskid ON ng_orchestration.ods_workflow_fallout USING btree (status, workflow_fallout_error_code, wf_task_id);


--
-- TOC entry 5923 (class 1259 OID 7455974)
-- Name: idx_ods_workflow_fallout_sts_errcde; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_sts_errcde ON ng_orchestration.ods_workflow_fallout USING btree (status, workflow_fallout_error_code);


--
-- TOC entry 5924 (class 1259 OID 7456010)
-- Name: idx_ods_workflow_fallout_sts_exptme; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_sts_exptme ON ng_orchestration.ods_workflow_fallout USING btree (status, expiry_time);


--
-- TOC entry 5925 (class 1259 OID 7455966)
-- Name: idx_ods_workflow_fallout_sts_taskid; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ods_workflow_fallout_sts_taskid ON ng_orchestration.ods_workflow_fallout USING btree (status, wf_task_id);


--
-- TOC entry 6458 (class 1259 OID 1392924)
-- Name: idx_reassign_esc; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_reassign_esc ON ng_orchestration.reassignment USING btree (escalation_reassignments_id);


--
-- TOC entry 6355 (class 1259 OID 357137)
-- Name: idx_region; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_region ON ng_orchestration.region USING btree (region_id);


--
-- TOC entry 6330 (class 1259 OID 356940)
-- Name: idx_region_id_pn_region; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_region_id_pn_region ON ng_orchestration.pn_region USING btree (region_id);


--
-- TOC entry 6231 (class 1259 OID 5201611)
-- Name: idx_req_log_taskid_rstatus_reqid; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_taskid_rstatus_reqid ON ng_orchestration.ods_request_log USING btree (wf_task_id, response_status, ods_request_log_id);


--
-- TOC entry 6232 (class 1259 OID 5201610)
-- Name: idx_req_log_taskid_source; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_taskid_source ON ng_orchestration.ods_request_log USING btree (wf_task_id, source);


--
-- TOC entry 6233 (class 1259 OID 7455986)
-- Name: idx_req_log_taskstatus_rstatus_exptime; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_taskstatus_rstatus_exptime ON ng_orchestration.ods_request_log USING btree (wf_task_status, response_status, expiry_time);


--
-- TOC entry 6234 (class 1259 OID 7455989)
-- Name: idx_req_log_title_taskname_rstatus_modifiedtime; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_title_taskname_rstatus_modifiedtime ON ng_orchestration.ods_request_log USING btree (title, wf_task_name, response_status, last_modified_time);


--
-- TOC entry 6235 (class 1259 OID 5201609)
-- Name: idx_req_log_title_titleversion_taskname; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_title_titleversion_taskname ON ng_orchestration.ods_request_log USING btree (title, title_version, wf_task_name);


--
-- TOC entry 6236 (class 1259 OID 5201608)
-- Name: idx_req_log_title_tversion; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_title_tversion ON ng_orchestration.ods_request_log USING btree (title, title_version);


--
-- TOC entry 6237 (class 1259 OID 7455988)
-- Name: idx_req_log_title_tversion_exptime; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_title_tversion_exptime ON ng_orchestration.ods_request_log USING btree (title, title_version, wf_task_name, expiry_time);


--
-- TOC entry 6238 (class 1259 OID 7455984)
-- Name: idx_req_log_title_tversion_taskname_createdtime; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_title_tversion_taskname_createdtime ON ng_orchestration.ods_request_log USING btree (title, title_version, wf_task_name, created_time);


--
-- TOC entry 6239 (class 1259 OID 7455987)
-- Name: idx_req_log_tstatus_rstatus_exptime_reqid; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_req_log_tstatus_rstatus_exptime_reqid ON ng_orchestration.ods_request_log USING btree (wf_task_status, response_status, expiry_time, ods_request_log_id);


--
-- TOC entry 5858 (class 1259 OID 7456045)
-- Name: idx_request_time_ods_interface_request; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_request_time_ods_interface_request ON ng_orchestration.ods_interface_request USING btree (request_time);


--
-- TOC entry 6316 (class 1259 OID 356881)
-- Name: idx_sr_sales; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_sr_sales ON ng_orchestration.sr_sales USING btree (sr_id);


--
-- TOC entry 5893 (class 1259 OID 445369)
-- Name: idx_srm_app_key; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_srm_app_key ON ng_orchestration.ods_service_route_map USING btree (app_key);


--
-- TOC entry 5894 (class 1259 OID 445370)
-- Name: idx_srm_combine; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_srm_combine ON ng_orchestration.ods_service_route_map USING btree (app_key, flow_node_process_name, flow_node_step_name);


--
-- TOC entry 5895 (class 1259 OID 445367)
-- Name: idx_srm_process_name; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_srm_process_name ON ng_orchestration.ods_service_route_map USING btree (flow_node_process_name);


--
-- TOC entry 5896 (class 1259 OID 445368)
-- Name: idx_srm_step_name; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_srm_step_name ON ng_orchestration.ods_service_route_map USING btree (flow_node_step_name);


--
-- TOC entry 6343 (class 1259 OID 357083)
-- Name: idx_state; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_state ON ng_orchestration.state USING btree (state_id);


--
-- TOC entry 6333 (class 1259 OID 356970)
-- Name: idx_state_id_pn_state; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_state_id_pn_state ON ng_orchestration.pn_state USING btree (state_id);


--
-- TOC entry 6327 (class 1259 OID 356915)
-- Name: idx_state_id_web_service_url_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_state_id_web_service_url_map ON ng_orchestration.web_service_url_map USING btree (web_service_url_map_id);


--
-- TOC entry 6240 (class 1259 OID 5201614)
-- Name: idx_status_combine; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_status_combine ON ng_orchestration.ods_request_log USING btree (wf_task_status, response_status);


--
-- TOC entry 5859 (class 1259 OID 7455981)
-- Name: idx_status_ods_interface_request; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_status_ods_interface_request ON ng_orchestration.ods_interface_request USING btree (status);


--
-- TOC entry 5860 (class 1259 OID 5201597)
-- Name: idx_transaction_id_ods_interface_request; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX idx_transaction_id_ods_interface_request ON ng_orchestration.ods_interface_request USING btree (transaction_id);


--
-- TOC entry 6241 (class 1259 OID 7455985)
-- Name: idx_ttl_vrs_tskname_wftskstaus_ctime; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_ttl_vrs_tskname_wftskstaus_ctime ON ng_orchestration.ods_request_log USING btree (title, title_version, wf_task_name, wf_task_status, created_time);


--
-- TOC entry 5926 (class 1259 OID 5201582)
-- Name: idx_wf_task_id; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX idx_wf_task_id ON ng_orchestration.ods_workflow_fallout USING btree (wf_task_id);


--
-- TOC entry 6256 (class 1259 OID 293727)
-- Name: jeop_config_param_type_idx_jeop_config_param; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX jeop_config_param_type_idx_jeop_config_param ON ng_orchestration.jeop_config_param USING btree (type);


--
-- TOC entry 6272 (class 1259 OID 351658)
-- Name: jeopardy_admin_docs_arr_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX jeopardy_admin_docs_arr_idx ON ng_orchestration.oldjeopardy_admin_docs USING btree (((jeopcodes -> 'jeopCode'::text)));


--
-- TOC entry 6279 (class 1259 OID 354634)
-- Name: jeopardy_admin_docs_jeopcodes; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX jeopardy_admin_docs_jeopcodes ON ng_orchestration.jeopardy_admin_docs USING gin (jeopcodes);


--
-- TOC entry 6280 (class 1259 OID 354635)
-- Name: jeopardy_admin_docs_jeopcodes_jeopcode; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX jeopardy_admin_docs_jeopcodes_jeopcode ON ng_orchestration.jeopardy_admin_docs USING gin (((jeopcodes -> 'jeopCode'::text)));


--
-- TOC entry 6265 (class 1259 OID 351017)
-- Name: jeopcode_uq; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE UNIQUE INDEX jeopcode_uq ON ng_orchestration.lci_admin_docs USING btree (((((document -> 'ZZZDE-VRD'::text) -> 'jeopCodes'::text) ->> 'jeopCode'::text)));


--
-- TOC entry 6469 (class 1259 OID 3406689)
-- Name: jv_commit_property_commit_fk_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX jv_commit_property_commit_fk_idx ON ng_orchestration.jv_commit_property USING btree (commit_fk);


--
-- TOC entry 6472 (class 1259 OID 3406690)
-- Name: jv_commit_property_property_name_property_value_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX jv_commit_property_property_name_property_value_idx ON ng_orchestration.jv_commit_property USING btree (property_name, property_value);


--
-- TOC entry 6266 (class 1259 OID 351010)
-- Name: lci_admin_docs_jeopcode_arr_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX lci_admin_docs_jeopcode_arr_idx ON ng_orchestration.lci_admin_docs USING btree (((((document -> 'ZZZDE-RQN'::text) -> 'jeopCodes'::text) -> 'jeopCode'::text)));


--
-- TOC entry 6283 (class 1259 OID 363044)
-- Name: lci_document_document_level_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX lci_document_document_level_idx ON ng_orchestration.lci_document_store USING btree (document_level);


--
-- TOC entry 6284 (class 1259 OID 363045)
-- Name: lci_document_document_name_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX lci_document_document_name_idx ON ng_orchestration.lci_document_store USING btree (document_name);


--
-- TOC entry 6285 (class 1259 OID 363042)
-- Name: lci_document_order_number_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX lci_document_order_number_idx ON ng_orchestration.lci_document_store USING btree (order_number);


--
-- TOC entry 6286 (class 1259 OID 363043)
-- Name: lci_document_order_version_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX lci_document_order_version_idx ON ng_orchestration.lci_document_store USING btree (order_version);


--
-- TOC entry 6287 (class 1259 OID 363048)
-- Name: lci_order_document_due_date_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX lci_order_document_due_date_idx ON ng_orchestration.lci_document_store USING btree (((((document -> 'serviceOrder'::text) -> 'serviceOrderHeader'::text) -> 'dueDate'::text)));


--
-- TOC entry 5863 (class 1259 OID 218746)
-- Name: mand_attrs_attrkey_idx_ods_mandatory_attrs; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX mand_attrs_attrkey_idx_ods_mandatory_attrs ON ng_orchestration.ods_mandatory_attrs USING btree (attr_key);


--
-- TOC entry 6377 (class 1259 OID 412142)
-- Name: manifest_app_config_ix1_manifest_app_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX manifest_app_config_ix1_manifest_app_config ON ng_orchestration.manifest_app_config USING btree (app_key);


--
-- TOC entry 6389 (class 1259 OID 412178)
-- Name: manifest_app_config_ix1_manifest_entity; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX manifest_app_config_ix1_manifest_entity ON ng_orchestration.manifest_entity USING btree (entity_hash);


--
-- TOC entry 6382 (class 1259 OID 5312573)
-- Name: manifest_app_trigram_idx; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX manifest_app_trigram_idx ON ng_orchestration.manifest_app_config USING gin (app_key ng_orchestration.gin_trgm_ops);


--
-- TOC entry 6385 (class 1259 OID 412159)
-- Name: manifest_doc_config_ix1_manifest_doc_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX manifest_doc_config_ix1_manifest_doc_config ON ng_orchestration.manifest_doc_config USING btree (app_id);


--
-- TOC entry 6386 (class 1259 OID 412160)
-- Name: manifest_doc_config_ix2_manifest_doc_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX manifest_doc_config_ix2_manifest_doc_config ON ng_orchestration.manifest_doc_config USING btree (doc_name);


--
-- TOC entry 6397 (class 1259 OID 412201)
-- Name: manifest_document_ix1_manifest_document; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX manifest_document_ix1_manifest_document ON ng_orchestration.manifest_document USING btree (entity_id);


--
-- TOC entry 6398 (class 1259 OID 412202)
-- Name: manifest_document_ix2_manifest_document; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX manifest_document_ix2_manifest_document ON ng_orchestration.manifest_document USING btree (doc_name);


--
-- TOC entry 6399 (class 1259 OID 498003)
-- Name: manifest_document_multi_ix; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE UNIQUE INDEX manifest_document_multi_ix ON ng_orchestration.manifest_document USING btree (entity_id, doc_name) WHERE (document_headers IS NULL);


--
-- TOC entry 6392 (class 1259 OID 412179)
-- Name: manifest_entity_ix2_manifest_app_config; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX manifest_entity_ix2_manifest_app_config ON ng_orchestration.manifest_entity USING btree (entity_string);


--
-- TOC entry 5832 (class 1259 OID 218738)
-- Name: milestone_order_ix1_milestone_order; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX milestone_order_ix1_milestone_order ON ng_orchestration.milestone_order USING btree (milestone_template_id, milestone_level);


--
-- TOC entry 5839 (class 1259 OID 218739)
-- Name: milestone_template_ix1_milestone_template; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX milestone_template_ix1_milestone_template ON ng_orchestration.milestone_template USING btree (milestone_template_name, milestone_name, milestone_category);


--
-- TOC entry 5844 (class 1259 OID 218740)
-- Name: milestone_template_map_fk1_milestone_template_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX milestone_template_map_fk1_milestone_template_map ON ng_orchestration.milestone_template_map USING btree (milestone_template_name);


--
-- TOC entry 5845 (class 1259 OID 218741)
-- Name: milestone_template_map_ix1_milestone_template_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX milestone_template_map_ix1_milestone_template_map ON ng_orchestration.milestone_template_map USING btree (product_type, order_type, order_supp_type, milestone_template_name, milestone_level);


--
-- TOC entry 5846 (class 1259 OID 218742)
-- Name: milestone_template_map_ix2_milestone_template_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX milestone_template_map_ix2_milestone_template_map ON ng_orchestration.milestone_template_map USING btree (product_type, order_type, order_supp_type, milestone_template_name, milestone_level);


--
-- TOC entry 6402 (class 1259 OID 412985)
-- Name: ntwk_channel_codes_ind01; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX ntwk_channel_codes_ind01 ON ng_orchestration.ntwk_channel_codes USING btree (upper((nc_code)::text));


--
-- TOC entry 5874 (class 1259 OID 7455983)
-- Name: ods_milestone_transaction_idx_ods_milestone_transaction; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX ods_milestone_transaction_idx_ods_milestone_transaction ON ng_orchestration.ods_milestone_transaction USING btree (root_case_id);


--
-- TOC entry 5877 (class 1259 OID 218748)
-- Name: ods_param_type_idx_ods_param_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX ods_param_type_idx_ods_param_config ON ng_orchestration.ods_param_config USING btree (type);


--
-- TOC entry 5878 (class 1259 OID 218750)
-- Name: param_cfg_key_idx_ods_param_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX param_cfg_key_idx_ods_param_config ON ng_orchestration.ods_param_config USING btree (param_key);


--
-- TOC entry 6257 (class 1259 OID 293728)
-- Name: param_cfg_keytype_idx_jeop_config_param; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX param_cfg_keytype_idx_jeop_config_param ON ng_orchestration.jeop_config_param USING btree (param_key, type);


--
-- TOC entry 5879 (class 1259 OID 218749)
-- Name: param_cfg_keytype_idx_ods_param_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX param_cfg_keytype_idx_ods_param_config ON ng_orchestration.ods_param_config USING btree (param_key, type);


--
-- TOC entry 5880 (class 1259 OID 673660)
-- Name: param_cfg_keytype_name_idx_ods_param_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX param_cfg_keytype_name_idx_ods_param_config ON ng_orchestration.ods_param_config USING btree (param_key, type, name);


--
-- TOC entry 5964 (class 1259 OID 218770)
-- Name: project_id_project_details; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX project_id_project_details ON ng_orchestration.project_details USING btree (project_id);


--
-- TOC entry 5885 (class 1259 OID 218751)
-- Name: reqtransidmap_procnamestepname_idx_ods_request_transaction_id_m; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX reqtransidmap_procnamestepname_idx_ods_request_transaction_id_m ON ng_orchestration.ods_request_transaction_id_map USING btree (flow_node_process_name, flow_node_step_name);


--
-- TOC entry 5890 (class 1259 OID 218753)
-- Name: resptransidmap_roottagname_idx_ods_response_transaction_id_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX resptransidmap_roottagname_idx_ods_response_transaction_id_map ON ng_orchestration.ods_response_transaction_id_map USING btree (root_tag_name);


--
-- TOC entry 5987 (class 1259 OID 218771)
-- Name: sched_name_qrtz_triggers; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX sched_name_qrtz_triggers ON ng_orchestration.qrtz_triggers USING btree (sched_name, job_name, job_group);


--
-- TOC entry 5990 (class 1259 OID 218772)
-- Name: search_cache_event_mntr_idx1_search_cache_event_monitor; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX search_cache_event_mntr_idx1_search_cache_event_monitor ON ng_orchestration.search_cache_event_monitor USING btree (key_name);


--
-- TOC entry 5991 (class 1259 OID 218773)
-- Name: search_cache_event_mntr_idx2_search_cache_event_monitor; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX search_cache_event_mntr_idx2_search_cache_event_monitor ON ng_orchestration.search_cache_event_monitor USING btree (key_value);


--
-- TOC entry 5992 (class 1259 OID 218774)
-- Name: search_cache_event_mntr_idx3_search_cache_event_monitor; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX search_cache_event_mntr_idx3_search_cache_event_monitor ON ng_orchestration.search_cache_event_monitor USING btree (creation_date);


--
-- TOC entry 5993 (class 1259 OID 218775)
-- Name: search_cache_event_mntr_idx4_search_cache_event_monitor; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX search_cache_event_mntr_idx4_search_cache_event_monitor ON ng_orchestration.search_cache_event_monitor USING btree (table_name, key_value, mod_type, status);


--
-- TOC entry 5994 (class 1259 OID 218776)
-- Name: search_cache_event_mntr_idx6_search_cache_event_monitor; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX search_cache_event_mntr_idx6_search_cache_event_monitor ON ng_orchestration.search_cache_event_monitor USING btree (table_name);


--
-- TOC entry 6294 (class 1259 OID 528283)
-- Name: service_request_ind; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX service_request_ind ON ng_orchestration.service_request USING btree (service_order_no);


--
-- TOC entry 6165 (class 1259 OID 218796)
-- Name: sla_process_map_id_tbl_task_sla; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX sla_process_map_id_tbl_task_sla ON ng_orchestration.tbl_task_sla USING btree (sla_process_map_id);


--
-- TOC entry 6295 (class 1259 OID 3805034)
-- Name: srnumind; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX srnumind ON ng_orchestration.service_request USING btree (upper(((btrim((cr_id)::text) || '-'::text) || (sr_seq)::text)));


--
-- TOC entry 6296 (class 1259 OID 3804993)
-- Name: srstatind; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX srstatind ON ng_orchestration.service_request USING btree (sr_status);


--
-- TOC entry 5958 (class 1259 OID 218768)
-- Name: status_project; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX status_project ON ng_orchestration.project USING btree (status);


--
-- TOC entry 5899 (class 1259 OID 218757)
-- Name: svcroutemap_appkeyprocnamestepname_idx_ods_service_route_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX svcroutemap_appkeyprocnamestepname_idx_ods_service_route_map ON ng_orchestration.ods_service_route_map USING btree (app_key, flow_node_process_name, flow_node_step_name);


--
-- TOC entry 5900 (class 1259 OID 218756)
-- Name: svcroutemap_appkeyprocnamestepnameregion_idx_ods_service_route_; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX svcroutemap_appkeyprocnamestepnameregion_idx_ods_service_route_ ON ng_orchestration.ods_service_route_map USING btree (app_key, flow_node_process_name, flow_node_step_name, region);


--
-- TOC entry 5903 (class 1259 OID 218759)
-- Name: svcroutemap_procnamestepname_idx_ods_service_route_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX svcroutemap_procnamestepname_idx_ods_service_route_map ON ng_orchestration.ods_service_route_map USING btree (flow_node_process_name, flow_node_step_name);


--
-- TOC entry 5904 (class 1259 OID 218758)
-- Name: svcroutemap_procnamestepnameregion_idx_ods_service_route_map; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX svcroutemap_procnamestepnameregion_idx_ods_service_route_map ON ng_orchestration.ods_service_route_map USING btree (flow_node_process_name, flow_node_step_name, region);


--
-- TOC entry 5999 (class 1259 OID 218777)
-- Name: tbl_application_ix1_tbl_application; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_application_ix1_tbl_application ON ng_orchestration.tbl_application USING btree (app_name);


--
-- TOC entry 6022 (class 1259 OID 218778)
-- Name: tbl_bonita_dynamic_flow_ix1_tbl_bonita_dynamic_flow; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_bonita_dynamic_flow_ix1_tbl_bonita_dynamic_flow ON ng_orchestration.tbl_bonita_dynamic_flow USING btree (call_activity_id);


--
-- TOC entry 6036 (class 1259 OID 218780)
-- Name: tbl_clli_selection_ix1_tbl_clli_selection; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_clli_selection_ix1_tbl_clli_selection ON ng_orchestration.tbl_clli_selection USING btree (request_source, location_ind, project_id);


--
-- TOC entry 6045 (class 1259 OID 218781)
-- Name: tbl_dispatch_job_track_ix_tbl_dispatch_job_track; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_dispatch_job_track_ix_tbl_dispatch_job_track ON ng_orchestration.tbl_dispatch_job_track USING btree (xnscid, order_id, job_id);


--
-- TOC entry 6050 (class 1259 OID 218782)
-- Name: tbl_dynamic_flow_map_ix1_tbl_dynamic_flow_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_dynamic_flow_map_ix1_tbl_dynamic_flow_map ON ng_orchestration.tbl_dynamic_flow_map USING btree (call_activity_name, line_of_business);


--
-- TOC entry 6057 (class 1259 OID 218783)
-- Name: tbl_engineering_issue_ix1_tbl_engineering_issue; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_engineering_issue_ix1_tbl_engineering_issue ON ng_orchestration.tbl_engineering_issue USING btree (order_source, status);


--
-- TOC entry 6095 (class 1259 OID 218785)
-- Name: tbl_manifest_doc_idx1_tbl_manifest_docs; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_manifest_doc_idx1_tbl_manifest_docs ON ng_orchestration.tbl_manifest_docs USING btree (doc_name);


--
-- TOC entry 6084 (class 1259 OID 218784)
-- Name: tbl_manifest_lci_doc_idx1_tbl_lci_manifest_docs; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_manifest_lci_doc_idx1_tbl_lci_manifest_docs ON ng_orchestration.tbl_lci_manifest_docs USING btree (doc_name);


--
-- TOC entry 6098 (class 1259 OID 218786)
-- Name: tbl_manifest_map_idx1_tbl_manifest_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_manifest_map_idx1_tbl_manifest_map ON ng_orchestration.tbl_manifest_map USING btree (manifest_id);


--
-- TOC entry 6119 (class 1259 OID 218787)
-- Name: tbl_order_notes_remarks_idx1_tbl_order_notes_remarks; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_order_notes_remarks_idx1_tbl_order_notes_remarks ON ng_orchestration.tbl_order_notes_remarks USING btree (order_number, region);


--
-- TOC entry 6122 (class 1259 OID 218788)
-- Name: tbl_order_request_fallout_ix1_tbl_order_request_fallout; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_order_request_fallout_ix1_tbl_order_request_fallout ON ng_orchestration.tbl_order_request_fallout USING btree (request_category, order_number, request_src);


--
-- TOC entry 6419 (class 1259 OID 451161)
-- Name: tbl_pg_asr_ix_tbl_pg_ordering_messages; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX tbl_pg_asr_ix_tbl_pg_ordering_messages ON ng_orchestration.tbl_pg_ordering_messages USING btree (asr_id);


--
-- TOC entry 6129 (class 1259 OID 218790)
-- Name: tbl_pon_entity_fk1_tbl_pon_entity; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_pon_entity_fk1_tbl_pon_entity ON ng_orchestration.tbl_pon_entity USING btree (app_id);


--
-- TOC entry 6134 (class 1259 OID 218791)
-- Name: tbl_reschedule_task_ix1_tbl_reschedule_task; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_reschedule_task_ix1_tbl_reschedule_task ON ng_orchestration.tbl_reschedule_task USING btree (activity_id);


--
-- TOC entry 6137 (class 1259 OID 218792)
-- Name: tbl_rqnorder_entity_fk1_tbl_rqnorder_entity; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_rqnorder_entity_fk1_tbl_rqnorder_entity ON ng_orchestration.tbl_rqnorder_entity USING btree (app_id);


--
-- TOC entry 6146 (class 1259 OID 218793)
-- Name: tbl_rule_ix_tbl_rule; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_rule_ix_tbl_rule ON ng_orchestration.tbl_rule USING btree (rule_set_id, rule_status);


--
-- TOC entry 6151 (class 1259 OID 218794)
-- Name: tbl_rule_set_map_ix_tbl_rule_set_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_rule_set_map_ix_tbl_rule_set_map ON ng_orchestration.tbl_rule_set_map USING btree (lob, product, category, mapping_status);


--
-- TOC entry 6158 (class 1259 OID 218795)
-- Name: tbl_ssporder_entity_fk1_tbl_ssporder_entity; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_ssporder_entity_fk1_tbl_ssporder_entity ON ng_orchestration.tbl_ssporder_entity USING btree (app_id);


--
-- TOC entry 6181 (class 1259 OID 218798)
-- Name: tbl_vps_order_circuit_ix1_tbl_vps_order_circuit; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_vps_order_circuit_ix1_tbl_vps_order_circuit ON ng_orchestration.tbl_vps_order_circuit USING btree (order_id, circuit_id);


--
-- TOC entry 6172 (class 1259 OID 218797)
-- Name: tbl_vps_order_ix1_tbl_vps_order; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_vps_order_ix1_tbl_vps_order ON ng_orchestration.tbl_vps_order USING btree (order_number, region);


--
-- TOC entry 6194 (class 1259 OID 218799)
-- Name: tbl_vps_order_version_ix1_tbl_vps_order_version; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_vps_order_version_ix1_tbl_vps_order_version ON ng_orchestration.tbl_vps_order_version USING btree (order_id, order_circuit_id, order_stage, prov_version);


--
-- TOC entry 6197 (class 1259 OID 218800)
-- Name: tbl_vps_sr_entity_ix1_tbl_vps_sr_entity; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_vps_sr_entity_ix1_tbl_vps_sr_entity ON ng_orchestration.tbl_vps_sr_entity USING btree (sr_version, sr_num, app_id);


--
-- TOC entry 6217 (class 1259 OID 218804)
-- Name: tbl_workflow_map_ext_ix1_tbl_workflow_map_ext; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_workflow_map_ext_ix1_tbl_workflow_map_ext ON ng_orchestration.tbl_workflow_map_ext USING btree (workflow_map_id, case_name, flow_action);


--
-- TOC entry 6212 (class 1259 OID 218803)
-- Name: tbl_workflow_map_ix1_tbl_workflow_map; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_workflow_map_ix1_tbl_workflow_map ON ng_orchestration.tbl_workflow_map USING btree (lob, order_source, product, order_type);


--
-- TOC entry 6220 (class 1259 OID 218805)
-- Name: tbl_workflow_template_ix1_tbl_workflow_template; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX tbl_workflow_template_ix1_tbl_workflow_template ON ng_orchestration.tbl_workflow_template USING btree (case_name, process_name);


--
-- TOC entry 6297 (class 1259 OID 528286)
-- Name: tmp_1; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX tmp_1 ON ng_orchestration.service_request USING btree (date_issued);


--
-- TOC entry 5907 (class 1259 OID 218760)
-- Name: transformercfg_key_idx_ods_transformer_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX transformercfg_key_idx_ods_transformer_config ON ng_orchestration.ods_transformer_config USING btree (transformer_key);


--
-- TOC entry 5959 (class 1259 OID 218769)
-- Name: type_project; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX type_project ON ng_orchestration.project USING btree (type);


--
-- TOC entry 6206 (class 1259 OID 218801)
-- Name: wf_param_caseidparamname_idx_tbl_wf_decision_params; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX wf_param_caseidparamname_idx_tbl_wf_decision_params ON ng_orchestration.tbl_wf_decision_params USING btree (root_case_id, wf_param_name);


--
-- TOC entry 6209 (class 1259 OID 218802)
-- Name: wf_param_root_case_id_idx_tbl_wf_decision_params; Type: INDEX; Schema: ng_orchestration; Owner: dbadmin
--

CREATE INDEX wf_param_root_case_id_idx_tbl_wf_decision_params ON ng_orchestration.tbl_wf_decision_params USING btree (root_case_id);


--
-- TOC entry 5929 (class 1259 OID 7455975)
-- Name: wffallout_cid_pname_sname_errcode_idx_ods_workflow_fallout; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffallout_cid_pname_sname_errcode_idx_ods_workflow_fallout ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_process_name, workflow_step_name, workflow_fallout_error_code);


--
-- TOC entry 5930 (class 1259 OID 7455968)
-- Name: wffallout_cid_pname_sname_errcode_sts_idx_ods_workflow_fallout; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffallout_cid_pname_sname_errcode_sts_idx_ods_workflow_fallout ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_process_name, workflow_step_name, workflow_fallout_error_code, status);


--
-- TOC entry 5931 (class 1259 OID 7455976)
-- Name: wffallout_cid_sname_errcode_idx_ods_workflow_fallout; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffallout_cid_sname_errcode_idx_ods_workflow_fallout ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_step_name, workflow_fallout_error_code);


--
-- TOC entry 5932 (class 1259 OID 5201575)
-- Name: wffallout_cid_sname_idx_ods_workflow_fallout; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffallout_cid_sname_idx_ods_workflow_fallout ON ng_orchestration.ods_workflow_fallout USING btree (case_id, workflow_step_name);


--
-- TOC entry 5935 (class 1259 OID 218765)
-- Name: wffalloutcfg_pname_sname_errcode_idx_ods_workflow_fallout_confi; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffalloutcfg_pname_sname_errcode_idx_ods_workflow_fallout_confi ON ng_orchestration.ods_workflow_fallout_config USING btree (workflow_process_name, workflow_stepname, workflow_fallout_error_code);


--
-- TOC entry 5938 (class 1259 OID 218766)
-- Name: wffalloutcfg_pname_sname_idx_ods_workflow_fallout_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffalloutcfg_pname_sname_idx_ods_workflow_fallout_config ON ng_orchestration.ods_workflow_fallout_config USING btree (workflow_process_name, workflow_stepname);


--
-- TOC entry 5939 (class 1259 OID 218767)
-- Name: wffalloutcfg_sname_errcode_idx_ods_workflow_fallout_config; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX wffalloutcfg_sname_errcode_idx_ods_workflow_fallout_config ON ng_orchestration.ods_workflow_fallout_config USING btree (workflow_stepname, workflow_fallout_error_code);


--
-- TOC entry 6298 (class 1259 OID 528287)
-- Name: xie2service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xie2service_request ON ng_orchestration.service_request USING btree (cw_order_id);


--
-- TOC entry 6443 (class 1259 OID 529533)
-- Name: xif11network_channel; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif11network_channel ON ng_orchestration.network_channel USING btree (service_type_id);


--
-- TOC entry 6299 (class 1259 OID 528288)
-- Name: xif12service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif12service_request ON ng_orchestration.service_request USING btree (corridor_id);


--
-- TOC entry 6444 (class 1259 OID 529535)
-- Name: xif157network_channel; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif157network_channel ON ng_orchestration.network_channel USING btree (line_cd);


--
-- TOC entry 6445 (class 1259 OID 529536)
-- Name: xif159network_channel; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif159network_channel ON ng_orchestration.network_channel USING btree (ckl2nci);


--
-- TOC entry 6446 (class 1259 OID 529537)
-- Name: xif160network_channel; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif160network_channel ON ng_orchestration.network_channel USING btree (network_channel_cd);


--
-- TOC entry 6447 (class 1259 OID 529538)
-- Name: xif161network_channel; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif161network_channel ON ng_orchestration.network_channel USING btree (ckl1nci);


--
-- TOC entry 6409 (class 1259 OID 413086)
-- Name: xif166wire_center; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif166wire_center ON ng_orchestration.wire_center USING btree (state_id);


--
-- TOC entry 6300 (class 1259 OID 528289)
-- Name: xif181service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif181service_request ON ng_orchestration.service_request USING btree (lob_id);


--
-- TOC entry 6301 (class 1259 OID 528290)
-- Name: xif182service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif182service_request ON ng_orchestration.service_request USING btree (sales_lob_id);


--
-- TOC entry 6302 (class 1259 OID 528291)
-- Name: xif183service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif183service_request ON ng_orchestration.service_request USING btree (date_created);


--
-- TOC entry 6303 (class 1259 OID 528292)
-- Name: xif3service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif3service_request ON ng_orchestration.service_request USING btree (cr_id);


--
-- TOC entry 6440 (class 1259 OID 529503)
-- Name: xif53sr_milestones; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif53sr_milestones ON ng_orchestration.sr_milestones USING btree (sr_id);


--
-- TOC entry 6304 (class 1259 OID 528293)
-- Name: xif67service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif67service_request ON ng_orchestration.service_request USING btree (onepass_indicator, opi_status_code);


--
-- TOC entry 6305 (class 1259 OID 3804969)
-- Name: xif68service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif68service_request ON ng_orchestration.service_request USING btree (service_type_id);


--
-- TOC entry 6306 (class 1259 OID 528295)
-- Name: xif69service_request; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE INDEX xif69service_request ON ng_orchestration.service_request USING btree (sr_cancel_id);


--
-- TOC entry 6405 (class 1259 OID 412986)
-- Name: xukntwk_channel_codes; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE UNIQUE INDEX xukntwk_channel_codes ON ng_orchestration.ntwk_channel_codes USING btree (nc_id);


--
-- TOC entry 6408 (class 1259 OID 412996)
-- Name: xukswitch_cotype; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE UNIQUE INDEX xukswitch_cotype ON ng_orchestration.switch_cotype USING btree (switch_cotype_id);


--
-- TOC entry 6412 (class 1259 OID 413087)
-- Name: xukwire_center; Type: INDEX; Schema: ng_orchestration; Owner: prvgwy
--

CREATE UNIQUE INDEX xukwire_center ON ng_orchestration.wire_center USING btree (wirecenter_id);


--
-- TOC entry 6529 (class 2620 OID 219278)
-- Name: project after_project_delete; Type: TRIGGER; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TRIGGER after_project_delete AFTER DELETE ON ng_orchestration.project FOR EACH ROW EXECUTE PROCEDURE ng_orchestration."after_project_delete$project"();


--
-- TOC entry 6530 (class 2620 OID 219279)
-- Name: project after_project_insert; Type: TRIGGER; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TRIGGER after_project_insert AFTER INSERT ON ng_orchestration.project FOR EACH ROW EXECUTE PROCEDURE ng_orchestration."after_project_insert$project"();


--
-- TOC entry 6531 (class 2620 OID 219280)
-- Name: project after_project_update; Type: TRIGGER; Schema: ng_orchestration; Owner: dbadmin
--

CREATE TRIGGER after_project_update AFTER UPDATE ON ng_orchestration.project FOR EACH ROW EXECUTE PROCEDURE ng_orchestration."after_project_update$project"();


--
-- TOC entry 6498 (class 2606 OID 219248)
-- Name: tbl_chronic_circuit chronic_site_id; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_chronic_circuit
    ADD CONSTRAINT chronic_site_id FOREIGN KEY (chronic_site_id) REFERENCES ng_orchestration.tbl_chronic_site(chronic_site_id);


--
-- TOC entry 6488 (class 2606 OID 219163)
-- Name: file_data file_id_fk; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.file_data
    ADD CONSTRAINT file_id_fk FOREIGN KEY (file_id) REFERENCES ng_orchestration.file_attachment(file_id) ON DELETE CASCADE;


--
-- TOC entry 6489 (class 2606 OID 294842)
-- Name: ods_milestone_transaction fk_ccgcly9w17ays9b60dbt4thky; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_milestone_transaction
    ADD CONSTRAINT fk_ccgcly9w17ays9b60dbt4thky FOREIGN KEY (ods_milestone_config_id) REFERENCES ng_orchestration.ods_milestone_config(ods_milestone_config_id);


--
-- TOC entry 6487 (class 2606 OID 219148)
-- Name: attachment_entity_map fk_dir_foreign_entity; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.attachment_entity_map
    ADD CONSTRAINT fk_dir_foreign_entity FOREIGN KEY (entity_type) REFERENCES ng_orchestration.dir_foreign_entity(entity_type) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6510 (class 2606 OID 294852)
-- Name: ods_notification_transaction fk_s7o22dy37bi7udi6o4y500d7y; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ods_notification_transaction
    ADD CONSTRAINT fk_s7o22dy37bi7udi6o4y500d7y FOREIGN KEY (ods_notification_config_id) REFERENCES ng_orchestration.ods_notification_config(ods_notification_config_id);


--
-- TOC entry 6527 (class 2606 OID 3406684)
-- Name: jv_commit_property jv_commit_property_commit_fk; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.jv_commit_property
    ADD CONSTRAINT jv_commit_property_commit_fk FOREIGN KEY (commit_fk) REFERENCES public.jv_commit(commit_pk);


--
-- TOC entry 6516 (class 2606 OID 412154)
-- Name: manifest_doc_config manifest_doc_config_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.manifest_doc_config
    ADD CONSTRAINT manifest_doc_config_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.manifest_app_config(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6518 (class 2606 OID 412206)
-- Name: manifest_document manifest_document_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_document
    ADD CONSTRAINT manifest_document_fk1 FOREIGN KEY (entity_id) REFERENCES ng_orchestration.manifest_entity(entity_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6519 (class 2606 OID 412196)
-- Name: manifest_document manifest_document_fk2; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_document
    ADD CONSTRAINT manifest_document_fk2 FOREIGN KEY (app_id) REFERENCES ng_orchestration.manifest_app_config(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6517 (class 2606 OID 412173)
-- Name: manifest_entity manifest_entity_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.manifest_entity
    ADD CONSTRAINT manifest_entity_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.manifest_app_config(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6492 (class 2606 OID 219188)
-- Name: project_details project_details_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project_details
    ADD CONSTRAINT project_details_ibfk_1 FOREIGN KEY (project_id) REFERENCES ng_orchestration.project(project_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6490 (class 2606 OID 219158)
-- Name: project project_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project
    ADD CONSTRAINT project_ibfk_1 FOREIGN KEY (type) REFERENCES ng_orchestration.dir_project_type(project_type) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6491 (class 2606 OID 219153)
-- Name: project project_ibfk_2; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.project
    ADD CONSTRAINT project_ibfk_2 FOREIGN KEY (status) REFERENCES ng_orchestration.dir_project_status(status) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6493 (class 2606 OID 219193)
-- Name: qrtz_blob_triggers qrtz_blob_triggers_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_blob_triggers
    ADD CONSTRAINT qrtz_blob_triggers_ibfk_1 FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES ng_orchestration.qrtz_triggers(sched_name, trigger_name, trigger_group) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6494 (class 2606 OID 219198)
-- Name: qrtz_cron_triggers qrtz_cron_triggers_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_cron_triggers
    ADD CONSTRAINT qrtz_cron_triggers_ibfk_1 FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES ng_orchestration.qrtz_triggers(sched_name, trigger_name, trigger_group) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6495 (class 2606 OID 219208)
-- Name: qrtz_simple_triggers qrtz_simple_triggers_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_simple_triggers
    ADD CONSTRAINT qrtz_simple_triggers_ibfk_1 FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES ng_orchestration.qrtz_triggers(sched_name, trigger_name, trigger_group) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6496 (class 2606 OID 219213)
-- Name: qrtz_simprop_triggers qrtz_simprop_triggers_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_simprop_triggers
    ADD CONSTRAINT qrtz_simprop_triggers_ibfk_1 FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES ng_orchestration.qrtz_triggers(sched_name, trigger_name, trigger_group) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6497 (class 2606 OID 219203)
-- Name: qrtz_triggers qrtz_triggers_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.qrtz_triggers
    ADD CONSTRAINT qrtz_triggers_ibfk_1 FOREIGN KEY (sched_name, job_name, job_group) REFERENCES ng_orchestration.qrtz_job_details(sched_name, job_name, job_group) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6526 (class 2606 OID 529559)
-- Name: network_channel r_11; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.network_channel
    ADD CONSTRAINT r_11 FOREIGN KEY (service_type_id) REFERENCES ng_orchestration.service_type(service_type_id);


--
-- TOC entry 6524 (class 2606 OID 529603)
-- Name: network_channel r_159; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.network_channel
    ADD CONSTRAINT r_159 FOREIGN KEY (ckl2nci) REFERENCES ng_orchestration.nci_code(nci_id);


--
-- TOC entry 6525 (class 2606 OID 529581)
-- Name: network_channel r_160; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.network_channel
    ADD CONSTRAINT r_160 FOREIGN KEY (network_channel_cd) REFERENCES ng_orchestration.ntwk_channel_codes(nc_id);


--
-- TOC entry 6523 (class 2606 OID 529608)
-- Name: network_channel r_161; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.network_channel
    ADD CONSTRAINT r_161 FOREIGN KEY (ckl1nci) REFERENCES ng_orchestration.nci_code(nci_id);


--
-- TOC entry 6520 (class 2606 OID 413090)
-- Name: wire_center r_166; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.wire_center
    ADD CONSTRAINT r_166 FOREIGN KEY (state_id) REFERENCES ng_orchestration.state(state_id);


--
-- TOC entry 6522 (class 2606 OID 1415160)
-- Name: ind_npa_nxx r_227; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.ind_npa_nxx
    ADD CONSTRAINT r_227 FOREIGN KEY (ind_switch_id) REFERENCES ng_orchestration.ind_switch(ind_switch_id);


--
-- TOC entry 6521 (class 2606 OID 498128)
-- Name: saved_columns saved_columns_pipeline_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.saved_columns
    ADD CONSTRAINT saved_columns_pipeline_id_fkey FOREIGN KEY (pipeline_id) REFERENCES ng_orchestration.pipeline_setting(pipeline_id);


--
-- TOC entry 6515 (class 2606 OID 529545)
-- Name: service_flavor service_flavor_service_type_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.service_flavor
    ADD CONSTRAINT service_flavor_service_type_id_fkey FOREIGN KEY (service_type_id) REFERENCES ng_orchestration.service_type(service_type_id);


--
-- TOC entry 6514 (class 2606 OID 397866)
-- Name: service_type service_type_svc_type_cat_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.service_type
    ADD CONSTRAINT service_type_svc_type_cat_id_fkey FOREIGN KEY (svc_type_cat_id) REFERENCES ng_orchestration.service_type_category(svc_type_cat_id);


--
-- TOC entry 6511 (class 2606 OID 357091)
-- Name: state_plan_map state_plan_map_state_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state_plan_map
    ADD CONSTRAINT state_plan_map_state_id_fkey FOREIGN KEY (state_id) REFERENCES ng_orchestration.state(state_id);


--
-- TOC entry 6513 (class 2606 OID 357148)
-- Name: state_region state_region_region_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state_region
    ADD CONSTRAINT state_region_region_id_fkey FOREIGN KEY (region_id) REFERENCES ng_orchestration.region(region_id);


--
-- TOC entry 6512 (class 2606 OID 357153)
-- Name: state_region state_region_state_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: prvgwy
--

ALTER TABLE ONLY ng_orchestration.state_region
    ADD CONSTRAINT state_region_state_id_fkey FOREIGN KEY (state_id) REFERENCES ng_orchestration.state(state_id);


--
-- TOC entry 6499 (class 2606 OID 219218)
-- Name: tbl_chronic_site_entity tbl_chronic_site_entity_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_chronic_site_entity
    ADD CONSTRAINT tbl_chronic_site_entity_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.tbl_application(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6500 (class 2606 OID 219258)
-- Name: tbl_manifest_map tbl_manifest_map_con1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest_map
    ADD CONSTRAINT tbl_manifest_map_con1 FOREIGN KEY (document_id) REFERENCES ng_orchestration.tbl_manifest_docs(document_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6501 (class 2606 OID 219253)
-- Name: tbl_manifest_map tbl_manifest_map_con2; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_manifest_map
    ADD CONSTRAINT tbl_manifest_map_con2 FOREIGN KEY (manifest_id) REFERENCES ng_orchestration.tbl_manifest(manifest_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6502 (class 2606 OID 219223)
-- Name: tbl_pon_entity tbl_pon_entity_idx1_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_pon_entity
    ADD CONSTRAINT tbl_pon_entity_idx1_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.tbl_application(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6503 (class 2606 OID 219228)
-- Name: tbl_rqnorder_entity tbl_rqnorder_entity_idx1_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_rqnorder_entity
    ADD CONSTRAINT tbl_rqnorder_entity_idx1_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.tbl_application(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6504 (class 2606 OID 219233)
-- Name: tbl_ssporder_entity tbl_ssporder_entity_idx1_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_ssporder_entity
    ADD CONSTRAINT tbl_ssporder_entity_idx1_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.tbl_application(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6505 (class 2606 OID 219263)
-- Name: tbl_task_sla tbl_task_sla_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_task_sla
    ADD CONSTRAINT tbl_task_sla_ibfk_1 FOREIGN KEY (sla_process_map_id) REFERENCES ng_orchestration.tbl_sla_process_map(sla_process_map_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6506 (class 2606 OID 219238)
-- Name: tbl_vps_order_entity tbl_vps_order_entity_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_entity
    ADD CONSTRAINT tbl_vps_order_entity_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.tbl_application(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6507 (class 2606 OID 219268)
-- Name: tbl_vps_order_version tbl_vps_order_version_fk2; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vps_order_version
    ADD CONSTRAINT tbl_vps_order_version_fk2 FOREIGN KEY (order_circuit_id) REFERENCES ng_orchestration.tbl_vps_order_circuit(order_circuit_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6508 (class 2606 OID 219243)
-- Name: tbl_vrd_order_entity tbl_vrd_order_entity_fk1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_vrd_order_entity
    ADD CONSTRAINT tbl_vrd_order_entity_fk1 FOREIGN KEY (app_id) REFERENCES ng_orchestration.tbl_application(app_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6509 (class 2606 OID 219273)
-- Name: tbl_workflow_map_ext tbl_workflow_map_ext_ibfk_1; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: dbadmin
--

ALTER TABLE ONLY ng_orchestration.tbl_workflow_map_ext
    ADD CONSTRAINT tbl_workflow_map_ext_ibfk_1 FOREIGN KEY (workflow_map_id) REFERENCES ng_orchestration.tbl_workflow_map(workflow_map_id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- TOC entry 6528 (class 2606 OID 5821422)
-- Name: test_table_orders test_table_orders_cust_id_fkey; Type: FK CONSTRAINT; Schema: ng_orchestration; Owner: postgres
--

ALTER TABLE ONLY ng_orchestration.test_table_orders
    ADD CONSTRAINT test_table_orders_cust_id_fkey FOREIGN KEY (cust_id) REFERENCES ng_orchestration.test_table(cust_id);


--
-- TOC entry 6663 (class 0 OID 0)
-- Dependencies: 68
-- Name: SCHEMA ng_orchestration; Type: ACL; Schema: -; Owner: prvgwy
--

GRANT ALL ON SCHEMA ng_orchestration TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SCHEMA ng_orchestration TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SCHEMA ng_orchestration TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SCHEMA ng_orchestration TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SCHEMA ng_orchestration TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SCHEMA ng_orchestration TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6664 (class 0 OID 0)
-- Dependencies: 1007
-- Name: FUNCTION "after_project_delete$project"(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration."after_project_delete$project"() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration."after_project_delete$project"() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration."after_project_delete$project"() TO ng_orch_nodelete;


--
-- TOC entry 6665 (class 0 OID 0)
-- Dependencies: 1008
-- Name: FUNCTION "after_project_insert$project"(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration."after_project_insert$project"() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration."after_project_insert$project"() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration."after_project_insert$project"() TO ng_orch_nodelete;


--
-- TOC entry 6666 (class 0 OID 0)
-- Dependencies: 1009
-- Name: FUNCTION "after_project_update$project"(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration."after_project_update$project"() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration."after_project_update$project"() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration."after_project_update$project"() TO ng_orch_nodelete;


--
-- TOC entry 6667 (class 0 OID 0)
-- Dependencies: 1065
-- Name: FUNCTION alphanum(par_input character varying); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.alphanum(par_input character varying) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.alphanum(par_input character varying) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.alphanum(par_input character varying) TO ng_orch_nodelete;


--
-- TOC entry 6668 (class 0 OID 0)
-- Dependencies: 1133
-- Name: FUNCTION charindex(text, text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.charindex(text, text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.charindex(text, text) TO ng_orch_nodelete;


--
-- TOC entry 6669 (class 0 OID 0)
-- Dependencies: 1134
-- Name: FUNCTION checkentityexist(_tbl regclass, entity_id bigint); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexist(_tbl regclass, entity_id bigint) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexist(_tbl regclass, entity_id bigint) TO ng_orch_nodelete;


--
-- TOC entry 6670 (class 0 OID 0)
-- Dependencies: 1135
-- Name: FUNCTION checkentityexistold(par_tab_name character varying, par_entity_id bigint); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold(par_tab_name character varying, par_entity_id bigint) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold(par_tab_name character varying, par_entity_id bigint) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold(par_tab_name character varying, par_entity_id bigint) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6671 (class 0 OID 0)
-- Dependencies: 1047
-- Name: FUNCTION checkentityexistold2(tb3_type anyelement, entity_id integer); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold2(tb3_type anyelement, entity_id integer) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold2(tb3_type anyelement, entity_id integer) TO ng_orch_nodelete;


--
-- TOC entry 6672 (class 0 OID 0)
-- Dependencies: 1048
-- Name: FUNCTION checkentityexistold2(tb3_type character varying, entity_id integer, tb2_type anyelement); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold2(tb3_type character varying, entity_id integer, tb2_type anyelement) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold2(tb3_type character varying, entity_id integer, tb2_type anyelement) TO ng_orch_nodelete;


--
-- TOC entry 6673 (class 0 OID 0)
-- Dependencies: 1049
-- Name: FUNCTION checkentityexistold3(_tbl regclass, entity_id integer); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold3(_tbl regclass, entity_id integer) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold3(_tbl regclass, entity_id integer) TO ng_orch_nodelete;


--
-- TOC entry 6674 (class 0 OID 0)
-- Dependencies: 1127
-- Name: FUNCTION checkentityexistold4(tb3_type anyelement, entity_id bigint); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold4(tb3_type anyelement, entity_id bigint) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold4(tb3_type anyelement, entity_id bigint) TO ng_orch_nodelete;


--
-- TOC entry 6675 (class 0 OID 0)
-- Dependencies: 1128
-- Name: FUNCTION checkentityexistold5(tb3_type character varying, entity_id integer, tb2_type anyelement); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold5(tb3_type character varying, entity_id integer, tb2_type anyelement) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.checkentityexistold5(tb3_type character varying, entity_id integer, tb2_type anyelement) TO ng_orch_nodelete;


--
-- TOC entry 6676 (class 0 OID 0)
-- Dependencies: 728
-- Name: TABLE orders_count_due; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.orders_count_due TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.orders_count_due TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.orders_count_due TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.orders_count_due TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.orders_count_due TO postgres;


--
-- TOC entry 6677 (class 0 OID 0)
-- Dependencies: 1169
-- Name: FUNCTION count_orders_due(o_source text, milestone text, o_region text, o_product text, business_type text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.count_orders_due(o_source text, milestone text, o_region text, o_product text, business_type text) TO ng_orch_nodelete;


--
-- TOC entry 6678 (class 0 OID 0)
-- Dependencies: 733
-- Name: TABLE orders_count; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.orders_count TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.orders_count TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.orders_count TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.orders_count TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.orders_count TO postgres;


--
-- TOC entry 6679 (class 0 OID 0)
-- Dependencies: 1151
-- Name: FUNCTION count_orders_fn(o_source text, milestone text, o_region text, o_product text, business_type text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.count_orders_fn(o_source text, milestone text, o_region text, o_product text, business_type text) TO ng_orch_nodelete;


--
-- TOC entry 6680 (class 0 OID 0)
-- Dependencies: 1095
-- Name: FUNCTION count_orders_past_due(o_source text, milestone text, o_region text, o_product text, business_type text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.count_orders_past_due(o_source text, milestone text, o_region text, o_product text, business_type text) TO ng_orch_nodelete;


--
-- TOC entry 6681 (class 0 OID 0)
-- Dependencies: 1152
-- Name: FUNCTION count_orders_upcoming(o_source text, milestone text, o_region text, o_product text, business_type text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.count_orders_upcoming(o_source text, milestone text, o_region text, o_product text, business_type text) TO ng_orch_nodelete;


--
-- TOC entry 6682 (class 0 OID 0)
-- Dependencies: 1145
-- Name: FUNCTION cr_id_to_string(); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.cr_id_to_string() TO ng_orch_nodelete;


--
-- TOC entry 6683 (class 0 OID 0)
-- Dependencies: 1050
-- Name: FUNCTION deletemanifest(par_entityid bigint); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.deletemanifest(par_entityid bigint) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.deletemanifest(par_entityid bigint) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.deletemanifest(par_entityid bigint) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6684 (class 0 OID 0)
-- Dependencies: 1066
-- Name: FUNCTION dml_table_sync_utl_purge_dml_monitor_data(par_p_event_id bigint); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_purge_dml_monitor_data(par_p_event_id bigint) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_purge_dml_monitor_data(par_p_event_id bigint) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_purge_dml_monitor_data(par_p_event_id bigint) TO ng_orch_nodelete;


--
-- TOC entry 6685 (class 0 OID 0)
-- Dependencies: 1051
-- Name: FUNCTION dml_table_sync_utl_sync_cmd_search_cache(par_p_table_name character varying, par_p_key_name character varying, par_p_key_value character varying, par_p_dml_type character varying); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_cmd_search_cache(par_p_table_name character varying, par_p_key_name character varying, par_p_key_value character varying, par_p_dml_type character varying) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_cmd_search_cache(par_p_table_name character varying, par_p_key_name character varying, par_p_key_value character varying, par_p_dml_type character varying) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_cmd_search_cache(par_p_table_name character varying, par_p_key_name character varying, par_p_key_value character varying, par_p_dml_type character varying) TO ng_orch_nodelete;


--
-- TOC entry 6686 (class 0 OID 0)
-- Dependencies: 1052
-- Name: FUNCTION dml_table_sync_utl_sync_dml_monitor_data(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_dml_monitor_data() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_dml_monitor_data() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_dml_monitor_data() TO ng_orch_nodelete;


--
-- TOC entry 6687 (class 0 OID 0)
-- Dependencies: 1055
-- Name: FUNCTION dml_table_sync_utl_sync_project(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_project() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_project() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.dml_table_sync_utl_sync_project() TO ng_orch_nodelete;


--
-- TOC entry 6688 (class 0 OID 0)
-- Dependencies: 1114
-- Name: FUNCTION dton(p_date date); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.dton(p_date date) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.dton(p_date date) TO ng_orch_nodelete;


--
-- TOC entry 6689 (class 0 OID 0)
-- Dependencies: 1025
-- Name: FUNCTION example(); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.example() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.example() TO ng_orch_nodelete;


--
-- TOC entry 6690 (class 0 OID 0)
-- Dependencies: 1129
-- Name: FUNCTION get_two_users_from_school(schoolid bigint); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.get_two_users_from_school(schoolid bigint) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.get_two_users_from_school(schoolid bigint) TO ng_orch_nodelete;


--
-- TOC entry 6691 (class 0 OID 0)
-- Dependencies: 1156
-- Name: FUNCTION getalldocuments(par_entityid bigint); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.getalldocuments(par_entityid bigint) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.getalldocuments(par_entityid bigint) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getalldocuments(par_entityid bigint) TO ng_orch_nodelete;


--
-- TOC entry 6692 (class 0 OID 0)
-- Dependencies: 1136
-- Name: FUNCTION getdate(); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getdate() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getdate() TO ng_orch_nodelete;


--
-- TOC entry 6693 (class 0 OID 0)
-- Dependencies: 1056
-- Name: FUNCTION getmanifest(par_entityid bigint, par_docname character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmanifest(par_entityid bigint, par_docname character varying) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.getmanifest(par_entityid bigint, par_docname character varying) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.getmanifest(par_entityid bigint, par_docname character varying) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6694 (class 0 OID 0)
-- Dependencies: 1057
-- Name: FUNCTION getmanifesttest(par_entityid bigint, par_docname character varying); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.getmanifesttest(par_entityid bigint, par_docname character varying) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.getmanifesttest(par_entityid bigint, par_docname character varying) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getmanifesttest(par_entityid bigint, par_docname character varying) TO ng_orch_nodelete;


--
-- TOC entry 6695 (class 0 OID 0)
-- Dependencies: 1058
-- Name: FUNCTION getmetadata(t_name text, s_name text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmetadata(t_name text, s_name text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getmetadata(t_name text, s_name text) TO ng_orch_nodelete;


--
-- TOC entry 6696 (class 0 OID 0)
-- Dependencies: 1059
-- Name: FUNCTION getmetadatanew(table_schema character varying, table_name character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmetadatanew(table_schema character varying, table_name character varying) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getmetadatanew(table_schema character varying, table_name character varying) TO ng_orch_nodelete;


--
-- TOC entry 6697 (class 0 OID 0)
-- Dependencies: 1125
-- Name: FUNCTION getmetadataold(par_tab_name character varying, par_schema_name character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmetadataold(par_tab_name character varying, par_schema_name character varying) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.getmetadataold(par_tab_name character varying, par_schema_name character varying) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.getmetadataold(par_tab_name character varying, par_schema_name character varying) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6698 (class 0 OID 0)
-- Dependencies: 1060
-- Name: FUNCTION getmetadataold1(s_name text, t_name text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmetadataold1(s_name text, t_name text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getmetadataold1(s_name text, t_name text) TO ng_orch_nodelete;


--
-- TOC entry 6699 (class 0 OID 0)
-- Dependencies: 1061
-- Name: FUNCTION getmetadatatest(par_tab_name character varying, par_schema_name character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmetadatatest(par_tab_name character varying, par_schema_name character varying) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.getmetadatatest(par_tab_name character varying, par_schema_name character varying) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.getmetadatatest(par_tab_name character varying, par_schema_name character varying) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6700 (class 0 OID 0)
-- Dependencies: 1053
-- Name: FUNCTION getmetadatatest2(t_name text, s_name text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.getmetadatatest2(t_name text, s_name text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.getmetadatatest2(t_name text, s_name text) TO ng_orch_nodelete;


--
-- TOC entry 6701 (class 0 OID 0)
-- Dependencies: 1144
-- Name: FUNCTION id_to_string(cr_id bigint); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.id_to_string(cr_id bigint) TO ng_orch_nodelete;


--
-- TOC entry 6702 (class 0 OID 0)
-- Dependencies: 1010
-- Name: FUNCTION "id_to_string_notUsed"(cr_id character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration."id_to_string_notUsed"(cr_id character varying) TO ng_orch_nodelete;


--
-- TOC entry 6703 (class 0 OID 0)
-- Dependencies: 1011
-- Name: FUNCTION "id_to_string_not_Used"(cr_id numeric); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration."id_to_string_not_Used"(cr_id numeric) TO ng_orch_nodelete;


--
-- TOC entry 6704 (class 0 OID 0)
-- Dependencies: 1067
-- Name: FUNCTION insertentitydata(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydata(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydata(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6705 (class 0 OID 0)
-- Dependencies: 1126
-- Name: FUNCTION insertentitydataold(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6706 (class 0 OID 0)
-- Dependencies: 1157
-- Name: FUNCTION insertentitydataold(par_tab_name character varying, par_entity_id bigint, par_app_id bigint, par_columnstring text, par_valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold(par_tab_name character varying, par_entity_id bigint, par_app_id bigint, par_columnstring text, par_valuestring text) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold(par_tab_name character varying, par_entity_id bigint, par_app_id bigint, par_columnstring text, par_valuestring text) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold(par_tab_name character varying, par_entity_id bigint, par_app_id bigint, par_columnstring text, par_valuestring text) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6707 (class 0 OID 0)
-- Dependencies: 1158
-- Name: FUNCTION insertentitydataold1(_tbl regclass, entity_id bigint, app_id bigint, columnstring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold1(_tbl regclass, entity_id bigint, app_id bigint, columnstring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold1(_tbl regclass, entity_id bigint, app_id bigint, columnstring text) TO ng_orch_nodelete;


--
-- TOC entry 6708 (class 0 OID 0)
-- Dependencies: 1068
-- Name: FUNCTION insertentitydataold2(_tbl regclass, entity_id bigint, app_id text, columnstring regclass, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold2(_tbl regclass, entity_id bigint, app_id text, columnstring regclass, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold2(_tbl regclass, entity_id bigint, app_id text, columnstring regclass, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6709 (class 0 OID 0)
-- Dependencies: 1069
-- Name: FUNCTION insertentitydataold3(_tbl regclass, entity_id bigint, app_id text, columnstring text, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold3(_tbl regclass, entity_id bigint, app_id text, columnstring text, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold3(_tbl regclass, entity_id bigint, app_id text, columnstring text, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6710 (class 0 OID 0)
-- Dependencies: 1070
-- Name: FUNCTION insertentitydataold4(_tbl regclass, entity_id bigint, app_id text, _columnstring character varying, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold4(_tbl regclass, entity_id bigint, app_id text, _columnstring character varying, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold4(_tbl regclass, entity_id bigint, app_id text, _columnstring character varying, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6711 (class 0 OID 0)
-- Dependencies: 1071
-- Name: FUNCTION insertentitydataold5(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold5(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold5(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6712 (class 0 OID 0)
-- Dependencies: 1072
-- Name: FUNCTION insertentitydataold6(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold6(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydataold6(_tbl regclass, entity_id bigint, app_id text, _columnstring text, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6713 (class 0 OID 0)
-- Dependencies: 1083
-- Name: FUNCTION insertentitydatatest(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.insertentitydatatest(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.insertentitydatatest(_tbl regclass, entity_id bigint, app_id bigint, _columnstring text, valuestring text) TO ng_orch_nodelete;


--
-- TOC entry 6714 (class 0 OID 0)
-- Dependencies: 1132
-- Name: FUNCTION "isnull"(anyelement, anyelement); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration."isnull"(anyelement, anyelement) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration."isnull"(anyelement, anyelement) TO ng_orch_nodelete;


--
-- TOC entry 6715 (class 0 OID 0)
-- Dependencies: 1137
-- Name: FUNCTION "left"(text, integer); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration."left"(text, integer) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration."left"(text, integer) TO ng_orch_nodelete;


--
-- TOC entry 6716 (class 0 OID 0)
-- Dependencies: 1159
-- Name: FUNCTION len(text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.len(text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.len(text) TO ng_orch_nodelete;


--
-- TOC entry 6717 (class 0 OID 0)
-- Dependencies: 1093
-- Name: FUNCTION "local_dton_not_Used"(p_date character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration."local_dton_not_Used"(p_date character varying) TO ng_orch_nodelete;


--
-- TOC entry 6718 (class 0 OID 0)
-- Dependencies: 1160
-- Name: FUNCTION local_dton_not_used(p_date date); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_dton_not_used(p_date date) TO ng_orch_nodelete;


--
-- TOC entry 6719 (class 0 OID 0)
-- Dependencies: 1091
-- Name: FUNCTION local_dton_pg(p_date_ts character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_dton_pg(p_date_ts character varying) TO ng_orch_nodelete;


--
-- TOC entry 6720 (class 0 OID 0)
-- Dependencies: 1094
-- Name: FUNCTION local_dton_test(p_date character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_dton_test(p_date character varying) TO ng_orch_nodelete;


--
-- TOC entry 6721 (class 0 OID 0)
-- Dependencies: 1012
-- Name: FUNCTION local_dton_test_ien(p_date date); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_dton_test_ien(p_date date) TO ng_orch_nodelete;


--
-- TOC entry 6722 (class 0 OID 0)
-- Dependencies: 1149
-- Name: FUNCTION local_ntod(p_num numeric); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_ntod(p_num numeric) TO ng_orch_nodelete;


--
-- TOC entry 6723 (class 0 OID 0)
-- Dependencies: 1150
-- Name: FUNCTION local_ntod_tes_ien(p_num numeric); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_ntod_tes_ien(p_num numeric) TO ng_orch_nodelete;


--
-- TOC entry 6724 (class 0 OID 0)
-- Dependencies: 1147
-- Name: FUNCTION local_ntod_test(p_num integer); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_ntod_test(p_num integer) TO ng_orch_nodelete;


--
-- TOC entry 6725 (class 0 OID 0)
-- Dependencies: 1148
-- Name: FUNCTION local_ntod_test(p_num numeric); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.local_ntod_test(p_num numeric) TO ng_orch_nodelete;


--
-- TOC entry 6726 (class 0 OID 0)
-- Dependencies: 1146
-- Name: FUNCTION manifest_backup_config_docs(); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.manifest_backup_config_docs() TO ng_orch_nodelete;


--
-- TOC entry 6727 (class 0 OID 0)
-- Dependencies: 1084
-- Name: FUNCTION month(timestamp without time zone); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.month(timestamp without time zone) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.month(timestamp without time zone) TO ng_orch_nodelete;


--
-- TOC entry 6728 (class 0 OID 0)
-- Dependencies: 1085
-- Name: FUNCTION my_function(_rowtype anyelement); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.my_function(_rowtype anyelement) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.my_function(_rowtype anyelement) TO ng_orch_nodelete;


--
-- TOC entry 6729 (class 0 OID 0)
-- Dependencies: 1113
-- Name: FUNCTION ntod(p_num integer); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.ntod(p_num integer) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.ntod(p_num integer) TO ng_orch_nodelete;


--
-- TOC entry 6730 (class 0 OID 0)
-- Dependencies: 1086
-- Name: FUNCTION postmanifest(par_entityid bigint, par_docname character varying, par_append integer, par_manifestdoc character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.postmanifest(par_entityid bigint, par_docname character varying, par_append integer, par_manifestdoc character varying) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.postmanifest(par_entityid bigint, par_docname character varying, par_append integer, par_manifestdoc character varying) TO ng_orch_nodelete;


--
-- TOC entry 6731 (class 0 OID 0)
-- Dependencies: 1087
-- Name: FUNCTION postmanifestold(par_entityid bigint, par_docname character varying, par_append smallint, par_manifestdoc character varying); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.postmanifestold(par_entityid bigint, par_docname character varying, par_append smallint, par_manifestdoc character varying) TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.postmanifestold(par_entityid bigint, par_docname character varying, par_append smallint, par_manifestdoc character varying) TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON FUNCTION ng_orchestration.postmanifestold(par_entityid bigint, par_docname character varying, par_append smallint, par_manifestdoc character varying) TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6732 (class 0 OID 0)
-- Dependencies: 1092
-- Name: FUNCTION replace_into_project_cmd_cache(par_project_details_id integer); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.replace_into_project_cmd_cache(par_project_details_id integer) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.replace_into_project_cmd_cache(par_project_details_id integer) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.replace_into_project_cmd_cache(par_project_details_id integer) TO ng_orch_nodelete;


--
-- TOC entry 6733 (class 0 OID 0)
-- Dependencies: 1138
-- Name: FUNCTION space(integer); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.space(integer) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.space(integer) TO ng_orch_nodelete;


--
-- TOC entry 6734 (class 0 OID 0)
-- Dependencies: 1168
-- Name: FUNCTION strcat(text, text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.strcat(text, text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.strcat(text, text) TO ng_orch_nodelete;


--
-- TOC entry 6735 (class 0 OID 0)
-- Dependencies: 1122
-- Name: FUNCTION sync_project_search_cache_purge_search_cache_event(par_p_event_id bigint); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_purge_search_cache_event(par_p_event_id bigint) TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_purge_search_cache_event(par_p_event_id bigint) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_purge_search_cache_event(par_p_event_id bigint) TO ng_orch_nodelete;


--
-- TOC entry 6736 (class 0 OID 0)
-- Dependencies: 1005
-- Name: FUNCTION sync_project_search_cache_sync_project_search_cache_inst(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_inst() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_inst() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_inst() TO ng_orch_nodelete;


--
-- TOC entry 6737 (class 0 OID 0)
-- Dependencies: 1006
-- Name: FUNCTION sync_project_search_cache_sync_project_search_cache_main(); Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_main() TO prvapp WITH GRANT OPTION;
GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_main() TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.sync_project_search_cache_sync_project_search_cache_main() TO ng_orch_nodelete;


--
-- TOC entry 6738 (class 0 OID 0)
-- Dependencies: 1054
-- Name: FUNCTION xp_sendmail(tofield text, message text, subject text); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.xp_sendmail(tofield text, message text, subject text) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.xp_sendmail(tofield text, message text, subject text) TO ng_orch_nodelete;


--
-- TOC entry 6739 (class 0 OID 0)
-- Dependencies: 1139
-- Name: FUNCTION year(timestamp without time zone); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.year(timestamp without time zone) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.year(timestamp without time zone) TO ng_orch_nodelete;


--
-- TOC entry 6740 (class 0 OID 0)
-- Dependencies: 1123
-- Name: FUNCTION year(timestamp with time zone); Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON FUNCTION ng_orchestration.year(timestamp with time zone) TO prvgwy_ro;
GRANT ALL ON FUNCTION ng_orchestration.year(timestamp with time zone) TO ng_orch_nodelete;


--
-- TOC entry 6741 (class 0 OID 0)
-- Dependencies: 714
-- Name: SEQUENCE "SR_ID_SEQ"; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration."SR_ID_SEQ" TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration."SR_ID_SEQ" TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration."SR_ID_SEQ" TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration."SR_ID_SEQ" TO postgres;


--
-- TOC entry 6742 (class 0 OID 0)
-- Dependencies: 719
-- Name: SEQUENCE add_contacts_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.add_contacts_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.add_contacts_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.add_contacts_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.add_contacts_id_seq TO postgres;


--
-- TOC entry 6743 (class 0 OID 0)
-- Dependencies: 537
-- Name: TABLE address_conversion; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON TABLE ng_orchestration.address_conversion TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.address_conversion TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.address_conversion TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.address_conversion TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.address_conversion TO postgres;


--
-- TOC entry 6744 (class 0 OID 0)
-- Dependencies: 503
-- Name: TABLE admin_document_store; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.admin_document_store TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.admin_document_store TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.admin_document_store TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.admin_document_store TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.admin_document_store TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.admin_document_store TO postgres;


--
-- TOC entry 6745 (class 0 OID 0)
-- Dependencies: 700
-- Name: TABLE aqm_task; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.aqm_task TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.aqm_task TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.aqm_task TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.aqm_task TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.aqm_task TO postgres;


--
-- TOC entry 6746 (class 0 OID 0)
-- Dependencies: 701
-- Name: TABLE aqm_wftemplate; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.aqm_wftemplate TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.aqm_wftemplate TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.aqm_wftemplate TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.aqm_wftemplate TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.aqm_wftemplate TO postgres;


--
-- TOC entry 6747 (class 0 OID 0)
-- Dependencies: 699
-- Name: TABLE aqm_workstep; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.aqm_workstep TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.aqm_workstep TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.aqm_workstep TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.aqm_workstep TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.aqm_workstep TO postgres;


--
-- TOC entry 6748 (class 0 OID 0)
-- Dependencies: 249
-- Name: SEQUENCE atoll_temp_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.atoll_temp_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.atoll_temp_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.atoll_temp_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.atoll_temp_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.atoll_temp_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.atoll_temp_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.atoll_temp_seq TO prvgwy;


--
-- TOC entry 6749 (class 0 OID 0)
-- Dependencies: 346
-- Name: TABLE atoll_temp; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.atoll_temp TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.atoll_temp TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.atoll_temp TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.atoll_temp TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.atoll_temp TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.atoll_temp TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.atoll_temp TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.atoll_temp TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6750 (class 0 OID 0)
-- Dependencies: 250
-- Name: SEQUENCE attachment_download_auth_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.attachment_download_auth_seq TO prvgwy;


--
-- TOC entry 6751 (class 0 OID 0)
-- Dependencies: 347
-- Name: TABLE attachment_download_auth; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.attachment_download_auth TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.attachment_download_auth TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.attachment_download_auth TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.attachment_download_auth TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.attachment_download_auth TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.attachment_download_auth TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.attachment_download_auth TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.attachment_download_auth TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6752 (class 0 OID 0)
-- Dependencies: 348
-- Name: TABLE attachment_entity_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.attachment_entity_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.attachment_entity_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.attachment_entity_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.attachment_entity_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.attachment_entity_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.attachment_entity_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.attachment_entity_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.attachment_entity_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6753 (class 0 OID 0)
-- Dependencies: 742
-- Name: SEQUENCE attachment_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.attachment_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.attachment_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.attachment_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.attachment_id_seq TO postgres;


--
-- TOC entry 6754 (class 0 OID 0)
-- Dependencies: 743
-- Name: SEQUENCE audit_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.audit_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.audit_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.audit_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.audit_id_seq TO postgres;


--
-- TOC entry 6755 (class 0 OID 0)
-- Dependencies: 855
-- Name: TABLE auth_users; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.auth_users TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.auth_users TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.auth_users TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.auth_users TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.auth_users TO postgres;


--
-- TOC entry 6756 (class 0 OID 0)
-- Dependencies: 744
-- Name: SEQUENCE bam_task_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.bam_task_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.bam_task_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.bam_task_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.bam_task_id_seq TO postgres;


--
-- TOC entry 6757 (class 0 OID 0)
-- Dependencies: 745
-- Name: SEQUENCE booleanexpr_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.booleanexpr_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.booleanexpr_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.booleanexpr_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.booleanexpr_id_seq TO postgres;


--
-- TOC entry 6758 (class 0 OID 0)
-- Dependencies: 698
-- Name: TABLE cafe_bases_service_type; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.cafe_bases_service_type TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.cafe_bases_service_type TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.cafe_bases_service_type TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.cafe_bases_service_type TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.cafe_bases_service_type TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.cafe_bases_service_type TO postgres;


--
-- TOC entry 6759 (class 0 OID 0)
-- Dependencies: 746
-- Name: SEQUENCE case_file_data_log_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.case_file_data_log_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.case_file_data_log_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.case_file_data_log_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.case_file_data_log_id_seq TO postgres;


--
-- TOC entry 6760 (class 0 OID 0)
-- Dependencies: 747
-- Name: SEQUENCE case_id_info_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.case_id_info_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.case_id_info_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.case_id_info_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.case_id_info_id_seq TO postgres;


--
-- TOC entry 6761 (class 0 OID 0)
-- Dependencies: 748
-- Name: SEQUENCE case_role_assign_log_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.case_role_assign_log_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.case_role_assign_log_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.case_role_assign_log_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.case_role_assign_log_id_seq TO postgres;


--
-- TOC entry 6762 (class 0 OID 0)
-- Dependencies: 510
-- Name: SEQUENCE cbscne_laser_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.cbscne_laser_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.cbscne_laser_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.cbscne_laser_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.cbscne_laser_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.cbscne_laser_seq TO postgres;


--
-- TOC entry 6763 (class 0 OID 0)
-- Dependencies: 511
-- Name: TABLE cbscne_laser; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.cbscne_laser TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.cbscne_laser TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.cbscne_laser TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.cbscne_laser TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.cbscne_laser TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.cbscne_laser TO postgres;


--
-- TOC entry 6764 (class 0 OID 0)
-- Dependencies: 691
-- Name: TABLE cfa_failed_validation; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.cfa_failed_validation TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.cfa_failed_validation TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.cfa_failed_validation TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.cfa_failed_validation TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.cfa_failed_validation TO postgres;


--
-- TOC entry 6765 (class 0 OID 0)
-- Dependencies: 749
-- Name: SEQUENCE comment_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.comment_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.comment_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.comment_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.comment_id_seq TO postgres;


--
-- TOC entry 6766 (class 0 OID 0)
-- Dependencies: 520
-- Name: TABLE config_parameters; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.config_parameters TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.config_parameters TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.config_parameters TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.config_parameters TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.config_parameters TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.config_parameters TO postgres;


--
-- TOC entry 6767 (class 0 OID 0)
-- Dependencies: 750
-- Name: SEQUENCE content_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.content_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.content_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.content_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.content_id_seq TO postgres;


--
-- TOC entry 6768 (class 0 OID 0)
-- Dependencies: 751
-- Name: SEQUENCE context_mapping_info_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.context_mapping_info_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.context_mapping_info_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.context_mapping_info_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.context_mapping_info_id_seq TO postgres;


--
-- TOC entry 6769 (class 0 OID 0)
-- Dependencies: 752
-- Name: SEQUENCE correlation_key_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.correlation_key_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.correlation_key_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.correlation_key_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.correlation_key_id_seq TO postgres;


--
-- TOC entry 6770 (class 0 OID 0)
-- Dependencies: 753
-- Name: SEQUENCE correlation_prop_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.correlation_prop_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.correlation_prop_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.correlation_prop_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.correlation_prop_id_seq TO postgres;


--
-- TOC entry 6771 (class 0 OID 0)
-- Dependencies: 713
-- Name: SEQUENCE cr_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.cr_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.cr_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.cr_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.cr_id_seq TO postgres;


--
-- TOC entry 6772 (class 0 OID 0)
-- Dependencies: 718
-- Name: SEQUENCE customer_project_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.customer_project_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.customer_project_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.customer_project_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.customer_project_id_seq TO postgres;


--
-- TOC entry 6773 (class 0 OID 0)
-- Dependencies: 689
-- Name: TABLE customer_request; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.customer_request TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.customer_request TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.customer_request TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.customer_request TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.customer_request TO postgres;


--
-- TOC entry 6774 (class 0 OID 0)
-- Dependencies: 536
-- Name: TABLE date_rule_milestones; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.date_rule_milestones TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.date_rule_milestones TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.date_rule_milestones TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.date_rule_milestones TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.date_rule_milestones TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.date_rule_milestones TO postgres;


--
-- TOC entry 6775 (class 0 OID 0)
-- Dependencies: 715
-- Name: TABLE db_count; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.db_count TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.db_count TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.db_count TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.db_count TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.db_count TO postgres;


--
-- TOC entry 6776 (class 0 OID 0)
-- Dependencies: 754
-- Name: SEQUENCE deadline_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.deadline_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.deadline_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.deadline_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.deadline_id_seq TO postgres;


--
-- TOC entry 6777 (class 0 OID 0)
-- Dependencies: 755
-- Name: SEQUENCE deploy_store_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.deploy_store_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.deploy_store_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.deploy_store_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.deploy_store_id_seq TO postgres;


--
-- TOC entry 6778 (class 0 OID 0)
-- Dependencies: 349
-- Name: TABLE dir_foreign_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.dir_foreign_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.dir_foreign_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.dir_foreign_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.dir_foreign_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.dir_foreign_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.dir_foreign_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_foreign_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_foreign_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6779 (class 0 OID 0)
-- Dependencies: 251
-- Name: SEQUENCE dir_project_action_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.dir_project_action_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.dir_project_action_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.dir_project_action_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.dir_project_action_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_action_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_action_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_action_seq TO prvgwy;


--
-- TOC entry 6780 (class 0 OID 0)
-- Dependencies: 350
-- Name: TABLE dir_project_action; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.dir_project_action TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.dir_project_action TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.dir_project_action TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.dir_project_action TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.dir_project_action TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.dir_project_action TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_project_action TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_project_action TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6781 (class 0 OID 0)
-- Dependencies: 252
-- Name: SEQUENCE dir_project_status_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.dir_project_status_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.dir_project_status_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.dir_project_status_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.dir_project_status_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_status_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_status_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_status_seq TO prvgwy;


--
-- TOC entry 6782 (class 0 OID 0)
-- Dependencies: 351
-- Name: TABLE dir_project_status; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.dir_project_status TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.dir_project_status TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.dir_project_status TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.dir_project_status TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.dir_project_status TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.dir_project_status TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_project_status TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_project_status TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6783 (class 0 OID 0)
-- Dependencies: 253
-- Name: SEQUENCE dir_project_type_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.dir_project_type_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.dir_project_type_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.dir_project_type_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.dir_project_type_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_type_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_type_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.dir_project_type_seq TO prvgwy;


--
-- TOC entry 6784 (class 0 OID 0)
-- Dependencies: 352
-- Name: TABLE dir_project_type; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.dir_project_type TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.dir_project_type TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.dir_project_type TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.dir_project_type TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.dir_project_type TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.dir_project_type TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_project_type TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dir_project_type TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6785 (class 0 OID 0)
-- Dependencies: 254
-- Name: SEQUENCE dml_monitor_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.dml_monitor_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.dml_monitor_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.dml_monitor_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.dml_monitor_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dml_monitor_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.dml_monitor_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.dml_monitor_seq TO prvgwy;


--
-- TOC entry 6786 (class 0 OID 0)
-- Dependencies: 353
-- Name: TABLE dml_monitor; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.dml_monitor TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.dml_monitor TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.dml_monitor TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.dml_monitor TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.dml_monitor TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.dml_monitor TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dml_monitor TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.dml_monitor TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6787 (class 0 OID 0)
-- Dependencies: 756
-- Name: SEQUENCE emailnotifhead_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.emailnotifhead_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.emailnotifhead_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.emailnotifhead_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.emailnotifhead_id_seq TO postgres;


--
-- TOC entry 6788 (class 0 OID 0)
-- Dependencies: 255
-- Name: SEQUENCE entity_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.entity_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.entity_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.entity_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.entity_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.entity_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.entity_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.entity_map_seq TO prvgwy;


--
-- TOC entry 6789 (class 0 OID 0)
-- Dependencies: 354
-- Name: TABLE entity_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.entity_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.entity_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.entity_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.entity_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.entity_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.entity_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.entity_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.entity_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6790 (class 0 OID 0)
-- Dependencies: 757
-- Name: SEQUENCE error_info_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.error_info_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.error_info_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.error_info_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.error_info_id_seq TO postgres;


--
-- TOC entry 6791 (class 0 OID 0)
-- Dependencies: 758
-- Name: SEQUENCE escalation_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.escalation_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.escalation_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.escalation_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.escalation_id_seq TO postgres;


--
-- TOC entry 6792 (class 0 OID 0)
-- Dependencies: 740
-- Name: TABLE eu_clli_codes; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.eu_clli_codes TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.eu_clli_codes TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.eu_clli_codes TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.eu_clli_codes TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.eu_clli_codes TO postgres;


--
-- TOC entry 6793 (class 0 OID 0)
-- Dependencies: 759
-- Name: SEQUENCE exec_error_info_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.exec_error_info_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.exec_error_info_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.exec_error_info_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.exec_error_info_id_seq TO postgres;


--
-- TOC entry 6794 (class 0 OID 0)
-- Dependencies: 531
-- Name: SEQUENCE facility_check_rules_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.facility_check_rules_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.facility_check_rules_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.facility_check_rules_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.facility_check_rules_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.facility_check_rules_seq TO postgres;


--
-- TOC entry 6795 (class 0 OID 0)
-- Dependencies: 532
-- Name: TABLE facility_check_rules; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.facility_check_rules TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.facility_check_rules TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.facility_check_rules TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.facility_check_rules TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.facility_check_rules TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.facility_check_rules TO postgres;


--
-- TOC entry 6796 (class 0 OID 0)
-- Dependencies: 256
-- Name: SEQUENCE file_attachment_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.file_attachment_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.file_attachment_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.file_attachment_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.file_attachment_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.file_attachment_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.file_attachment_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.file_attachment_seq TO prvgwy;


--
-- TOC entry 6797 (class 0 OID 0)
-- Dependencies: 355
-- Name: TABLE file_attachment; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.file_attachment TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.file_attachment TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.file_attachment TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.file_attachment TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.file_attachment TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.file_attachment TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.file_attachment TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.file_attachment TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6798 (class 0 OID 0)
-- Dependencies: 356
-- Name: TABLE file_data; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.file_data TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.file_data TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.file_data TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.file_data TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.file_data TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.file_data TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.file_data TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.file_data TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6799 (class 0 OID 0)
-- Dependencies: 721
-- Name: TABLE floor_val; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.floor_val TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.floor_val TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.floor_val TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.floor_val TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.floor_val TO postgres;


--
-- TOC entry 6800 (class 0 OID 0)
-- Dependencies: 732
-- Name: TABLE flyway_schema_history; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.flyway_schema_history TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.flyway_schema_history TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.flyway_schema_history TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.flyway_schema_history TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.flyway_schema_history TO postgres;


--
-- TOC entry 6801 (class 0 OID 0)
-- Dependencies: 905
-- Name: TABLE flywaytable1; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.flywaytable1 TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.flywaytable1 TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.flywaytable1 TO postgres;


--
-- TOC entry 6803 (class 0 OID 0)
-- Dependencies: 904
-- Name: SEQUENCE flywaytable1_user_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.flywaytable1_user_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.flywaytable1_user_id_seq TO postgres;


--
-- TOC entry 6804 (class 0 OID 0)
-- Dependencies: 697
-- Name: TABLE functional_area; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.functional_area TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.functional_area TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.functional_area TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.functional_area TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.functional_area TO postgres;


--
-- TOC entry 6805 (class 0 OID 0)
-- Dependencies: 484
-- Name: SEQUENCE hibernate_sequence; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.hibernate_sequence TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.hibernate_sequence TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.hibernate_sequence TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.hibernate_sequence TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.hibernate_sequence TO postgres;


--
-- TOC entry 6806 (class 0 OID 0)
-- Dependencies: 514
-- Name: SEQUENCE holiday_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.holiday_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.holiday_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.holiday_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.holiday_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.holiday_seq TO postgres;


--
-- TOC entry 6807 (class 0 OID 0)
-- Dependencies: 515
-- Name: TABLE holiday; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.holiday TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.holiday TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.holiday TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.holiday TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.holiday TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.holiday TO postgres;


--
-- TOC entry 6808 (class 0 OID 0)
-- Dependencies: 541
-- Name: TABLE holiday_admin; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.holiday_admin TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.holiday_admin TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.holiday_admin TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.holiday_admin TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.holiday_admin TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.holiday_admin TO postgres;


--
-- TOC entry 6809 (class 0 OID 0)
-- Dependencies: 513
-- Name: SEQUENCE holiday_admin_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.holiday_admin_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.holiday_admin_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.holiday_admin_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.holiday_admin_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.holiday_admin_seq TO postgres;


--
-- TOC entry 6810 (class 0 OID 0)
-- Dependencies: 760
-- Name: SEQUENCE i18ntext_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.i18ntext_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.i18ntext_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.i18ntext_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.i18ntext_id_seq TO postgres;


--
-- TOC entry 6811 (class 0 OID 0)
-- Dependencies: 358
-- Name: TABLE if_onenetwork_qe_automationcheck; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qe_automationcheck TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6812 (class 0 OID 0)
-- Dependencies: 357
-- Name: TABLE if_onenetwork_qeautomation; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qeautomation TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.if_onenetwork_qeautomation TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.if_onenetwork_qeautomation TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.if_onenetwork_qeautomation TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qeautomation TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qeautomation TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qeautomation TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.if_onenetwork_qeautomation TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6813 (class 0 OID 0)
-- Dependencies: 705
-- Name: TABLE ind_npa_nxx; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ind_npa_nxx TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ind_npa_nxx TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ind_npa_nxx TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ind_npa_nxx TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ind_npa_nxx TO postgres;


--
-- TOC entry 6814 (class 0 OID 0)
-- Dependencies: 704
-- Name: TABLE ind_switch; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ind_switch TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ind_switch TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ind_switch TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ind_switch TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ind_switch TO postgres;


--
-- TOC entry 6815 (class 0 OID 0)
-- Dependencies: 716
-- Name: TABLE "int"; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration."int" TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration."int" TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration."int" TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration."int" TO dbadmin;
GRANT ALL ON TABLE ng_orchestration."int" TO postgres;


--
-- TOC entry 6816 (class 0 OID 0)
-- Dependencies: 543
-- Name: TABLE interval_mapping; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.interval_mapping TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.interval_mapping TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.interval_mapping TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.interval_mapping TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.interval_mapping TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.interval_mapping TO postgres;


--
-- TOC entry 6817 (class 0 OID 0)
-- Dependencies: 495
-- Name: SEQUENCE jeop_config_param_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.jeop_config_param_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jeop_config_param_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jeop_config_param_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.jeop_config_param_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.jeop_config_param_seq TO postgres;


--
-- TOC entry 6818 (class 0 OID 0)
-- Dependencies: 496
-- Name: TABLE jeop_config_param; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.jeop_config_param TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.jeop_config_param TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.jeop_config_param TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.jeop_config_param TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.jeop_config_param TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.jeop_config_param TO postgres;


--
-- TOC entry 6819 (class 0 OID 0)
-- Dependencies: 502
-- Name: TABLE oldjeopardy_admin_docs; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.oldjeopardy_admin_docs TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.oldjeopardy_admin_docs TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.oldjeopardy_admin_docs TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.oldjeopardy_admin_docs TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.oldjeopardy_admin_docs TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.oldjeopardy_admin_docs TO postgres;


--
-- TOC entry 6821 (class 0 OID 0)
-- Dependencies: 504
-- Name: SEQUENCE jeopardy_admin_docs_jeop_admin_doc_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.jeopardy_admin_docs_jeop_admin_doc_id_seq TO postgres;


--
-- TOC entry 6822 (class 0 OID 0)
-- Dependencies: 505
-- Name: TABLE jeopardy_admin_docs; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.jeopardy_admin_docs TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.jeopardy_admin_docs TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.jeopardy_admin_docs TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.jeopardy_admin_docs TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.jeopardy_admin_docs TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.jeopardy_admin_docs TO postgres;


--
-- TOC entry 6823 (class 0 OID 0)
-- Dependencies: 493
-- Name: SEQUENCE jeopardy_transaction_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.jeopardy_transaction_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jeopardy_transaction_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jeopardy_transaction_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.jeopardy_transaction_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.jeopardy_transaction_seq TO postgres;


--
-- TOC entry 6824 (class 0 OID 0)
-- Dependencies: 494
-- Name: TABLE jeopardy_transaction; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.jeopardy_transaction TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.jeopardy_transaction TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.jeopardy_transaction TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.jeopardy_transaction TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.jeopardy_transaction TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.jeopardy_transaction TO postgres;


--
-- TOC entry 6825 (class 0 OID 0)
-- Dependencies: 257
-- Name: SEQUENCE jv_cdo_class_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.jv_cdo_class_seq TO prvgwy;


--
-- TOC entry 6826 (class 0 OID 0)
-- Dependencies: 906
-- Name: TABLE jv_commit_property; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.jv_commit_property TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.jv_commit_property TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.jv_commit_property TO postgres;


--
-- TOC entry 6827 (class 0 OID 0)
-- Dependencies: 258
-- Name: SEQUENCE jv_commit_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.jv_commit_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_commit_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_commit_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jv_commit_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_commit_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_commit_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.jv_commit_seq TO prvgwy;


--
-- TOC entry 6828 (class 0 OID 0)
-- Dependencies: 259
-- Name: SEQUENCE jv_global_id_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.jv_global_id_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_global_id_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_global_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jv_global_id_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_global_id_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_global_id_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.jv_global_id_seq TO prvgwy;


--
-- TOC entry 6829 (class 0 OID 0)
-- Dependencies: 260
-- Name: SEQUENCE jv_snapshot_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.jv_snapshot_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_snapshot_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.jv_snapshot_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.jv_snapshot_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_snapshot_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.jv_snapshot_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.jv_snapshot_seq TO prvgwy;


--
-- TOC entry 6830 (class 0 OID 0)
-- Dependencies: 542
-- Name: TABLE lam_interval; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.lam_interval TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.lam_interval TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.lam_interval TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.lam_interval TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.lam_interval TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.lam_interval TO postgres;


--
-- TOC entry 6831 (class 0 OID 0)
-- Dependencies: 500
-- Name: TABLE lci_admin_docs; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.lci_admin_docs TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.lci_admin_docs TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.lci_admin_docs TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.lci_admin_docs TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.lci_admin_docs TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.lci_admin_docs TO postgres;


--
-- TOC entry 6832 (class 0 OID 0)
-- Dependencies: 499
-- Name: SEQUENCE lci_admin_docs_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.lci_admin_docs_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.lci_admin_docs_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.lci_admin_docs_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.lci_admin_docs_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.lci_admin_docs_seq TO postgres;


--
-- TOC entry 6833 (class 0 OID 0)
-- Dependencies: 501
-- Name: TABLE lci_admin_docs_testlarge; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.lci_admin_docs_testlarge TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.lci_admin_docs_testlarge TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.lci_admin_docs_testlarge TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.lci_admin_docs_testlarge TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.lci_admin_docs_testlarge TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.lci_admin_docs_testlarge TO postgres;


--
-- TOC entry 6834 (class 0 OID 0)
-- Dependencies: 507
-- Name: TABLE lci_document_store; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.lci_document_store TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.lci_document_store TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.lci_document_store TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.lci_document_store TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.lci_document_store TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.lci_document_store TO postgres;


--
-- TOC entry 6836 (class 0 OID 0)
-- Dependencies: 506
-- Name: SEQUENCE lci_document_store_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.lci_document_store_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.lci_document_store_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.lci_document_store_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.lci_document_store_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.lci_document_store_seq TO postgres;


--
-- TOC entry 6837 (class 0 OID 0)
-- Dependencies: 649
-- Name: TABLE lookup_values; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.lookup_values TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.lookup_values TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.lookup_values TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.lookup_values TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.lookup_values TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.lookup_values TO postgres;


--
-- TOC entry 6838 (class 0 OID 0)
-- Dependencies: 554
-- Name: TABLE manifest_app_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.manifest_app_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.manifest_app_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_app_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_app_config TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.manifest_app_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.manifest_app_config TO postgres;


--
-- TOC entry 6840 (class 0 OID 0)
-- Dependencies: 553
-- Name: SEQUENCE manifest_app_config_app_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.manifest_app_config_app_id_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.manifest_app_config_app_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.manifest_app_config_app_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.manifest_app_config_app_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.manifest_app_config_app_id_seq TO postgres;


--
-- TOC entry 6843 (class 0 OID 0)
-- Dependencies: 556
-- Name: TABLE manifest_doc_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.manifest_doc_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.manifest_doc_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_doc_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_doc_config TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.manifest_doc_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.manifest_doc_config TO postgres;


--
-- TOC entry 6845 (class 0 OID 0)
-- Dependencies: 555
-- Name: SEQUENCE manifest_doc_config_doc_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.manifest_doc_config_doc_id_seq TO postgres;


--
-- TOC entry 6846 (class 0 OID 0)
-- Dependencies: 560
-- Name: TABLE manifest_document; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON TABLE ng_orchestration.manifest_document TO prvgwy_ro;
GRANT ALL ON TABLE ng_orchestration.manifest_document TO prvgwy;
GRANT SELECT ON TABLE ng_orchestration.manifest_document TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_document TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_document TO ng_orch_readwrite;


--
-- TOC entry 6847 (class 0 OID 0)
-- Dependencies: 727
-- Name: TABLE manifest_document_backup_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.manifest_document_backup_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_document_backup_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_document_backup_config TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.manifest_document_backup_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.manifest_document_backup_config TO postgres;


--
-- TOC entry 6848 (class 0 OID 0)
-- Dependencies: 657
-- Name: TABLE manifest_document_bkup_05_07_19; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.manifest_document_bkup_05_07_19 TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_document_bkup_05_07_19 TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_document_bkup_05_07_19 TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.manifest_document_bkup_05_07_19 TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.manifest_document_bkup_05_07_19 TO postgres;


--
-- TOC entry 6850 (class 0 OID 0)
-- Dependencies: 559
-- Name: SEQUENCE manifest_document_doc_id_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON SEQUENCE ng_orchestration.manifest_document_doc_id_seq TO prvgwy_ro;
GRANT ALL ON SEQUENCE ng_orchestration.manifest_document_doc_id_seq TO prvgwy;
GRANT SELECT ON SEQUENCE ng_orchestration.manifest_document_doc_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.manifest_document_doc_id_seq TO ng_orch_nodelete;


--
-- TOC entry 6851 (class 0 OID 0)
-- Dependencies: 654
-- Name: TABLE manifest_document_ordvalid_bkup_04_03; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.manifest_document_ordvalid_bkup_04_03 TO postgres;


--
-- TOC entry 6852 (class 0 OID 0)
-- Dependencies: 558
-- Name: TABLE manifest_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON TABLE ng_orchestration.manifest_entity TO prvgwy_ro;
GRANT ALL ON TABLE ng_orchestration.manifest_entity TO prvgwy;
GRANT SELECT ON TABLE ng_orchestration.manifest_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.manifest_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.manifest_entity TO ng_orch_readwrite;


--
-- TOC entry 6854 (class 0 OID 0)
-- Dependencies: 557
-- Name: SEQUENCE manifest_entity_entity_id_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON SEQUENCE ng_orchestration.manifest_entity_entity_id_seq TO prvgwy_ro;
GRANT ALL ON SEQUENCE ng_orchestration.manifest_entity_entity_id_seq TO prvgwy;
GRANT SELECT ON SEQUENCE ng_orchestration.manifest_entity_entity_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.manifest_entity_entity_id_seq TO ng_orch_nodelete;


--
-- TOC entry 6855 (class 0 OID 0)
-- Dependencies: 518
-- Name: SEQUENCE micro_service_tracker_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.micro_service_tracker_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.micro_service_tracker_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.micro_service_tracker_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.micro_service_tracker_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.micro_service_tracker_seq TO postgres;


--
-- TOC entry 6856 (class 0 OID 0)
-- Dependencies: 519
-- Name: TABLE micro_service_tracker; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.micro_service_tracker TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.micro_service_tracker TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.micro_service_tracker TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.micro_service_tracker TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.micro_service_tracker TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.micro_service_tracker TO postgres;


--
-- TOC entry 6857 (class 0 OID 0)
-- Dependencies: 544
-- Name: SEQUENCE micro_service_tracker_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.micro_service_tracker_id_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.micro_service_tracker_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.micro_service_tracker_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.micro_service_tracker_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.micro_service_tracker_id_seq TO postgres;


--
-- TOC entry 6858 (class 0 OID 0)
-- Dependencies: 261
-- Name: SEQUENCE milestone_order_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_order_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_order_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_order_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_seq TO prvgwy;


--
-- TOC entry 6859 (class 0 OID 0)
-- Dependencies: 359
-- Name: TABLE milestone_order; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_order TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_order TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_order TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_order TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_order TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_order TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_order TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_order TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6860 (class 0 OID 0)
-- Dependencies: 262
-- Name: SEQUENCE milestone_order_bak_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_bak_seq TO prvgwy;


--
-- TOC entry 6861 (class 0 OID 0)
-- Dependencies: 360
-- Name: TABLE milestone_order_bak; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_order_bak TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_order_bak TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_order_bak TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_order_bak TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_order_bak TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_order_bak TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_order_bak TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_order_bak TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6862 (class 0 OID 0)
-- Dependencies: 263
-- Name: SEQUENCE milestone_order_new_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_new_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_order_new_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_order_new_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_order_new_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_new_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_new_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_order_new_seq TO prvgwy;


--
-- TOC entry 6863 (class 0 OID 0)
-- Dependencies: 361
-- Name: TABLE milestone_order_new; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_order_new TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_order_new TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_order_new TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_order_new TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_order_new TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_order_new TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_order_new TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_order_new TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6864 (class 0 OID 0)
-- Dependencies: 264
-- Name: SEQUENCE milestone_template_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_template_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_seq TO prvgwy;


--
-- TOC entry 6865 (class 0 OID 0)
-- Dependencies: 362
-- Name: TABLE milestone_template; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_template TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_template TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_template TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_template TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_template TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_template TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6866 (class 0 OID 0)
-- Dependencies: 265
-- Name: SEQUENCE milestone_template_bak_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_bak_seq TO prvgwy;


--
-- TOC entry 6867 (class 0 OID 0)
-- Dependencies: 363
-- Name: TABLE milestone_template_bak; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_template_bak TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_template_bak TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_template_bak TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_template_bak TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_template_bak TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_template_bak TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template_bak TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template_bak TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6868 (class 0 OID 0)
-- Dependencies: 266
-- Name: SEQUENCE milestone_template_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_template_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_map_seq TO prvgwy;


--
-- TOC entry 6869 (class 0 OID 0)
-- Dependencies: 364
-- Name: TABLE milestone_template_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_template_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_template_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_template_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_template_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_template_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_template_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6870 (class 0 OID 0)
-- Dependencies: 267
-- Name: SEQUENCE milestone_template_new_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_new_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_new_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.milestone_template_new_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.milestone_template_new_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_new_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_new_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.milestone_template_new_seq TO prvgwy;


--
-- TOC entry 6871 (class 0 OID 0)
-- Dependencies: 365
-- Name: TABLE milestone_template_new; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.milestone_template_new TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.milestone_template_new TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.milestone_template_new TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.milestone_template_new TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.milestone_template_new TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.milestone_template_new TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template_new TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.milestone_template_new TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6872 (class 0 OID 0)
-- Dependencies: 687
-- Name: TABLE nci_code; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.nci_code TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.nci_code TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.nci_code TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.nci_code TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.nci_code TO postgres;


--
-- TOC entry 6873 (class 0 OID 0)
-- Dependencies: 708
-- Name: TABLE network_channel; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.network_channel TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.network_channel TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.network_channel TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.network_channel TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.network_channel TO postgres;


--
-- TOC entry 6874 (class 0 OID 0)
-- Dependencies: 508
-- Name: SEQUENCE nid_automation_ext_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.nid_automation_ext_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.nid_automation_ext_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.nid_automation_ext_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.nid_automation_ext_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.nid_automation_ext_seq TO postgres;


--
-- TOC entry 6875 (class 0 OID 0)
-- Dependencies: 509
-- Name: TABLE nid_automation_ext; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.nid_automation_ext TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.nid_automation_ext TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.nid_automation_ext TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.nid_automation_ext TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.nid_automation_ext TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.nid_automation_ext TO postgres;


--
-- TOC entry 6876 (class 0 OID 0)
-- Dependencies: 761
-- Name: SEQUENCE node_inst_log_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.node_inst_log_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.node_inst_log_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.node_inst_log_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.node_inst_log_id_seq TO postgres;


--
-- TOC entry 6877 (class 0 OID 0)
-- Dependencies: 762
-- Name: SEQUENCE notification_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.notification_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.notification_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.notification_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.notification_id_seq TO postgres;


--
-- TOC entry 6878 (class 0 OID 0)
-- Dependencies: 702
-- Name: TABLE npa_nxx; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.npa_nxx TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.npa_nxx TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.npa_nxx TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.npa_nxx TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.npa_nxx TO postgres;


--
-- TOC entry 6879 (class 0 OID 0)
-- Dependencies: 561
-- Name: TABLE ntwk_channel_codes; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ntwk_channel_codes TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ntwk_channel_codes TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ntwk_channel_codes TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ntwk_channel_codes TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ntwk_channel_codes TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ntwk_channel_codes TO postgres;


--
-- TOC entry 6880 (class 0 OID 0)
-- Dependencies: 903
-- Name: TABLE numdaysflt; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.numdaysflt TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.numdaysflt TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.numdaysflt TO postgres;


--
-- TOC entry 6881 (class 0 OID 0)
-- Dependencies: 725
-- Name: TABLE "numeric"; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration."numeric" TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration."numeric" TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration."numeric" TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration."numeric" TO dbadmin;
GRANT ALL ON TABLE ng_orchestration."numeric" TO postgres;


--
-- TOC entry 6882 (class 0 OID 0)
-- Dependencies: 908
-- Name: TABLE ods_book_test; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_book_test TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_book_test TO postgres;


--
-- TOC entry 6883 (class 0 OID 0)
-- Dependencies: 528
-- Name: TABLE ods_document_store; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_document_store TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ods_document_store TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_document_store TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_document_store TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_document_store TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_document_store TO postgres;


--
-- TOC entry 6885 (class 0 OID 0)
-- Dependencies: 527
-- Name: SEQUENCE ods_document_store_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.ods_document_store_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_document_store_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_document_store_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.ods_document_store_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_document_store_seq TO postgres;


--
-- TOC entry 6886 (class 0 OID 0)
-- Dependencies: 268
-- Name: SEQUENCE ods_interface_request_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_interface_request_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_interface_request_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_interface_request_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_interface_request_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_interface_request_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_interface_request_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_interface_request_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6887 (class 0 OID 0)
-- Dependencies: 366
-- Name: TABLE ods_interface_request; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.ods_interface_request TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_interface_request TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_interface_request TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_interface_request TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_interface_request TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_interface_request TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_interface_request TO postgres;


--
-- TOC entry 6888 (class 0 OID 0)
-- Dependencies: 731
-- Name: TABLE ods_interface_request_temp; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_interface_request_temp TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_interface_request_temp TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_interface_request_temp TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_interface_request_temp TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_interface_request_temp TO postgres;


--
-- TOC entry 6889 (class 0 OID 0)
-- Dependencies: 269
-- Name: SEQUENCE ods_mandatory_attrs_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_mandatory_attrs_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6890 (class 0 OID 0)
-- Dependencies: 367
-- Name: TABLE ods_mandatory_attrs; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_mandatory_attrs TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_mandatory_attrs TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_mandatory_attrs TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_mandatory_attrs TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_mandatory_attrs TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_mandatory_attrs TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_mandatory_attrs TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_mandatory_attrs TO postgres;


--
-- TOC entry 6891 (class 0 OID 0)
-- Dependencies: 270
-- Name: SEQUENCE ods_milestone_config_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_config_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6892 (class 0 OID 0)
-- Dependencies: 368
-- Name: TABLE ods_milestone_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_milestone_config TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_milestone_config TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_milestone_config TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_milestone_config TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_config TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_config TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_config TO postgres;


--
-- TOC entry 6893 (class 0 OID 0)
-- Dependencies: 271
-- Name: SEQUENCE ods_milestone_transaction_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_milestone_transaction_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6894 (class 0 OID 0)
-- Dependencies: 369
-- Name: TABLE ods_milestone_transaction; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_milestone_transaction TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_milestone_transaction TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_milestone_transaction TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_milestone_transaction TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_transaction TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_transaction TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_transaction TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_milestone_transaction TO postgres;


--
-- TOC entry 6895 (class 0 OID 0)
-- Dependencies: 489
-- Name: SEQUENCE ods_notification_config_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.ods_notification_config_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_notification_config_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_notification_config_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.ods_notification_config_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_notification_config_seq TO postgres;


--
-- TOC entry 6896 (class 0 OID 0)
-- Dependencies: 490
-- Name: TABLE ods_notification_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_notification_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ods_notification_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_notification_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_notification_config TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_notification_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_notification_config TO postgres;


--
-- TOC entry 6897 (class 0 OID 0)
-- Dependencies: 491
-- Name: SEQUENCE ods_notification_transaction_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.ods_notification_transaction_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_notification_transaction_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_notification_transaction_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.ods_notification_transaction_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_notification_transaction_seq TO postgres;


--
-- TOC entry 6898 (class 0 OID 0)
-- Dependencies: 492
-- Name: TABLE ods_notification_transaction; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_notification_transaction TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ods_notification_transaction TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_notification_transaction TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_notification_transaction TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_notification_transaction TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_notification_transaction TO postgres;


--
-- TOC entry 6899 (class 0 OID 0)
-- Dependencies: 272
-- Name: SEQUENCE ods_param_config_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_param_config_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_param_config_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_param_config_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_param_config_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_param_config_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_param_config_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_param_config_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6900 (class 0 OID 0)
-- Dependencies: 370
-- Name: TABLE ods_param_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_param_config TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_param_config TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_param_config TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_param_config TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_param_config TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_param_config TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_param_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_param_config TO postgres;


--
-- TOC entry 6901 (class 0 OID 0)
-- Dependencies: 735
-- Name: SEQUENCE ods_request_log_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.ods_request_log_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_request_log_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_log_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_log_seq TO postgres;


--
-- TOC entry 6902 (class 0 OID 0)
-- Dependencies: 486
-- Name: TABLE ods_request_log; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_request_log TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_request_log TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_request_log TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_request_log TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_request_log TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_request_log TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_request_log TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_request_log TO postgres;


--
-- TOC entry 6904 (class 0 OID 0)
-- Dependencies: 485
-- Name: SEQUENCE ods_request_log_ods_request_log_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_log_ods_request_log_id_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6905 (class 0 OID 0)
-- Dependencies: 739
-- Name: TABLE ods_request_log_temp; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_request_log_temp TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_request_log_temp TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_request_log_temp TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_request_log_temp TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_request_log_temp TO postgres;


--
-- TOC entry 6906 (class 0 OID 0)
-- Dependencies: 273
-- Name: SEQUENCE ods_request_transaction_id_map_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_request_transaction_id_map_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6907 (class 0 OID 0)
-- Dependencies: 371
-- Name: TABLE ods_request_transaction_id_map; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_request_transaction_id_map TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_request_transaction_id_map TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_request_transaction_id_map TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_request_transaction_id_map TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_request_transaction_id_map TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_request_transaction_id_map TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_request_transaction_id_map TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_request_transaction_id_map TO postgres;


--
-- TOC entry 6908 (class 0 OID 0)
-- Dependencies: 497
-- Name: TABLE ods_response_param_map; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_response_param_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ods_response_param_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_response_param_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_response_param_map TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_response_param_map TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_response_param_map TO postgres;


--
-- TOC entry 6909 (class 0 OID 0)
-- Dependencies: 274
-- Name: SEQUENCE ods_response_transaction_id_map_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_response_transaction_id_map_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6910 (class 0 OID 0)
-- Dependencies: 372
-- Name: TABLE ods_response_transaction_id_map; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_response_transaction_id_map TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_response_transaction_id_map TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_response_transaction_id_map TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_response_transaction_id_map TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_response_transaction_id_map TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_response_transaction_id_map TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_response_transaction_id_map TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_response_transaction_id_map TO postgres;


--
-- TOC entry 6911 (class 0 OID 0)
-- Dependencies: 487
-- Name: SEQUENCE ods_scheduler_lock_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.ods_scheduler_lock_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_scheduler_lock_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_scheduler_lock_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.ods_scheduler_lock_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_scheduler_lock_seq TO postgres;


--
-- TOC entry 6912 (class 0 OID 0)
-- Dependencies: 488
-- Name: TABLE ods_scheduler_lock; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_scheduler_lock TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ods_scheduler_lock TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_scheduler_lock TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_scheduler_lock TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_scheduler_lock TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_scheduler_lock TO postgres;


--
-- TOC entry 6913 (class 0 OID 0)
-- Dependencies: 275
-- Name: SEQUENCE ods_service_route_map_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_service_route_map_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6914 (class 0 OID 0)
-- Dependencies: 373
-- Name: TABLE ods_service_route_map; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_service_route_map TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_service_route_map TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_service_route_map TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_service_route_map TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_service_route_map TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_service_route_map TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_service_route_map TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_service_route_map TO postgres;


--
-- TOC entry 6915 (class 0 OID 0)
-- Dependencies: 276
-- Name: SEQUENCE ods_transformer_config_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_transformer_config_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6916 (class 0 OID 0)
-- Dependencies: 374
-- Name: TABLE ods_transformer_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_transformer_config TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_transformer_config TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_transformer_config TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_transformer_config TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_transformer_config TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_transformer_config TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_transformer_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_transformer_config TO postgres;


--
-- TOC entry 6917 (class 0 OID 0)
-- Dependencies: 498
-- Name: TABLE ods_wf_correlation_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.ods_wf_correlation_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ods_wf_correlation_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_wf_correlation_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ods_wf_correlation_config TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.ods_wf_correlation_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_wf_correlation_config TO postgres;


--
-- TOC entry 6918 (class 0 OID 0)
-- Dependencies: 277
-- Name: SEQUENCE ods_workflow_fallout_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6919 (class 0 OID 0)
-- Dependencies: 375
-- Name: TABLE ods_workflow_fallout; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_workflow_fallout TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_workflow_fallout TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_workflow_fallout TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout TO postgres;


--
-- TOC entry 6920 (class 0 OID 0)
-- Dependencies: 278
-- Name: SEQUENCE ods_workflow_fallout_config_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT USAGE ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO postgres;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ods_workflow_fallout_config_seq TO prvgwy;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6921 (class 0 OID 0)
-- Dependencies: 376
-- Name: TABLE ods_workflow_fallout_config; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_config TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_workflow_fallout_config TO prvgwy_ro;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT ON TABLE ng_orchestration.ods_workflow_fallout_config TO ng_orch_readonly;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ods_workflow_fallout_config TO ng_orch_nodelete;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_config TO prvgwy;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_config TO ng_orch_readwrite;
RESET SESSION AUTHORIZATION;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_config TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_config TO postgres;


--
-- TOC entry 6922 (class 0 OID 0)
-- Dependencies: 907
-- Name: TABLE ods_workflow_fallout_temp; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_temp TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.ods_workflow_fallout_temp TO postgres;


--
-- TOC entry 6923 (class 0 OID 0)
-- Dependencies: 279
-- Name: SEQUENCE onenet_common_parameter_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_common_parameter_seq TO prvgwy;


--
-- TOC entry 6924 (class 0 OID 0)
-- Dependencies: 377
-- Name: TABLE onenet_common_parameter; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.onenet_common_parameter TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.onenet_common_parameter TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.onenet_common_parameter TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.onenet_common_parameter TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.onenet_common_parameter TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.onenet_common_parameter TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_common_parameter TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_common_parameter TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6925 (class 0 OID 0)
-- Dependencies: 280
-- Name: SEQUENCE onenet_holiday_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.onenet_holiday_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_holiday_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_holiday_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.onenet_holiday_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_holiday_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_holiday_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_holiday_seq TO prvgwy;


--
-- TOC entry 6926 (class 0 OID 0)
-- Dependencies: 378
-- Name: TABLE onenet_holiday; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.onenet_holiday TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.onenet_holiday TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.onenet_holiday TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.onenet_holiday TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.onenet_holiday TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.onenet_holiday TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_holiday TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_holiday TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6927 (class 0 OID 0)
-- Dependencies: 281
-- Name: SEQUENCE onenet_milestone_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.onenet_milestone_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_milestone_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_milestone_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.onenet_milestone_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_milestone_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_milestone_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_milestone_seq TO prvgwy;


--
-- TOC entry 6928 (class 0 OID 0)
-- Dependencies: 379
-- Name: TABLE onenet_milestone; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.onenet_milestone TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.onenet_milestone TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.onenet_milestone TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.onenet_milestone TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.onenet_milestone TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.onenet_milestone TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_milestone TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_milestone TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6929 (class 0 OID 0)
-- Dependencies: 282
-- Name: SEQUENCE onenet_order_build_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_build_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_order_build_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_order_build_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.onenet_order_build_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_build_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_build_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_build_seq TO prvgwy;


--
-- TOC entry 6930 (class 0 OID 0)
-- Dependencies: 380
-- Name: TABLE onenet_order_build; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.onenet_order_build TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.onenet_order_build TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.onenet_order_build TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.onenet_order_build TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.onenet_order_build TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.onenet_order_build TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_order_build TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_order_build TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6931 (class 0 OID 0)
-- Dependencies: 283
-- Name: SEQUENCE onenet_order_data_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_data_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_order_data_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_order_data_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.onenet_order_data_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_data_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_data_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_order_data_seq TO prvgwy;


--
-- TOC entry 6932 (class 0 OID 0)
-- Dependencies: 381
-- Name: TABLE onenet_order_data; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.onenet_order_data TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.onenet_order_data TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.onenet_order_data TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.onenet_order_data TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.onenet_order_data TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.onenet_order_data TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_order_data TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_order_data TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6933 (class 0 OID 0)
-- Dependencies: 284
-- Name: SEQUENCE onenet_transaction_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.onenet_transaction_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_transaction_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.onenet_transaction_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.onenet_transaction_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_transaction_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_transaction_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.onenet_transaction_seq TO prvgwy;


--
-- TOC entry 6934 (class 0 OID 0)
-- Dependencies: 382
-- Name: TABLE onenet_transaction; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.onenet_transaction TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.onenet_transaction TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.onenet_transaction TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.onenet_transaction TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.onenet_transaction TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.onenet_transaction TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_transaction TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.onenet_transaction TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6935 (class 0 OID 0)
-- Dependencies: 285
-- Name: SEQUENCE ordchange_msg_config_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.ordchange_msg_config_seq TO prvgwy;


--
-- TOC entry 6936 (class 0 OID 0)
-- Dependencies: 383
-- Name: TABLE ordchange_msg_config; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.ordchange_msg_config TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.ordchange_msg_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.ordchange_msg_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.ordchange_msg_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.ordchange_msg_config TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.ordchange_msg_config TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ordchange_msg_config TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.ordchange_msg_config TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6937 (class 0 OID 0)
-- Dependencies: 465
-- Name: TABLE orders; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON TABLE ng_orchestration.orders TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.orders TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.orders TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.orders TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.orders TO ng_orch_readwrite;


--
-- TOC entry 6938 (class 0 OID 0)
-- Dependencies: 729
-- Name: TABLE orders_count_past_due; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.orders_count_past_due TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.orders_count_past_due TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.orders_count_past_due TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.orders_count_past_due TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.orders_count_past_due TO postgres;


--
-- TOC entry 6939 (class 0 OID 0)
-- Dependencies: 730
-- Name: TABLE orders_count_upcoming; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.orders_count_upcoming TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.orders_count_upcoming TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.orders_count_upcoming TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.orders_count_upcoming TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.orders_count_upcoming TO postgres;


--
-- TOC entry 6940 (class 0 OID 0)
-- Dependencies: 695
-- Name: TABLE organization; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.organization TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.organization TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.organization TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.organization TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.organization TO postgres;


--
-- TOC entry 6941 (class 0 OID 0)
-- Dependencies: 775
-- Name: TABLE organizationalentity; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.organizationalentity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.organizationalentity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.organizationalentity TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.organizationalentity TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.organizationalentity TO postgres;


--
-- TOC entry 6942 (class 0 OID 0)
-- Dependencies: 722
-- Name: TABLE p_date; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.p_date TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.p_date TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.p_date TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.p_date TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.p_date TO postgres;


--
-- TOC entry 6943 (class 0 OID 0)
-- Dependencies: 660
-- Name: TABLE pipeline_setting; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.pipeline_setting TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.pipeline_setting TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.pipeline_setting TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.pipeline_setting TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.pipeline_setting TO postgres;


--
-- TOC entry 6945 (class 0 OID 0)
-- Dependencies: 659
-- Name: SEQUENCE pipeline_setting_pipeline_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.pipeline_setting_pipeline_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.pipeline_setting_pipeline_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.pipeline_setting_pipeline_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.pipeline_setting_pipeline_id_seq TO postgres;


--
-- TOC entry 6946 (class 0 OID 0)
-- Dependencies: 523
-- Name: SEQUENCE pn_region_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.pn_region_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.pn_region_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.pn_region_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.pn_region_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.pn_region_seq TO postgres;


--
-- TOC entry 6947 (class 0 OID 0)
-- Dependencies: 524
-- Name: TABLE pn_region; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.pn_region TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.pn_region TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.pn_region TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.pn_region TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.pn_region TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.pn_region TO postgres;


--
-- TOC entry 6948 (class 0 OID 0)
-- Dependencies: 525
-- Name: SEQUENCE pn_state_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.pn_state_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.pn_state_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.pn_state_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.pn_state_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.pn_state_seq TO postgres;


--
-- TOC entry 6949 (class 0 OID 0)
-- Dependencies: 526
-- Name: TABLE pn_state; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.pn_state TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.pn_state TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.pn_state TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.pn_state TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.pn_state TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.pn_state TO postgres;


--
-- TOC entry 6950 (class 0 OID 0)
-- Dependencies: 902
-- Name: TABLE preference_group; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.preference_group TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.preference_group TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.preference_group TO postgres;


--
-- TOC entry 6951 (class 0 OID 0)
-- Dependencies: 548
-- Name: SEQUENCE prism_seq_id; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.prism_seq_id TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.prism_seq_id TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.prism_seq_id TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.prism_seq_id TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.prism_seq_id TO postgres;


--
-- TOC entry 6952 (class 0 OID 0)
-- Dependencies: 763
-- Name: SEQUENCE proc_inst_log_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.proc_inst_log_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.proc_inst_log_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.proc_inst_log_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.proc_inst_log_id_seq TO postgres;


--
-- TOC entry 6953 (class 0 OID 0)
-- Dependencies: 764
-- Name: SEQUENCE process_instance_info_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.process_instance_info_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.process_instance_info_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.process_instance_info_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.process_instance_info_id_seq TO postgres;


--
-- TOC entry 6954 (class 0 OID 0)
-- Dependencies: 741
-- Name: TABLE product_unbld; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.product_unbld TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.product_unbld TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.product_unbld TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.product_unbld TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.product_unbld TO postgres;


--
-- TOC entry 6955 (class 0 OID 0)
-- Dependencies: 286
-- Name: SEQUENCE project_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.project_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.project_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.project_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.project_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.project_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.project_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.project_seq TO prvgwy;


--
-- TOC entry 6956 (class 0 OID 0)
-- Dependencies: 384
-- Name: TABLE project; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.project TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.project TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.project TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.project TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.project TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.project TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.project TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.project TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6957 (class 0 OID 0)
-- Dependencies: 385
-- Name: TABLE project_cmd_cache; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.project_cmd_cache TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.project_cmd_cache TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.project_cmd_cache TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.project_cmd_cache TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.project_cmd_cache TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.project_cmd_cache TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.project_cmd_cache TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.project_cmd_cache TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6958 (class 0 OID 0)
-- Dependencies: 287
-- Name: SEQUENCE project_details_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.project_details_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.project_details_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.project_details_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.project_details_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.project_details_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.project_details_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.project_details_seq TO prvgwy;


--
-- TOC entry 6959 (class 0 OID 0)
-- Dependencies: 386
-- Name: TABLE project_details; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.project_details TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.project_details TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.project_details TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.project_details TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.project_details TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.project_details TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.project_details TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.project_details TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6960 (class 0 OID 0)
-- Dependencies: 387
-- Name: TABLE qrtz_blob_triggers; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_blob_triggers TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_blob_triggers TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_blob_triggers TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_blob_triggers TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_blob_triggers TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_blob_triggers TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_blob_triggers TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_blob_triggers TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6961 (class 0 OID 0)
-- Dependencies: 388
-- Name: TABLE qrtz_calendars; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_calendars TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_calendars TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_calendars TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_calendars TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_calendars TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_calendars TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_calendars TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_calendars TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6962 (class 0 OID 0)
-- Dependencies: 389
-- Name: TABLE qrtz_cron_triggers; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_cron_triggers TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_cron_triggers TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_cron_triggers TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_cron_triggers TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_cron_triggers TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_cron_triggers TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_cron_triggers TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_cron_triggers TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6963 (class 0 OID 0)
-- Dependencies: 390
-- Name: TABLE qrtz_fired_triggers; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_fired_triggers TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_fired_triggers TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_fired_triggers TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_fired_triggers TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_fired_triggers TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_fired_triggers TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_fired_triggers TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_fired_triggers TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6964 (class 0 OID 0)
-- Dependencies: 391
-- Name: TABLE qrtz_job_details; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_job_details TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_job_details TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_job_details TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_job_details TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_job_details TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_job_details TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_job_details TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_job_details TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6965 (class 0 OID 0)
-- Dependencies: 392
-- Name: TABLE qrtz_locks; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_locks TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_locks TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_locks TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_locks TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_locks TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_locks TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_locks TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_locks TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6966 (class 0 OID 0)
-- Dependencies: 393
-- Name: TABLE qrtz_paused_trigger_grps; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_paused_trigger_grps TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6967 (class 0 OID 0)
-- Dependencies: 394
-- Name: TABLE qrtz_scheduler_state; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_scheduler_state TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_scheduler_state TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_scheduler_state TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_scheduler_state TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_scheduler_state TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_scheduler_state TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_scheduler_state TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_scheduler_state TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6968 (class 0 OID 0)
-- Dependencies: 395
-- Name: TABLE qrtz_simple_triggers; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_simple_triggers TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_simple_triggers TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_simple_triggers TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_simple_triggers TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_simple_triggers TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_simple_triggers TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_simple_triggers TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_simple_triggers TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6969 (class 0 OID 0)
-- Dependencies: 396
-- Name: TABLE qrtz_simprop_triggers; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_simprop_triggers TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_simprop_triggers TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_simprop_triggers TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_simprop_triggers TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_simprop_triggers TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_simprop_triggers TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_simprop_triggers TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_simprop_triggers TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6970 (class 0 OID 0)
-- Dependencies: 397
-- Name: TABLE qrtz_triggers; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.qrtz_triggers TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.qrtz_triggers TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.qrtz_triggers TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.qrtz_triggers TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.qrtz_triggers TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.qrtz_triggers TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_triggers TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.qrtz_triggers TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6971 (class 0 OID 0)
-- Dependencies: 765
-- Name: SEQUENCE query_def_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.query_def_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.query_def_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.query_def_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.query_def_id_seq TO postgres;


--
-- TOC entry 6972 (class 0 OID 0)
-- Dependencies: 470
-- Name: TABLE raj; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.raj TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.raj TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.raj TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.raj TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.raj TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.raj TO postgres;


--
-- TOC entry 6973 (class 0 OID 0)
-- Dependencies: 481
-- Name: TABLE rajtest; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.rajtest TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.rajtest TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.rajtest TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.rajtest TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.rajtest TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.rajtest TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.rajtest TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.rajtest TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6975 (class 0 OID 0)
-- Dependencies: 480
-- Name: SEQUENCE rajtest_id_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.rajtest_id_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.rajtest_id_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.rajtest_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.rajtest_id_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.rajtest_id_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.rajtest_id_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.rajtest_id_seq TO prvgwy;


--
-- TOC entry 6976 (class 0 OID 0)
-- Dependencies: 776
-- Name: TABLE reassignment; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.reassignment TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.reassignment TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.reassignment TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.reassignment TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.reassignment TO postgres;


--
-- TOC entry 6977 (class 0 OID 0)
-- Dependencies: 766
-- Name: SEQUENCE reassignment_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.reassignment_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.reassignment_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.reassignment_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.reassignment_id_seq TO postgres;


--
-- TOC entry 6978 (class 0 OID 0)
-- Dependencies: 538
-- Name: SEQUENCE region_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.region_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.region_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.region_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.region_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.region_seq TO postgres;


--
-- TOC entry 6979 (class 0 OID 0)
-- Dependencies: 539
-- Name: TABLE region; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.region TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.region TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.region TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.region TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.region TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.region TO postgres;


--
-- TOC entry 6980 (class 0 OID 0)
-- Dependencies: 767
-- Name: SEQUENCE request_info_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.request_info_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.request_info_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.request_info_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.request_info_id_seq TO postgres;


--
-- TOC entry 6981 (class 0 OID 0)
-- Dependencies: 706
-- Name: TABLE rn_line_code; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.rn_line_code TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.rn_line_code TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.rn_line_code TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.rn_line_code TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.rn_line_code TO postgres;


--
-- TOC entry 6982 (class 0 OID 0)
-- Dependencies: 696
-- Name: TABLE rn_user_ext; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.rn_user_ext TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.rn_user_ext TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.rn_user_ext TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.rn_user_ext TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.rn_user_ext TO postgres;


--
-- TOC entry 6983 (class 0 OID 0)
-- Dependencies: 530
-- Name: TABLE rqn_document_store; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.rqn_document_store TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.rqn_document_store TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.rqn_document_store TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.rqn_document_store TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.rqn_document_store TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.rqn_document_store TO postgres;


--
-- TOC entry 6985 (class 0 OID 0)
-- Dependencies: 529
-- Name: SEQUENCE rqn_document_store_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.rqn_document_store_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.rqn_document_store_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.rqn_document_store_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.rqn_document_store_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.rqn_document_store_seq TO postgres;


--
-- TOC entry 6986 (class 0 OID 0)
-- Dependencies: 662
-- Name: TABLE saved_columns; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.saved_columns TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.saved_columns TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.saved_columns TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.saved_columns TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.saved_columns TO postgres;


--
-- TOC entry 6988 (class 0 OID 0)
-- Dependencies: 661
-- Name: SEQUENCE saved_columns_saved_column_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.saved_columns_saved_column_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.saved_columns_saved_column_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.saved_columns_saved_column_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.saved_columns_saved_column_id_seq TO postgres;


--
-- TOC entry 6989 (class 0 OID 0)
-- Dependencies: 288
-- Name: SEQUENCE search_cache_event_monitor_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.search_cache_event_monitor_seq TO prvgwy;


--
-- TOC entry 6990 (class 0 OID 0)
-- Dependencies: 398
-- Name: TABLE search_cache_event_monitor; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.search_cache_event_monitor TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.search_cache_event_monitor TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.search_cache_event_monitor TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.search_cache_event_monitor TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.search_cache_event_monitor TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.search_cache_event_monitor TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.search_cache_event_monitor TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.search_cache_event_monitor TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 6991 (class 0 OID 0)
-- Dependencies: 694
-- Name: TABLE sec_groups; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sec_groups TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sec_groups TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sec_groups TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sec_groups TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sec_groups TO postgres;


--
-- TOC entry 6992 (class 0 OID 0)
-- Dependencies: 692
-- Name: TABLE sec_users; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sec_users TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sec_users TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sec_users TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sec_users TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sec_users TO postgres;


--
-- TOC entry 6993 (class 0 OID 0)
-- Dependencies: 663
-- Name: TABLE service_determination_details; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.service_determination_details TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.service_determination_details TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.service_determination_details TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.service_determination_details TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.service_determination_details TO postgres;


--
-- TOC entry 6994 (class 0 OID 0)
-- Dependencies: 552
-- Name: TABLE service_flavor; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.service_flavor TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.service_flavor TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.service_flavor TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.service_flavor TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.service_flavor TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.service_flavor TO postgres;


--
-- TOC entry 6995 (class 0 OID 0)
-- Dependencies: 512
-- Name: TABLE service_request; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.service_request TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.service_request TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.service_request TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.service_request TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.service_request TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.service_request TO postgres;


--
-- TOC entry 6996 (class 0 OID 0)
-- Dependencies: 551
-- Name: TABLE service_type; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.service_type TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.service_type TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.service_type TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.service_type TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.service_type TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.service_type TO postgres;


--
-- TOC entry 6997 (class 0 OID 0)
-- Dependencies: 550
-- Name: TABLE service_type_category; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.service_type_category TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.service_type_category TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.service_type_category TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.service_type_category TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.service_type_category TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.service_type_category TO postgres;


--
-- TOC entry 6998 (class 0 OID 0)
-- Dependencies: 768
-- Name: SEQUENCE sessioninfo_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.sessioninfo_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.sessioninfo_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.sessioninfo_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.sessioninfo_id_seq TO postgres;


--
-- TOC entry 6999 (class 0 OID 0)
-- Dependencies: 658
-- Name: TABLE spog_user_settings; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.spog_user_settings TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.spog_user_settings TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.spog_user_settings TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.spog_user_settings TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.spog_user_settings TO postgres;


--
-- TOC entry 7000 (class 0 OID 0)
-- Dependencies: 717
-- Name: SEQUENCE sr_address_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.sr_address_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.sr_address_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.sr_address_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.sr_address_id_seq TO postgres;


--
-- TOC entry 7001 (class 0 OID 0)
-- Dependencies: 710
-- Name: TABLE sr_address_info; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_address_info TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_address_info TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_address_info TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_address_info TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_address_info TO postgres;


--
-- TOC entry 7002 (class 0 OID 0)
-- Dependencies: 690
-- Name: TABLE sr_ckl_fmc; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_ckl_fmc TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_ckl_fmc TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_ckl_fmc TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_ckl_fmc TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_ckl_fmc TO postgres;


--
-- TOC entry 7003 (class 0 OID 0)
-- Dependencies: 709
-- Name: TABLE sr_ckl_sales; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_ckl_sales TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_ckl_sales TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_ckl_sales TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_ckl_sales TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_ckl_sales TO postgres;


--
-- TOC entry 7004 (class 0 OID 0)
-- Dependencies: 724
-- Name: SEQUENCE sr_equipment_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.sr_equipment_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.sr_equipment_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.sr_equipment_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.sr_equipment_id_seq TO postgres;


--
-- TOC entry 7005 (class 0 OID 0)
-- Dependencies: 688
-- Name: TABLE sr_essm_info; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_essm_info TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_essm_info TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_essm_info TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_essm_info TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_essm_info TO postgres;


--
-- TOC entry 7006 (class 0 OID 0)
-- Dependencies: 707
-- Name: TABLE sr_milestones; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_milestones TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_milestones TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_milestones TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_milestones TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_milestones TO postgres;


--
-- TOC entry 7007 (class 0 OID 0)
-- Dependencies: 720
-- Name: TABLE sr_problem_code; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_problem_code TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_problem_code TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_problem_code TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_problem_code TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_problem_code TO postgres;


--
-- TOC entry 7008 (class 0 OID 0)
-- Dependencies: 723
-- Name: SEQUENCE sr_remark_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.sr_remark_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.sr_remark_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.sr_remark_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.sr_remark_id_seq TO postgres;


--
-- TOC entry 7009 (class 0 OID 0)
-- Dependencies: 516
-- Name: TABLE sr_sales; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.sr_sales TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.sr_sales TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.sr_sales TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.sr_sales TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.sr_sales TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.sr_sales TO postgres;


--
-- TOC entry 7010 (class 0 OID 0)
-- Dependencies: 533
-- Name: SEQUENCE state_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.state_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.state_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.state_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.state_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.state_seq TO postgres;


--
-- TOC entry 7011 (class 0 OID 0)
-- Dependencies: 534
-- Name: TABLE state; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.state TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.state TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.state TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.state TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.state TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.state TO postgres;


--
-- TOC entry 7012 (class 0 OID 0)
-- Dependencies: 535
-- Name: TABLE state_plan_map; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.state_plan_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.state_plan_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.state_plan_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.state_plan_map TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.state_plan_map TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.state_plan_map TO postgres;


--
-- TOC entry 7013 (class 0 OID 0)
-- Dependencies: 540
-- Name: TABLE state_region; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.state_region TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.state_region TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.state_region TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.state_region TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.state_region TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.state_region TO postgres;


--
-- TOC entry 7014 (class 0 OID 0)
-- Dependencies: 545
-- Name: SEQUENCE std_interval_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.std_interval_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.std_interval_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.std_interval_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.std_interval_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.std_interval_seq TO postgres;


--
-- TOC entry 7015 (class 0 OID 0)
-- Dependencies: 546
-- Name: TABLE std_interval; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.std_interval TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.std_interval TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.std_interval TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.std_interval TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.std_interval TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.std_interval TO postgres;


--
-- TOC entry 7016 (class 0 OID 0)
-- Dependencies: 703
-- Name: TABLE switch; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.switch TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.switch TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.switch TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.switch TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.switch TO postgres;


--
-- TOC entry 7017 (class 0 OID 0)
-- Dependencies: 562
-- Name: TABLE switch_cotype; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.switch_cotype TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.switch_cotype TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.switch_cotype TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.switch_cotype TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.switch_cotype TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.switch_cotype TO postgres;


--
-- TOC entry 7018 (class 0 OID 0)
-- Dependencies: 769
-- Name: SEQUENCE task_def_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.task_def_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.task_def_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.task_def_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.task_def_id_seq TO postgres;


--
-- TOC entry 7019 (class 0 OID 0)
-- Dependencies: 770
-- Name: SEQUENCE task_event_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.task_event_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.task_event_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.task_event_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.task_event_id_seq TO postgres;


--
-- TOC entry 7020 (class 0 OID 0)
-- Dependencies: 771
-- Name: SEQUENCE task_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.task_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.task_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.task_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.task_id_seq TO postgres;


--
-- TOC entry 7021 (class 0 OID 0)
-- Dependencies: 772
-- Name: SEQUENCE task_var_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.task_var_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.task_var_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.task_var_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.task_var_id_seq TO postgres;


--
-- TOC entry 7022 (class 0 OID 0)
-- Dependencies: 399
-- Name: TABLE tbl_access_order; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_access_order TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_access_order TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_access_order TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_access_order TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_access_order TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_access_order TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_access_order TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_access_order TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7023 (class 0 OID 0)
-- Dependencies: 289
-- Name: SEQUENCE tbl_application_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_application_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_application_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_application_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_seq TO prvgwy;


--
-- TOC entry 7024 (class 0 OID 0)
-- Dependencies: 400
-- Name: TABLE tbl_application; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_application TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_application TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_application TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_application TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_application TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_application TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_application TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_application TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7025 (class 0 OID 0)
-- Dependencies: 290
-- Name: SEQUENCE tbl_application_config_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_config_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_application_config_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_application_config_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_application_config_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_config_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_config_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_application_config_seq TO prvgwy;


--
-- TOC entry 7026 (class 0 OID 0)
-- Dependencies: 401
-- Name: TABLE tbl_application_config; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_application_config TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_application_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_application_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_application_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_application_config TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_application_config TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_application_config TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_application_config TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7027 (class 0 OID 0)
-- Dependencies: 292
-- Name: SEQUENCE tbl_baais_orch_trace_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_baais_orch_trace_entity_seq TO prvgwy;


--
-- TOC entry 7028 (class 0 OID 0)
-- Dependencies: 403
-- Name: TABLE tbl_baais_orch_trace_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_baais_orch_trace_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7029 (class 0 OID 0)
-- Dependencies: 291
-- Name: SEQUENCE tbl_baaisn_cem_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_baaisn_cem_entity_seq TO prvgwy;


--
-- TOC entry 7030 (class 0 OID 0)
-- Dependencies: 402
-- Name: TABLE tbl_baaisn_cem_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_baaisn_cem_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7031 (class 0 OID 0)
-- Dependencies: 293
-- Name: SEQUENCE tbl_bonita_dynamic_flow_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_bonita_dynamic_flow_seq TO prvgwy;


--
-- TOC entry 7032 (class 0 OID 0)
-- Dependencies: 404
-- Name: TABLE tbl_bonita_dynamic_flow; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_bonita_dynamic_flow TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7033 (class 0 OID 0)
-- Dependencies: 294
-- Name: SEQUENCE tbl_chronic_circuit_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_circuit_seq TO prvgwy;


--
-- TOC entry 7034 (class 0 OID 0)
-- Dependencies: 405
-- Name: TABLE tbl_chronic_circuit; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_chronic_circuit TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_chronic_circuit TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_chronic_circuit TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_chronic_circuit TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_circuit TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_circuit TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_circuit TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_circuit TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7035 (class 0 OID 0)
-- Dependencies: 295
-- Name: SEQUENCE tbl_chronic_site_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_seq TO prvgwy;


--
-- TOC entry 7036 (class 0 OID 0)
-- Dependencies: 406
-- Name: TABLE tbl_chronic_site; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_chronic_site TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_chronic_site TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_chronic_site TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7037 (class 0 OID 0)
-- Dependencies: 296
-- Name: SEQUENCE tbl_chronic_site_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_chronic_site_entity_seq TO prvgwy;


--
-- TOC entry 7038 (class 0 OID 0)
-- Dependencies: 407
-- Name: TABLE tbl_chronic_site_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_chronic_site_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_chronic_site_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_chronic_site_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_chronic_site_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7039 (class 0 OID 0)
-- Dependencies: 297
-- Name: SEQUENCE tbl_circuit_relation_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_circuit_relation_seq TO prvgwy;


--
-- TOC entry 7040 (class 0 OID 0)
-- Dependencies: 408
-- Name: TABLE tbl_circuit_relation; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_circuit_relation TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_circuit_relation TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_circuit_relation TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_circuit_relation TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_circuit_relation TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_circuit_relation TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_circuit_relation TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_circuit_relation TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7041 (class 0 OID 0)
-- Dependencies: 298
-- Name: SEQUENCE tbl_clli_selection_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_clli_selection_seq TO prvgwy;


--
-- TOC entry 7042 (class 0 OID 0)
-- Dependencies: 409
-- Name: TABLE tbl_clli_selection; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_clli_selection TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_clli_selection TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_clli_selection TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_clli_selection TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_clli_selection TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_clli_selection TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_clli_selection TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_clli_selection TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7043 (class 0 OID 0)
-- Dependencies: 299
-- Name: SEQUENCE tbl_demo_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_demo_entity_seq TO prvgwy;


--
-- TOC entry 7044 (class 0 OID 0)
-- Dependencies: 410
-- Name: TABLE tbl_demo_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_demo_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_demo_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_demo_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_demo_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_demo_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_demo_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_demo_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_demo_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7045 (class 0 OID 0)
-- Dependencies: 300
-- Name: SEQUENCE tbl_dispatch_job_track_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_dispatch_job_track_seq TO prvgwy;


--
-- TOC entry 7046 (class 0 OID 0)
-- Dependencies: 411
-- Name: TABLE tbl_dispatch_job_track; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_dispatch_job_track TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_dispatch_job_track TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_dispatch_job_track TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_dispatch_job_track TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_dispatch_job_track TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_dispatch_job_track TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_dispatch_job_track TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_dispatch_job_track TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7047 (class 0 OID 0)
-- Dependencies: 301
-- Name: SEQUENCE tbl_ds1_migration_params_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ds1_migration_params_seq TO prvgwy;


--
-- TOC entry 7048 (class 0 OID 0)
-- Dependencies: 412
-- Name: TABLE tbl_ds1_migration_params; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_ds1_migration_params TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_ds1_migration_params TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_ds1_migration_params TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_ds1_migration_params TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_ds1_migration_params TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_ds1_migration_params TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ds1_migration_params TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ds1_migration_params TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7049 (class 0 OID 0)
-- Dependencies: 302
-- Name: SEQUENCE tbl_dynamic_flow_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_dynamic_flow_map_seq TO prvgwy;


--
-- TOC entry 7050 (class 0 OID 0)
-- Dependencies: 413
-- Name: TABLE tbl_dynamic_flow_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_dynamic_flow_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_dynamic_flow_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_dynamic_flow_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_dynamic_flow_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_dynamic_flow_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_dynamic_flow_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_dynamic_flow_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_dynamic_flow_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7051 (class 0 OID 0)
-- Dependencies: 303
-- Name: SEQUENCE tbl_ecost_batch_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ecost_batch_entity_seq TO prvgwy;


--
-- TOC entry 7052 (class 0 OID 0)
-- Dependencies: 414
-- Name: TABLE tbl_ecost_batch_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_ecost_batch_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_ecost_batch_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_ecost_batch_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_ecost_batch_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_ecost_batch_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_ecost_batch_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ecost_batch_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ecost_batch_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7053 (class 0 OID 0)
-- Dependencies: 304
-- Name: SEQUENCE tbl_engineering_issue_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_engineering_issue_seq TO prvgwy;


--
-- TOC entry 7054 (class 0 OID 0)
-- Dependencies: 415
-- Name: TABLE tbl_engineering_issue; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_engineering_issue TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_engineering_issue TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_engineering_issue TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_engineering_issue TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_engineering_issue TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_engineering_issue TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_engineering_issue TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_engineering_issue TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7055 (class 0 OID 0)
-- Dependencies: 305
-- Name: SEQUENCE tbl_escalation_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_entity_seq TO prvgwy;


--
-- TOC entry 7056 (class 0 OID 0)
-- Dependencies: 416
-- Name: TABLE tbl_escalation_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_escalation_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_escalation_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_escalation_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_escalation_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7057 (class 0 OID 0)
-- Dependencies: 306
-- Name: SEQUENCE tbl_escalation_ticket_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_escalation_ticket_seq TO prvgwy;


--
-- TOC entry 7058 (class 0 OID 0)
-- Dependencies: 417
-- Name: TABLE tbl_escalation_ticket; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_escalation_ticket TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_escalation_ticket TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_escalation_ticket TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_escalation_ticket TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_ticket TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_ticket TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_ticket TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_escalation_ticket TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7059 (class 0 OID 0)
-- Dependencies: 482
-- Name: SEQUENCE tbl_event_fallout_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.tbl_event_fallout_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_event_fallout_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_event_fallout_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_event_fallout_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_event_fallout_seq TO postgres;


--
-- TOC entry 7060 (class 0 OID 0)
-- Dependencies: 483
-- Name: TABLE tbl_event_fallout; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON TABLE ng_orchestration.tbl_event_fallout TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_event_fallout TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_event_fallout TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_event_fallout TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_event_fallout TO ng_orch_readwrite;


--
-- TOC entry 7061 (class 0 OID 0)
-- Dependencies: 307
-- Name: SEQUENCE tbl_hack_demo_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_hack_demo_entity_seq TO prvgwy;


--
-- TOC entry 7062 (class 0 OID 0)
-- Dependencies: 418
-- Name: TABLE tbl_hack_demo_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_hack_demo_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_hack_demo_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_hack_demo_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_hack_demo_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_hack_demo_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_hack_demo_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_hack_demo_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_hack_demo_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7063 (class 0 OID 0)
-- Dependencies: 419
-- Name: TABLE tbl_holiday; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_holiday TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_holiday TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_holiday TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_holiday TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_holiday TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_holiday TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_holiday TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_holiday TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7064 (class 0 OID 0)
-- Dependencies: 712
-- Name: TABLE tbl_ien_order; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.tbl_ien_order TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_ien_order TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_ien_order TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.tbl_ien_order TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.tbl_ien_order TO postgres;


--
-- TOC entry 7066 (class 0 OID 0)
-- Dependencies: 711
-- Name: SEQUENCE tbl_ien_order_ien_order_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ien_order_ien_order_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_ien_order_ien_order_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ien_order_ien_order_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ien_order_ien_order_id_seq TO postgres;


--
-- TOC entry 7067 (class 0 OID 0)
-- Dependencies: 549
-- Name: SEQUENCE tbl_ien_order_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ien_order_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ien_order_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_ien_order_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ien_order_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ien_order_seq TO postgres;


--
-- TOC entry 7068 (class 0 OID 0)
-- Dependencies: 420
-- Name: TABLE tbl_interval_mapping; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_interval_mapping TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_interval_mapping TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_interval_mapping TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_interval_mapping TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_interval_mapping TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_interval_mapping TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_interval_mapping TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_interval_mapping TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7069 (class 0 OID 0)
-- Dependencies: 308
-- Name: SEQUENCE tbl_jeop_code_metadata_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_jeop_code_metadata_seq TO prvgwy;


--
-- TOC entry 7070 (class 0 OID 0)
-- Dependencies: 421
-- Name: TABLE tbl_jeop_code_metadata; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_jeop_code_metadata TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_jeop_code_metadata TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_jeop_code_metadata TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_jeop_code_metadata TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_jeop_code_metadata TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_jeop_code_metadata TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_jeop_code_metadata TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_jeop_code_metadata TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7071 (class 0 OID 0)
-- Dependencies: 422
-- Name: TABLE tbl_lam_interval; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_lam_interval TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_lam_interval TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_lam_interval TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_lam_interval TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_lam_interval TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_lam_interval TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_lam_interval TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_lam_interval TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7072 (class 0 OID 0)
-- Dependencies: 309
-- Name: SEQUENCE tbl_lci_manifest_docs_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_lci_manifest_docs_seq TO prvgwy;


--
-- TOC entry 7073 (class 0 OID 0)
-- Dependencies: 423
-- Name: TABLE tbl_lci_manifest_docs; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_lci_manifest_docs TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_lci_manifest_docs TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_lci_manifest_docs TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_lci_manifest_docs TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_lci_manifest_docs TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_lci_manifest_docs TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_lci_manifest_docs TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_lci_manifest_docs TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7074 (class 0 OID 0)
-- Dependencies: 310
-- Name: SEQUENCE tbl_manifest_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_manifest_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_manifest_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_manifest_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_seq TO prvgwy;


--
-- TOC entry 7075 (class 0 OID 0)
-- Dependencies: 424
-- Name: TABLE tbl_manifest; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_manifest TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_manifest TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_manifest TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_manifest TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7076 (class 0 OID 0)
-- Dependencies: 311
-- Name: SEQUENCE tbl_manifest_docs_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_docs_seq TO prvgwy;


--
-- TOC entry 7077 (class 0 OID 0)
-- Dependencies: 425
-- Name: TABLE tbl_manifest_docs; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_manifest_docs TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_manifest_docs TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_manifest_docs TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_manifest_docs TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_docs TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_docs TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_docs TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_docs TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7078 (class 0 OID 0)
-- Dependencies: 312
-- Name: SEQUENCE tbl_manifest_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_manifest_map_seq TO prvgwy;


--
-- TOC entry 7079 (class 0 OID 0)
-- Dependencies: 426
-- Name: TABLE tbl_manifest_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_manifest_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_manifest_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_manifest_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_manifest_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_manifest_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7080 (class 0 OID 0)
-- Dependencies: 313
-- Name: SEQUENCE tbl_message_config_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_message_config_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_message_config_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_message_config_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_message_config_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_message_config_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_message_config_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_message_config_seq TO prvgwy;


--
-- TOC entry 7081 (class 0 OID 0)
-- Dependencies: 427
-- Name: TABLE tbl_message_config; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_message_config TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_message_config TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_message_config TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_message_config TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_message_config TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_message_config TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_message_config TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_message_config TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7082 (class 0 OID 0)
-- Dependencies: 314
-- Name: SEQUENCE tbl_nid_audit_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_nid_audit_entity_seq TO prvgwy;


--
-- TOC entry 7083 (class 0 OID 0)
-- Dependencies: 428
-- Name: TABLE tbl_nid_audit_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_nid_audit_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_nid_audit_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_nid_audit_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_nid_audit_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_nid_audit_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_nid_audit_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_nid_audit_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_nid_audit_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7084 (class 0 OID 0)
-- Dependencies: 564
-- Name: TABLE tbl_order; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.tbl_order TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.tbl_order TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.tbl_order TO postgres;


--
-- TOC entry 7085 (class 0 OID 0)
-- Dependencies: 316
-- Name: SEQUENCE tbl_order_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_entity_seq TO prvgwy;


--
-- TOC entry 7086 (class 0 OID 0)
-- Dependencies: 429
-- Name: TABLE tbl_order_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_order_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7087 (class 0 OID 0)
-- Dependencies: 317
-- Name: SEQUENCE tbl_order_jeopardy_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_jeopardy_seq TO prvgwy;


--
-- TOC entry 7088 (class 0 OID 0)
-- Dependencies: 430
-- Name: TABLE tbl_order_jeopardy; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_jeopardy TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_jeopardy TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_jeopardy TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order_jeopardy TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order_jeopardy TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_order_jeopardy TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_jeopardy TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_jeopardy TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7089 (class 0 OID 0)
-- Dependencies: 318
-- Name: SEQUENCE tbl_order_notes_remarks_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_notes_remarks_seq TO prvgwy;


--
-- TOC entry 7090 (class 0 OID 0)
-- Dependencies: 431
-- Name: TABLE tbl_order_notes_remarks; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_notes_remarks TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_notes_remarks TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_notes_remarks TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order_notes_remarks TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order_notes_remarks TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_order_notes_remarks TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_notes_remarks TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_notes_remarks TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7091 (class 0 OID 0)
-- Dependencies: 319
-- Name: SEQUENCE tbl_order_request_fallout_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_request_fallout_seq TO prvgwy;


--
-- TOC entry 7092 (class 0 OID 0)
-- Dependencies: 432
-- Name: TABLE tbl_order_request_fallout; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_request_fallout TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_request_fallout TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_request_fallout TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order_request_fallout TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order_request_fallout TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_order_request_fallout TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_request_fallout TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_request_fallout TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7093 (class 0 OID 0)
-- Dependencies: 926
-- Name: TABLE tbl_order_restore; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_restore TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_restore TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_restore TO ng_orch_readonly;
GRANT ALL ON TABLE ng_orchestration.tbl_order_restore TO PUBLIC;


--
-- TOC entry 7094 (class 0 OID 0)
-- Dependencies: 320
-- Name: SEQUENCE tbl_order_search_index_store_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_search_index_store_seq TO prvgwy;


--
-- TOC entry 7095 (class 0 OID 0)
-- Dependencies: 433
-- Name: TABLE tbl_order_search_index_store; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_search_index_store TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_search_index_store TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_search_index_store TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order_search_index_store TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order_search_index_store TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_order_search_index_store TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_search_index_store TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_search_index_store TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7096 (class 0 OID 0)
-- Dependencies: 315
-- Name: SEQUENCE tbl_order_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_seq TO prvgwy;


--
-- TOC entry 7097 (class 0 OID 0)
-- Dependencies: 321
-- Name: SEQUENCE tbl_order_status_metadata_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_order_status_metadata_seq TO prvgwy;


--
-- TOC entry 7098 (class 0 OID 0)
-- Dependencies: 434
-- Name: TABLE tbl_order_status_metadata; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_order_status_metadata TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_status_metadata TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_order_status_metadata TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_order_status_metadata TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_order_status_metadata TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_order_status_metadata TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_status_metadata TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_order_status_metadata TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7099 (class 0 OID 0)
-- Dependencies: 651
-- Name: TABLE tbl_pg_ordering_messages; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.tbl_pg_ordering_messages TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_pg_ordering_messages TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_pg_ordering_messages TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_pg_ordering_messages TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.tbl_pg_ordering_messages TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.tbl_pg_ordering_messages TO postgres;


--
-- TOC entry 7100 (class 0 OID 0)
-- Dependencies: 737
-- Name: TABLE tbl_pg_ordering_messages_uat_temp_for_migration; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.tbl_pg_ordering_messages_uat_temp_for_migration TO postgres;


--
-- TOC entry 7101 (class 0 OID 0)
-- Dependencies: 322
-- Name: SEQUENCE tbl_pon_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_pon_entity_seq TO prvgwy;


--
-- TOC entry 7102 (class 0 OID 0)
-- Dependencies: 435
-- Name: TABLE tbl_pon_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_pon_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_pon_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_pon_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_pon_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_pon_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_pon_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_pon_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_pon_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7103 (class 0 OID 0)
-- Dependencies: 323
-- Name: SEQUENCE tbl_reschedule_task_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_reschedule_task_seq TO prvgwy;


--
-- TOC entry 7104 (class 0 OID 0)
-- Dependencies: 436
-- Name: TABLE tbl_reschedule_task; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_reschedule_task TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_reschedule_task TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_reschedule_task TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_reschedule_task TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_reschedule_task TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_reschedule_task TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_reschedule_task TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_reschedule_task TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7105 (class 0 OID 0)
-- Dependencies: 324
-- Name: SEQUENCE tbl_rqnorder_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rqnorder_entity_seq TO prvgwy;


--
-- TOC entry 7106 (class 0 OID 0)
-- Dependencies: 437
-- Name: TABLE tbl_rqnorder_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_rqnorder_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_rqnorder_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_rqnorder_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_rqnorder_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_rqnorder_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_rqnorder_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rqnorder_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rqnorder_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7107 (class 0 OID 0)
-- Dependencies: 325
-- Name: SEQUENCE tbl_ruggedization_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ruggedization_entity_seq TO prvgwy;


--
-- TOC entry 7108 (class 0 OID 0)
-- Dependencies: 438
-- Name: TABLE tbl_ruggedization_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_ruggedization_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_ruggedization_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_ruggedization_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_ruggedization_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_ruggedization_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_ruggedization_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ruggedization_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ruggedization_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7109 (class 0 OID 0)
-- Dependencies: 326
-- Name: SEQUENCE tbl_rule_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rule_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rule_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_rule_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_seq TO prvgwy;


--
-- TOC entry 7110 (class 0 OID 0)
-- Dependencies: 439
-- Name: TABLE tbl_rule; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_rule TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_rule TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_rule TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_rule TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_rule TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_rule TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rule TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rule TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7111 (class 0 OID 0)
-- Dependencies: 327
-- Name: SEQUENCE tbl_rule_set_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_seq TO prvgwy;


--
-- TOC entry 7112 (class 0 OID 0)
-- Dependencies: 440
-- Name: TABLE tbl_rule_set; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_rule_set TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_rule_set TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_rule_set TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_rule_set TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7113 (class 0 OID 0)
-- Dependencies: 328
-- Name: SEQUENCE tbl_rule_set_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_rule_set_map_seq TO prvgwy;


--
-- TOC entry 7114 (class 0 OID 0)
-- Dependencies: 441
-- Name: TABLE tbl_rule_set_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_rule_set_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_rule_set_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_rule_set_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_rule_set_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_rule_set_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7115 (class 0 OID 0)
-- Dependencies: 329
-- Name: SEQUENCE tbl_service_route_map_table_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_service_route_map_table_seq TO prvgwy;


--
-- TOC entry 7116 (class 0 OID 0)
-- Dependencies: 442
-- Name: TABLE tbl_service_route_map_table; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_service_route_map_table TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_service_route_map_table TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_service_route_map_table TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_service_route_map_table TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_service_route_map_table TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_service_route_map_table TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_service_route_map_table TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_service_route_map_table TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7117 (class 0 OID 0)
-- Dependencies: 330
-- Name: SEQUENCE tbl_sla_process_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_sla_process_map_seq TO prvgwy;


--
-- TOC entry 7118 (class 0 OID 0)
-- Dependencies: 443
-- Name: TABLE tbl_sla_process_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_sla_process_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_sla_process_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_sla_process_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_sla_process_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_sla_process_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_sla_process_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_sla_process_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_sla_process_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7119 (class 0 OID 0)
-- Dependencies: 331
-- Name: SEQUENCE tbl_ssporder_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_ssporder_entity_seq TO prvgwy;


--
-- TOC entry 7120 (class 0 OID 0)
-- Dependencies: 444
-- Name: TABLE tbl_ssporder_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_ssporder_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_ssporder_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_ssporder_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_ssporder_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_ssporder_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_ssporder_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ssporder_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_ssporder_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7121 (class 0 OID 0)
-- Dependencies: 445
-- Name: TABLE tbl_state; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_state TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_state TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_state TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_state TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_state TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_state TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_state TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_state TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7122 (class 0 OID 0)
-- Dependencies: 446
-- Name: TABLE tbl_state_plan_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_state_plan_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_state_plan_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_state_plan_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_state_plan_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_state_plan_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_state_plan_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_state_plan_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_state_plan_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7123 (class 0 OID 0)
-- Dependencies: 447
-- Name: TABLE tbl_std_interval; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_std_interval TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_std_interval TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_std_interval TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_std_interval TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_std_interval TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_std_interval TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_std_interval TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_std_interval TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7124 (class 0 OID 0)
-- Dependencies: 332
-- Name: SEQUENCE tbl_subprocess_mapping_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_subprocess_mapping_seq TO prvgwy;


--
-- TOC entry 7125 (class 0 OID 0)
-- Dependencies: 448
-- Name: TABLE tbl_subprocess_mapping; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_subprocess_mapping TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_subprocess_mapping TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_subprocess_mapping TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_subprocess_mapping TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_subprocess_mapping TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_subprocess_mapping TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_subprocess_mapping TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_subprocess_mapping TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7126 (class 0 OID 0)
-- Dependencies: 333
-- Name: SEQUENCE tbl_task_sla_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_task_sla_seq TO prvgwy;


--
-- TOC entry 7127 (class 0 OID 0)
-- Dependencies: 449
-- Name: TABLE tbl_task_sla; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_task_sla TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_task_sla TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_task_sla TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_task_sla TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_task_sla TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_task_sla TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_task_sla TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_task_sla TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7128 (class 0 OID 0)
-- Dependencies: 334
-- Name: SEQUENCE tbl_vps_order_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO prvapp WITH GRANT OPTION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO prvgwy;
RESET SESSION AUTHORIZATION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_seq TO prvgwy;


--
-- TOC entry 7129 (class 0 OID 0)
-- Dependencies: 450
-- Name: TABLE tbl_vps_order; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_order TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7130 (class 0 OID 0)
-- Dependencies: 335
-- Name: SEQUENCE tbl_vps_order_bak_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_bak_seq TO prvgwy;


--
-- TOC entry 7131 (class 0 OID 0)
-- Dependencies: 451
-- Name: TABLE tbl_vps_order_bak; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_bak TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_bak TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_bak TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_bak TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_bak TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_bak TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_bak TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_bak TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7132 (class 0 OID 0)
-- Dependencies: 336
-- Name: SEQUENCE tbl_vps_order_circuit_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_circuit_seq TO prvgwy;


--
-- TOC entry 7133 (class 0 OID 0)
-- Dependencies: 452
-- Name: TABLE tbl_vps_order_circuit; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_circuit TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_circuit TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_circuit TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_circuit TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_circuit TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_circuit TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_circuit TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_circuit TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7134 (class 0 OID 0)
-- Dependencies: 337
-- Name: SEQUENCE tbl_vps_order_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_entity_seq TO prvgwy;


--
-- TOC entry 7135 (class 0 OID 0)
-- Dependencies: 453
-- Name: TABLE tbl_vps_order_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7136 (class 0 OID 0)
-- Dependencies: 565
-- Name: TABLE tbl_vps_order_lambda_test; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_lambda_test TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_lambda_test TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_lambda_test TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_lambda_test TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_lambda_test TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_lambda_test TO postgres;


--
-- TOC entry 7137 (class 0 OID 0)
-- Dependencies: 338
-- Name: SEQUENCE tbl_vps_order_new_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_new_seq TO prvgwy;


--
-- TOC entry 7138 (class 0 OID 0)
-- Dependencies: 454
-- Name: TABLE tbl_vps_order_new; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_new TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_new TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_new TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_new TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_new TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_new TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_new TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_new TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7139 (class 0 OID 0)
-- Dependencies: 738
-- Name: TABLE tbl_vps_order_test; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_test TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_test TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_test TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_test TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_test TO postgres;


--
-- TOC entry 7140 (class 0 OID 0)
-- Dependencies: 339
-- Name: SEQUENCE tbl_vps_order_version_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_order_version_seq TO prvgwy;


--
-- TOC entry 7141 (class 0 OID 0)
-- Dependencies: 455
-- Name: TABLE tbl_vps_order_version; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_version TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_version TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_order_version TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_order_version TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_version TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_version TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_version TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_order_version TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7142 (class 0 OID 0)
-- Dependencies: 340
-- Name: SEQUENCE tbl_vps_sr_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vps_sr_entity_seq TO prvgwy;


--
-- TOC entry 7143 (class 0 OID 0)
-- Dependencies: 456
-- Name: TABLE tbl_vps_sr_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vps_sr_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_sr_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vps_sr_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vps_sr_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_sr_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_sr_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_sr_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vps_sr_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7144 (class 0 OID 0)
-- Dependencies: 341
-- Name: SEQUENCE tbl_vrd_order_entity_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_vrd_order_entity_seq TO prvgwy;


--
-- TOC entry 7145 (class 0 OID 0)
-- Dependencies: 457
-- Name: TABLE tbl_vrd_order_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vrd_order_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vrd_order_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vrd_order_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vrd_order_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vrd_order_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vrd_order_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vrd_order_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vrd_order_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7146 (class 0 OID 0)
-- Dependencies: 458
-- Name: TABLE tbl_vzt_vzw_sharedpanel_entity; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_vzt_vzw_sharedpanel_entity TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7147 (class 0 OID 0)
-- Dependencies: 459
-- Name: TABLE tbl_wf_decision_params; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_wf_decision_params TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_wf_decision_params TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_wf_decision_params TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_wf_decision_params TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_wf_decision_params TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_wf_decision_params TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_wf_decision_params TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_wf_decision_params TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7148 (class 0 OID 0)
-- Dependencies: 342
-- Name: SEQUENCE tbl_workflow_map_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_seq TO prvgwy;


--
-- TOC entry 7149 (class 0 OID 0)
-- Dependencies: 460
-- Name: TABLE tbl_workflow_map; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_workflow_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_workflow_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_workflow_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7150 (class 0 OID 0)
-- Dependencies: 343
-- Name: SEQUENCE tbl_workflow_map_ext_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_map_ext_seq TO prvgwy;


--
-- TOC entry 7151 (class 0 OID 0)
-- Dependencies: 461
-- Name: TABLE tbl_workflow_map_ext; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map_ext TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_workflow_map_ext TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_workflow_map_ext TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_workflow_map_ext TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map_ext TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map_ext TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map_ext TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_map_ext TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7152 (class 0 OID 0)
-- Dependencies: 344
-- Name: SEQUENCE tbl_workflow_template_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.tbl_workflow_template_seq TO prvgwy;


--
-- TOC entry 7153 (class 0 OID 0)
-- Dependencies: 462
-- Name: TABLE tbl_workflow_template; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.tbl_workflow_template TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.tbl_workflow_template TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.tbl_workflow_template TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.tbl_workflow_template TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_template TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_template TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_template TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.tbl_workflow_template TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7154 (class 0 OID 0)
-- Dependencies: 909
-- Name: TABLE test_table; Type: ACL; Schema: ng_orchestration; Owner: postgres
--

GRANT ALL ON TABLE ng_orchestration.test_table TO prvgwy;


--
-- TOC entry 7155 (class 0 OID 0)
-- Dependencies: 919
-- Name: TABLE test_table_orders; Type: ACL; Schema: ng_orchestration; Owner: postgres
--

GRANT ALL ON TABLE ng_orchestration.test_table_orders TO prvgwy;


--
-- TOC entry 7156 (class 0 OID 0)
-- Dependencies: 547
-- Name: TABLE testtable; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.testtable TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.testtable TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.testtable TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.testtable TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.testtable TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.testtable TO postgres;


--
-- TOC entry 7157 (class 0 OID 0)
-- Dependencies: 726
-- Name: TABLE trunc_value; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.trunc_value TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.trunc_value TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.trunc_value TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.trunc_value TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.trunc_value TO postgres;


--
-- TOC entry 7158 (class 0 OID 0)
-- Dependencies: 901
-- Name: TABLE user_preference; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT ALL ON TABLE ng_orchestration.user_preference TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.user_preference TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.user_preference TO postgres;


--
-- TOC entry 7159 (class 0 OID 0)
-- Dependencies: 345
-- Name: SEQUENCE users_seq; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON SEQUENCE ng_orchestration.users_seq TO prvapp WITH GRANT OPTION;
GRANT SELECT ON SEQUENCE ng_orchestration.users_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.users_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.users_seq TO ng_orch_nodelete;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.users_seq TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON SEQUENCE ng_orchestration.users_seq TO postgres;
RESET SESSION AUTHORIZATION;
GRANT ALL ON SEQUENCE ng_orchestration.users_seq TO prvgwy;


--
-- TOC entry 7160 (class 0 OID 0)
-- Dependencies: 463
-- Name: TABLE users; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.users TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.users TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.users TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.users TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.users TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.users TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.users TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.users TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7161 (class 0 OID 0)
-- Dependencies: 773
-- Name: SEQUENCE var_inst_log_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.var_inst_log_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.var_inst_log_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.var_inst_log_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.var_inst_log_id_seq TO postgres;


--
-- TOC entry 7162 (class 0 OID 0)
-- Dependencies: 479
-- Name: TABLE var_local_doc_id; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT SELECT ON TABLE ng_orchestration.var_local_doc_id TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.var_local_doc_id TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.var_local_doc_id TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.var_local_doc_id TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.var_local_doc_id TO ng_orch_readwrite;


--
-- TOC entry 7163 (class 0 OID 0)
-- Dependencies: 464
-- Name: TABLE vdsi_view_onenet_order_data; Type: ACL; Schema: ng_orchestration; Owner: dbadmin
--

GRANT ALL ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO prvapp WITH GRANT OPTION;
GRANT SELECT ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO prvgwy;
GRANT ALL ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO ng_orch_readwrite;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO dbadmin;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION prvapp;
GRANT ALL ON TABLE ng_orchestration.vdsi_view_onenet_order_data TO postgres;
RESET SESSION AUTHORIZATION;


--
-- TOC entry 7164 (class 0 OID 0)
-- Dependencies: 517
-- Name: TABLE vzot_transaction_log; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.vzot_transaction_log TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.vzot_transaction_log TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.vzot_transaction_log TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.vzot_transaction_log TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.vzot_transaction_log TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.vzot_transaction_log TO postgres;


--
-- TOC entry 7165 (class 0 OID 0)
-- Dependencies: 521
-- Name: SEQUENCE web_service_url_map_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.web_service_url_map_seq TO prvgwy_ro;
GRANT SELECT ON SEQUENCE ng_orchestration.web_service_url_map_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.web_service_url_map_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.web_service_url_map_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.web_service_url_map_seq TO postgres;


--
-- TOC entry 7166 (class 0 OID 0)
-- Dependencies: 522
-- Name: TABLE web_service_url_map; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.web_service_url_map TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.web_service_url_map TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.web_service_url_map TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.web_service_url_map TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.web_service_url_map TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.web_service_url_map TO postgres;


--
-- TOC entry 7167 (class 0 OID 0)
-- Dependencies: 563
-- Name: TABLE wire_center; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.wire_center TO prvgwy_ro;
GRANT SELECT ON TABLE ng_orchestration.wire_center TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.wire_center TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.wire_center TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.wire_center TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.wire_center TO postgres;


--
-- TOC entry 7168 (class 0 OID 0)
-- Dependencies: 774
-- Name: SEQUENCE workiteminfo_id_seq; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON SEQUENCE ng_orchestration.workiteminfo_id_seq TO ng_orch_readonly;
GRANT USAGE ON SEQUENCE ng_orchestration.workiteminfo_id_seq TO ng_orch_nodelete;
GRANT ALL ON SEQUENCE ng_orchestration.workiteminfo_id_seq TO dbadmin;
GRANT ALL ON SEQUENCE ng_orchestration.workiteminfo_id_seq TO postgres;


--
-- TOC entry 7169 (class 0 OID 0)
-- Dependencies: 693
-- Name: TABLE zax_admin; Type: ACL; Schema: ng_orchestration; Owner: prvgwy
--

GRANT SELECT ON TABLE ng_orchestration.zax_admin TO ng_orch_readonly;
GRANT SELECT,INSERT,UPDATE ON TABLE ng_orchestration.zax_admin TO ng_orch_nodelete;
GRANT ALL ON TABLE ng_orchestration.zax_admin TO ng_orch_readwrite;
GRANT ALL ON TABLE ng_orchestration.zax_admin TO dbadmin;
GRANT ALL ON TABLE ng_orchestration.zax_admin TO postgres;


--
-- TOC entry 4262 (class 826 OID 219302)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: dbadmin
--

ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration REVOKE ALL ON SEQUENCES  FROM dbadmin;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON SEQUENCES  TO prvapp WITH GRANT OPTION;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON SEQUENCES  TO prvgwy;


--
-- TOC entry 4265 (class 826 OID 5201072)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration REVOKE ALL ON SEQUENCES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration GRANT ALL ON SEQUENCES  TO prvgwy;


--
-- TOC entry 4268 (class 826 OID 5312725)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: prvgwy
--

ALTER DEFAULT PRIVILEGES FOR ROLE prvgwy IN SCHEMA ng_orchestration REVOKE ALL ON SEQUENCES  FROM prvgwy;
ALTER DEFAULT PRIVILEGES FOR ROLE prvgwy IN SCHEMA ng_orchestration GRANT SELECT,USAGE ON SEQUENCES  TO prvgwy;


--
-- TOC entry 4256 (class 826 OID 219304)
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: dbadmin
--

ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration REVOKE ALL ON TYPES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration REVOKE ALL ON TYPES  FROM dbadmin;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON TYPES  TO prvapp;


--
-- TOC entry 4261 (class 826 OID 219303)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: dbadmin
--

ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration REVOKE ALL ON FUNCTIONS  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration REVOKE ALL ON FUNCTIONS  FROM dbadmin;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON FUNCTIONS  TO prvapp;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON FUNCTIONS  TO prvgwy;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON FUNCTIONS  TO prvgwy_ro;


--
-- TOC entry 4264 (class 826 OID 5201071)
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration REVOKE ALL ON FUNCTIONS  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration REVOKE ALL ON FUNCTIONS  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration GRANT ALL ON FUNCTIONS  TO prvgwy;


--
-- TOC entry 4266 (class 826 OID 219301)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: dbadmin
--

ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration REVOKE ALL ON TABLES  FROM dbadmin;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT ALL ON TABLES  TO prvapp WITH GRANT OPTION;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT SELECT ON TABLES  TO prvgwy_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA ng_orchestration GRANT SELECT ON TABLES  TO ng_orch_readonly;


--
-- TOC entry 4263 (class 826 OID 5201074)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: ng_orchestration; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA ng_orchestration GRANT ALL ON TABLES  TO prvgwy;


-- Completed on 2020-04-24 12:31:19 EDT

--
-- PostgreSQL database dump complete
--


