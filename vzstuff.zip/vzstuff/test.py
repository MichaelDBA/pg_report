#!/usr/bin/env python
import signal, os, time, sys, datetime
#import string, sys, os, subprocess, time, datetime, types, exceptions,
#warnings, signal
#from subprocess import *

global ABORT_INFO
# string to capture restart information for interrups
global ABORT_INFO

ABORT_INFO = ''

################################################################
# signal interruptor to clean up import stuff for easy restart #
################################################################
def signal_handler(signal, frame):
     global ABORT_INFO
     print 'User-interrupted! %s' % (datetime.datetime.now())
     sys.exit(0)

def readConfiguration(signalNumber, frame):
    print ('(SIGHUP) reading configuration')
    return

def terminateProcess(signalNumber, frame):
    print ('(SIGTERM) terminating the process')
    sys.exit()

def receiveSignal(signalNumber, frame):
    print('Received:', signalNumber)
    return

if __name__ == '__main__':

   # Register the signal handler for CNTRL-C logic
   signal.signal(signal.SIGINT, signal_handler)

   # output current process id
   print('My PID is:', os.getpid())

   # wait in an endless loop for signals
   while True:
       print('Waiting...')
       time.sleep(3)









