#!/bin/bash

str=`users`
last=''
IFS=' ' # space is set as delimiter
read -ra ADDR <<< "$str" # str is read into an array as tokens separated by IFS
for i in "${ADDR[@]}"; do # access each element of array
    # echo "$i"
    if [ "$i" == "vitalmi" ];then
        echo "It's me: $i"
    elif [ "$i" == "$last" ];then
	    echo "bypassing same user, $i"
    else
        echo "reporting $i"
        echo "user logged on=$i" | mail -s "tpalse0svd009 notification"  -r michael.vitale@verizon.com -- michael.vitale@verizon.com

    fi
	last=$i
done
exit 0