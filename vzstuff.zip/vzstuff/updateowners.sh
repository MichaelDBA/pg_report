#!/bin/bash

SCRIPTDIR="/apps/opt/postgres/scripts"

echo "INFO  `date`: ******* updating object owners..."
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb activn dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb audit dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb bill dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb config dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb etl dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb infra dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb localds dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb ordng dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb svcinv dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb tninv dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb topology dbowner
${SCRIPTDIR}/updateowner.sh localhost dbadmin connectdb uui dbowner
echo "INFO  `date`: ******* object owners updated successfully."
exit 0

