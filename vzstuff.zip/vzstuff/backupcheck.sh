#!/bin/sh
# this script checks that pgbackrest did a full or differential backup successfully today
# this script should run after the backup is completed. 
# create cron job like this:
# 00 07 * * * /apps/opt/postgres/scripts/backupcheck.sh
#
# TESTING --> BACKUPDATE='2016-08-10'
echo "today=${TODAY}  backup=${BACKUPDATE}"

TODAY=`date +%Y-%m-%d`
# EMAILEES="michael.vitale@verizon.com michaeldba@sqlexec.com"
EMAILEES="michael.vitale@verizon.com"
REPO=/apps/opt/postgres/backup/pgbackrest
CHECKLOGDIR=/apps/opt/postgres/backup
############
CONTEXT=PROD
BACKUPDATE=`awk '/INFO: new backup label/{a=$1}END{print a}' ${REPO}/log/prod-backup.log`
Host=tpalse0svd008
if [ "$TODAY" = "$BACKUPDATE" ]; then
    echo "`date`: ${Host}.${CONTEXT} Backup succeeded today: ${BACKUPDATE}"
    echo "`date`: ${Host}.${CONTEXT} Backup succeeded today: ${BACKUPDATE}" > ${CHECKLOGDIR}/check.log
elif [ "$TODAY" > "$BACKUPDATE" ] ; then
    echo "`date`: ${Host}.${CONTEXT} Backup is old: ${BACKUPDATE}"
    echo "`date`: ${Host}.${CONTEXT} Backup is old: ${BACKUPDATE}"  > ${CHECKLOGDIR}/check.log
    mail -s "Server : ${Host}.${CONTEXT}  Backup is old: ${BACKUPDATE}" < ${CHECKLOGDIR}/check.log ${EMAILEES}
fi

# Don't know why these 0 byte date directories are created, so delete them if they exist
#rm /var/lib/postgresql/scripts/20*
exit 0

#mail -s "Server : tpalse0svd008.prod Backup is old" < /apps/opt/postgres/backup/check.log michael.vitale@verizon.com

