--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 11.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pamperf; Type: DATABASE; Schema: -; Owner: dbadmin
--

CREATE DATABASE pamperf WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE pamperf OWNER TO dbadmin;

\connect pamperf

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pam; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pam;


ALTER SCHEMA pam OWNER TO postgres;

--
-- Name: SCHEMA pam; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA pam IS 'User for Red Hat jBPM DEV Process Server for Provisioning';


--
-- Name: booleanexpression_expression_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.booleanexpression_expression_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.expression as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.booleanexpression_expression_clob_after_delete() OWNER TO postgres;

--
-- Name: booleanexpression_expression_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.booleanexpression_expression_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.expression as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.booleanexpression_expression_clob_after_update() OWNER TO postgres;

--
-- Name: booleanexpression_expression_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.booleanexpression_expression_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.expression as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.booleanexpression_expression_clob_before_insert() OWNER TO postgres;

--
-- Name: booleanexpression_expression_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.booleanexpression_expression_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.expression as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.booleanexpression_expression_clob_before_update() OWNER TO postgres;

--
-- Name: deploymentstore_deploymentunit_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.deploymentstore_deploymentunit_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.deploymentunit as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.deploymentstore_deploymentunit_clob_after_delete() OWNER TO postgres;

--
-- Name: deploymentstore_deploymentunit_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.deploymentstore_deploymentunit_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.deploymentunit as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.deploymentstore_deploymentunit_clob_after_update() OWNER TO postgres;

--
-- Name: deploymentstore_deploymentunit_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.deploymentstore_deploymentunit_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.deploymentunit as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.deploymentstore_deploymentunit_clob_before_insert() OWNER TO postgres;

--
-- Name: deploymentstore_deploymentunit_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.deploymentstore_deploymentunit_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.deploymentunit as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.deploymentstore_deploymentunit_clob_before_update() OWNER TO postgres;

--
-- Name: email_header_body_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.email_header_body_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.body as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.email_header_body_clob_after_delete() OWNER TO postgres;

--
-- Name: email_header_body_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.email_header_body_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.body as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.email_header_body_clob_after_update() OWNER TO postgres;

--
-- Name: email_header_body_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.email_header_body_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.body as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.email_header_body_clob_before_insert() OWNER TO postgres;

--
-- Name: email_header_body_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.email_header_body_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.body as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.email_header_body_clob_before_update() OWNER TO postgres;

--
-- Name: executionerrorinfo_error_info_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.executionerrorinfo_error_info_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.error_info as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.executionerrorinfo_error_info_clob_after_delete() OWNER TO postgres;

--
-- Name: executionerrorinfo_error_info_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.executionerrorinfo_error_info_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.error_info as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.executionerrorinfo_error_info_clob_after_update() OWNER TO postgres;

--
-- Name: executionerrorinfo_error_info_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.executionerrorinfo_error_info_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.error_info as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.executionerrorinfo_error_info_clob_before_insert() OWNER TO postgres;

--
-- Name: executionerrorinfo_error_info_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.executionerrorinfo_error_info_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.error_info as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.executionerrorinfo_error_info_clob_before_update() OWNER TO postgres;

--
-- Name: i18ntext_text_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.i18ntext_text_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.text as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.i18ntext_text_clob_after_delete() OWNER TO postgres;

--
-- Name: i18ntext_text_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.i18ntext_text_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.text as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.i18ntext_text_clob_after_update() OWNER TO postgres;

--
-- Name: i18ntext_text_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.i18ntext_text_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.text as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.i18ntext_text_clob_before_insert() OWNER TO postgres;

--
-- Name: i18ntext_text_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.i18ntext_text_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.text as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.i18ntext_text_clob_before_update() OWNER TO postgres;

--
-- Name: querydefinitionstore_qexpression_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.querydefinitionstore_qexpression_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.qexpression as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.querydefinitionstore_qexpression_clob_after_delete() OWNER TO postgres;

--
-- Name: querydefinitionstore_qexpression_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.querydefinitionstore_qexpression_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.qexpression as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.querydefinitionstore_qexpression_clob_after_update() OWNER TO postgres;

--
-- Name: querydefinitionstore_qexpression_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.querydefinitionstore_qexpression_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.qexpression as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.querydefinitionstore_qexpression_clob_before_insert() OWNER TO postgres;

--
-- Name: querydefinitionstore_qexpression_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.querydefinitionstore_qexpression_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.qexpression as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.querydefinitionstore_qexpression_clob_before_update() OWNER TO postgres;

--
-- Name: task_comment_text_clob_after_delete(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.task_comment_text_clob_after_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.text as oid);
    return old;
end;
$$;


ALTER FUNCTION pam.task_comment_text_clob_after_delete() OWNER TO postgres;

--
-- Name: task_comment_text_clob_after_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.task_comment_text_clob_after_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    delete from jbpm_active_clob where loid = cast(old.text as oid);
    return new;
end;
$$;


ALTER FUNCTION pam.task_comment_text_clob_after_update() OWNER TO postgres;

--
-- Name: task_comment_text_clob_before_insert(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.task_comment_text_clob_before_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.text as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.task_comment_text_clob_before_insert() OWNER TO postgres;

--
-- Name: task_comment_text_clob_before_update(); Type: FUNCTION; Schema: pam; Owner: postgres
--

CREATE FUNCTION pam.task_comment_text_clob_before_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
begin
    insert into jbpm_active_clob (loid) values (cast(new.text as oid));
    return new;
end;
$$;


ALTER FUNCTION pam.task_comment_text_clob_before_update() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: attachment; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.attachment (
    id bigint NOT NULL,
    accesstype integer,
    attachedat timestamp without time zone,
    attachmentcontentid bigint NOT NULL,
    contenttype character varying(255),
    name character varying(255),
    attachment_size integer,
    attachedby_id character varying(255),
    taskdata_attachments_id bigint
);


ALTER TABLE pam.attachment OWNER TO postgres;

--
-- Name: attachment_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.attachment_id_seq OWNER TO postgres;

--
-- Name: audit_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.audit_id_seq OWNER TO postgres;

--
-- Name: audittaskimpl; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.audittaskimpl (
    id bigint NOT NULL,
    activationtime timestamp without time zone,
    actualowner character varying(255),
    createdby character varying(255),
    createdon timestamp without time zone,
    deploymentid character varying(255),
    description character varying(255),
    duedate timestamp without time zone,
    name character varying(255),
    parentid bigint NOT NULL,
    priority integer NOT NULL,
    processid character varying(255),
    processinstanceid bigint NOT NULL,
    processsessionid bigint NOT NULL,
    status character varying(255),
    taskid bigint,
    workitemid bigint,
    lastmodificationdate timestamp without time zone
);


ALTER TABLE pam.audittaskimpl OWNER TO postgres;

--
-- Name: bam_task_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.bam_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.bam_task_id_seq OWNER TO postgres;

--
-- Name: bamtasksummary; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.bamtasksummary (
    pk bigint NOT NULL,
    createddate timestamp without time zone,
    duration bigint,
    enddate timestamp without time zone,
    processinstanceid bigint NOT NULL,
    startdate timestamp without time zone,
    status character varying(255),
    taskid bigint NOT NULL,
    taskname character varying(255),
    userid character varying(255),
    optlock integer
);


ALTER TABLE pam.bamtasksummary OWNER TO postgres;

--
-- Name: booleanexpr_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.booleanexpr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.booleanexpr_id_seq OWNER TO postgres;

--
-- Name: booleanexpression; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.booleanexpression (
    id bigint NOT NULL,
    expression text,
    type character varying(255),
    escalation_constraints_id bigint
);


ALTER TABLE pam.booleanexpression OWNER TO postgres;

--
-- Name: case_file_data_log_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.case_file_data_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.case_file_data_log_id_seq OWNER TO postgres;

--
-- Name: case_id_info_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.case_id_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.case_id_info_id_seq OWNER TO postgres;

--
-- Name: case_role_assign_log_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.case_role_assign_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.case_role_assign_log_id_seq OWNER TO postgres;

--
-- Name: casefiledatalog; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.casefiledatalog (
    id bigint NOT NULL,
    casedefid character varying(255),
    caseid character varying(255),
    itemname character varying(255),
    itemtype character varying(255),
    itemvalue character varying(255),
    lastmodified timestamp without time zone,
    lastmodifiedby character varying(255)
);


ALTER TABLE pam.casefiledatalog OWNER TO postgres;

--
-- Name: caseidinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.caseidinfo (
    id bigint NOT NULL,
    caseidprefix character varying(255),
    currentvalue bigint
);


ALTER TABLE pam.caseidinfo OWNER TO postgres;

--
-- Name: caseroleassignmentlog; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.caseroleassignmentlog (
    id bigint NOT NULL,
    caseid character varying(255),
    entityid character varying(255),
    processinstanceid bigint NOT NULL,
    rolename character varying(255),
    type integer NOT NULL
);


ALTER TABLE pam.caseroleassignmentlog OWNER TO postgres;

--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.comment_id_seq OWNER TO postgres;

--
-- Name: content; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.content (
    id bigint NOT NULL,
    content oid
);


ALTER TABLE pam.content OWNER TO postgres;

--
-- Name: content_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.content_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.content_id_seq OWNER TO postgres;

--
-- Name: context_mapping_info_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.context_mapping_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.context_mapping_info_id_seq OWNER TO postgres;

--
-- Name: contextmappinginfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.contextmappinginfo (
    mappingid bigint NOT NULL,
    context_id character varying(255) NOT NULL,
    ksession_id bigint NOT NULL,
    owner_id character varying(255),
    optlock integer
);


ALTER TABLE pam.contextmappinginfo OWNER TO postgres;

--
-- Name: correlation_key_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.correlation_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.correlation_key_id_seq OWNER TO postgres;

--
-- Name: correlation_prop_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.correlation_prop_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.correlation_prop_id_seq OWNER TO postgres;

--
-- Name: correlationkeyinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.correlationkeyinfo (
    keyid bigint NOT NULL,
    name character varying(500),
    processinstanceid bigint NOT NULL,
    optlock integer
);


ALTER TABLE pam.correlationkeyinfo OWNER TO postgres;

--
-- Name: correlationpropertyinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.correlationpropertyinfo (
    propertyid bigint NOT NULL,
    name character varying(500),
    value character varying(255),
    optlock integer,
    correlationkey_keyid bigint
);


ALTER TABLE pam.correlationpropertyinfo OWNER TO postgres;

--
-- Name: deadline; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.deadline (
    id bigint NOT NULL,
    deadline_date timestamp without time zone,
    escalated smallint,
    deadlines_startdeadline_id bigint,
    deadlines_enddeadline_id bigint
);


ALTER TABLE pam.deadline OWNER TO postgres;

--
-- Name: deadline_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.deadline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.deadline_id_seq OWNER TO postgres;

--
-- Name: delegation_delegates; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.delegation_delegates (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.delegation_delegates OWNER TO postgres;

--
-- Name: deploy_store_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.deploy_store_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.deploy_store_id_seq OWNER TO postgres;

--
-- Name: deploymentstore; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.deploymentstore (
    id bigint NOT NULL,
    attributes character varying(255),
    deployment_id character varying(255),
    deploymentunit text,
    state integer,
    updatedate timestamp without time zone
);


ALTER TABLE pam.deploymentstore OWNER TO postgres;

--
-- Name: email_header; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.email_header (
    id bigint NOT NULL,
    body text,
    fromaddress character varying(255),
    language character varying(255),
    replytoaddress character varying(255),
    subject character varying(255)
);


ALTER TABLE pam.email_header OWNER TO postgres;

--
-- Name: emailnotifhead_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.emailnotifhead_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.emailnotifhead_id_seq OWNER TO postgres;

--
-- Name: error_info_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.error_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.error_info_id_seq OWNER TO postgres;

--
-- Name: errorinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.errorinfo (
    id bigint NOT NULL,
    message character varying(255),
    stacktrace character varying(5000),
    "timestamp" timestamp without time zone,
    request_id bigint NOT NULL
);


ALTER TABLE pam.errorinfo OWNER TO postgres;

--
-- Name: escalation; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.escalation (
    id bigint NOT NULL,
    name character varying(255),
    deadline_escalation_id bigint
);


ALTER TABLE pam.escalation OWNER TO postgres;

--
-- Name: escalation_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.escalation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.escalation_id_seq OWNER TO postgres;

--
-- Name: eventtypes; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.eventtypes (
    instanceid bigint NOT NULL,
    element character varying(255)
);


ALTER TABLE pam.eventtypes OWNER TO postgres;

--
-- Name: exec_error_info_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.exec_error_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.exec_error_info_id_seq OWNER TO postgres;

--
-- Name: executionerrorinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.executionerrorinfo (
    id bigint NOT NULL,
    error_ack smallint,
    error_ack_at timestamp without time zone,
    error_ack_by character varying(255),
    activity_id bigint,
    activity_name character varying(255),
    deployment_id character varying(255),
    error_info text,
    error_date timestamp without time zone,
    error_id character varying(255),
    error_msg character varying(255),
    init_activity_id bigint,
    job_id bigint,
    process_id character varying(255),
    process_inst_id bigint,
    error_type character varying(255)
);


ALTER TABLE pam.executionerrorinfo OWNER TO postgres;

--
-- Name: i18ntext; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.i18ntext (
    id bigint NOT NULL,
    language character varying(255),
    shorttext character varying(255),
    text text,
    task_subjects_id bigint,
    task_names_id bigint,
    task_descriptions_id bigint,
    reassignment_documentation_id bigint,
    notification_subjects_id bigint,
    notification_names_id bigint,
    notification_documentation_id bigint,
    notification_descriptions_id bigint,
    deadline_documentation_id bigint
);


ALTER TABLE pam.i18ntext OWNER TO postgres;

--
-- Name: i18ntext_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.i18ntext_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.i18ntext_id_seq OWNER TO postgres;

--
-- Name: jbpm_active_clob; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.jbpm_active_clob (
    loid oid
);


ALTER TABLE pam.jbpm_active_clob OWNER TO postgres;

--
-- Name: node_inst_log_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.node_inst_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.node_inst_log_id_seq OWNER TO postgres;

--
-- Name: nodeinstancelog; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.nodeinstancelog (
    id bigint NOT NULL,
    connection character varying(255),
    log_date timestamp without time zone,
    externalid character varying(255),
    nodeid character varying(255),
    nodeinstanceid character varying(255),
    nodename character varying(255),
    nodetype character varying(255),
    processid character varying(255),
    processinstanceid bigint NOT NULL,
    sla_due_date timestamp without time zone,
    slacompliance integer,
    type integer NOT NULL,
    workitemid bigint,
    nodecontainerid character varying(255),
    referenceid bigint
);


ALTER TABLE pam.nodeinstancelog OWNER TO postgres;

--
-- Name: notification; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.notification (
    dtype character varying(31) NOT NULL,
    id bigint NOT NULL,
    priority integer NOT NULL,
    escalation_notifications_id bigint
);


ALTER TABLE pam.notification OWNER TO postgres;

--
-- Name: notification_bas; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.notification_bas (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.notification_bas OWNER TO postgres;

--
-- Name: notification_email_header; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.notification_email_header (
    notification_id bigint NOT NULL,
    emailheaders_id bigint NOT NULL,
    mapkey character varying(255) NOT NULL
);


ALTER TABLE pam.notification_email_header OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.notification_id_seq OWNER TO postgres;

--
-- Name: notification_recipients; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.notification_recipients (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.notification_recipients OWNER TO postgres;

--
-- Name: organizationalentity; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.organizationalentity (
    dtype character varying(31) NOT NULL,
    id character varying(255) NOT NULL
);


ALTER TABLE pam.organizationalentity OWNER TO postgres;

--
-- Name: peopleassignments_bas; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.peopleassignments_bas (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.peopleassignments_bas OWNER TO postgres;

--
-- Name: peopleassignments_exclowners; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.peopleassignments_exclowners (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.peopleassignments_exclowners OWNER TO postgres;

--
-- Name: peopleassignments_potowners; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.peopleassignments_potowners (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.peopleassignments_potowners OWNER TO postgres;

--
-- Name: peopleassignments_recipients; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.peopleassignments_recipients (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.peopleassignments_recipients OWNER TO postgres;

--
-- Name: peopleassignments_stakeholders; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.peopleassignments_stakeholders (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.peopleassignments_stakeholders OWNER TO postgres;

--
-- Name: proc_inst_log_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.proc_inst_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.proc_inst_log_id_seq OWNER TO postgres;

--
-- Name: process_instance_info_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.process_instance_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.process_instance_info_id_seq OWNER TO postgres;

--
-- Name: processinstanceinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.processinstanceinfo (
    instanceid bigint NOT NULL,
    lastmodificationdate timestamp without time zone,
    lastreaddate timestamp without time zone,
    processid character varying(255),
    processinstancebytearray oid,
    startdate timestamp without time zone,
    state integer NOT NULL,
    optlock integer
);


ALTER TABLE pam.processinstanceinfo OWNER TO postgres;

--
-- Name: processinstancelog; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.processinstancelog (
    id bigint NOT NULL,
    correlationkey character varying(255),
    duration bigint,
    end_date timestamp without time zone,
    externalid character varying(255),
    user_identity character varying(255),
    outcome character varying(255),
    parentprocessinstanceid bigint,
    processid character varying(255),
    processinstancedescription character varying(255),
    processinstanceid bigint NOT NULL,
    processname character varying(255),
    processtype integer,
    processversion character varying(255),
    sla_due_date timestamp without time zone,
    slacompliance integer,
    start_date timestamp without time zone,
    status integer
);


ALTER TABLE pam.processinstancelog OWNER TO postgres;

--
-- Name: qrtz_blob_triggers; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE pam.qrtz_blob_triggers OWNER TO postgres;

--
-- Name: qrtz_calendars; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE pam.qrtz_calendars OWNER TO postgres;

--
-- Name: qrtz_cron_triggers; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(120) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE pam.qrtz_cron_triggers OWNER TO postgres;

--
-- Name: qrtz_fired_triggers; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    sched_time bigint NOT NULL,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent boolean,
    requests_recovery boolean
);


ALTER TABLE pam.qrtz_fired_triggers OWNER TO postgres;

--
-- Name: qrtz_job_details; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    is_nonconcurrent boolean NOT NULL,
    is_update_data boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


ALTER TABLE pam.qrtz_job_details OWNER TO postgres;

--
-- Name: qrtz_locks; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


ALTER TABLE pam.qrtz_locks OWNER TO postgres;

--
-- Name: qrtz_paused_trigger_grps; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


ALTER TABLE pam.qrtz_paused_trigger_grps OWNER TO postgres;

--
-- Name: qrtz_scheduler_state; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE pam.qrtz_scheduler_state OWNER TO postgres;

--
-- Name: qrtz_simple_triggers; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE pam.qrtz_simple_triggers OWNER TO postgres;

--
-- Name: qrtz_simprop_triggers; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 boolean,
    bool_prop_2 boolean
);


ALTER TABLE pam.qrtz_simprop_triggers OWNER TO postgres;

--
-- Name: qrtz_triggers; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.qrtz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr smallint,
    job_data bytea
);


ALTER TABLE pam.qrtz_triggers OWNER TO postgres;

--
-- Name: query_def_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.query_def_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.query_def_id_seq OWNER TO postgres;

--
-- Name: querydefinitionstore; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.querydefinitionstore (
    id bigint NOT NULL,
    qexpression text,
    qname character varying(255),
    qsource character varying(255),
    qtarget character varying(255)
);


ALTER TABLE pam.querydefinitionstore OWNER TO postgres;

--
-- Name: reassignment; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.reassignment (
    id bigint NOT NULL,
    escalation_reassignments_id bigint
);


ALTER TABLE pam.reassignment OWNER TO postgres;

--
-- Name: reassignment_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.reassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.reassignment_id_seq OWNER TO postgres;

--
-- Name: reassignment_potentialowners; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.reassignment_potentialowners (
    task_id bigint NOT NULL,
    entity_id character varying(255) NOT NULL
);


ALTER TABLE pam.reassignment_potentialowners OWNER TO postgres;

--
-- Name: request_info_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.request_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.request_info_id_seq OWNER TO postgres;

--
-- Name: requestinfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.requestinfo (
    id bigint NOT NULL,
    commandname character varying(255),
    deploymentid character varying(255),
    executions integer NOT NULL,
    businesskey character varying(255),
    message character varying(255),
    owner character varying(255),
    priority integer NOT NULL,
    processinstanceid bigint,
    requestdata oid,
    responsedata oid,
    retries integer NOT NULL,
    status character varying(255),
    "timestamp" timestamp without time zone
);


ALTER TABLE pam.requestinfo OWNER TO postgres;

--
-- Name: sessioninfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.sessioninfo (
    id bigint NOT NULL,
    lastmodificationdate timestamp without time zone,
    rulesbytearray oid,
    startdate timestamp without time zone,
    optlock integer
);


ALTER TABLE pam.sessioninfo OWNER TO postgres;

--
-- Name: sessioninfo_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.sessioninfo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.sessioninfo_id_seq OWNER TO postgres;

--
-- Name: task; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.task (
    id bigint NOT NULL,
    archived smallint,
    allowedtodelegate character varying(255),
    description character varying(255),
    formname character varying(255),
    name character varying(255),
    priority integer NOT NULL,
    subtaskstrategy character varying(255),
    subject character varying(255),
    activationtime timestamp without time zone,
    createdon timestamp without time zone,
    deploymentid character varying(255),
    documentaccesstype integer,
    documentcontentid bigint NOT NULL,
    documenttype character varying(255),
    expirationtime timestamp without time zone,
    faultaccesstype integer,
    faultcontentid bigint NOT NULL,
    faultname character varying(255),
    faulttype character varying(255),
    outputaccesstype integer,
    outputcontentid bigint NOT NULL,
    outputtype character varying(255),
    parentid bigint NOT NULL,
    previousstatus integer,
    processid character varying(255),
    processinstanceid bigint NOT NULL,
    processsessionid bigint NOT NULL,
    skipable boolean NOT NULL,
    status character varying(255),
    workitemid bigint NOT NULL,
    tasktype character varying(255),
    optlock integer,
    taskinitiator_id character varying(255),
    actualowner_id character varying(255),
    createdby_id character varying(255)
);


ALTER TABLE pam.task OWNER TO postgres;

--
-- Name: task_comment; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.task_comment (
    id bigint NOT NULL,
    addedat timestamp without time zone,
    text text,
    addedby_id character varying(255),
    taskdata_comments_id bigint
);


ALTER TABLE pam.task_comment OWNER TO postgres;

--
-- Name: task_def_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.task_def_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.task_def_id_seq OWNER TO postgres;

--
-- Name: task_event_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.task_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.task_event_id_seq OWNER TO postgres;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.task_id_seq OWNER TO postgres;

--
-- Name: task_var_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.task_var_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.task_var_id_seq OWNER TO postgres;

--
-- Name: taskdef; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.taskdef (
    id bigint NOT NULL,
    name character varying(255),
    priority integer NOT NULL
);


ALTER TABLE pam.taskdef OWNER TO postgres;

--
-- Name: taskevent; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.taskevent (
    id bigint NOT NULL,
    logtime timestamp without time zone,
    message character varying(255),
    processinstanceid bigint,
    taskid bigint,
    type character varying(255),
    userid character varying(255),
    optlock integer,
    workitemid bigint
);


ALTER TABLE pam.taskevent OWNER TO postgres;

--
-- Name: taskvariableimpl; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.taskvariableimpl (
    id bigint NOT NULL,
    modificationdate timestamp without time zone,
    name character varying(255),
    processid character varying(255),
    processinstanceid bigint,
    taskid bigint,
    type integer,
    value character varying(4000)
);


ALTER TABLE pam.taskvariableimpl OWNER TO postgres;

--
-- Name: var_inst_log_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.var_inst_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.var_inst_log_id_seq OWNER TO postgres;

--
-- Name: variableinstancelog; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.variableinstancelog (
    id bigint NOT NULL,
    log_date timestamp without time zone,
    externalid character varying(255),
    oldvalue character varying(255),
    processid character varying(255),
    processinstanceid bigint NOT NULL,
    value character varying(255),
    variableid character varying(255),
    variableinstanceid character varying(255)
);


ALTER TABLE pam.variableinstancelog OWNER TO postgres;

--
-- Name: workiteminfo; Type: TABLE; Schema: pam; Owner: postgres
--

CREATE TABLE pam.workiteminfo (
    workitemid bigint NOT NULL,
    creationdate timestamp without time zone,
    name character varying(255),
    processinstanceid bigint NOT NULL,
    state bigint NOT NULL,
    optlock integer,
    workitembytearray oid
);


ALTER TABLE pam.workiteminfo OWNER TO postgres;

--
-- Name: workiteminfo_id_seq; Type: SEQUENCE; Schema: pam; Owner: postgres
--

CREATE SEQUENCE pam.workiteminfo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pam.workiteminfo_id_seq OWNER TO postgres;

--
-- Name: attachment attachment_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.attachment
    ADD CONSTRAINT attachment_pkey PRIMARY KEY (id);


--
-- Name: audittaskimpl audittaskimpl_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.audittaskimpl
    ADD CONSTRAINT audittaskimpl_pkey PRIMARY KEY (id);


--
-- Name: bamtasksummary bamtasksummary_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.bamtasksummary
    ADD CONSTRAINT bamtasksummary_pkey PRIMARY KEY (pk);


--
-- Name: booleanexpression booleanexpression_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.booleanexpression
    ADD CONSTRAINT booleanexpression_pkey PRIMARY KEY (id);


--
-- Name: casefiledatalog casefiledatalog_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.casefiledatalog
    ADD CONSTRAINT casefiledatalog_pkey PRIMARY KEY (id);


--
-- Name: caseidinfo caseidinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.caseidinfo
    ADD CONSTRAINT caseidinfo_pkey PRIMARY KEY (id);


--
-- Name: caseroleassignmentlog caseroleassignmentlog_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.caseroleassignmentlog
    ADD CONSTRAINT caseroleassignmentlog_pkey PRIMARY KEY (id);


--
-- Name: content content_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.content
    ADD CONSTRAINT content_pkey PRIMARY KEY (id);


--
-- Name: contextmappinginfo contextmappinginfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.contextmappinginfo
    ADD CONSTRAINT contextmappinginfo_pkey PRIMARY KEY (mappingid);


--
-- Name: correlationkeyinfo correlationkeyinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.correlationkeyinfo
    ADD CONSTRAINT correlationkeyinfo_pkey PRIMARY KEY (keyid);


--
-- Name: correlationpropertyinfo correlationpropertyinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.correlationpropertyinfo
    ADD CONSTRAINT correlationpropertyinfo_pkey PRIMARY KEY (propertyid);


--
-- Name: deadline deadline_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deadline
    ADD CONSTRAINT deadline_pkey PRIMARY KEY (id);


--
-- Name: deploymentstore deploymentstore_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deploymentstore
    ADD CONSTRAINT deploymentstore_pkey PRIMARY KEY (id);


--
-- Name: email_header email_header_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.email_header
    ADD CONSTRAINT email_header_pkey PRIMARY KEY (id);


--
-- Name: errorinfo errorinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.errorinfo
    ADD CONSTRAINT errorinfo_pkey PRIMARY KEY (id);


--
-- Name: escalation escalation_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.escalation
    ADD CONSTRAINT escalation_pkey PRIMARY KEY (id);


--
-- Name: executionerrorinfo executionerrorinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.executionerrorinfo
    ADD CONSTRAINT executionerrorinfo_pkey PRIMARY KEY (id);


--
-- Name: i18ntext i18ntext_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT i18ntext_pkey PRIMARY KEY (id);


--
-- Name: nodeinstancelog nodeinstancelog_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.nodeinstancelog
    ADD CONSTRAINT nodeinstancelog_pkey PRIMARY KEY (id);


--
-- Name: notification_email_header notification_email_header_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_email_header
    ADD CONSTRAINT notification_email_header_pkey PRIMARY KEY (notification_id, mapkey);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: organizationalentity organizationalentity_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.organizationalentity
    ADD CONSTRAINT organizationalentity_pkey PRIMARY KEY (id);


--
-- Name: processinstanceinfo processinstanceinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.processinstanceinfo
    ADD CONSTRAINT processinstanceinfo_pkey PRIMARY KEY (instanceid);


--
-- Name: processinstancelog processinstancelog_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.processinstancelog
    ADD CONSTRAINT processinstancelog_pkey PRIMARY KEY (id);


--
-- Name: qrtz_blob_triggers qrtz_blob_triggers_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_blob_triggers
    ADD CONSTRAINT qrtz_blob_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_calendars qrtz_calendars_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_calendars
    ADD CONSTRAINT qrtz_calendars_pkey PRIMARY KEY (sched_name, calendar_name);


--
-- Name: qrtz_cron_triggers qrtz_cron_triggers_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_cron_triggers
    ADD CONSTRAINT qrtz_cron_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_fired_triggers qrtz_fired_triggers_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_fired_triggers
    ADD CONSTRAINT qrtz_fired_triggers_pkey PRIMARY KEY (sched_name, entry_id);


--
-- Name: qrtz_job_details qrtz_job_details_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_job_details
    ADD CONSTRAINT qrtz_job_details_pkey PRIMARY KEY (sched_name, job_name, job_group);


--
-- Name: qrtz_locks qrtz_locks_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_locks
    ADD CONSTRAINT qrtz_locks_pkey PRIMARY KEY (sched_name, lock_name);


--
-- Name: qrtz_paused_trigger_grps qrtz_paused_trigger_grps_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_paused_trigger_grps
    ADD CONSTRAINT qrtz_paused_trigger_grps_pkey PRIMARY KEY (sched_name, trigger_group);


--
-- Name: qrtz_scheduler_state qrtz_scheduler_state_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_scheduler_state
    ADD CONSTRAINT qrtz_scheduler_state_pkey PRIMARY KEY (sched_name, instance_name);


--
-- Name: qrtz_simple_triggers qrtz_simple_triggers_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_simple_triggers
    ADD CONSTRAINT qrtz_simple_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_simprop_triggers qrtz_simprop_triggers_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_simprop_triggers
    ADD CONSTRAINT qrtz_simprop_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_triggers qrtz_triggers_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_triggers
    ADD CONSTRAINT qrtz_triggers_pkey PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: querydefinitionstore querydefinitionstore_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.querydefinitionstore
    ADD CONSTRAINT querydefinitionstore_pkey PRIMARY KEY (id);


--
-- Name: reassignment reassignment_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment
    ADD CONSTRAINT reassignment_pkey PRIMARY KEY (id);


--
-- Name: requestinfo requestinfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.requestinfo
    ADD CONSTRAINT requestinfo_pkey PRIMARY KEY (id);


--
-- Name: sessioninfo sessioninfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.sessioninfo
    ADD CONSTRAINT sessioninfo_pkey PRIMARY KEY (id);


--
-- Name: task_comment task_comment_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task_comment
    ADD CONSTRAINT task_comment_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: taskdef taskdef_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.taskdef
    ADD CONSTRAINT taskdef_pkey PRIMARY KEY (id);


--
-- Name: taskevent taskevent_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.taskevent
    ADD CONSTRAINT taskevent_pkey PRIMARY KEY (id);


--
-- Name: taskvariableimpl taskvariableimpl_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.taskvariableimpl
    ADD CONSTRAINT taskvariableimpl_pkey PRIMARY KEY (id);


--
-- Name: querydefinitionstore uk1dmy087nhbykucpgjipcnyluv; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.querydefinitionstore
    ADD CONSTRAINT uk1dmy087nhbykucpgjipcnyluv UNIQUE (qname);


--
-- Name: deploymentstore uk85rgskt09thd8mkkfl3tb0y81; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deploymentstore
    ADD CONSTRAINT uk85rgskt09thd8mkkfl3tb0y81 UNIQUE (deployment_id);


--
-- Name: querydefinitionstore uk_4ry5gt77jvq0orfttsoghta2j; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.querydefinitionstore
    ADD CONSTRAINT uk_4ry5gt77jvq0orfttsoghta2j UNIQUE (qname);


--
-- Name: deploymentstore uk_85rgskt09thd8mkkfl3tb0y81; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deploymentstore
    ADD CONSTRAINT uk_85rgskt09thd8mkkfl3tb0y81 UNIQUE (deployment_id);


--
-- Name: caseidinfo uk_caseidinfo_1; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.caseidinfo
    ADD CONSTRAINT uk_caseidinfo_1 UNIQUE (caseidprefix);


--
-- Name: notification_email_header uk_ptaka5kost68h7l3wflv7w6y8; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_email_header
    ADD CONSTRAINT uk_ptaka5kost68h7l3wflv7w6y8 UNIQUE (emailheaders_id);


--
-- Name: caseidinfo ukftvt225gyxpjnl3d06alqkqyj; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.caseidinfo
    ADD CONSTRAINT ukftvt225gyxpjnl3d06alqkqyj UNIQUE (caseidprefix);


--
-- Name: variableinstancelog variableinstancelog_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.variableinstancelog
    ADD CONSTRAINT variableinstancelog_pkey PRIMARY KEY (id);


--
-- Name: workiteminfo workiteminfo_pkey; Type: CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.workiteminfo
    ADD CONSTRAINT workiteminfo_pkey PRIMARY KEY (workitemid);


--
-- Name: idx_attachment_dataid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_attachment_dataid ON pam.attachment USING btree (taskdata_attachments_id);


--
-- Name: idx_attachment_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_attachment_id ON pam.attachment USING btree (attachedby_id);


--
-- Name: idx_audittaskimpl_name; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_audittaskimpl_name ON pam.audittaskimpl USING btree (name);


--
-- Name: idx_audittaskimpl_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_audittaskimpl_pinstid ON pam.audittaskimpl USING btree (processinstanceid);


--
-- Name: idx_audittaskimpl_processid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_audittaskimpl_processid ON pam.audittaskimpl USING btree (processid);


--
-- Name: idx_audittaskimpl_status; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_audittaskimpl_status ON pam.audittaskimpl USING btree (status);


--
-- Name: idx_audittaskimpl_taskid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_audittaskimpl_taskid ON pam.audittaskimpl USING btree (taskid);


--
-- Name: idx_audittaskimpl_workitemid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_audittaskimpl_workitemid ON pam.audittaskimpl USING btree (workitemid);


--
-- Name: idx_bamtasksumm_createddate; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_createddate ON pam.bamtasksummary USING btree (createddate);


--
-- Name: idx_bamtasksumm_duration; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_duration ON pam.bamtasksummary USING btree (duration);


--
-- Name: idx_bamtasksumm_enddate; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_enddate ON pam.bamtasksummary USING btree (enddate);


--
-- Name: idx_bamtasksumm_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_pinstid ON pam.bamtasksummary USING btree (processinstanceid);


--
-- Name: idx_bamtasksumm_startdate; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_startdate ON pam.bamtasksummary USING btree (startdate);


--
-- Name: idx_bamtasksumm_status; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_status ON pam.bamtasksummary USING btree (status);


--
-- Name: idx_bamtasksumm_taskid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_taskid ON pam.bamtasksummary USING btree (taskid);


--
-- Name: idx_bamtasksumm_taskname; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_taskname ON pam.bamtasksummary USING btree (taskname);


--
-- Name: idx_bamtasksumm_userid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_bamtasksumm_userid ON pam.bamtasksummary USING btree (userid);


--
-- Name: idx_boolexpr_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_boolexpr_id ON pam.booleanexpression USING btree (escalation_constraints_id);


--
-- Name: idx_cmi_context; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_cmi_context ON pam.contextmappinginfo USING btree (context_id);


--
-- Name: idx_cmi_ksession; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_cmi_ksession ON pam.contextmappinginfo USING btree (ksession_id);


--
-- Name: idx_cmi_owner; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_cmi_owner ON pam.contextmappinginfo USING btree (owner_id);


--
-- Name: idx_corrpropinfo_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_corrpropinfo_id ON pam.correlationpropertyinfo USING btree (correlationkey_keyid);


--
-- Name: idx_deadline_endid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_deadline_endid ON pam.deadline USING btree (deadlines_enddeadline_id);


--
-- Name: idx_deadline_startid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_deadline_startid ON pam.deadline USING btree (deadlines_startdeadline_id);


--
-- Name: idx_delegation_entityid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_delegation_entityid ON pam.delegation_delegates USING btree (entity_id);


--
-- Name: idx_delegation_taskid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_delegation_taskid ON pam.delegation_delegates USING btree (task_id);


--
-- Name: idx_errorinfo_errorack; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_errorinfo_errorack ON pam.executionerrorinfo USING btree (error_ack);


--
-- Name: idx_errorinfo_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_errorinfo_id ON pam.errorinfo USING btree (request_id);


--
-- Name: idx_errorinfo_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_errorinfo_pinstid ON pam.executionerrorinfo USING btree (process_inst_id);


--
-- Name: idx_escalation_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_escalation_id ON pam.escalation USING btree (deadline_escalation_id);


--
-- Name: idx_eventtypes_element; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_eventtypes_element ON pam.eventtypes USING btree (element);


--
-- Name: idx_eventtypes_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_eventtypes_id ON pam.eventtypes USING btree (instanceid);


--
-- Name: idx_i18ntext_deaddocid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_deaddocid ON pam.i18ntext USING btree (deadline_documentation_id);


--
-- Name: idx_i18ntext_descrid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_descrid ON pam.i18ntext USING btree (task_descriptions_id);


--
-- Name: idx_i18ntext_nameid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_nameid ON pam.i18ntext USING btree (task_names_id);


--
-- Name: idx_i18ntext_notdescrid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_notdescrid ON pam.i18ntext USING btree (notification_descriptions_id);


--
-- Name: idx_i18ntext_notdocid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_notdocid ON pam.i18ntext USING btree (notification_documentation_id);


--
-- Name: idx_i18ntext_notnamid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_notnamid ON pam.i18ntext USING btree (notification_names_id);


--
-- Name: idx_i18ntext_notsubjid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_notsubjid ON pam.i18ntext USING btree (notification_subjects_id);


--
-- Name: idx_i18ntext_reassignid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_reassignid ON pam.i18ntext USING btree (reassignment_documentation_id);


--
-- Name: idx_i18ntext_subjid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_i18ntext_subjid ON pam.i18ntext USING btree (task_subjects_id);


--
-- Name: idx_ninstlog_nodetype; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_ninstlog_nodetype ON pam.nodeinstancelog USING btree (nodetype);


--
-- Name: idx_ninstlog_pid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_ninstlog_pid ON pam.nodeinstancelog USING btree (processid);


--
-- Name: idx_ninstlog_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_ninstlog_pinstid ON pam.nodeinstancelog USING btree (processinstanceid);


--
-- Name: idx_not_escid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_not_escid ON pam.notification USING btree (escalation_notifications_id);


--
-- Name: idx_notbas_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_notbas_entity ON pam.notification_bas USING btree (entity_id);


--
-- Name: idx_notbas_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_notbas_task ON pam.notification_bas USING btree (task_id);


--
-- Name: idx_notemail_header; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_notemail_header ON pam.notification_email_header USING btree (emailheaders_id);


--
-- Name: idx_notemail_not; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_notemail_not ON pam.notification_email_header USING btree (notification_id);


--
-- Name: idx_notrec_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_notrec_entity ON pam.notification_recipients USING btree (entity_id);


--
-- Name: idx_notrec_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_notrec_task ON pam.notification_recipients USING btree (task_id);


--
-- Name: idx_pasbas_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pasbas_entity ON pam.peopleassignments_bas USING btree (entity_id);


--
-- Name: idx_pasbas_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pasbas_task ON pam.peopleassignments_bas USING btree (task_id);


--
-- Name: idx_pasexcl_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pasexcl_entity ON pam.peopleassignments_exclowners USING btree (entity_id);


--
-- Name: idx_pasexcl_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pasexcl_task ON pam.peopleassignments_exclowners USING btree (task_id);


--
-- Name: idx_paspot_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_paspot_entity ON pam.peopleassignments_potowners USING btree (entity_id);


--
-- Name: idx_paspot_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_paspot_task ON pam.peopleassignments_potowners USING btree (task_id);


--
-- Name: idx_pasrecip_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pasrecip_entity ON pam.peopleassignments_recipients USING btree (entity_id);


--
-- Name: idx_pasrecip_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pasrecip_task ON pam.peopleassignments_recipients USING btree (task_id);


--
-- Name: idx_passtake_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_passtake_entity ON pam.peopleassignments_stakeholders USING btree (entity_id);


--
-- Name: idx_passtake_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_passtake_task ON pam.peopleassignments_stakeholders USING btree (task_id);


--
-- Name: idx_pinstlog_correlation; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_correlation ON pam.processinstancelog USING btree (correlationkey);


--
-- Name: idx_pinstlog_duration; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_duration ON pam.processinstancelog USING btree (duration);


--
-- Name: idx_pinstlog_end_date; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_end_date ON pam.processinstancelog USING btree (end_date);


--
-- Name: idx_pinstlog_extid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_extid ON pam.processinstancelog USING btree (externalid);


--
-- Name: idx_pinstlog_outcome; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_outcome ON pam.processinstancelog USING btree (outcome);


--
-- Name: idx_pinstlog_parentpinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_parentpinstid ON pam.processinstancelog USING btree (parentprocessinstanceid);


--
-- Name: idx_pinstlog_pid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_pid ON pam.processinstancelog USING btree (processid);


--
-- Name: idx_pinstlog_pinstedescr; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_pinstedescr ON pam.processinstancelog USING btree (processinstancedescription);


--
-- Name: idx_pinstlog_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_pinstid ON pam.processinstancelog USING btree (processinstanceid);


--
-- Name: idx_pinstlog_pname; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_pname ON pam.processinstancelog USING btree (processname);


--
-- Name: idx_pinstlog_pversion; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_pversion ON pam.processinstancelog USING btree (processversion);


--
-- Name: idx_pinstlog_start_date; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_start_date ON pam.processinstancelog USING btree (start_date);


--
-- Name: idx_pinstlog_status; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_status ON pam.processinstancelog USING btree (status);


--
-- Name: idx_pinstlog_user_identity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_pinstlog_user_identity ON pam.processinstancelog USING btree (user_identity);


--
-- Name: idx_qrtz_ft_inst_job_req_rcvry; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_inst_job_req_rcvry ON pam.qrtz_fired_triggers USING btree (sched_name, instance_name, requests_recovery);


--
-- Name: idx_qrtz_ft_j_g; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_j_g ON pam.qrtz_fired_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: idx_qrtz_ft_jg; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_jg ON pam.qrtz_fired_triggers USING btree (sched_name, job_group);


--
-- Name: idx_qrtz_ft_t_g; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_t_g ON pam.qrtz_fired_triggers USING btree (sched_name, trigger_name, trigger_group);


--
-- Name: idx_qrtz_ft_tg; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_tg ON pam.qrtz_fired_triggers USING btree (sched_name, trigger_group);


--
-- Name: idx_qrtz_ft_trig_inst_name; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_ft_trig_inst_name ON pam.qrtz_fired_triggers USING btree (sched_name, instance_name);


--
-- Name: idx_qrtz_j_grp; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_j_grp ON pam.qrtz_job_details USING btree (sched_name, job_group);


--
-- Name: idx_qrtz_j_req_recovery; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_j_req_recovery ON pam.qrtz_job_details USING btree (sched_name, requests_recovery);


--
-- Name: idx_qrtz_t_c; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_c ON pam.qrtz_triggers USING btree (sched_name, calendar_name);


--
-- Name: idx_qrtz_t_g; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_g ON pam.qrtz_triggers USING btree (sched_name, trigger_group);


--
-- Name: idx_qrtz_t_j; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_j ON pam.qrtz_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: idx_qrtz_t_jg; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_jg ON pam.qrtz_triggers USING btree (sched_name, job_group);


--
-- Name: idx_qrtz_t_n_g_state; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_n_g_state ON pam.qrtz_triggers USING btree (sched_name, trigger_group, trigger_state);


--
-- Name: idx_qrtz_t_n_state; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_n_state ON pam.qrtz_triggers USING btree (sched_name, trigger_name, trigger_group, trigger_state);


--
-- Name: idx_qrtz_t_next_fire_time; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_next_fire_time ON pam.qrtz_triggers USING btree (sched_name, next_fire_time);


--
-- Name: idx_qrtz_t_nft_misfire; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_misfire ON pam.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time);


--
-- Name: idx_qrtz_t_nft_st; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_st ON pam.qrtz_triggers USING btree (sched_name, trigger_state, next_fire_time);


--
-- Name: idx_qrtz_t_nft_st_misfire; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_st_misfire ON pam.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_state);


--
-- Name: idx_qrtz_t_nft_st_misfire_grp; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_nft_st_misfire_grp ON pam.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_group, trigger_state);


--
-- Name: idx_qrtz_t_state; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_qrtz_t_state ON pam.qrtz_triggers USING btree (sched_name, trigger_state);


--
-- Name: idx_reassign_esc; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_reassign_esc ON pam.reassignment USING btree (escalation_reassignments_id);


--
-- Name: idx_reassignpo_entity; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_reassignpo_entity ON pam.reassignment_potentialowners USING btree (entity_id);


--
-- Name: idx_reassignpo_task; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_reassignpo_task ON pam.reassignment_potentialowners USING btree (task_id);


--
-- Name: idx_requestinfo_owner; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_requestinfo_owner ON pam.requestinfo USING btree (owner);


--
-- Name: idx_requestinfo_status; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_requestinfo_status ON pam.requestinfo USING btree (status);


--
-- Name: idx_requestinfo_timestamp; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_requestinfo_timestamp ON pam.requestinfo USING btree ("timestamp");


--
-- Name: idx_task_actualowner; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_actualowner ON pam.task USING btree (actualowner_id);


--
-- Name: idx_task_archived; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_archived ON pam.task USING btree (archived);


--
-- Name: idx_task_createdby; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_createdby ON pam.task USING btree (createdby_id);


--
-- Name: idx_task_initiator; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_initiator ON pam.task USING btree (taskinitiator_id);


--
-- Name: idx_task_processid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_processid ON pam.task USING btree (processid);


--
-- Name: idx_task_processinstanceid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_processinstanceid ON pam.task USING btree (processinstanceid);


--
-- Name: idx_task_status; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_status ON pam.task USING btree (status);


--
-- Name: idx_task_workitemid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_task_workitemid ON pam.task USING btree (workitemid);


--
-- Name: idx_taskcomments_createdby; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_taskcomments_createdby ON pam.task_comment USING btree (addedby_id);


--
-- Name: idx_taskcomments_id; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_taskcomments_id ON pam.task_comment USING btree (taskdata_comments_id);


--
-- Name: idx_taskvariableimpl_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_taskvariableimpl_pinstid ON pam.taskvariableimpl USING btree (processinstanceid);


--
-- Name: idx_taskvariableimpl_processid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_taskvariableimpl_processid ON pam.taskvariableimpl USING btree (processid);


--
-- Name: idx_taskvariableimpl_taskid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_taskvariableimpl_taskid ON pam.taskvariableimpl USING btree (taskid);


--
-- Name: idx_vinstlog_pid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_vinstlog_pid ON pam.variableinstancelog USING btree (processid);


--
-- Name: idx_vinstlog_pinstid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_vinstlog_pinstid ON pam.variableinstancelog USING btree (processinstanceid);


--
-- Name: idx_vinstlog_varid; Type: INDEX; Schema: pam; Owner: postgres
--

CREATE INDEX idx_vinstlog_varid ON pam.variableinstancelog USING btree (variableid);


--
-- Name: booleanexpression booleanexpression_expression_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER booleanexpression_expression_clob_after_delete_trigger AFTER DELETE ON pam.booleanexpression FOR EACH ROW WHEN ((old.expression IS NOT NULL)) EXECUTE PROCEDURE pam.booleanexpression_expression_clob_after_delete();


--
-- Name: booleanexpression booleanexpression_expression_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER booleanexpression_expression_clob_after_update_trigger AFTER UPDATE ON pam.booleanexpression FOR EACH ROW WHEN (((old.expression IS NOT NULL) AND (old.expression IS DISTINCT FROM new.expression))) EXECUTE PROCEDURE pam.booleanexpression_expression_clob_after_update();


--
-- Name: booleanexpression booleanexpression_expression_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER booleanexpression_expression_clob_before_insert_trigger BEFORE INSERT ON pam.booleanexpression FOR EACH ROW WHEN ((new.expression IS NOT NULL)) EXECUTE PROCEDURE pam.booleanexpression_expression_clob_before_insert();


--
-- Name: booleanexpression booleanexpression_expression_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER booleanexpression_expression_clob_before_update_trigger BEFORE UPDATE ON pam.booleanexpression FOR EACH ROW WHEN (((new.expression IS NOT NULL) AND (old.expression IS DISTINCT FROM new.expression))) EXECUTE PROCEDURE pam.booleanexpression_expression_clob_before_update();


--
-- Name: deploymentstore deploymentstore_deploymentunit_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER deploymentstore_deploymentunit_clob_after_delete_trigger AFTER DELETE ON pam.deploymentstore FOR EACH ROW WHEN ((old.deploymentunit IS NOT NULL)) EXECUTE PROCEDURE pam.deploymentstore_deploymentunit_clob_after_delete();


--
-- Name: deploymentstore deploymentstore_deploymentunit_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER deploymentstore_deploymentunit_clob_after_update_trigger AFTER UPDATE ON pam.deploymentstore FOR EACH ROW WHEN (((old.deploymentunit IS NOT NULL) AND (old.deploymentunit IS DISTINCT FROM new.deploymentunit))) EXECUTE PROCEDURE pam.deploymentstore_deploymentunit_clob_after_update();


--
-- Name: deploymentstore deploymentstore_deploymentunit_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER deploymentstore_deploymentunit_clob_before_insert_trigger BEFORE INSERT ON pam.deploymentstore FOR EACH ROW WHEN ((new.deploymentunit IS NOT NULL)) EXECUTE PROCEDURE pam.deploymentstore_deploymentunit_clob_before_insert();


--
-- Name: deploymentstore deploymentstore_deploymentunit_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER deploymentstore_deploymentunit_clob_before_update_trigger BEFORE UPDATE ON pam.deploymentstore FOR EACH ROW WHEN (((new.deploymentunit IS NOT NULL) AND (old.deploymentunit IS DISTINCT FROM new.deploymentunit))) EXECUTE PROCEDURE pam.deploymentstore_deploymentunit_clob_before_update();


--
-- Name: email_header email_header_body_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER email_header_body_clob_after_delete_trigger AFTER DELETE ON pam.email_header FOR EACH ROW WHEN ((old.body IS NOT NULL)) EXECUTE PROCEDURE pam.email_header_body_clob_after_delete();


--
-- Name: email_header email_header_body_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER email_header_body_clob_after_update_trigger AFTER UPDATE ON pam.email_header FOR EACH ROW WHEN (((old.body IS NOT NULL) AND (old.body IS DISTINCT FROM new.body))) EXECUTE PROCEDURE pam.email_header_body_clob_after_update();


--
-- Name: email_header email_header_body_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER email_header_body_clob_before_insert_trigger BEFORE INSERT ON pam.email_header FOR EACH ROW WHEN ((new.body IS NOT NULL)) EXECUTE PROCEDURE pam.email_header_body_clob_before_insert();


--
-- Name: email_header email_header_body_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER email_header_body_clob_before_update_trigger BEFORE UPDATE ON pam.email_header FOR EACH ROW WHEN (((new.body IS NOT NULL) AND (old.body IS DISTINCT FROM new.body))) EXECUTE PROCEDURE pam.email_header_body_clob_before_update();


--
-- Name: executionerrorinfo executionerrorinfo_error_info_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER executionerrorinfo_error_info_clob_after_delete_trigger AFTER DELETE ON pam.executionerrorinfo FOR EACH ROW WHEN ((old.error_info IS NOT NULL)) EXECUTE PROCEDURE pam.executionerrorinfo_error_info_clob_after_delete();


--
-- Name: executionerrorinfo executionerrorinfo_error_info_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER executionerrorinfo_error_info_clob_after_update_trigger AFTER UPDATE ON pam.executionerrorinfo FOR EACH ROW WHEN (((old.error_info IS NOT NULL) AND (old.error_info IS DISTINCT FROM new.error_info))) EXECUTE PROCEDURE pam.executionerrorinfo_error_info_clob_after_update();


--
-- Name: executionerrorinfo executionerrorinfo_error_info_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER executionerrorinfo_error_info_clob_before_insert_trigger BEFORE INSERT ON pam.executionerrorinfo FOR EACH ROW WHEN ((new.error_info IS NOT NULL)) EXECUTE PROCEDURE pam.executionerrorinfo_error_info_clob_before_insert();


--
-- Name: executionerrorinfo executionerrorinfo_error_info_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER executionerrorinfo_error_info_clob_before_update_trigger BEFORE UPDATE ON pam.executionerrorinfo FOR EACH ROW WHEN (((new.error_info IS NOT NULL) AND (old.error_info IS DISTINCT FROM new.error_info))) EXECUTE PROCEDURE pam.executionerrorinfo_error_info_clob_before_update();


--
-- Name: i18ntext i18ntext_text_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER i18ntext_text_clob_after_delete_trigger AFTER DELETE ON pam.i18ntext FOR EACH ROW WHEN ((old.text IS NOT NULL)) EXECUTE PROCEDURE pam.i18ntext_text_clob_after_delete();


--
-- Name: i18ntext i18ntext_text_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER i18ntext_text_clob_after_update_trigger AFTER UPDATE ON pam.i18ntext FOR EACH ROW WHEN (((old.text IS NOT NULL) AND (old.text IS DISTINCT FROM new.text))) EXECUTE PROCEDURE pam.i18ntext_text_clob_after_update();


--
-- Name: i18ntext i18ntext_text_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER i18ntext_text_clob_before_insert_trigger BEFORE INSERT ON pam.i18ntext FOR EACH ROW WHEN ((new.text IS NOT NULL)) EXECUTE PROCEDURE pam.i18ntext_text_clob_before_insert();


--
-- Name: i18ntext i18ntext_text_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER i18ntext_text_clob_before_update_trigger BEFORE UPDATE ON pam.i18ntext FOR EACH ROW WHEN (((new.text IS NOT NULL) AND (old.text IS DISTINCT FROM new.text))) EXECUTE PROCEDURE pam.i18ntext_text_clob_before_update();


--
-- Name: querydefinitionstore querydefinitionstore_qexpression_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER querydefinitionstore_qexpression_clob_after_delete_trigger AFTER DELETE ON pam.querydefinitionstore FOR EACH ROW WHEN ((old.qexpression IS NOT NULL)) EXECUTE PROCEDURE pam.querydefinitionstore_qexpression_clob_after_delete();


--
-- Name: querydefinitionstore querydefinitionstore_qexpression_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER querydefinitionstore_qexpression_clob_after_update_trigger AFTER UPDATE ON pam.querydefinitionstore FOR EACH ROW WHEN (((old.qexpression IS NOT NULL) AND (old.qexpression IS DISTINCT FROM new.qexpression))) EXECUTE PROCEDURE pam.querydefinitionstore_qexpression_clob_after_update();


--
-- Name: querydefinitionstore querydefinitionstore_qexpression_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER querydefinitionstore_qexpression_clob_before_insert_trigger BEFORE INSERT ON pam.querydefinitionstore FOR EACH ROW WHEN ((new.qexpression IS NOT NULL)) EXECUTE PROCEDURE pam.querydefinitionstore_qexpression_clob_before_insert();


--
-- Name: querydefinitionstore querydefinitionstore_qexpression_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER querydefinitionstore_qexpression_clob_before_update_trigger BEFORE UPDATE ON pam.querydefinitionstore FOR EACH ROW WHEN (((new.qexpression IS NOT NULL) AND (old.qexpression IS DISTINCT FROM new.qexpression))) EXECUTE PROCEDURE pam.querydefinitionstore_qexpression_clob_before_update();


--
-- Name: task_comment task_comment_text_clob_after_delete_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER task_comment_text_clob_after_delete_trigger AFTER DELETE ON pam.task_comment FOR EACH ROW WHEN ((old.text IS NOT NULL)) EXECUTE PROCEDURE pam.task_comment_text_clob_after_delete();


--
-- Name: task_comment task_comment_text_clob_after_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER task_comment_text_clob_after_update_trigger AFTER UPDATE ON pam.task_comment FOR EACH ROW WHEN (((old.text IS NOT NULL) AND (old.text IS DISTINCT FROM new.text))) EXECUTE PROCEDURE pam.task_comment_text_clob_after_update();


--
-- Name: task_comment task_comment_text_clob_before_insert_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER task_comment_text_clob_before_insert_trigger BEFORE INSERT ON pam.task_comment FOR EACH ROW WHEN ((new.text IS NOT NULL)) EXECUTE PROCEDURE pam.task_comment_text_clob_before_insert();


--
-- Name: task_comment task_comment_text_clob_before_update_trigger; Type: TRIGGER; Schema: pam; Owner: postgres
--

CREATE TRIGGER task_comment_text_clob_before_update_trigger BEFORE UPDATE ON pam.task_comment FOR EACH ROW WHEN (((new.text IS NOT NULL) AND (old.text IS DISTINCT FROM new.text))) EXECUTE PROCEDURE pam.task_comment_text_clob_before_update();


--
-- Name: deadline fk361ggw230po88svgfasg36i2w; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deadline
    ADD CONSTRAINT fk361ggw230po88svgfasg36i2w FOREIGN KEY (deadlines_startdeadline_id) REFERENCES pam.task(id);


--
-- Name: notification_bas fk378pb1cvjv54w4ljqpw99s3wr; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_bas
    ADD CONSTRAINT fk378pb1cvjv54w4ljqpw99s3wr FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: escalation fk37v8ova8ti6jiblda7n6j298e; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.escalation
    ADD CONSTRAINT fk37v8ova8ti6jiblda7n6j298e FOREIGN KEY (deadline_escalation_id) REFERENCES pam.deadline(id);


--
-- Name: task fk48d1bfgwf0jqow1yk8ku4xcpi; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT fk48d1bfgwf0jqow1yk8ku4xcpi FOREIGN KEY (taskinitiator_id) REFERENCES pam.organizationalentity(id);


--
-- Name: peopleassignments_exclowners fk5ituvd6t8uvp63hsx6282xo6h; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_exclowners
    ADD CONSTRAINT fk5ituvd6t8uvp63hsx6282xo6h FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: i18ntext fk6k8hmfvhko069970eghiy2ifp; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk6k8hmfvhko069970eghiy2ifp FOREIGN KEY (notification_descriptions_id) REFERENCES pam.notification(id);


--
-- Name: delegation_delegates fk85x3trafk3wfbrv719cafr591; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.delegation_delegates
    ADD CONSTRAINT fk85x3trafk3wfbrv719cafr591 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fk8wn7sw34q6bifsi1pvl2b1yyb; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk8wn7sw34q6bifsi1pvl2b1yyb FOREIGN KEY (deadline_documentation_id) REFERENCES pam.deadline(id);


--
-- Name: peopleassignments_recipients fk9gnbv6bplxkxoedj35vg8n7ir; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_recipients
    ADD CONSTRAINT fk9gnbv6bplxkxoedj35vg8n7ir FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: peopleassignments_stakeholders fk9uy76cu650rg1nnkrtjwj1e9t; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_stakeholders
    ADD CONSTRAINT fk9uy76cu650rg1nnkrtjwj1e9t FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: task_comment fk_1ws9jdmhtey6mxu7jb0r0ufvs; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task_comment
    ADD CONSTRAINT fk_1ws9jdmhtey6mxu7jb0r0ufvs FOREIGN KEY (taskdata_comments_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fk_21qvifarxsvuxeaw5sxwh473w; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_21qvifarxsvuxeaw5sxwh473w FOREIGN KEY (deadline_documentation_id) REFERENCES pam.deadline(id);


--
-- Name: booleanexpression fk_394nf2qoc0k9ok6omgd6jtpso; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.booleanexpression
    ADD CONSTRAINT fk_394nf2qoc0k9ok6omgd6jtpso FOREIGN KEY (escalation_constraints_id) REFERENCES pam.escalation(id);


--
-- Name: notification_recipients fk_3l244pj8sh78vtn9imaymrg47; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_recipients
    ADD CONSTRAINT fk_3l244pj8sh78vtn9imaymrg47 FOREIGN KEY (task_id) REFERENCES pam.notification(id);


--
-- Name: peopleassignments_stakeholders fk_4bh3ay74x6ql9usunubttfdf1; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_stakeholders
    ADD CONSTRAINT fk_4bh3ay74x6ql9usunubttfdf1 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: peopleassignments_potowners fk_4dv2oji7pr35ru0w45trix02x; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_potowners
    ADD CONSTRAINT fk_4dv2oji7pr35ru0w45trix02x FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fk_4eyfp69ucrron2hr7qx4np2fp; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_4eyfp69ucrron2hr7qx4np2fp FOREIGN KEY (task_descriptions_id) REFERENCES pam.task(id);


--
-- Name: peopleassignments_recipients fk_4g7y3wx6gnokf6vycgpxs83d6; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_recipients
    ADD CONSTRAINT fk_4g7y3wx6gnokf6vycgpxs83d6 FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: deadline fk_68w742sge00vco2cq3jhbvmgx; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deadline
    ADD CONSTRAINT fk_68w742sge00vco2cq3jhbvmgx FOREIGN KEY (deadlines_startdeadline_id) REFERENCES pam.task(id);


--
-- Name: attachment fk_7ndpfa311i50bq7hy18q05va3; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.attachment
    ADD CONSTRAINT fk_7ndpfa311i50bq7hy18q05va3 FOREIGN KEY (attachedby_id) REFERENCES pam.organizationalentity(id);


--
-- Name: reassignment_potentialowners fk_8frl6la7tgparlnukhp8xmody; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment_potentialowners
    ADD CONSTRAINT fk_8frl6la7tgparlnukhp8xmody FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: task_comment fk_aax378yjnsmw9kb9vsu994jjv; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task_comment
    ADD CONSTRAINT fk_aax378yjnsmw9kb9vsu994jjv FOREIGN KEY (addedby_id) REFERENCES pam.organizationalentity(id);


--
-- Name: escalation fk_ay2gd4fvl9yaapviyxudwuvfg; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.escalation
    ADD CONSTRAINT fk_ay2gd4fvl9yaapviyxudwuvfg FOREIGN KEY (deadline_escalation_id) REFERENCES pam.deadline(id);


--
-- Name: peopleassignments_exclowners fk_b8owuxfrdng050ugpk0pdowa7; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_exclowners
    ADD CONSTRAINT fk_b8owuxfrdng050ugpk0pdowa7 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: notification fk_bdbeml3768go5im41cgfpyso9; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification
    ADD CONSTRAINT fk_bdbeml3768go5im41cgfpyso9 FOREIGN KEY (escalation_notifications_id) REFERENCES pam.escalation(id);


--
-- Name: notification_recipients fk_blf9jsrumtrthdaqnpwxt25eu; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_recipients
    ADD CONSTRAINT fk_blf9jsrumtrthdaqnpwxt25eu FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: i18ntext fk_bw8vmpekejxt1ei2ge26gdsry; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_bw8vmpekejxt1ei2ge26gdsry FOREIGN KEY (notification_descriptions_id) REFERENCES pam.notification(id);


--
-- Name: errorinfo fk_cms0met37ggfw5p5gci3otaq0; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.errorinfo
    ADD CONSTRAINT fk_cms0met37ggfw5p5gci3otaq0 FOREIGN KEY (request_id) REFERENCES pam.requestinfo(id);


--
-- Name: task fk_dpk0f9ucm14c78bsxthh7h8yh; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT fk_dpk0f9ucm14c78bsxthh7h8yh FOREIGN KEY (taskinitiator_id) REFERENCES pam.organizationalentity(id);


--
-- Name: peopleassignments_recipients fk_enhk831fghf6akjilfn58okl4; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_recipients
    ADD CONSTRAINT fk_enhk831fghf6akjilfn58okl4 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: notification_email_header fk_eth4nvxn21fk1vnju85vkjrai; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_email_header
    ADD CONSTRAINT fk_eth4nvxn21fk1vnju85vkjrai FOREIGN KEY (notification_id) REFERENCES pam.notification(id);


--
-- Name: deadline fk_euoohoelbqvv94d8a8rcg8s5n; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deadline
    ADD CONSTRAINT fk_euoohoelbqvv94d8a8rcg8s5n FOREIGN KEY (deadlines_enddeadline_id) REFERENCES pam.task(id);


--
-- Name: delegation_delegates fk_fajq6kossbsqwr3opkrctxei3; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.delegation_delegates
    ADD CONSTRAINT fk_fajq6kossbsqwr3opkrctxei3 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: notification_bas fk_fc0uuy76t2bvxaxqysoo8xts7; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_bas
    ADD CONSTRAINT fk_fc0uuy76t2bvxaxqysoo8xts7 FOREIGN KEY (task_id) REFERENCES pam.notification(id);


--
-- Name: i18ntext fk_fd9uk6hemv2dx1ojovo7ms3vp; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_fd9uk6hemv2dx1ojovo7ms3vp FOREIGN KEY (task_names_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fk_g1trxri8w64enudw2t1qahhk5; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_g1trxri8w64enudw2t1qahhk5 FOREIGN KEY (notification_names_id) REFERENCES pam.notification(id);


--
-- Name: delegation_delegates fk_gn7ula51sk55wj1o1m57guqxb; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.delegation_delegates
    ADD CONSTRAINT fk_gn7ula51sk55wj1o1m57guqxb FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: attachment fk_hqupx569krp0f0sgu9kh87513; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.attachment
    ADD CONSTRAINT fk_hqupx569krp0f0sgu9kh87513 FOREIGN KEY (taskdata_attachments_id) REFERENCES pam.task(id);


--
-- Name: correlationpropertyinfo fk_hrmx1m882cejwj9c04ixh50i4; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.correlationpropertyinfo
    ADD CONSTRAINT fk_hrmx1m882cejwj9c04ixh50i4 FOREIGN KEY (correlationkey_keyid) REFERENCES pam.correlationkeyinfo(keyid);


--
-- Name: task fk_k02og0u71obf1uxgcdjx9rcjc; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT fk_k02og0u71obf1uxgcdjx9rcjc FOREIGN KEY (createdby_id) REFERENCES pam.organizationalentity(id);


--
-- Name: i18ntext fk_k16jpgrh67ti9uedf6konsu1p; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_k16jpgrh67ti9uedf6konsu1p FOREIGN KEY (task_subjects_id) REFERENCES pam.task(id);


--
-- Name: peopleassignments_stakeholders fk_met63inaep6cq4ofb3nnxi4tm; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_stakeholders
    ADD CONSTRAINT fk_met63inaep6cq4ofb3nnxi4tm FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: notification_bas fk_mfbsnbrhth4rjhqc2ud338s4i; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_bas
    ADD CONSTRAINT fk_mfbsnbrhth4rjhqc2ud338s4i FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: task fk_nh9nnt47f3l61qjlyedqt05rf; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT fk_nh9nnt47f3l61qjlyedqt05rf FOREIGN KEY (actualowner_id) REFERENCES pam.organizationalentity(id);


--
-- Name: eventtypes fk_nrecj4617iwxlc65ij6m7lsl1; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.eventtypes
    ADD CONSTRAINT fk_nrecj4617iwxlc65ij6m7lsl1 FOREIGN KEY (instanceid) REFERENCES pam.processinstanceinfo(instanceid);


--
-- Name: i18ntext fk_o84rkh69r47ti8uv4eyj7bmo2; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_o84rkh69r47ti8uv4eyj7bmo2 FOREIGN KEY (notification_subjects_id) REFERENCES pam.notification(id);


--
-- Name: peopleassignments_bas fk_omjg5qh7uv8e9bolbaq7hv6oh; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_bas
    ADD CONSTRAINT fk_omjg5qh7uv8e9bolbaq7hv6oh FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: reassignment fk_pnpeue9hs6kx2ep0sp16b6kfd; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment
    ADD CONSTRAINT fk_pnpeue9hs6kx2ep0sp16b6kfd FOREIGN KEY (escalation_reassignments_id) REFERENCES pam.escalation(id);


--
-- Name: i18ntext fk_pqarjvvnwfjpeyb87yd7m0bfi; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_pqarjvvnwfjpeyb87yd7m0bfi FOREIGN KEY (reassignment_documentation_id) REFERENCES pam.reassignment(id);


--
-- Name: notification_email_header fk_ptaka5kost68h7l3wflv7w6y8; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_email_header
    ADD CONSTRAINT fk_ptaka5kost68h7l3wflv7w6y8 FOREIGN KEY (emailheaders_id) REFERENCES pam.email_header(id);


--
-- Name: peopleassignments_exclowners fk_pth28a73rj6bxtlfc69kmqo0a; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_exclowners
    ADD CONSTRAINT fk_pth28a73rj6bxtlfc69kmqo0a FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: reassignment_potentialowners fk_qbega5ncu6b9yigwlw55aeijn; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment_potentialowners
    ADD CONSTRAINT fk_qbega5ncu6b9yigwlw55aeijn FOREIGN KEY (task_id) REFERENCES pam.reassignment(id);


--
-- Name: i18ntext fk_qoce92c70adem3ccb3i7lec8x; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fk_qoce92c70adem3ccb3i7lec8x FOREIGN KEY (notification_documentation_id) REFERENCES pam.notification(id);


--
-- Name: peopleassignments_bas fk_t38xbkrq6cppifnxequhvjsl2; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_bas
    ADD CONSTRAINT fk_t38xbkrq6cppifnxequhvjsl2 FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: peopleassignments_potowners fk_tee3ftir7xs6eo3fdvi3xw026; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_potowners
    ADD CONSTRAINT fk_tee3ftir7xs6eo3fdvi3xw026 FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: peopleassignments_bas fka90cdfgc4km384n1ataqigq67; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_bas
    ADD CONSTRAINT fka90cdfgc4km384n1ataqigq67 FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: peopleassignments_stakeholders fkaeyk4nwslvx0jywjomjq7083i; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_stakeholders
    ADD CONSTRAINT fkaeyk4nwslvx0jywjomjq7083i FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: notification_bas fkb123fgeomc741s9yc014421yy; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_bas
    ADD CONSTRAINT fkb123fgeomc741s9yc014421yy FOREIGN KEY (task_id) REFERENCES pam.notification(id);


--
-- Name: correlationpropertyinfo fkbchyl7kb8i6ghvi3dbr86bgo0; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.correlationpropertyinfo
    ADD CONSTRAINT fkbchyl7kb8i6ghvi3dbr86bgo0 FOREIGN KEY (correlationkey_keyid) REFERENCES pam.correlationkeyinfo(keyid);


--
-- Name: i18ntext fkcd6eb4q62d9ab8p0di8pb99ch; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkcd6eb4q62d9ab8p0di8pb99ch FOREIGN KEY (task_subjects_id) REFERENCES pam.task(id);


--
-- Name: attachment fkd5xpm81gxg8n40167lbu5rbfb; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.attachment
    ADD CONSTRAINT fkd5xpm81gxg8n40167lbu5rbfb FOREIGN KEY (attachedby_id) REFERENCES pam.organizationalentity(id);


--
-- Name: notification_email_header fkd74pdu41avy2f7a8qyp7wn2n; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_email_header
    ADD CONSTRAINT fkd74pdu41avy2f7a8qyp7wn2n FOREIGN KEY (emailheaders_id) REFERENCES pam.email_header(id);


--
-- Name: errorinfo fkdarp6ushq06q39jmij3fdpdbs; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.errorinfo
    ADD CONSTRAINT fkdarp6ushq06q39jmij3fdpdbs FOREIGN KEY (request_id) REFERENCES pam.requestinfo(id);


--
-- Name: reassignment fkessy30safh44b30f1cfoujv2k; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment
    ADD CONSTRAINT fkessy30safh44b30f1cfoujv2k FOREIGN KEY (escalation_reassignments_id) REFERENCES pam.escalation(id);


--
-- Name: delegation_delegates fkewkdyi0wrgy9byp6abyglpcxq; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.delegation_delegates
    ADD CONSTRAINT fkewkdyi0wrgy9byp6abyglpcxq FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: task fkexuboqnbla7jfyyesyo61ucmb; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT fkexuboqnbla7jfyyesyo61ucmb FOREIGN KEY (createdby_id) REFERENCES pam.organizationalentity(id);


--
-- Name: notification_email_header fkfdnoyp8rl0kxu29l4pyaa5566; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_email_header
    ADD CONSTRAINT fkfdnoyp8rl0kxu29l4pyaa5566 FOREIGN KEY (notification_id) REFERENCES pam.notification(id);


--
-- Name: reassignment_potentialowners fkftegfexshix752bh2jfxf6bnh; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment_potentialowners
    ADD CONSTRAINT fkftegfexshix752bh2jfxf6bnh FOREIGN KEY (task_id) REFERENCES pam.reassignment(id);


--
-- Name: i18ntext fkg2jsybeuc8pbj8ek8xwxutuyo; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkg2jsybeuc8pbj8ek8xwxutuyo FOREIGN KEY (notification_names_id) REFERENCES pam.notification(id);


--
-- Name: peopleassignments_potowners fkh8oqmk4iuh2pmpgby6g8r3jd1; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_potowners
    ADD CONSTRAINT fkh8oqmk4iuh2pmpgby6g8r3jd1 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fkiogka67sji8fk4cp7a369895i; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkiogka67sji8fk4cp7a369895i FOREIGN KEY (task_names_id) REFERENCES pam.task(id);


--
-- Name: eventtypes fkj0o3uve2nqo5yrjwrkc9jfttq; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.eventtypes
    ADD CONSTRAINT fkj0o3uve2nqo5yrjwrkc9jfttq FOREIGN KEY (instanceid) REFERENCES pam.processinstanceinfo(instanceid);


--
-- Name: attachment fkjj9psk52ifamilliyo16epwpc; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.attachment
    ADD CONSTRAINT fkjj9psk52ifamilliyo16epwpc FOREIGN KEY (taskdata_attachments_id) REFERENCES pam.task(id);


--
-- Name: task_comment fkm2mwc1ukcpdsiqwgkoroy6ise; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task_comment
    ADD CONSTRAINT fkm2mwc1ukcpdsiqwgkoroy6ise FOREIGN KEY (taskdata_comments_id) REFERENCES pam.task(id);


--
-- Name: notification_recipients fkn7v944d0hw37bh0auv4gr3hsf; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_recipients
    ADD CONSTRAINT fkn7v944d0hw37bh0auv4gr3hsf FOREIGN KEY (task_id) REFERENCES pam.notification(id);


--
-- Name: notification_recipients fkot769nimyq1jvw0m61pgsq5g3; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification_recipients
    ADD CONSTRAINT fkot769nimyq1jvw0m61pgsq5g3 FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: notification fkoxq5uqfg4ylwyijsg2ubyflna; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.notification
    ADD CONSTRAINT fkoxq5uqfg4ylwyijsg2ubyflna FOREIGN KEY (escalation_notifications_id) REFERENCES pam.escalation(id);


--
-- Name: i18ntext fkp0m7uhipskrljktvfeubdgfid; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkp0m7uhipskrljktvfeubdgfid FOREIGN KEY (notification_documentation_id) REFERENCES pam.notification(id);


--
-- Name: deadline fkpeiadnoy228t35213t63c3imm; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.deadline
    ADD CONSTRAINT fkpeiadnoy228t35213t63c3imm FOREIGN KEY (deadlines_enddeadline_id) REFERENCES pam.task(id);


--
-- Name: task fkpmkxvqq63aed2y2boruu53a0s; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task
    ADD CONSTRAINT fkpmkxvqq63aed2y2boruu53a0s FOREIGN KEY (actualowner_id) REFERENCES pam.organizationalentity(id);


--
-- Name: task_comment fkqb4mkarf209y9546w7n75lb7a; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.task_comment
    ADD CONSTRAINT fkqb4mkarf209y9546w7n75lb7a FOREIGN KEY (addedby_id) REFERENCES pam.organizationalentity(id);


--
-- Name: booleanexpression fkqth56a8k6d8pv6ngsu2vjp4kj; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.booleanexpression
    ADD CONSTRAINT fkqth56a8k6d8pv6ngsu2vjp4kj FOREIGN KEY (escalation_constraints_id) REFERENCES pam.escalation(id);


--
-- Name: peopleassignments_exclowners fkqxbjm1b3dl7w8w2f2y6sk0fv8; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_exclowners
    ADD CONSTRAINT fkqxbjm1b3dl7w8w2f2y6sk0fv8 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fkqxgws3fnukyqlaet11tivqg5u; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkqxgws3fnukyqlaet11tivqg5u FOREIGN KEY (reassignment_documentation_id) REFERENCES pam.reassignment(id);


--
-- Name: peopleassignments_recipients fkrd0h9ud1bhs9waf2mdmiv6j2r; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_recipients
    ADD CONSTRAINT fkrd0h9ud1bhs9waf2mdmiv6j2r FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: i18ntext fkrisdlmalotmk64mdeqpo4s5m0; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkrisdlmalotmk64mdeqpo4s5m0 FOREIGN KEY (task_descriptions_id) REFERENCES pam.task(id);


--
-- Name: peopleassignments_potowners fksa3rrrjsm1qw98ajbbu2s7cjr; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_potowners
    ADD CONSTRAINT fksa3rrrjsm1qw98ajbbu2s7cjr FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: reassignment_potentialowners fksqrmpvehlc4qe9i0km22nmkjl; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.reassignment_potentialowners
    ADD CONSTRAINT fksqrmpvehlc4qe9i0km22nmkjl FOREIGN KEY (entity_id) REFERENCES pam.organizationalentity(id);


--
-- Name: peopleassignments_bas fkt4xs0glwhbsa0xwg69r6xduv9; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.peopleassignments_bas
    ADD CONSTRAINT fkt4xs0glwhbsa0xwg69r6xduv9 FOREIGN KEY (task_id) REFERENCES pam.task(id);


--
-- Name: i18ntext fkthf8ix3t3opf9hya1s04hwsx8; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.i18ntext
    ADD CONSTRAINT fkthf8ix3t3opf9hya1s04hwsx8 FOREIGN KEY (notification_subjects_id) REFERENCES pam.notification(id);


--
-- Name: qrtz_blob_triggers qrtz_blob_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_blob_triggers
    ADD CONSTRAINT qrtz_blob_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES pam.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_cron_triggers qrtz_cron_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_cron_triggers
    ADD CONSTRAINT qrtz_cron_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES pam.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_simple_triggers qrtz_simple_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_simple_triggers
    ADD CONSTRAINT qrtz_simple_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES pam.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_simprop_triggers qrtz_simprop_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_simprop_triggers
    ADD CONSTRAINT qrtz_simprop_triggers_sched_name_fkey FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES pam.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_triggers qrtz_triggers_sched_name_fkey; Type: FK CONSTRAINT; Schema: pam; Owner: postgres
--

ALTER TABLE ONLY pam.qrtz_triggers
    ADD CONSTRAINT qrtz_triggers_sched_name_fkey FOREIGN KEY (sched_name, job_name, job_group) REFERENCES pam.qrtz_job_details(sched_name, job_name, job_group);


--
-- Name: DATABASE pamperf; Type: ACL; Schema: -; Owner: dbadmin
--

REVOKE CONNECT,TEMPORARY ON DATABASE pamperf FROM PUBLIC;
GRANT ALL ON DATABASE pamperf TO pamperf;
GRANT ALL ON DATABASE pamperf TO postgres;
GRANT CONNECT,TEMPORARY ON DATABASE pamperf TO read_role;
GRANT ALL ON DATABASE pamperf TO write_role;


--
-- Name: SCHEMA pam; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA pam TO write_role;
GRANT USAGE ON SCHEMA pam TO read_role;
GRANT ALL ON SCHEMA pam TO pamperf;


--
-- Name: FUNCTION booleanexpression_expression_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_after_delete() TO write_role;
GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION booleanexpression_expression_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_after_update() TO write_role;
GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_after_update() TO pamperf;


--
-- Name: FUNCTION booleanexpression_expression_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_before_insert() TO write_role;
GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION booleanexpression_expression_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_before_update() TO write_role;
GRANT ALL ON FUNCTION pam.booleanexpression_expression_clob_before_update() TO pamperf;


--
-- Name: FUNCTION deploymentstore_deploymentunit_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_after_delete() TO write_role;
GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION deploymentstore_deploymentunit_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_after_update() TO write_role;
GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_after_update() TO pamperf;


--
-- Name: FUNCTION deploymentstore_deploymentunit_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_before_insert() TO write_role;
GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION deploymentstore_deploymentunit_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_before_update() TO write_role;
GRANT ALL ON FUNCTION pam.deploymentstore_deploymentunit_clob_before_update() TO pamperf;


--
-- Name: FUNCTION email_header_body_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.email_header_body_clob_after_delete() TO write_role;
GRANT ALL ON FUNCTION pam.email_header_body_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION email_header_body_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.email_header_body_clob_after_update() TO write_role;
GRANT ALL ON FUNCTION pam.email_header_body_clob_after_update() TO pamperf;


--
-- Name: FUNCTION email_header_body_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.email_header_body_clob_before_insert() TO write_role;
GRANT ALL ON FUNCTION pam.email_header_body_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION email_header_body_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.email_header_body_clob_before_update() TO write_role;
GRANT ALL ON FUNCTION pam.email_header_body_clob_before_update() TO pamperf;


--
-- Name: FUNCTION executionerrorinfo_error_info_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.executionerrorinfo_error_info_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION executionerrorinfo_error_info_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.executionerrorinfo_error_info_clob_after_update() TO pamperf;


--
-- Name: FUNCTION executionerrorinfo_error_info_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.executionerrorinfo_error_info_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION executionerrorinfo_error_info_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.executionerrorinfo_error_info_clob_before_update() TO pamperf;


--
-- Name: FUNCTION i18ntext_text_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.i18ntext_text_clob_after_delete() TO write_role;
GRANT ALL ON FUNCTION pam.i18ntext_text_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION i18ntext_text_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.i18ntext_text_clob_after_update() TO write_role;
GRANT ALL ON FUNCTION pam.i18ntext_text_clob_after_update() TO pamperf;


--
-- Name: FUNCTION i18ntext_text_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.i18ntext_text_clob_before_insert() TO write_role;
GRANT ALL ON FUNCTION pam.i18ntext_text_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION i18ntext_text_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.i18ntext_text_clob_before_update() TO write_role;
GRANT ALL ON FUNCTION pam.i18ntext_text_clob_before_update() TO pamperf;


--
-- Name: FUNCTION querydefinitionstore_qexpression_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_after_delete() TO write_role;
GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION querydefinitionstore_qexpression_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_after_update() TO write_role;
GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_after_update() TO pamperf;


--
-- Name: FUNCTION querydefinitionstore_qexpression_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_before_insert() TO write_role;
GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION querydefinitionstore_qexpression_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_before_update() TO write_role;
GRANT ALL ON FUNCTION pam.querydefinitionstore_qexpression_clob_before_update() TO pamperf;


--
-- Name: FUNCTION task_comment_text_clob_after_delete(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.task_comment_text_clob_after_delete() TO write_role;
GRANT ALL ON FUNCTION pam.task_comment_text_clob_after_delete() TO pamperf;


--
-- Name: FUNCTION task_comment_text_clob_after_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.task_comment_text_clob_after_update() TO write_role;
GRANT ALL ON FUNCTION pam.task_comment_text_clob_after_update() TO pamperf;


--
-- Name: FUNCTION task_comment_text_clob_before_insert(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.task_comment_text_clob_before_insert() TO write_role;
GRANT ALL ON FUNCTION pam.task_comment_text_clob_before_insert() TO pamperf;


--
-- Name: FUNCTION task_comment_text_clob_before_update(); Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON FUNCTION pam.task_comment_text_clob_before_update() TO write_role;
GRANT ALL ON FUNCTION pam.task_comment_text_clob_before_update() TO pamperf;


--
-- Name: TABLE attachment; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.attachment TO pamperf;


--
-- Name: SEQUENCE attachment_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.attachment_id_seq TO pamperf;


--
-- Name: SEQUENCE audit_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.audit_id_seq TO pamperf;


--
-- Name: TABLE audittaskimpl; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.audittaskimpl TO pamperf;


--
-- Name: SEQUENCE bam_task_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.bam_task_id_seq TO pamperf;


--
-- Name: TABLE bamtasksummary; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.bamtasksummary TO pamperf;


--
-- Name: SEQUENCE booleanexpr_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.booleanexpr_id_seq TO pamperf;


--
-- Name: TABLE booleanexpression; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.booleanexpression TO pamperf;


--
-- Name: SEQUENCE case_file_data_log_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.case_file_data_log_id_seq TO pamperf;


--
-- Name: SEQUENCE case_id_info_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.case_id_info_id_seq TO pamperf;


--
-- Name: SEQUENCE case_role_assign_log_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.case_role_assign_log_id_seq TO pamperf;


--
-- Name: TABLE casefiledatalog; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.casefiledatalog TO pamperf;


--
-- Name: TABLE caseidinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.caseidinfo TO pamperf;


--
-- Name: TABLE caseroleassignmentlog; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.caseroleassignmentlog TO pamperf;


--
-- Name: SEQUENCE comment_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.comment_id_seq TO pamperf;


--
-- Name: TABLE content; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.content TO pamperf;


--
-- Name: SEQUENCE content_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.content_id_seq TO pamperf;


--
-- Name: SEQUENCE context_mapping_info_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.context_mapping_info_id_seq TO pamperf;


--
-- Name: TABLE contextmappinginfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.contextmappinginfo TO pamperf;


--
-- Name: SEQUENCE correlation_key_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.correlation_key_id_seq TO pamperf;


--
-- Name: SEQUENCE correlation_prop_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.correlation_prop_id_seq TO pamperf;


--
-- Name: TABLE correlationkeyinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.correlationkeyinfo TO pamperf;


--
-- Name: TABLE correlationpropertyinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.correlationpropertyinfo TO pamperf;


--
-- Name: TABLE deadline; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.deadline TO pamperf;


--
-- Name: SEQUENCE deadline_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.deadline_id_seq TO pamperf;


--
-- Name: TABLE delegation_delegates; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.delegation_delegates TO pamperf;


--
-- Name: SEQUENCE deploy_store_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.deploy_store_id_seq TO pamperf;


--
-- Name: TABLE deploymentstore; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.deploymentstore TO pamperf;


--
-- Name: TABLE email_header; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.email_header TO pamperf;


--
-- Name: SEQUENCE emailnotifhead_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.emailnotifhead_id_seq TO pamperf;


--
-- Name: SEQUENCE error_info_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.error_info_id_seq TO pamperf;


--
-- Name: TABLE errorinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.errorinfo TO pamperf;


--
-- Name: TABLE escalation; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.escalation TO pamperf;


--
-- Name: SEQUENCE escalation_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.escalation_id_seq TO pamperf;


--
-- Name: TABLE eventtypes; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.eventtypes TO pamperf;


--
-- Name: SEQUENCE exec_error_info_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.exec_error_info_id_seq TO pamperf;


--
-- Name: TABLE executionerrorinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.executionerrorinfo TO pamperf;


--
-- Name: TABLE i18ntext; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.i18ntext TO pamperf;


--
-- Name: SEQUENCE i18ntext_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.i18ntext_id_seq TO pamperf;


--
-- Name: TABLE jbpm_active_clob; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.jbpm_active_clob TO write_role;
GRANT SELECT ON TABLE pam.jbpm_active_clob TO read_role;
GRANT ALL ON TABLE pam.jbpm_active_clob TO pamperf;


--
-- Name: SEQUENCE node_inst_log_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.node_inst_log_id_seq TO pamperf;


--
-- Name: TABLE nodeinstancelog; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.nodeinstancelog TO pamperf;


--
-- Name: TABLE notification; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.notification TO pamperf;


--
-- Name: TABLE notification_bas; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.notification_bas TO pamperf;


--
-- Name: TABLE notification_email_header; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.notification_email_header TO pamperf;


--
-- Name: SEQUENCE notification_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.notification_id_seq TO pamperf;


--
-- Name: TABLE notification_recipients; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.notification_recipients TO pamperf;


--
-- Name: TABLE organizationalentity; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.organizationalentity TO pamperf;


--
-- Name: TABLE peopleassignments_bas; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.peopleassignments_bas TO pamperf;


--
-- Name: TABLE peopleassignments_exclowners; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.peopleassignments_exclowners TO pamperf;


--
-- Name: TABLE peopleassignments_potowners; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.peopleassignments_potowners TO pamperf;


--
-- Name: TABLE peopleassignments_recipients; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.peopleassignments_recipients TO pamperf;


--
-- Name: TABLE peopleassignments_stakeholders; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.peopleassignments_stakeholders TO pamperf;


--
-- Name: SEQUENCE proc_inst_log_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.proc_inst_log_id_seq TO pamperf;


--
-- Name: SEQUENCE process_instance_info_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.process_instance_info_id_seq TO pamperf;


--
-- Name: TABLE processinstanceinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.processinstanceinfo TO pamperf;


--
-- Name: TABLE processinstancelog; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.processinstancelog TO pamperf;


--
-- Name: TABLE qrtz_blob_triggers; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_blob_triggers TO write_role;
GRANT SELECT ON TABLE pam.qrtz_blob_triggers TO read_role;
GRANT ALL ON TABLE pam.qrtz_blob_triggers TO pamperf;


--
-- Name: TABLE qrtz_calendars; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_calendars TO write_role;
GRANT SELECT ON TABLE pam.qrtz_calendars TO read_role;
GRANT ALL ON TABLE pam.qrtz_calendars TO pamperf;


--
-- Name: TABLE qrtz_cron_triggers; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_cron_triggers TO write_role;
GRANT SELECT ON TABLE pam.qrtz_cron_triggers TO read_role;
GRANT ALL ON TABLE pam.qrtz_cron_triggers TO pamperf;


--
-- Name: TABLE qrtz_fired_triggers; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_fired_triggers TO write_role;
GRANT SELECT ON TABLE pam.qrtz_fired_triggers TO read_role;
GRANT ALL ON TABLE pam.qrtz_fired_triggers TO pamperf;


--
-- Name: TABLE qrtz_job_details; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_job_details TO write_role;
GRANT SELECT ON TABLE pam.qrtz_job_details TO read_role;
GRANT ALL ON TABLE pam.qrtz_job_details TO pamperf;


--
-- Name: TABLE qrtz_locks; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_locks TO write_role;
GRANT SELECT ON TABLE pam.qrtz_locks TO read_role;
GRANT ALL ON TABLE pam.qrtz_locks TO pamperf;


--
-- Name: TABLE qrtz_paused_trigger_grps; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_paused_trigger_grps TO write_role;
GRANT SELECT ON TABLE pam.qrtz_paused_trigger_grps TO read_role;
GRANT ALL ON TABLE pam.qrtz_paused_trigger_grps TO pamperf;


--
-- Name: TABLE qrtz_scheduler_state; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_scheduler_state TO write_role;
GRANT SELECT ON TABLE pam.qrtz_scheduler_state TO read_role;
GRANT ALL ON TABLE pam.qrtz_scheduler_state TO pamperf;


--
-- Name: TABLE qrtz_simple_triggers; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_simple_triggers TO write_role;
GRANT SELECT ON TABLE pam.qrtz_simple_triggers TO read_role;
GRANT ALL ON TABLE pam.qrtz_simple_triggers TO pamperf;


--
-- Name: TABLE qrtz_simprop_triggers; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_simprop_triggers TO write_role;
GRANT SELECT ON TABLE pam.qrtz_simprop_triggers TO read_role;
GRANT ALL ON TABLE pam.qrtz_simprop_triggers TO pamperf;


--
-- Name: TABLE qrtz_triggers; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.qrtz_triggers TO write_role;
GRANT SELECT ON TABLE pam.qrtz_triggers TO read_role;
GRANT ALL ON TABLE pam.qrtz_triggers TO pamperf;


--
-- Name: SEQUENCE query_def_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.query_def_id_seq TO pamperf;


--
-- Name: TABLE querydefinitionstore; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.querydefinitionstore TO pamperf;


--
-- Name: TABLE reassignment; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.reassignment TO pamperf;


--
-- Name: SEQUENCE reassignment_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.reassignment_id_seq TO pamperf;


--
-- Name: TABLE reassignment_potentialowners; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.reassignment_potentialowners TO pamperf;


--
-- Name: SEQUENCE request_info_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.request_info_id_seq TO pamperf;


--
-- Name: TABLE requestinfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.requestinfo TO pamperf;


--
-- Name: TABLE sessioninfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.sessioninfo TO pamperf;


--
-- Name: SEQUENCE sessioninfo_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.sessioninfo_id_seq TO pamperf;


--
-- Name: TABLE task; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.task TO pamperf;


--
-- Name: TABLE task_comment; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.task_comment TO pamperf;


--
-- Name: SEQUENCE task_def_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.task_def_id_seq TO pamperf;


--
-- Name: SEQUENCE task_event_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.task_event_id_seq TO pamperf;


--
-- Name: SEQUENCE task_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.task_id_seq TO pamperf;


--
-- Name: SEQUENCE task_var_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.task_var_id_seq TO pamperf;


--
-- Name: TABLE taskdef; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.taskdef TO pamperf;


--
-- Name: TABLE taskevent; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.taskevent TO pamperf;


--
-- Name: TABLE taskvariableimpl; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.taskvariableimpl TO pamperf;


--
-- Name: SEQUENCE var_inst_log_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.var_inst_log_id_seq TO pamperf;


--
-- Name: TABLE variableinstancelog; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.variableinstancelog TO pamperf;


--
-- Name: TABLE workiteminfo; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON TABLE pam.workiteminfo TO pamperf;


--
-- Name: SEQUENCE workiteminfo_id_seq; Type: ACL; Schema: pam; Owner: postgres
--

GRANT ALL ON SEQUENCE pam.workiteminfo_id_seq TO pamperf;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: pam; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam REVOKE ALL ON SEQUENCES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam GRANT SELECT,USAGE ON SEQUENCES  TO write_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: pam; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam REVOKE ALL ON FUNCTIONS  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam REVOKE ALL ON FUNCTIONS  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam GRANT ALL ON FUNCTIONS  TO write_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: pam; Owner: dbadmin
--

ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA pam REVOKE ALL ON FUNCTIONS  FROM PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pam; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam GRANT ALL ON TABLES  TO write_role;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA pam GRANT SELECT ON TABLES  TO read_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: pam; Owner: dbadmin
--

ALTER DEFAULT PRIVILEGES FOR ROLE dbadmin IN SCHEMA pam GRANT ALL ON TABLES  TO pamperf;


--
-- PostgreSQL database dump complete
--

