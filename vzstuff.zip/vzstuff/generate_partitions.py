#!/usr/bin/env python
##################################################################################################
#
# RANGE-->  ./generate_partitions.py -d ihr2 -o ihr -t ch_obs_producer_p -n ch_obs_producer_parent  -m range -s 150000000000 -f 90 -p 300 -k id -a -b 
# RANGE-->  ./generate_partitions.py -d ihr2 -o testing -t nodeinstancelog -n nodeinstancelog  -m range -y 2020 -f 90 -q monthly -b
# HASH -->  ./generate_partitions.py -d ihr2 -o testing -t nodeinstancelog -n nodeinstancelog  -m hash -f 90 -p 300 -k id,processinstanceid -b
# leave out primary key if you don't want them created manually for each child.  v11+ does it implicitly from parent
#
# disable autovacuum for partitioned tables
# HASH -->  ./generate_partitions.py -d ihr2 -o testing -t nodeinstancelog -n nodeinstancelog  -m hash -f 90 -p 300 -b
#
#
# NOTE:  For PG v12+ you need not specify primary keys or indexes for partitions being attached to existing table.
#        Hash partitioning is great when you have many different values.
##################################################################################################
##################################################################################################
import sys, os, argparse, time, datetime, calendar
from optparse import OptionParser 

verbose = True
nohups  = []
weeks   = []

def printit(text):
    if verbose:
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        text = now + ' ' + text
    print (text)
    # don't use v3 way to flush output since we want this to work for v2 and 3
    #print (txt, flush=True)
    sys.stdout.flush()
    return

def getweeks(year):
    cal= calendar.Calendar()
    str = ''
    for amonth in range(1, 13):
        for avalue in cal.monthdatescalendar(year, amonth): 
            str = avalue[0].strftime('%Y-%m-%d')
            str = "('" + str + "')"
            weeks.append(str)
    lastweek = ''
    thisweek = ''
    alen = len(weeks)
    return 0     
         
def spanfill(partitions, span, maxval, idx, start):
    # Span out up to 10 additional partitions based on double the span until the last one which spans out to max for int/bigint.
    newspan = span * 2
    if maxval == -1:
        rangetofill = 9223372036854775807
    else:		
        rangetofill = maxval - start
    newparts = int(rangetofill / newspan)
    if newparts > 10:
        newparts = 10

    # begin to create the next batch of partitions	
    print ("-- Adding %d additional partitions..." % (newparts))
    for x in range(newparts):	
        # add catch last catch all partition
        idx = idx + 1
        end = start + newspan		
        table = "CREATE TABLE %s_%03d PARTITION OF %s FOR VALUES FROM (%015d) TO (%015d) WITH (FILLFACTOR=%s);" % (newfullname, idx, newfullname, start, end - 1, fillfactor)
        printit(table)
        if pkey != "":	
            alter = "ALTER TABLE  %s_%03d ADD CONSTRAINT %s_%03d_pkey PRIMARY KEY (%s);" % (newfullname, idx, newtable, idx, pkey)
            printit(alter)
        if disable_autovacuum:		
            alter = "ALTER TABLE  %s_%03d SET (autovacuum_enabled = false, toast.autovacuum_enabled = false);" % (newfullname, idx)	
            printit(alter)			
        if asyncs:
            cmd = 'nohup psql %s -c "INSERT INTO %s_%03d (SELECT * FROM %s WHERE %s BETWEEN %015d AND %015d order by %s)" &'		% (dbname, newfullname, idx, oldfullname, pkey, start, end - 1, pkey)
            nohups.append(cmd)			
        start = start + newspan			
			
        printit('-- -----------------------------------')			

    # fill out the last partition to max for int/bigint			 
    idx = idx + 1
    print ("-- Adding the last partition to fill up to max allowed value.")
    table = "CREATE TABLE %s_%03d PARTITION OF %s FOR VALUES FROM (%015d) TO (%d) WITH (FILLFACTOR=%s);" % (newfullname, idx, newfullname, start, 9223372036854775807, fillfactor)
    print (table)	
    if pkey != "":	
        alter = "ALTER TABLE  %s_%03d ADD CONSTRAINT %s_%03d_pkey PRIMARY KEY (%s);" % (newfullname, idx, newtable, idx, pkey)
        printit(alter)
    if disable_autovacuum:		
        alter = "ALTER TABLE  %s_%03d SET (autovacuum_enabled = false, toast.autovacuum_enabled = false);" % (newfullname, idx)	
        printit(alter)				
        if asyncs:
            cmd = 'nohup psql %s -c "INSERT INTO %s_%03d (SELECT * FROM %s WHERE %s BETWEEN %015d AND %015d order by %s)" &' % (dbname, newfullname, idx, oldfullname, pkey, start, 9223372036854775807, pkey)
            nohups.append(cmd)
    return

def handle_range():	
    start = 1
    end   = 0
    idx   = 0	
    for x in range(partitions):
        idx = idx + 1
        end = start + span
        table = "CREATE TABLE %s_%03d PARTITION OF %s FOR VALUES FROM (%015d) TO (%015d) WITH (FILLFACTOR=%s);" % (newfullname, idx, newfullname, start, end - 1, fillfactor)
        printit(table)

        if pkey != "":	
            alter = "ALTER TABLE  %s_%03d ADD CONSTRAINT %s_%03d_pkey PRIMARY KEY (%s);" % (newfullname, idx, newtable, idx, pkey)
            printit(alter)
        if disable_autovacuum:		
            alter = "ALTER TABLE  %s_%03d SET (autovacuum_enabled = false, toast.autovacuum_enabled = false);" % (newfullname, idx)	
            printit(alter)	
        if asyncs:
            cmd = 'nohup psql %s -c "INSERT INTO %s_%03d (SELECT * FROM %s WHERE %s BETWEEN %015d AND %015d order by %s)" &'		% (dbname, newfullname, idx, oldfullname, pkey, start, end - 1, pkey)
            nohups.append(cmd)
        start = start + span		
	
        printit('-- -----------------------------------')

    # span out the last 10 partitions doubling the range		
    spanfill(partitions, span, maxval, idx, start)	

    # loop through asyncs if application and print them out last
    if asyncs:
        printit('-- -----------------------------------')			
        printit('-- Execute async background insert statements directly into data layer partitioned tables for parallel processing')			
        printit('-- Consider doing these a few batches at a time to not overutilize all available CPUs.')
        for x in range(len(nohups)):
            printit ('-- ' + nohups[x])
    return 0
	
def handle_hash():	
    remainder = 0
    for x in range(partitions):
        table = "CREATE TABLE %s_%04d PARTITION OF %s FOR VALUES WITH (MODULUS %s, REMAINDER %d) WITH (FILLFACTOR=%s);" % (newfullname, remainder, newfullname, partitions, remainder, fillfactor)
        printit(table)
        
        if pkey != "":	
            alter = "ALTER TABLE  %s_%04d ADD CONSTRAINT %s_%04d_pkey PRIMARY KEY (%s);" % (newfullname, remainder, newtable, remainder, pkey)
            printit(alter)
        if disable_autovacuum:		
            alter = "ALTER TABLE  %s_%04d SET (autovacuum_enabled = false, toast.autovacuum_enabled = false);" % (newfullname, remainder)	
            printit(alter)	
	
        printit('-- -----------------------------------')
        remainder = remainder + 1
    return 0
    
def handle_rangedates():	
    cntr = 0
    nextyear = year + 1
    start_date_cnt = 0

    # create start date range partitions for annual partition
    if frequency == 'yearly':
        start_date_cnt = 1
        print "-- creating 1 annual data layer partition..."
        startdt = str(year) + '-01-01'
        enddt   = str(year + 1)  + '-01-01'
        ddl = "CREATE TABLE %s_annually_%d PARTITION OF %s FOR VALUES FROM ('%s') TO ('%s');" % (newfullname, year, newfullname, startdt, enddt)
        print ddl
            
    # create start date range partitions for quarterly partition
    if frequency == 'quarterly':
        start_date_cnt = start_date_cnt + 4
        print "-- creating 4 quarterly partitions..."
        ddl = "CREATE TABLE %s_quarterly_%d_%02d PARTITION OF %s FOR VALUES FROM ('%d-01-01') TO ('%d-04-01');" % (newfullname, year, 1, newfullname, year, year)
        print ddl
        ddl = "CREATE TABLE %s_quarterly_%d_%02d PARTITION OF %s FOR VALUES FROM ('%d-04-01') TO ('%d-07-01');" % (newfullname, year, 2, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_quarterly_%d_%02d PARTITION OF %s FOR VALUES FROM ('%d-07-01') TO ('%d-10-01');" % (newfullname, year, 3, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_quarterly_%d_%02d PARTITION OF %s FOR VALUES FROM ('%d-10-01') TO ('%d-01-01');" % (newfullname, year, 4, newfullname, year, year+1)
        print ddl                            

    # create start date range partitions for monthly
    if frequency == 'monthly':
        start_date_cnt = start_date_cnt + 12
        print "-- creating 12 monthly partitions..."
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-01-01') TO ('%d-02-01');" % (newfullname, year, 1, newfullname, year, year)
        print ddl                                                                                                                                                                                                   
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-02-01') TO ('%d-03-01');" % (newfullname, year, 2, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-03-01') TO ('%d-04-01');" % (newfullname, year, 3, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-04-01') TO ('%d-05-01');" % (newfullname, year, 4, newfullname, year, year)
        print ddl                             
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-05-01') TO ('%d-06-01');" % (newfullname, year, 5, newfullname, year, year)
        print ddl                             
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-06-01') TO ('%d-07-01');" % (newfullname, year, 6, newfullname, year, year)
        print ddl                                                                                                                                                                                                   
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-07-01') TO ('%d-08-01');" % (newfullname, year, 7, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-08-01') TO ('%d-09-01');" % (newfullname, year, 8, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-09-01') TO ('%d-10-01');" % (newfullname, year, 9, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-10-01') TO ('%d-11-01');" % (newfullname, year, 10, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-11-01') TO ('%d-12-01');" % (newfullname, year, 11, newfullname, year, year)
        print ddl                            
        ddl = "CREATE TABLE %s_monthly_%d_%02d PARTITION OF %s_monthly FOR VALUES FROM ('%d-12-01') TO ('%d-01-01');" % (newfullname, year, 12, newfullname, year, nextyear)
        print ddl                            

    # create start date range partitions for weekly
    if frequency == 'weekly':
        start_date_cnt = start_date_cnt + 52
        print "-- creating 52 weekly partitions..."
        rc = getweeks(year)
        cntr = 0
        lastweek = ''
        for aweek in weeks:
            thisweek = aweek
            if lastweek <> '' and lastweek <> thisweek:
                cntr = cntr + 1
                arange = "%s TO %s" % (lastweek, thisweek)
                ddl = "CREATE TABLE %s_weekly_%d_%02d PARTITION OF %s FOR VALUES FROM %s;" % (newfullname, year, cntr, newfullname, arange)
                print ddl
            lastweek = thisweek                                                        

    return 0    


####################
# MAIN ENTRY POINT #
####################

# Setup up the argument parser
parser = OptionParser("PostgreSQL Partitioning Tool", add_help_option=True)
parser.add_option("-d", "--dbname",     dest="dbname",     help="database name",     type=str, default="", metavar="DBNAME")
parser.add_option("-o", "--schemaname", dest="schemaname", help="parent schema name",type=str, default="", metavar="SCHEMANAME")
parser.add_option("-t", "--oldtable",   dest="oldtable",    help="old table name",    type=str, default="<old table>", metavar="OLDTABLE")
parser.add_option("-n", "--newtable",   dest="newtable",    help="new table name",    type=str, default="<new table>", metavar="NEWTABLE")
parser.add_option("-m", "--pmethod",    dest="pmethod",    help="partition method",  type=str, default="",            metavar="PMETHOD")
parser.add_option("-p", "--partitions", dest="partitions", help="# of partitions",   type=int, default=-1,            metavar="PARTITIONS")
parser.add_option("-s", "--span",       dest="span",       help="span",              type=int, default=-1,            metavar="SPAN")
parser.add_option("-x", "--maxval",     dest="maxval",     help="max key value",     type=int, default=-1,            metavar="MAXVAL")
parser.add_option("-q", "--frequency",  dest="frequency",  help="frequency",         type=str, default="",            metavar="FREQUENCY")
parser.add_option("-y", "--year",       dest="year",       help="year",              type=int, default=-1,            metavar="YEAR")
parser.add_option("-f", "--fillfactor", dest="fillfactor", help="fill factor",       type=int, default = 100,         metavar="FILLFACTOR")
parser.add_option("-a", "--async",      dest="asyncs",     help="async commands",    default=False, action="store_true", metavar="ASYNCS")
parser.add_option("-k", "--primarykey", dest="pkey",       help="primary key",       type=str, default="",            metavar="PKEY")
parser.add_option("-b", "--disableauto",dest="disableauto",help="disable autovacuum",default=False, action="store_true", metavar="DISABLEAUTO")
parser.add_option("-v", "--verbose",    dest="verbose",    help="verbose output",    default=False, action="store_true", metavar="VERBOSE")

(options,args) = parser.parse_args()
dryrun = False

dbname     = options.dbname.lower()
schemaname = options.schemaname.lower()
oldtable   = options.oldtable.lower()
newtable   = options.newtable.lower()
if '.' in oldtable or '.' in newtable:
    printit ("You cannot specify a schema qualifier for a table name. Do that with the schemaname parameter.")
    sys.exit(1)	
pmethod    = options.pmethod.lower()
partitions = options.partitions
span       = options.span
frequency  = options.frequency.lower()
year       = options.year

maxval     = options.maxval
# max value for postgresql bigint: +9223372036854775807
# max value for postgresql    int:          +2147483647

fillfactor = options.fillfactor
pkey       = options.pkey
asyncs     = options.asyncs
disable_autovacuum = options.disableauto
verbose    = options.verbose

if partitions < 1 and frequency == '' and year == -1:
    printit("Invalid number of partitions specified (%d)." % partitions)
    sys.exit(1)	
if pmethod == "":
    printit("partition method not specified.")
    sys.exit(1)
	
if pmethod in ('range','list','hash'):
    if pmethod == 'list':
        printit("Only Range and Hash partitioning implemented at this time.")
        sys.exit(1)
    elif pmethod == 'hash':
        if asyncs:
            printit('-- aysncs not supported for hash partitions.')			
            sys.exit(1)
        elif span <> -1:        
            printit('-- span not valid for hash partitioning.')			
            sys.exit(1)        
        elif maxval <> -1:        
            printit('-- maxvalue not valid for hash partitioning.')			
            sys.exit(1)             
    elif pmethod == 'range':
        if frequency == "" and year == -1:
            # must be integer range so depend on span
            if span == -1:
                printit("Invalid span for range method.")
                sys.exit(1)            
            pass
        elif frequency != "" and year != -1:
            # must be date range
            if frequency in ('yearly','quarterly','monthly', 'weekly', 'daily'):
                pass
            else:
                printit("Invalid date range method specified (%s).  Valid values are: Yearly, Quarterly, Monthly, weekly, and daily." % frequency)
                sys.exit(1)
        else:
            printit("Invalid range method specified (%s).  For date range, year and frequency must be specified.  Otherwise they should not be specified to indicate number span range type." % pmethod)
            sys.exit(1)
else:
    printit("Invalid partition method specified (%s).  Only Range and List are valid." % pmethod)
    sys.exit(1)

printit ("-- Runtime Parms: dbname(%s)  schemaname(%s)  old table(%s)  new table(%s)  partition method(%s)  #partitions(%d)  span(%d)  year(%d)  frequency(%s)  fillfactor(%d) pkey(%s)  async(%r)  Disable Autovacuum(%r)  verbose(%r)" \
        % (dbname, schemaname, oldtable, newtable, pmethod, partitions, span, year, frequency, fillfactor, pkey, asyncs, disable_autovacuum, verbose))
		
if schemaname == "":
    oldfullname = oldtable
    newfullname = newtable	
else:
    oldfullname = "%s.%s" % (schemaname, oldtable)
    newfullname = "%s.%s" % (schemaname, newtable)

if pmethod == 'range' and frequency == '':
    rc = handle_range();
elif pmethod == 'range' and frequency in ('yearly', 'quarterly', 'monthly', 'weekly', 'daily'):
    rc = handle_rangedates();    
elif pmethod == 'hash':
    rc = handle_hash();    
  

if rc <> 0:
    printit ("-- Error(s) detected.")
    sys.exit(1)
else:
    printit ("-- DDL Generated Successfully.")
    sys.exit(0)
