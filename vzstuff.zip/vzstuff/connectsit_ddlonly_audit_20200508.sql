CREATE SCHEMA audit;
ALTER SCHEMA audit OWNER TO postgres;
COMMENT ON SCHEMA audit IS 'Databse Schema for Audit/Report Domain';

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

CREATE SEQUENCE audit.audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE audit.audit_id_seq OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: audit; Owner: connectsit
--

CREATE TABLE audit.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE audit.schema_version OWNER TO postgres;

--
-- Name: t_audit_info; Type: TABLE; Schema: audit; Owner: connectsit
--

CREATE TABLE audit.t_audit_info (
    audit_id bigint DEFAULT nextval('audit.audit_id_seq'::regclass) NOT NULL,
    lob character varying(24) NOT NULL,
    source_sys character varying(64) NOT NULL,
    destination_sys character varying(64) NOT NULL,
    region character varying(32) NOT NULL,
    audit_data jsonb NOT NULL,
    audit_date date NOT NULL,
    audit_by character varying(64) NOT NULL,
    entity_id character varying(96) NOT NULL,
    entity_type character varying(96) NOT NULL
);


ALTER TABLE audit.t_audit_info OWNER TO postgres;

ALTER TABLE ONLY audit.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


ALTER TABLE ONLY audit.t_audit_info
    ADD CONSTRAINT t_audit_info_pkey PRIMARY KEY (audit_id);

CREATE INDEX schema_version_ir_idx ON audit.schema_version USING btree (installed_rank);

CREATE INDEX schema_version_s_idx ON audit.schema_version USING btree (success);

CREATE INDEX schema_version_vr_idx ON audit.schema_version USING btree (version_rank);



--
-- PostgreSQL database dump complete
--

