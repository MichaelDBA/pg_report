export PGPASSFILE=~/.pgpass                                                      
PG_CONNECT_SCRIPT=~/bin/pgpass.py                                       

function pg-connect () {                                                         
    PSQL_COMMAND=$($PG_CONNECT_SCRIPT print-connection-command $1)               
	exitcode=$?
    if [ $exitcode -ne 0 ]; then
        exit $exitcode	
	fi
    echo "pg-connect($1, $PSQL_COMMAND)"                                         
    sh -c "$PSQL_COMMAND"                                                        
}                                                                                

function pg-list () {                                                            
    $PG_CONNECT_SCRIPT list                                                      
}   