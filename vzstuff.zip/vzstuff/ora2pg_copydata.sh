export ORASCHEMA=ACELAOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=EILSROWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=OSSOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=PERSEUSOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=RMOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=SDDOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=SDMOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=TSIDROWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

echo ">`date +'%Y-%m-%d %H:%M:%S'` Finished."
exit 0

-- -------------------------------------------------------------------------------------------------------------------------

export ORASCHEMA=ACELAOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=EILSROWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=OSSOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=PERSEUSOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=RMOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=SDDOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=SDMOWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

export ORASCHEMA=TSIDROWN
export TARGET=/apps/opt/postgres/oracle_export_OSST6/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

echo ">`date +'%Y-%m-%d %H:%M:%S'` Finished."
exit 0













