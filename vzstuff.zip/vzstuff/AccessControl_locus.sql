-- revoke all privileges on public schema
REVOKE ALL ON DATABASE mydatabase FROM PUBLIC;
REVOKE USAGE ON LANGUAGE plpgsql FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM public;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

-- revoke all privs for login roles
revoke all privileges on all tables in schema prestaging, staging, golden from apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
REVOKE ALL ON DATABASE GWYVLATI FROM apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
REVOKE ALL on schema prestaging, staging, golden from apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA prestaging, staging, golden FROM apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
ALTER DEFAULT PRIVILEGES IN SCHEMA prestaging, staging, golden REVOKE ALL ON TABLES FROM apiuser, cyberarc, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON SCHEMAS FROM apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON TABLES FROM apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON SEQUENCES FROM apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON FUNCTIONS FROM apiuser, datapro, fmeuser, inbbatch, mdmbatch, stgbatch, v805244;

-- read only perms for non-login roles
CREATE ROLE prestaging_ro;
CREATE ROLE staging_ro;
CREATE ROLE golden_ro;
GRANT CONNECT ON DATABASE gwyvlati TO prestaging_ro, staging_ro, golden_ro;
GRANT USAGE ON SCHEMA prestaging, staging, golden TO prestaging_ro, staging_ro, golden_ro;

GRANT SELECT ON ALL TABLES IN SCHEMA prestaging TO prestaging_ro;
GRANT SELECT ON ALL TABLES IN SCHEMA staging    TO staging_ro;
GRANT SELECT ON ALL TABLES IN SCHEMA golden     TO golden_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA prestaging TO prestaging_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA staging    TO staging_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA golden     TO golden_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA prestaging GRANT USAGE,SELECT ON SEQUENCES TO prestaging_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA staging    GRANT USAGE,SELECT ON SEQUENCES TO staging_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA golden     GRANT USAGE,SELECT ON SEQUENCES TO golden_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA prestaging GRANT ALL ON TABLES TO prestaging_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA staging    GRANT ALL ON TABLES TO staging_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA golden     GRANT ALL ON TABLES TO golden_ro;
ALTER ROLE prestaging_ro SET search_path TO 'prestaging, pg_catalog';
ALTER ROLE staging_ro SET search_path TO 'staging, pg_catalog';
ALTER ROLE golden_ro SET search_path TO 'golden, pg_catalog';

-- read/write perms for non-login roles
CREATE ROLE prestaging_rw;
CREATE ROLE staging_rw;
CREATE ROLE golden_rw;
GRANT CONNECT ON DATABASE "GWYVLATI" TO prestaging_rw, staging_rw, golden_rw;
GRANT USAGE ON SCHEMA prestaging, staging, golden TO prestaging_rw, staging_rw, golden_rw;
GRANT ALL ON ALL TABLES IN SCHEMA prestaging TO prestaging_rw;
GRANT ALL ON ALL TABLES IN SCHEMA staging    TO staging_rw;
GRANT ALL ON ALL TABLES IN SCHEMA golden     TO golden_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA prestaging TO prestaging_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA staging    TO staging_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA golden     TO golden_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA prestaging to prestaging_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA staging to staging_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA golden to golden_rw;

ALTER DEFAULT PRIVILEGES IN SCHEMA prestaging GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO prestaging_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA staging    GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO staging_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA golden     GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO golden_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA prestaging GRANT ALL ON TABLES TO prestaging_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA staging    GRANT ALL ON TABLES TO staging_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA golden     GRANT ALL ON TABLES TO golden_rw;

ALTER DEFAULT PRIVILEGES IN SCHEMA prestaging GRANT EXECUTE ON FUNCTIONS TO prestaging_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA staging    GRANT EXECUTE ON FUNCTIONS TO staging_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA golden     GRANT EXECUTE ON FUNCTIONS TO golden_rw;

ALTER DEFAULT PRIVILEGES IN schema prestaging grant all ON types to prestaging_rw;
ALTER DEFAULT PRIVILEGES IN schema staging grant all ON types to staging_rw;
ALTER DEFAULT PRIVILEGES IN schema golden grant all ON types to golden_rw;

ALTER ROLE prestaging_rw SET search_path TO 'prestaging, pg_catalog';
ALTER ROLE staging_rw SET search_path TO 'staging, pg_catalog';
ALTER ROLE golden_rw SET search_path TO 'golden, pg_catalog';

-- login role permissions
GRANT prestaging_rw to inbbatch;
GRANT prestaging_rw, staging_rw, golden_rw to stgbatch;
GRANT prestaging_rw, staging_rw, golden_rw to mdmbatch;
GRANT prestaging_rw, staging_rw, golden_rw to fmeuser;
GRANT golden_rw to apiuser;

************************************************************************************************
