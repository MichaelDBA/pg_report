Tuesday, July 28, 2020
psql -h gwyv-locus2-prd-01.cl9vgbtolm5s.us-east-1.rds.amazonaws.com -p5432 -d gwyvlati -U dbadmin -c "select pg_get_functiondef(oid) from pg_proc where proname = 'proc_populate_telcoinfo'"

 CREATE OR REPLACE PROCEDURE golden.proc_populate_telcoinfo(loc_id bigint, user_id text)             
  LANGUAGE plpgsql                                                                                   
 AS $procedure$                                                                                      
                                                                                                     
 BEGIN                                                                                               
                                                                                                     
         --inserting into golden.tbl_telcoinfo_wc LOCUS_DS                                           
		 --BEGIN
         insert into golden.tbl_telcoinfo_wc as telcowc(                                             
                 location_id,                                                                        
                 wc_name,                                                                            
                 wcleccode,                                                                          
                 inregion,                                                                           
                 created_by                                                                          
         )                                                                                           
          select                                                                                     
                  distinct on(a.location_id) a.location_id,                                          
                  b.lerg_wire_ctr as wc_name,                                                        
                  c.lec_code as wcleccode,                                                           
                  (case when c.lec_code='VZE' or c.lec_code='VZW' then true else false end) inregion,
                  user_id created_by                                                                 
          from                                                                                       
                  golden.tbl_location a                                                              
                  inner join staging.tbl_stg_exchange_info b                                         
                                 on st_intersects(ST_SetSRID(b.geoloc,4326), a.geom) = true          
                  left join staging.tbl_stg_wire_center_icsc_xref c                                  
                                 on c.wire_ctr = b.lerg_wire_ctr                                     
         where a.location_id=loc_id                                                                  
                                                                                                     
         ON CONFLICT (location_id) DO UPDATE                                                         
                 set                                                                                 
                 wc_name=EXCLUDED.wc_name,                                                           
                 wcleccode=EXCLUDED.wcleccode,                                                       
                 inregion=EXCLUDED.inregion,                                                         
                 modified_dt=now(),                                                                  
                 modified_by=user_id                                                                 
                 where coalesce(telcowc.modified_by,'')<>'LOCUS_DS';                                 
         --COMMIT;                                                                                                     
         
		 --inserting into golden.tbl_telcoinfo_rc                                                    
         --BEGIN                                                                                            
         insert into golden.tbl_telcoinfo_rc as telcorc(                                             
                 location_id,                                                                        
                 rcstate,                                                                            
                 rcname,                                                                             
                 created_by                                                                          
         )                                                                                           
         select                                                                                      
                 d.location_id,                                                                      
                 a.state as rcstate,                                                                 
                 a.rate_cntr as rcname,                                                              
                 user_id as created_by                                                               
         from                                                                                        
                 staging.tbl_stg_indsty_rate_center a,                                               
                 golden.tbl_location d                                                               
         where                                                                                       
                 st_intersects(ST_SetSRID(a.geoloc,4326), d.geom) = true                             
                 and d.location_id=loc_id                                                            
         ON CONFLICT (location_id) DO UPDATE                                                         
         set                                                                                         
                 rcstate=EXCLUDED.rcstate,                                                           
                 rcname=EXCLUDED.rcname,                                                             
                 modified_dt=now(),                                                                  
                 modified_by=user_id                                                                 
                 where coalesce(telcorc.modified_by,'')<>'LOCUS_DS';                                 
         --commit;                                                                                                                                                                                                 
         
		 --inserting into golden.tbl_telcoinfo_sca                                                   
		 --BEGIN
         insert into golden.tbl_telcoinfo_sca as telcosca(                                           
                 location_id,                                                                        
                 scastate,                                                                           
                 scaname,                                                                            
                 created_by                                                                          
         )                                                                                           
         select                                                                                      
                 d.location_id,                                                                      
                 a.state as scastate,                                                                
                 a.name as scaname,                                                                  
                 user_id as created_by                                                               
         from                                                                                        
                 staging.tbl_stg_sca a,                                                              
                 golden.tbl_location d                                                               
         where                                                                                       
                 st_intersects(ST_SetSRID(a.geoloc,4326), d.geom) = true                             
                 and d.location_id=loc_id                                                            
         ON CONFLICT (location_id) DO UPDATE                                                         
         set                                                                                         
                 scastate=EXCLUDED.scastate,                                                         
                 scaname=EXCLUDED.scaname,                                                           
                 modified_dt=now(),                                                                  
                 modified_by=user_id                                                                 
                 where coalesce(telcosca.modified_by,'')<>'LOCUS_DS';                                
        --commit;                                                                                                                                                                                                  
		
         --inserting into golden.tbl_telcoinfo_psap                                                  
		-- BEGIN
         insert into golden.tbl_telcoinfo_psap as telcopsap(                                         
                 location_id,                                                                        
                 psapid,                                                                             
                 psapagency,                                                                         
                 psaptendigit1,                                                                      
                 created_by                                                                          
         )                                                                                           
         select                                                                                      
                 d.location_id,                                                                      
                 psapid,                                                                             
                 agency as psapagency,                                                               
                 operatorphone as psaptendigit1,                                                     
                 user_id as created_by                                                               
         from                                                                                        
                 staging.tbl_stg_psap a,                                                             
                 golden.tbl_location d                                                               
         where                                                                                       
                 st_intersects(ST_SetSRID(a.geoloc,4326), d.geom) = true                             
                 and d.location_id=loc_id                                                            
         ON CONFLICT (location_id) DO UPDATE                                                         
         set                                                                                         
                 psapid=EXCLUDED.psapid,                                                             
                 psapagency=EXCLUDED.psapagency,                                                     
                 psaptendigit1=EXCLUDED.psaptendigit1,                                               
                 modified_dt=now(),                                                                  
                 modified_by=user_id                                                                 
                 where coalesce(telcopsap.modified_by,'')<>'LOCUS_DS';                               
        --commit;                                                                                                                                                                                                        
         
		 --inserting into golden.tbl_telcoinfo_lata                                                  
		 --BEGIN
         insert into golden.tbl_telcoinfo_lata as telcolata(                                         
                 location_id,                                                                        
                 lata,                                                                               
                 created_by                                                                          
         )                                                                                           
         select                                                                                      
                 d.location_id,                                                                      
                 a.lata_id::double precision as lata,                                                
                 user_id as created_by                                                               
         from                                                                                        
                 staging.tbl_stg_lata_info a,                                                        
                 golden.tbl_location d                                                               
         where                                                                                       
                 st_intersects(ST_SetSRID(a.geoloc,4326), d.geom) = true                             
                 and d.location_id=loc_id                                                            
         ON CONFLICT (location_id) DO UPDATE                                                         
         set                                                                                         
                 lata=EXCLUDED.lata,                                                                 
                 modified_dt=now(),                                                                  
                 modified_by=user_id                                                                 
                 where coalesce(telcolata.modified_by,'')<>'LOCUS_DS';                               
        --commit;                                                                                                    
         
		 --inserting into golden.tbl_telcoinfo_county                                                
		 --BEGIN
         insert into golden.tbl_telcoinfo_county as telcocounty(                                     
                 location_id,                                                                        
                 countyfips,                                                                         
                 created_by                                                                          
         )                                                                                           
         select                                                                                      
                 d.location_id,                                                                      
                 fips as countyfips,                                                                 
                 user_id as created_by                                                               
         from                                                                                        
                 staging.tbl_stg_county_info a,                                                      
                 golden.tbl_location d                                                               
         where                                                                                       
                 st_intersects(ST_SetSRID(a.geoloc,4326), d.geom) = true                             
                 and d.location_id=loc_id                                                            
         ON CONFLICT (location_id) DO UPDATE                                                         
         set                                                                                         
                 countyfips=EXCLUDED.countyfips,                                                     
                 modified_dt=now(),                                                                  
                 modified_by=user_id                                                                 
                 where coalesce(telcocounty.modified_by,'')<>'LOCUS_DS';                             
		--commit;		 
 END;                                                                                                
 $procedure$                                                                                         
