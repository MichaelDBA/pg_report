export ORACLE_HOME=/usr/lib/oracle/19.6/client64
export LD_LIBRARY_PATH=/usr/lib/oracle/19.6/client64/lib:$LD_LIBRARY_PATH
export ORACLE_SID=POSS
#export ORACLE_DSN=dbi:Oracle:host=localhost;sid=POSS
#export NLS_LANG=`$ORACLE_HOME/bin/nls_lang.sh`
export PATH=$ORACLE_HOME/bin:$PATH
export TNS_ADMIN=/usr/lib/oracle/19.6/client64/lib/network/admin
alias sqlplus="rlwrap -i -f ~/.sqlplus_history -H ~/.sqlplus_history -s 30000 sqlplus"


