-- deployed to CONNECT DEV :nvoip.calku0teekje.us-west-2.rds.amazonaws.com  DB name:connect_dev
-- deployed to CONNECT DIT :nvoip.calku0teekje.us-west-2.rds.amazonaws.com  DB name:nvoip
-- psql -h nvoip.calku0teekje.us-west-2.rds.amazonaws.com -v ON_ERROR_STOP=1 -a -d connect_dev -U dbadmin < ./localds_ddlonly_20200615.sql
-- psql -h nvoip.calku0teekje.us-west-2.rds.amazonaws.com -v ON_ERROR_STOP=1 -a -d nvoip       -U dbadmin < ./localds_ddlonly_20200615.sql

--
-- nvoipQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: localds2; Type: SCHEMA; Schema: -; Owner: nvoip
--

drop schema if exists localds2 cascade;
create schema localds2 authorization nvoip;

ALTER SCHEMA localds2 OWNER TO nvoip;

--
-- Name: varray_cde_action; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_cde_action AS (
        varray_cde_action character varying(15)[]
);


ALTER TYPE localds2.varray_cde_action OWNER TO nvoip;

--
-- Name: varray_cde_clli_swt_frm; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_cde_clli_swt_frm AS (
        varray_cde_clli_swt_frm character varying(11)[]
);


ALTER TYPE localds2.varray_cde_clli_swt_frm OWNER TO nvoip;

--
-- Name: varray_cde_clli_swt_to; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_cde_clli_swt_to AS (
        varray_cde_clli_swt_to character varying(11)[]
);


ALTER TYPE localds2.varray_cde_clli_swt_to OWNER TO nvoip;

--
-- Name: varray_cde_lpic; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_cde_lpic AS (
        varray_cde_lpic character(5)[]
);


ALTER TYPE localds2.varray_cde_lpic OWNER TO nvoip;

--
-- Name: varray_cde_pic; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_cde_pic AS (
        varray_cde_pic character(5)[]
);


ALTER TYPE localds2.varray_cde_pic OWNER TO nvoip;

--
-- Name: varray_cde_status; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_cde_status AS (
        varray_cde_status character varying(10)[]
);


ALTER TYPE localds2.varray_cde_status OWNER TO nvoip;

--
-- Name: varray_flg_911_but_all_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_911_but_all_blk AS (
        varray_flg_911_but_all_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_911_but_all_blk OWNER TO nvoip;

--
-- Name: varray_flg_asi_dir_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_asi_dir_blk AS (
        varray_flg_asi_dir_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_asi_dir_blk OWNER TO nvoip;

--
-- Name: varray_flg_inb_all_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_inb_all_blk AS (
        varray_flg_inb_all_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_inb_all_blk OWNER TO nvoip;

--
-- Name: varray_flg_ld_dom_otb_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_ld_dom_otb_blk AS (
        varray_flg_ld_dom_otb_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_ld_dom_otb_blk OWNER TO nvoip;

--
-- Name: varray_flg_ld_inter_otb_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_ld_inter_otb_blk AS (
        varray_flg_ld_inter_otb_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_ld_inter_otb_blk OWNER TO nvoip;

--
-- Name: varray_flg_ld_intnl_otb_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_ld_intnl_otb_blk AS (
        varray_flg_ld_intnl_otb_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_ld_intnl_otb_blk OWNER TO nvoip;

--
-- Name: varray_flg_ld_intra_otb_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_ld_intra_otb_blk AS (
        varray_flg_ld_intra_otb_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_ld_intra_otb_blk OWNER TO nvoip;

--
-- Name: varray_flg_local_otb_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_local_otb_blk AS (
        varray_flg_local_otb_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_local_otb_blk OWNER TO nvoip;

--
-- Name: varray_flg_otb_all_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_otb_all_blk AS (
        varray_flg_otb_all_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_otb_all_blk OWNER TO nvoip;

--
-- Name: varray_flg_svc_911_blk; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_flg_svc_911_blk AS (
        varray_flg_svc_911_blk character(1)[]
);


ALTER TYPE localds2.varray_flg_svc_911_blk OWNER TO nvoip;

--
-- Name: varray_idn_reseller; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_idn_reseller AS (
        varray_idn_reseller character varying(5)[]
);


ALTER TYPE localds2.varray_idn_reseller OWNER TO nvoip;

--
-- Name: varray_idn_spid_frm; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_idn_spid_frm AS (
        varray_idn_spid_frm character varying(4)[]
);


ALTER TYPE localds2.varray_idn_spid_frm OWNER TO nvoip;

--
-- Name: varray_idn_spid_to; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_idn_spid_to AS (
        varray_idn_spid_to character varying(4)[]
);


ALTER TYPE localds2.varray_idn_spid_to OWNER TO nvoip;

--
-- Name: varray_idx_request_tps; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_idx_request_tps AS (
        varray_idx_request_tps character varying(33)[]
);


ALTER TYPE localds2.varray_idx_request_tps OWNER TO nvoip;

--
-- Name: varray_idx_tri; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_idx_tri AS (
        varray_idx_tri bigint[]
);


ALTER TYPE localds2.varray_idx_tri OWNER TO nvoip;

--
-- Name: varray_ind_drc_call; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_ind_drc_call AS (
        varray_ind_drc_call character(1)[]
);


ALTER TYPE localds2.varray_ind_drc_call OWNER TO nvoip;

--
-- Name: varray_key_tkg_pseudo_frm; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_key_tkg_pseudo_frm AS (
        varray_key_tkg_pseudo_frm character varying(12)[]
);


ALTER TYPE localds2.varray_key_tkg_pseudo_frm OWNER TO nvoip;

--
-- Name: varray_key_tkg_pseudo_to; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_key_tkg_pseudo_to AS (
        varray_key_tkg_pseudo_to character varying(12)[]
);


ALTER TYPE localds2.varray_key_tkg_pseudo_to OWNER TO nvoip;

--
-- Name: varray_nbr_nme_rte_office_frm; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_nbr_nme_rte_office_frm AS (
        varray_nbr_nme_rte_office_frm character varying(14)[]
);


ALTER TYPE localds2.varray_nbr_nme_rte_office_frm OWNER TO nvoip;

--
-- Name: varray_nbr_nme_rte_office_to; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_nbr_nme_rte_office_to AS (
        varray_nbr_nme_rte_office_to character varying(14)[]
);


ALTER TYPE localds2.varray_nbr_nme_rte_office_to OWNER TO nvoip;

--
-- Name: varray_nbr_tkg_frm; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_nbr_tkg_frm AS (
        varray_nbr_tkg_frm character varying(11)[]
);


ALTER TYPE localds2.varray_nbr_tkg_frm OWNER TO nvoip;

--
-- Name: varray_nbr_tkg_to; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_nbr_tkg_to AS (
        varray_nbr_tkg_to character varying(11)[]
);


ALTER TYPE localds2.varray_nbr_tkg_to OWNER TO nvoip;

--
-- Name: varray_nme_grp_psali_frm; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_nme_grp_psali_frm AS (
        varray_nme_grp_psali_frm character varying(6)[]
);


ALTER TYPE localds2.varray_nme_grp_psali_frm OWNER TO nvoip;

--
-- Name: varray_nme_grp_psali_to; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_nme_grp_psali_to AS (
        varray_nme_grp_psali_to character varying(6)[]
);


ALTER TYPE localds2.varray_nme_grp_psali_to OWNER TO nvoip;

--
-- Name: varray_ord_num; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_ord_num AS (
        varray_ord_num character varying(13)[]
);


ALTER TYPE localds2.varray_ord_num OWNER TO nvoip;

--
-- Name: varray_port_act_ind; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_port_act_ind AS (
        varray_port_act_ind character(1)[]
);


ALTER TYPE localds2.varray_port_act_ind OWNER TO nvoip;

--
-- Name: varray_sys_submitted; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_sys_submitted AS (
        varray_sys_submitted character varying(15)[]
);


ALTER TYPE localds2.varray_sys_submitted OWNER TO nvoip;

--
-- Name: varray_tn; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_tn AS (
        varray_tn bigint[]
);


ALTER TYPE localds2.varray_tn OWNER TO nvoip;

--
-- Name: varray_tnb; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_tnb AS (
        varray_tnb bigint[]
);


ALTER TYPE localds2.varray_tnb OWNER TO nvoip;

--
-- Name: varray_txt_status; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_txt_status AS (
        varray_txt_status character varying(2000)[]
);


ALTER TYPE localds2.varray_txt_status OWNER TO nvoip;

--
-- Name: varray_typ_account; Type: TYPE; Schema: localds2; Owner: nvoip
--

CREATE TYPE localds2.varray_typ_account AS (
        varray_typ_account character varying(2)[]
);


ALTER TYPE localds2.varray_typ_account OWNER TO nvoip;

--
-- Name: trigger_fct_tra_log_trig(); Type: FUNCTION; Schema: localds2; Owner: nvoip
--

CREATE FUNCTION localds2.trigger_fct_tra_log_trig() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN

INSERT INTO ossr_tra_log_his(
        tnb,
        cde_sts_tsk,
        idx_lec,
        nbr_seq_tsk,
        ind_tsk_ord,
        nbr_bch,
        idx_org_ord,
        nbr_ord,
        idx_spn_ord,
        nme_tsk,
        txt_cmn,
        idx_mgl,
        ind_prs,
        dtx_tra,
        cde_sts_fbk,
        gdt_sts_fbk,
        nme_customer,
        cde_function,
        cde_atn_cnam,
        cde_rsc_cnam,
        cde_bns,
        key_1_transaction,
        txt_record,
        dtx_replication,
        seq_his_log_tra

  )
VALUES (
        NEW.tnb,
        NEW.cde_sts_tsk,
        NEW.idx_lec,
        nextval('seq_hist_nbr_seq_tsk'),
        NEW.idn_tsk_ord,
        NEW.nbr_bch,
        NEW.idx_org_ord,
        NEW.nbr_ord,
        NEW.idx_spn_ord,
        NEW.nme_tsk,
        NEW.txt_cmn,
        NEW.idx_mgl,
        NEW.ind_prs,
        NEW.dtx_tra,
        NEW.cde_sts_fbk,
        NEW.gdt_sts_fbk,
        NEW.nme_customer,
        NEW.cde_function,
        NEW.cde_atn_cnam,
        NEW.cde_rsc_cnam,
        NEW.cde_bns,
        NEW.key_1_transaction,
        NEW.txt_record,
        LOCALTIMESTAMP,
        nextval('seq_ossr_tra_log_his')

);
IF FOUND THEN
DELETE
FROM OSSR_TRA_LOG
where nbr_ord = NEW.nbr_ord
and idx_spn_ord = NEW.idx_spn_ord
and  tnb = NEW.tnb
AND idx_lec=NEW.idx_lec;
END IF;
RETURN NEW;
END
$$;


ALTER FUNCTION localds2.trigger_fct_tra_log_trig() OWNER TO nvoip;

SET default_tablespace = '';

-- PG 12 only
-- SET default_table_access_method = heap;

--
-- Name: acela_admin_his_chg; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_admin_his_chg (
    idn_his_chg bigint NOT NULL,
    idn_admin_staff character varying(32) NOT NULL,
    typ_upd character(1) NOT NULL,
    idn_person character varying(32) NOT NULL,
    dtx_upd_las timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    desc_fdl character varying(2000) NOT NULL,
    nme_org_person character varying(32),
    nme_first_person character varying(32),
    nme_last_person character varying(32)
);


ALTER TABLE localds2.acela_admin_his_chg OWNER TO nvoip;

--
-- Name: acela_admin_org; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_admin_org (
    nme_org character varying(32) NOT NULL,
    desc_org character varying(80) NOT NULL
);


ALTER TABLE localds2.acela_admin_org OWNER TO nvoip;

--
-- Name: acela_admin_org_to_staffadmin; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_admin_org_to_staffadmin (
    idn_admin_staff character varying(32) NOT NULL,
    nme_org character varying(32) NOT NULL
);


ALTER TABLE localds2.acela_admin_org_to_staffadmin OWNER TO nvoip;

--
-- Name: acela_admin_org_to_workpool; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_admin_org_to_workpool (
    nme_org character varying(32) NOT NULL,
    nme_pool_wrk character varying(32) NOT NULL
);


ALTER TABLE localds2.acela_admin_org_to_workpool OWNER TO nvoip;

--
-- Name: acela_admin_staffadmin; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_admin_staffadmin (
    idn_admin_staff character varying(32) NOT NULL,
    nme_first character varying(32) NOT NULL,
    nme_last character varying(32) NOT NULL
);


ALTER TABLE localds2.acela_admin_staffadmin OWNER TO nvoip;

--
-- Name: acela_am_exception; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_am_exception (
    nbr_order character varying(13) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    idn_exception character varying(255) NOT NULL,
    cde_type smallint,
    cde_status smallint,
    ind_personalized character(1),
    dtx_timestamp timestamp with time zone DEFAULT LOCALTIMESTAMP
);


ALTER TABLE localds2.acela_am_exception OWNER TO nvoip;

--
-- Name: acela_am_exception_info; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_am_exception_info (
    nbr_order character varying(13) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    idn_exception character varying(255) NOT NULL,
    nme_element character varying(255) NOT NULL,
    val_element character varying(255)
);


ALTER TABLE localds2.acela_am_exception_info OWNER TO nvoip;

--
-- Name: acela_am_version; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_am_version (
    nbr_order character varying(13) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    idn_msg_lcom character varying(20) NOT NULL,
    dtx_timestamp timestamp with time zone DEFAULT LOCALTIMESTAMP
);


ALTER TABLE localds2.acela_am_version OWNER TO nvoip;

--
-- Name: acela_det_org; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_det_org (
    nme_sys_failed character varying(40) NOT NULL,
    cde_sys_failed character varying(20) NOT NULL,
    nme_tsk_failed character varying(40) NOT NULL,
    nme_org character varying(40) NOT NULL,
    cat_task smallint NOT NULL
);


ALTER TABLE localds2.acela_det_org OWNER TO nvoip;

--
-- Name: acela_det_pool_org; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_det_pool_org (
    nme_org character varying(40) NOT NULL,
    nbr_parameter smallint NOT NULL,
    nme_parameter character varying(40) NOT NULL
);


ALTER TABLE localds2.acela_det_pool_org OWNER TO nvoip;

--
-- Name: acela_det_pool_work; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_det_pool_work (
    nme_org character varying(40) NOT NULL,
    nbr_pool_wrk smallint NOT NULL,
    nme_pool_wrk character varying(40) NOT NULL,
    val_1_parameter character varying(50),
    val_2_parameter character varying(50),
    val_3_parameter character varying(50),
    val_4_parameter character varying(50),
    val_5_parameter character varying(50),
    val_6_parameter character varying(50),
    val_7_parameter character varying(50),
    val_8_parameter character varying(50),
    val_9_parameter character varying(50),
    val_10_parameter character varying(50)
);


ALTER TABLE localds2.acela_det_pool_work OWNER TO nvoip;

--
-- Name: acela_ord_comment; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_ord_comment (
    nbr_order character varying(13) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    seq_comment numeric(20,0) NOT NULL,
    nme_sys_origin character varying(32),
    txt_comment character varying(2000),
    dtx_timestamp timestamp with time zone DEFAULT LOCALTIMESTAMP
);


ALTER TABLE localds2.acela_ord_comment OWNER TO nvoip;

--
-- Name: acela_ord_status; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_ord_status (
    idn_response numeric(20,0) NOT NULL,
    nbr_order character varying(13) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    sts_order character varying(50),
    cde_error character varying(10),
    txt_error character varying(512),
    dtx_timestamp timestamp with time zone DEFAULT LOCALTIMESTAMP
);


ALTER TABLE localds2.acela_ord_status OWNER TO nvoip;

--
-- Name: acela_proc_workflow; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_proc_workflow (
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    idn_inst_process character varying(255) NOT NULL,
    nme_inst_process character varying(255) NOT NULL,
    nme_sys_flow_wrk character varying(32)
);


ALTER TABLE localds2.acela_proc_workflow OWNER TO nvoip;

--
-- Name: acela_prov_order; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_prov_order (
    nbr_order character varying(13) NOT NULL,
    cde_svc_prov character varying(5) NOT NULL,
    cde_atn_prov character(1) NOT NULL,
    cde_cty_sls_tcom character varying(3),
    nbr_ord_tcoms character varying(8)
);


ALTER TABLE localds2.acela_prov_order OWNER TO nvoip;

--
-- Name: acela_reg_input; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_reg_input (
    idn_registry bigint NOT NULL,
    idn_source character varying(30) NOT NULL,
    cde_status smallint DEFAULT 0 NOT NULL,
    dtx_updated timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    blb_data_source text NOT NULL
);


ALTER TABLE localds2.acela_reg_input OWNER TO nvoip;

--
-- Name: acela_sequence; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_sequence (
    nme_sequence character varying(32) NOT NULL,
    val_last numeric(20,0)
);


ALTER TABLE localds2.acela_sequence OWNER TO nvoip;

--
-- Name: acela_sys_outage; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_sys_outage (
    nme_system character varying(30) NOT NULL,
    dtx_start timestamp with time zone NOT NULL,
    dtx_end timestamp with time zone NOT NULL,
    desc_system character varying(255) NOT NULL
)
WITH (fillfactor='80');


ALTER TABLE localds2.acela_sys_outage OWNER TO nvoip;

--
-- Name: acela_tcoms_return_code; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_tcoms_return_code (
    cde_return character varying(8) NOT NULL,
    cde_jeopardy character varying(8),
    cde_role character varying(8),
    nme_task_fallout character varying(100)
);


ALTER TABLE localds2.acela_tcoms_return_code OWNER TO nvoip;

--
-- Name: acela_tsk_response; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_tsk_response (
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nme_task character varying(30) NOT NULL,
    sts_task character varying(2) NOT NULL,
    dtx_task timestamp with time zone DEFAULT LOCALTIMESTAMP,
    cde_error character varying(35),
    txt_comment character varying(2000),
    CONSTRAINT acela_task_sts16 CHECK (((sts_task)::text = ANY ((ARRAY['CO'::character varying, 'RY'::character varying, 'ER'::character varying, 'RT'::character varying])::text[])))
);


ALTER TABLE localds2.acela_tsk_response OWNER TO nvoip;

--
-- Name: acela_tsk_workflow; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.acela_tsk_workflow (
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nme_task character varying(30) NOT NULL,
    ind_reqd_lidb character(1) DEFAULT 'N'::bpchar NOT NULL,
    ind_reqd_translation_swt character(1) DEFAULT 'N'::bpchar NOT NULL,
    cnt_retry smallint DEFAULT 0 NOT NULL,
    idn_correlation character varying(255) NOT NULL,
    tsk_starter character varying(255),
    cat_chg character varying(20),
    atn_order character varying(20),
    CONSTRAINT sys_c008013 CHECK ((ind_reqd_lidb = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT sys_c008014 CHECK ((ind_reqd_translation_swt = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.acela_tsk_workflow OWNER TO nvoip;

--
-- Name: authenticate; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.authenticate (
    user_id character varying(100) NOT NULL,
    password character varying(100) NOT NULL
);


ALTER TABLE localds2.authenticate OWNER TO nvoip;

--
-- Name: change_history_id; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.change_history_id
    START WITH 1384
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.change_history_id OWNER TO nvoip;

--
-- Name: e911vztsequence_vzbdel; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.e911vztsequence_vzbdel
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE localds2.e911vztsequence_vzbdel OWNER TO nvoip;

--
-- Name: ei_911_vali_confirmation; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ei_911_vali_confirmation (
    cde_vendor character varying(20) NOT NULL,
    txt_cmn_code_vendor character varying(250) NOT NULL,
    cde_status character varying(5) NOT NULL,
    ind_response character varying(25)
);


ALTER TABLE localds2.ei_911_vali_confirmation OWNER TO nvoip;

--
-- Name: ei_911_vali_order; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ei_911_vali_order (
    nbr_ord_ei bigint NOT NULL,
    tnb character(10) NOT NULL,
    nbr_ord_external character varying(50) NOT NULL,
    cde_status character varying(5) NOT NULL,
    txt_adr character varying(250) NOT NULL,
    dtx_status timestamp with time zone NOT NULL,
    dtx_request timestamp with time zone NOT NULL,
    idx_org_ord_external character varying(10) NOT NULL,
    idx_org_ord_client character varying(10) NOT NULL,
    cde_function character(1) NOT NULL,
    typ_adr character(1) NOT NULL,
    txt_adr_corrected character varying(250),
    txt_svc_of_level character varying(50),
    nbr_supp_order character varying(3),
    txt_key character varying(100),
    CONSTRAINT ei_911_vali_order_csn01 CHECK ((cde_function = ANY (ARRAY['I'::bpchar, 'D'::bpchar, 'C'::bpchar, 'M'::bpchar, 'U'::bpchar]))),
    CONSTRAINT ei_911_vali_order_csn02 CHECK ((typ_adr = ANY (ARRAY['S'::bpchar, 'P'::bpchar])))
);


ALTER TABLE localds2.ei_911_vali_order OWNER TO nvoip;

--
-- Name: ei_911_vali_order_comments; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ei_911_vali_order_comments (
    nbr_seq_comments numeric(20,0) NOT NULL,
    nbr_ord_ei bigint NOT NULL,
    txt_message character varying(300) NOT NULL,
    dtx_comments timestamp with time zone NOT NULL,
    ind_response character varying(25),
    cde_vendor character varying(20) NOT NULL
);


ALTER TABLE localds2.ei_911_vali_order_comments OWNER TO nvoip;

--
-- Name: ei_911_vali_order_his; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ei_911_vali_order_his (
    nbr_seq_history numeric(20,0) NOT NULL,
    nbr_ord_ei bigint NOT NULL,
    tnb character(10) NOT NULL,
    nbr_ord_external character varying(50) NOT NULL,
    cde_status character varying(5) NOT NULL,
    txt_adr character varying(250) NOT NULL,
    dtx_status timestamp with time zone NOT NULL,
    dtx_request timestamp with time zone NOT NULL,
    idx_org_ord_external character varying(10) NOT NULL,
    idx_org_ord_client character varying(10) NOT NULL,
    cde_function character(1) NOT NULL,
    typ_adr character(1) NOT NULL,
    txt_adr_corrected character varying(250),
    txt_svc_of_level character varying(50),
    nbr_supp_order character varying(3),
    txt_key character varying(100),
    CONSTRAINT ei_911_vali_order_his_csn01 CHECK ((cde_function = ANY (ARRAY['I'::bpchar, 'D'::bpchar, 'C'::bpchar, 'M'::bpchar, 'U'::bpchar]))),
    CONSTRAINT ei_911_vali_order_his_csn02 CHECK ((typ_adr = ANY (ARRAY['S'::bpchar, 'P'::bpchar])))
);


ALTER TABLE localds2.ei_911_vali_order_his OWNER TO nvoip;

--
-- Name: ei_911_vali_status; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ei_911_vali_status (
    cde_status_input character varying(100) NOT NULL,
    cde_status_output character varying(5) NOT NULL
);


ALTER TABLE localds2.ei_911_vali_status OWNER TO nvoip;

--
-- Name: ei_exception_log; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ei_exception_log (
    nbr_order character varying(75),
    nbr_supp_order character varying(3),
    txt_error character varying(250),
    dtx_error timestamp with time zone
);


ALTER TABLE localds2.ei_exception_log OWNER TO nvoip;

--
-- Name: eitrans_dadl; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.eitrans_dadl (
    idx_tnb character varying(12),
    cde_ali character varying(3),
    idx_dir character varying(6),
    ind_gov character(1),
    ind_adv_dir character(1),
    typ_tra character varying(2),
    typ_rcd character varying(3),
    typ_lst character varying(2),
    tnb_prv character(10),
    idx_dsg_lst character varying(12),
    ind_cct_dlv_new character(1),
    ind_adr_dir_omt character(1),
    cde_sic character varying(4),
    nme_fil_spl character varying(50),
    idx_pst_ltr character varying(25),
    tnb_ref character(10),
    idx_com character varying(4),
    flg_omt_lst_cus character(1),
    flg_omt_adr_dir character(1),
    ind_lst_bus_rsd character(1),
    ind_lst_rsd_bus character(1),
    tnb_alt character varying(40),
    txt_cll_hrs_aft character varying(45),
    sts_jbs character varying(15),
    dtx_eff_sts timestamp with time zone,
    ind_atv_asi_dir character(1),
    ind_aut_exs character(1),
    flg_ath_agn character(1),
    ind_bil_alt character(1),
    txt_capt character varying(20),
    ind_typ_capt character varying(20),
    ind_chg_carr character(1),
    txt_srf character varying(50),
    idx_pon_cus character varying(18),
    ind_nme_fst_dul character(1),
    nme_lst_fst_dul character varying(20),
    ind_hdr character(1),
    idx_hdr character(2),
    txt_hdr character varying(20),
    cde_hdr character varying(6),
    ind_lvl_indt bigint,
    ind_lvl_indt_new character(1),
    txt_indt character varying(50),
    ind_deg_indt bigint,
    txt_adr_indt character varying(100),
    tnb_indt character(10),
    sts_lvl_ind character(1),
    qty_dlv_dir_mul bigint,
    qty_wpg_ann bigint,
    qty_ypg_ann bigint,
    qty_wpg_init bigint,
    qty_ypg_init character varying(18),
    qty_dir_btb bigint,
    ind_lst_prof character(1),
    ind_exp character(1),
    flg_cut_hto_cor character(1),
    nbr_act_bil_dir character varying(13),
    idn_subs_dir character varying(14),
    flg_exm_tax_dir character(1),
    txt_dsg_prof character varying(25),
    dtx_snt timestamp with time zone,
    nme_dir character varying(35),
    idx_lne_acs character varying(12),
    typ_phn character varying(25),
    nbr_phn_ste character varying(15),
    idx_lec character varying(3),
    tnb character(10),
    tnb_bil character(10),
    typ_cus character(1),
    idx_opt_pln_cll character varying(20),
    tnb_lec_icn_ren character(10),
    tnb_ren_lec character(10),
    nbr_pth_inp_ilec bigint,
    tnb_rfl_wcm character(10),
    nbr_mth_rfl_wcm bigint,
    idx_grp character varying(5),
    nbr_seq_hun bigint,
    cde_acn character(2),
    ind_exc_frg character(1),
    ind_drc_cll character(1),
    dtx_eff_svf timestamp with time zone,
    idx_ord character varying(13),
    typ_ord character varying(3),
    ind_atn_ord character(1),
    cat_chg character(1),
    idx_org_ord character(1),
    nbr_ord character varying(13),
    idx_spn_ord character varying(3),
    cde_sts_ord character varying(10),
    cat_spn character varying(2),
    nbr_ord_rlt character varying(20),
    dtx_due_dre_cus timestamp with time zone,
    idn_lec_los character varying(20),
    cde_rol_adr character varying(3),
    idx_adr character varying(30),
    nme_tgh character varying(8),
    nme_cty character varying(35),
    cde_zip_exd character(9),
    cde_ste character(2),
    adr_pre_bld character varying(5),
    nbr_bld character varying(15),
    nbr_sfx_bld character varying(5),
    nbr_rom character varying(20),
    nbr_flo_bld character varying(20),
    idx_str_drc_pcd character varying(10),
    nme_str character varying(60),
    idx_str_drc_psd character varying(10),
    des_oth character varying(45),
    adr_one_lne character varying(30),
    adr_two_lne character varying(30),
    nme_cry character varying(25),
    cde_rol_nme character varying(3),
    idx_nme character varying(12),
    nme_las character varying(50),
    nme_fst character varying(35),
    nme_ini_mid character(1),
    nme_lne character varying(12),
    nme_ttl character varying(12),
    nme_two_ttl character varying(12),
    nme_com_ctc character varying(50),
    typ_rec_pcb character(1),
    cde_hdg_pge_yel character varying(8),
    nbr_ord_rlt_ilec character varying(17),
    tnb_lst character(10),
    tnb_ctc character varying(10),
    cde_ist_lst character(4),
    cde_srv_cls_lne character(3),
    flg_lst_ren character(1),
    typ_rqn character(1),
    sts_rqn character(1),
    ind_exm_tax_dir character(1),
    tnb_nonstd character varying(20),
    cde_subsct_dir character varying(14),
    idx_tnb_old character varying(12),
    typ_tnb_por character(3),
    flg_lst_for character(1),
    ind_tnb_new_old character(1),
    ind_lne_acs_new_old character(1),
    cat_phn character varying(10),
    qty_pth_tnb_ren bigint,
    txt_rmk_dira_drl character varying(200),
    txt_hdg_pge_yel character varying(200),
    nme_nck character varying(20),
    txt_typ_lst character varying(3),
    cde_dir character varying(20),
    nme_bld character varying(9),
    adr_rom character varying(9),
    cde_typ_adr character varying(10),
    ind_ord_crr character(1),
    cde_brk_alp character(18),
    nbr_qry_ord integer,
    ind_res_lst character(1),
    ind_bus_lst character(1),
    txt_tnb character varying(50),
    cde_prd_wpg character varying(3),
    txt_spl character varying(50),
    typ_acn character(1),
    cde_lob character varying(3),
    idn_pvd_srv smallint,
    nbr_acn_bil character varying(13)
);


ALTER TABLE localds2.eitrans_dadl OWNER TO nvoip;

--
-- Name: ilec_avail_exception_id; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.ilec_avail_exception_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.ilec_avail_exception_id OWNER TO nvoip;

--
-- Name: lsr_admin_response; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_admin_response (
    idx_response character varying(16) NOT NULL,
    nbr_pon character varying(20) NOT NULL,
    nbr_version_pon character varying(5) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    typ_response character(1),
    flg_tsk_current character(1),
    seq_of_out character(1),
    sts_task character varying(15),
    dtx_task timestamp with time zone,
    dtx_scheduled timestamp with time zone,
    nbr_dsr character varying(50),
    rmk_lec character varying(160),
    nbr_ver_ec character varying(3),
    tnb_atn character varying(14),
    cde_act_init_prvd character varying(3),
    nbr_ring_trig_digit_ten character varying(10),
    dtx_system timestamp with time zone,
    nbr_ord_lup_lec character varying(20),
    val_time_frame_desired character varying(12),
    dtx_replication timestamp with time zone,
    seq_resp_admin numeric(20,0) NOT NULL,
    ind_ord_voip character(1),
    CONSTRAINT lsr_admin_response_csn01 CHECK ((flg_tsk_current = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT lsradmin_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.lsr_admin_response OWNER TO nvoip;

--
-- Name: lsr_am_task_info; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_am_task_info (
    idx_task_am character varying(32) NOT NULL,
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_flow_work_task character varying(3),
    sts_tsk_order character(1),
    nme_tsk_flow_work character varying(75),
    rmk_tsk character varying(100),
    dtx_task timestamp with time zone NOT NULL,
    dtx_task_upd_las timestamp with time zone,
    seq_info_task_am numeric(20,0) NOT NULL,
    sts_process_task character(1),
    nme_process character varying(20),
    txt_tsk_attributes character varying(1000)
);


ALTER TABLE localds2.lsr_am_task_info OWNER TO nvoip;

--
-- Name: lsr_am_task_info_report; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_am_task_info_report (
    idx_task_am character varying(32) NOT NULL,
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_flow_work_task character varying(3),
    sts_tsk_order character(1),
    nme_tsk_flow_work character varying(75),
    rmk_tsk character varying(100),
    dtx_task timestamp with time zone,
    dtx_task_upd_las timestamp with time zone,
    seq_info_task_am numeric(20,0) NOT NULL
);


ALTER TABLE localds2.lsr_am_task_info_report OWNER TO nvoip;

--
-- Name: lsr_dl_response; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_dl_response (
    nbr_pon character varying(20) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_line_dl integer NOT NULL,
    tnb_listed character(10) NOT NULL,
    cde_ali_our character varying(5) NOT NULL,
    cde_ali_lec character varying(5),
    ind_lact character(1),
    txt_key_dir character varying(250),
    dtx_replication timestamp with time zone,
    seq_resp_dl numeric(20,0) NOT NULL,
    ind_ord_voip character(1),
    CONSTRAINT d1_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.lsr_dl_response OWNER TO nvoip;

--
-- Name: lsr_lec_sla; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_lec_sla (
    nme_lec character varying(3) NOT NULL,
    sts_task character varying(25) NOT NULL,
    nbr_sla smallint NOT NULL,
    val_1_parameter character varying(50),
    val_2_parameter character varying(50),
    val_3_parameter character varying(50)
);


ALTER TABLE localds2.lsr_lec_sla OWNER TO nvoip;

--
-- Name: lsr_ls_response; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_ls_response (
    nbr_pon character varying(20) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_line_ls integer NOT NULL,
    tnb bigint NOT NULL,
    idn_ckt_our character varying(17)
);


ALTER TABLE localds2.lsr_ls_response OWNER TO nvoip;

--
-- Name: lsr_ls_response_info; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_ls_response_info (
    idx_response character varying(16) NOT NULL,
    nbr_lnum character varying(4) NOT NULL,
    idn_ecckt character varying(53),
    tnb bigint,
    idn_ckt_our character varying(17)
);


ALTER TABLE localds2.lsr_ls_response_info OWNER TO nvoip;

--
-- Name: lsr_lsnp_response; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_lsnp_response (
    nbr_pon character varying(20) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_line_lsnp integer NOT NULL,
    tnb bigint NOT NULL,
    idn_ckt_our character varying(17),
    typ_tnb_por character varying(3)
);


ALTER TABLE localds2.lsr_lsnp_response OWNER TO nvoip;

--
-- Name: lsr_np_response; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_np_response (
    nbr_pon character varying(20) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_line_np integer NOT NULL,
    tnb character(15) NOT NULL,
    dtx_replication timestamp with time zone,
    seq_resp_np numeric(20,0) NOT NULL,
    ind_ord_voip character(1),
    CONSTRAINT np_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.lsr_np_response OWNER TO nvoip;

--
-- Name: lsr_pon_tracking; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_pon_tracking (
    nbr_pon character varying(20) NOT NULL,
    tnb_bil_lec character(10) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_version_pon character varying(5) NOT NULL,
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    typ_request character varying(4) NOT NULL,
    dtx_due_desired_cus timestamp with time zone NOT NULL,
    nbr_line_np_max smallint,
    nbr_line_dl_max integer,
    idx_lec character varying(10),
    dtx_sent_estimated timestamp with time zone,
    dtx_meet_vendor timestamp with time zone,
    nbr_flow_work_task character varying(3),
    sts_ord_pon character varying(25),
    dtx_pon timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    nbr_line_ls_max smallint,
    dtx_replication timestamp with time zone,
    seq_track_pon numeric(20,0) NOT NULL,
    ind_ord_voip character(1),
    ind_timr_mdm character(1),
    flg_por_smpl character(1),
    ind_rgn_npac character varying(20),
    rpon character varying(20),
    rpver character varying(5),
    nor character varying(4),
    CONSTRAINT chk_lsr_pon_trac_flg_por_smpl CHECK ((flg_por_smpl = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT chk_lsr_pon_trac_ind_timr_mdm CHECK ((ind_timr_mdm = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT lsr_pon_tracking_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT lsr_pon_tracking_csn01 CHECK (((typ_request)::text = ANY ((ARRAY['NP'::character varying, 'DL'::character varying, 'ND'::character varying, 'NPDL'::character varying, 'LP'::character varying, 'LN'::character varying, 'AL'::character varying, 'LD'::character varying])::text[])))
);


ALTER TABLE localds2.lsr_pon_tracking OWNER TO nvoip;

--
-- Name: lsr_pon_tracking_report; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_pon_tracking_report (
    nbr_pon character varying(20) NOT NULL,
    tnb_bil_lec character(10) NOT NULL,
    nbr_supp_order character varying(3) NOT NULL,
    nbr_version_pon character varying(5) NOT NULL,
    nbr_order character varying(13) NOT NULL,
    idn_origin_order character(1) NOT NULL,
    typ_request character varying(4) NOT NULL,
    dtx_due_desired_cus timestamp with time zone NOT NULL,
    nbr_line_np_max smallint,
    nbr_line_dl_max integer,
    idx_lec character varying(10),
    dtx_sent_estimated timestamp with time zone,
    dtx_meet_vendor timestamp with time zone,
    nbr_flow_work_task character varying(3),
    sts_ord_pon character varying(25),
    dtx_pon timestamp with time zone NOT NULL,
    nbr_line_ls_max smallint,
    dtx_replication timestamp with time zone,
    seq_track_pon numeric(20,0) NOT NULL
);


ALTER TABLE localds2.lsr_pon_tracking_report OWNER TO nvoip;

--
-- Name: lsr_reject_detail; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_reject_detail (
    idx_response character varying(16) NOT NULL,
    idx_reject character varying(16) NOT NULL,
    cde_reject character varying(50),
    dtl_reject character varying(500),
    nbr_order character varying(13),
    nbr_supp_order character varying(3),
    nbr_flow_work_task character varying(3),
    dtx_received timestamp with time zone,
    dtx_replication timestamp with time zone,
    seq_detl_reject numeric(20,0) NOT NULL
);


ALTER TABLE localds2.lsr_reject_detail OWNER TO nvoip;

--
-- Name: lsr_report_ctl; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_report_ctl (
    nme_tbl_report character varying(30) NOT NULL,
    val_seq_last numeric(20,0) NOT NULL
);


ALTER TABLE localds2.lsr_report_ctl OWNER TO nvoip;

--
-- Name: lsr_response_audit_tracking; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_response_audit_tracking (
    nbr_pon character varying(20) NOT NULL,
    nbr_version_pon character varying(5) NOT NULL,
    idn_origin_order character(1),
    nbr_order character varying(13),
    nbr_supp_order character varying(3),
    nbr_flow_work_task character varying(3),
    idx_header_jms character varying(80),
    sts_task character varying(15),
    txt_remarks character varying(200),
    sts_tsk_order character varying(10),
    dtx_replication timestamp with time zone,
    seq_track_audit numeric(20,0) NOT NULL
);


ALTER TABLE localds2.lsr_response_audit_tracking OWNER TO nvoip;

--
-- Name: lsr_tsk_sts; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.lsr_tsk_sts (
    cde_task smallint NOT NULL,
    sts_task character varying(25) NOT NULL,
    des_task character varying(50) NOT NULL,
    sts_job_task character varying(3)
);


ALTER TABLE localds2.lsr_tsk_sts OWNER TO nvoip;

--
-- Name: months; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.months (
    cur_month character varying(6) NOT NULL,
    status character varying(1) NOT NULL,
    statusb character varying(1),
    bsaved_date timestamp with time zone
);


ALTER TABLE localds2.months OWNER TO nvoip;

--
-- Name: nbr_seq_apl; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.nbr_seq_apl
    START WITH 775187
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 20;


ALTER TABLE localds2.nbr_seq_apl OWNER TO nvoip;

--
-- Name: npar_bas; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_bas (
    nme_bas character varying(20) NOT NULL,
    CONSTRAINT npar_bas_csn01 CHECK (((nme_bas)::text = ANY ((ARRAY['INTRADA'::character varying, 'OSS'::character varying, 'SDD'::character varying, 'ADS'::character varying, 'SDM'::character varying, 'WLS'::character varying, 'WOC'::character varying, 'TNIS'::character varying])::text[])))
);


ALTER TABLE localds2.npar_bas OWNER TO nvoip;

--
-- Name: npar_bch; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_bch (
    nbr_bch numeric(38,0) NOT NULL,
    dtx_pmv_beg timestamp with time zone NOT NULL,
    dtx_pmv_end timestamp with time zone NOT NULL,
    des_bch character varying(35)
);


ALTER TABLE localds2.npar_bch OWNER TO nvoip;

--
-- Name: npar_spi; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_spi (
    nbr_npa_old character(3) NOT NULL,
    nbr_nxx character(3) NOT NULL,
    nbr_npa_new character(3) NOT NULL,
    nbr_bch bigint NOT NULL,
    dtx_cut timestamp with time zone NOT NULL,
    idx_tnk_emac_new character(3),
    cde_oba_new character(3),
    CONSTRAINT npar_spi_ck01 CHECK (((nbr_npa_old)::bigint >= 200)),
    CONSTRAINT npar_spi_ck02 CHECK (((nbr_nxx)::bigint >= 200)),
    CONSTRAINT npar_spi_ck03 CHECK (((nbr_npa_new)::bigint >= 200))
);


ALTER TABLE localds2.npar_spi OWNER TO nvoip;

--
-- Name: npar_spi_apl; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_spi_apl (
    nbr_npa_old character(3) NOT NULL,
    nbr_nxx character(3) NOT NULL,
    nme_bas character varying(20) NOT NULL,
    nme_tbl character varying(20) NOT NULL,
    nbr_seq_apl bigint NOT NULL,
    cde_sts_spi_apl character(1) NOT NULL,
    dtx_sts timestamp with time zone NOT NULL,
    CONSTRAINT sys_c008374 CHECK (((nbr_npa_old)::bigint >= 200)),
    CONSTRAINT sys_c008375 CHECK (((nbr_nxx)::bigint >= 200))
);


ALTER TABLE localds2.npar_spi_apl OWNER TO nvoip;

--
-- Name: npar_sts_err_log; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_sts_err_log (
    nbr_npa_from character(3),
    nbr_nxx_from character(3),
    nme_process character varying(30),
    msg_status_error character varying(2000),
    ind_ord_voip character(1),
    dtx_status_error timestamp with time zone,
    CONSTRAINT ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
)
WITH (fillfactor='80');


ALTER TABLE localds2.npar_sts_err_log OWNER TO nvoip;

--
-- Name: npar_tbl; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_tbl (
    nme_bas character varying(20) NOT NULL,
    nme_tbl character varying(20) NOT NULL,
    nme_prc_sto character varying(60)
);


ALTER TABLE localds2.npar_tbl OWNER TO nvoip;

--
-- Name: npar_voip_spi; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.npar_voip_spi (
    cde_sts_split character(2) NOT NULL,
    nbr_npa_from character(3) NOT NULL,
    nbr_nxx_from character(3) NOT NULL,
    key_tkg_psu_from character varying(12) NOT NULL,
    nbr_tkg_from character varying(11),
    nbr_nme_rte_off_from character varying(14),
    cde_clli_swt_wcom_from character varying(11),
    cde_action character(1),
    nbr_npa_to character(3),
    key_tkg_psu_to character varying(12),
    nbr_tkg_to character varying(11),
    nbr_nme_rte_off_to character varying(14),
    nme_grp_ali_ps_to character varying(6),
    dtx_split_npa timestamp with time zone,
    dtx_submitted timestamp with time zone,
    dtx_completed timestamp with time zone
)
WITH (fillfactor='80');


ALTER TABLE localds2.npar_voip_spi OWNER TO nvoip;

--
-- Name: ord_frontier_chng_4302020; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ord_frontier_chng_4302020 (
    idx_ord character varying(13) NOT NULL,
    idx_org_ord character(1) NOT NULL,
    nbr_ord_rlt character varying(20),
    idx_spn_ord character varying(3) NOT NULL,
    cde_sts_ord character varying(10) NOT NULL,
    idx_fer_loc_srv character varying(15) NOT NULL,
    ind_atn_ord character(1) NOT NULL,
    cde_lob character varying(3) NOT NULL,
    ind_chc character(1),
    nbr_ord character varying(13) NOT NULL,
    typ_ord character varying(3) NOT NULL,
    typ_cus character(1),
    cat_chg character varying(3),
    dtx_due_dre_cus timestamp with time zone,
    flg_exp_ord character(1) NOT NULL,
    flg_rqd_han_man character(1),
    ind_trn_ord character(1),
    idn_itm_wrk_ext character varying(20),
    idx_cus_ixp character varying(13),
    qty_t1 integer,
    qty_tkg integer,
    dtx_upd_las timestamp with time zone NOT NULL,
    sys_upd_las_idn character(1),
    typ_sal character varying(3),
    ind_exp_lsr character(1),
    nbr_acn_bil character varying(13),
    idn_pvd_srv character varying(4) NOT NULL,
    nbr_ocn character varying(4) NOT NULL,
    idn_ord_pvn_ldn character varying(8),
    typ_bri character(3),
    qty_lne_bri smallint,
    ind_tnb character(1),
    ind_ont_cus character(1) NOT NULL,
    txt_cat_spn character varying(256),
    idn_lsp character varying(4),
    cde_loc_rev character varying(3),
    idn_pvd_srv_los character varying(4),
    nbr_vcm character(10),
    cde_own_swt character(1),
    nbr_sdm integer,
    idx_cus_cis character varying(22),
    idx_adr_cis character varying(22),
    tmx_cut_hot character(4),
    des_rea_exp_lsr character varying(80),
    idn_rslr character varying(5),
    idx_cus_rslr character varying(22),
    dtx_met_vnd timestamp with time zone,
    zne_tmx_cddd character varying(3),
    idn_pvd_srv_gan character varying(4),
    ind_lsr character(2),
    typ_acc character varying(2),
    dtx_foc_pvn timestamp with time zone,
    ind_mig character varying(3),
    idn_pvd_srv_dl character varying(4),
    ind_mov_por character(1),
    dtx_foc_wsp timestamp with time zone,
    nbr_cfm_app character varying(10),
    cde_cty_sls_tcom character varying(3),
    cde_icsc character varying(4),
    nbr_sup_tsk_prv_adp character varying(30),
    ind_cfa_reuse character(1),
    idx_cntr_oe character varying(3),
    idx_cntr_srv_prov character varying(14),
    nbr_rel character varying(5),
    ind_fac_reuse character(1),
    idn_pvd_srv_lup character varying(4),
    idx_wrld_one character varying(9),
    cde_loc_rev_int character varying(3),
    typ_prd_sub character varying(10),
    typ_sdm character varying(2),
    typ_trnspt character varying(2),
    nbr_sup_tsk_prv_t1 character varying(30),
    nbr_sup_tsk_prv_line character varying(30),
    nbr_sup_tsk_prv_chn_trnk character varying(30),
    ind_cfa_chg character(1),
    cls_ord character varying(10),
    ind_int_ext character varying(10),
    ind_svc_site character(1),
    ind_act_por character(1),
    ind_sdi character(1),
    flg_chc_iasa character(1),
    txt_dtx_due_dre_cus character varying(14),
    flg_por_smpl character(1),
    txt_rgn_npac character varying(20),
    gch_id character varying(16),
    svc_inst_id character varying(64)
);


ALTER TABLE localds2.ord_frontier_chng_4302020 OWNER TO nvoip;

--
-- Name: ossr_800_tol_fre; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_800_tol_fre (
    idx_tnb character varying(12) NOT NULL,
    tnb_fre_tol character(10) NOT NULL
);


ALTER TABLE localds2.ossr_800_tol_fre OWNER TO nvoip;

--
-- Name: ossr_911; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_911 (
    idx_tnb character varying(12) NOT NULL,
    tnb_main character(10) NOT NULL,
    idx_nme character varying(12) NOT NULL,
    idx_adr character varying(30) NOT NULL,
    idx_chg_fnt character(1) NOT NULL,
    idx_cus_911 character varying(9),
    idx_exc character varying(4),
    typ_srv character(1),
    txt_inf_rcf character varying(18),
    sts_jbs character varying(15) NOT NULL,
    cde_tar character(6),
    dtx_eff_sts timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    txt_cmn_911 character varying(30),
    dtx_snt timestamp with time zone,
    nbr_srv_esn character varying(5),
    cls_srv character(1),
    sts_jbs_vali character varying(15),
    dtx_eff_sts_vali timestamp with time zone,
    dtx_snt_vali timestamp with time zone,
    cls_srv_voip character(1),
    ind_ord_voip character(1),
    CONSTRAINT ossr_911_csn01 CHECK ((idx_chg_fnt = ANY (ARRAY['I'::bpchar, 'C'::bpchar, 'D'::bpchar, 'M'::bpchar, 'U'::bpchar]))),
    CONSTRAINT ossr_911_csn02 CHECK ((typ_srv = ANY (ARRAY['0'::bpchar, '1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '5'::bpchar]))),
    CONSTRAINT ossr_911_csn03 CHECK ((cls_srv = ANY (ARRAY['0'::bpchar, '1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '5'::bpchar, '6'::bpchar, '7'::bpchar, '8'::bpchar, '9'::bpchar, 'V'::bpchar, 'C'::bpchar, 'D'::bpchar, 'E'::bpchar, 'F'::bpchar, 'J'::bpchar, 'K'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_911_csn04 CHECK ((cls_srv_voip = ANY (ARRAY['V'::bpchar, 'C'::bpchar, 'D'::bpchar, 'E'::bpchar, 'F'::bpchar, 'J'::bpchar, 'K'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_911_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_911 OWNER TO nvoip;

--
-- Name: ossr_acs_lne; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_acs_lne (
    idn_lne_acs character varying(12) NOT NULL,
    idx_ord character varying(13) NOT NULL,
    idx_swt_wcom character varying(5),
    idx_ord_wrk character varying(14),
    idx_por_swt character varying(36),
    cde_rsc_tol character varying(5) DEFAULT '7'::character varying,
    idx_fer_loc_srv character varying(15) NOT NULL,
    typ_cir character varying(3) NOT NULL,
    flg_ntw_off character(1) NOT NULL,
    flg_cnv_lne character(1) DEFAULT 'N'::bpchar NOT NULL,
    ind_lop_gnd_sta character(1) NOT NULL,
    ind_srv_sus character(1) DEFAULT 'N'::bpchar NOT NULL,
    cde_atv_lne character(1),
    flg_tctn character(1) DEFAULT 'Y'::bpchar NOT NULL,
    idn_npnx_ilec_old character varying(18),
    dtx_foc_ilec timestamp with time zone,
    idn_tnk_emac character varying(3),
    nbr_ord_rlt_ilec character varying(17),
    idx_lne_acs_old character varying(12),
    cde_typ_lne character varying(3) NOT NULL,
    idn_cir character varying(10),
    idn_par_tie character varying(32),
    ind_lne_acs_new_old character(1),
    cde_cfa character varying(42),
    loc_actl character varying(11),
    cde_nci character varying(12),
    cde_ncc character varying(4),
    cde_nci_scd character varying(12),
    nbr_ord_rlt_ilec_np character varying(17),
    idn_cir_lec character varying(53),
    cde_clli_swt_wcom character varying(11),
    cde_ord_isdn character(3),
    typ_swt character varying(6),
    qty_dn smallint,
    qty_spid smallint,
    cde_tmt_acs character varying(5),
    idx_swt_srv character varying(5),
    cde_clli_swt_srv character varying(11),
    dtx_foc_lnp_ilec timestamp with time zone,
    dtx_due_dre_lsr timestamp with time zone,
    idn_cir_wcom character varying(17),
    idx_spe_asm character varying(20),
    cde_atv_sup_lne character(1),
    cde_atv_dta_lne character varying(3),
    idx_par_chn character varying(5),
    nbr_cbl character varying(5),
    cde_atv_rej character(1),
    cde_sts_ntw_lne character varying(25),
    cde_tsp character varying(12),
    cde_rdt character varying(20),
    cde_crv character varying(4),
    cde_sts_lne_prov character varying(25),
    ind_drc_cll character(1),
    idn_cir_old character varying(10),
    CONSTRAINT ossr_acs_lne_csn05 CHECK ((flg_ntw_off = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn06 CHECK ((flg_cnv_lne = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn07 CHECK ((ind_lop_gnd_sta = ANY (ARRAY['G'::bpchar, 'L'::bpchar, 'E'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn08 CHECK ((ind_srv_sus = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn09 CHECK ((flg_tctn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn10 CHECK ((cde_atv_lne = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar, 'M'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn11 CHECK ((ind_lne_acs_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn13 CHECK ((cde_atv_sup_lne = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_acs_lne_csn14 CHECK (((cde_sts_ntw_lne)::text = ANY ((ARRAY['LSDS-AVAILABLE'::character varying, 'LSDS-WORKING'::character varying, 'LSDS-UNAVAILABLE'::character varying, 'LSDS-UNTESTED'::character varying, 'TCOMS-ENGINEERED'::character varying, 'TCOMS-UNCHANGED'::character varying, 'MLT-PROV-SUCCESSFUL'::character varying, 'MLT-PROV-NO-DIAL-TONE'::character varying, 'MLT-PROV-ANI-MISMATCH'::character varying, 'MLT-PROV-LOOP-LENGTH'::character varying, 'MLT-PROV-UNTESTED'::character varying, 'MLT-INST-SUCCESSFUL'::character varying, 'MLT-INST-NO-DIAL-TONE'::character varying, 'MLT-INST-ANI-MISMATCH'::character varying, 'MLT-INST-LOOP-LENGTH'::character varying])::text[]))),
    CONSTRAINT ossr_acs_lne_csn15 CHECK (((cde_sts_lne_prov)::text = ANY ((ARRAY['TCOMS-ENGINEERED'::character varying, 'TCOMS-UNCHANGED'::character varying, 'TCOMS-NO-ENGINEERING'::character varying, 'TCOMS-AUTO-CORRECTED'::character varying, 'TCOMS-USER-CORRECTED'::character varying])::text[]))),
    CONSTRAINT ossr_acs_lne_csn16 CHECK ((ind_drc_cll = ANY (ARRAY['B'::bpchar, 'I'::bpchar, 'O'::bpchar])))
);


ALTER TABLE localds2.ossr_acs_lne OWNER TO nvoip;

--
-- Name: ossr_acs_lne_04_29_2014; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_acs_lne_04_29_2014 (
    idn_lne_acs character varying(12) NOT NULL,
    idx_ord character varying(13) NOT NULL,
    idx_swt_wcom character varying(5),
    idx_ord_wrk character varying(14),
    idx_por_swt character varying(36),
    cde_rsc_tol character varying(5),
    idx_fer_loc_srv character varying(15) NOT NULL,
    typ_cir character varying(3) NOT NULL,
    flg_ntw_off character(1) NOT NULL,
    flg_cnv_lne character(1) NOT NULL,
    ind_lop_gnd_sta character(1) NOT NULL,
    ind_srv_sus character(1) NOT NULL,
    cde_atv_lne character(1),
    flg_tctn character(1) NOT NULL,
    idn_npnx_ilec_old character varying(18),
    dtx_foc_ilec timestamp with time zone,
    idn_tnk_emac character varying(3),
    nbr_ord_rlt_ilec character varying(17),
    idx_lne_acs_old character varying(12),
    cde_typ_lne character varying(3) NOT NULL,
    idn_cir character varying(10),
    idn_par_tie character varying(32),
    ind_lne_acs_new_old character(1),
    cde_cfa character varying(42),
    loc_actl character varying(11),
    cde_nci character varying(12),
    cde_ncc character varying(4),
    cde_nci_scd character varying(12),
    nbr_ord_rlt_ilec_np character varying(17),
    idn_cir_lec character varying(53),
    cde_clli_swt_wcom character varying(11),
    cde_ord_isdn character(3),
    typ_swt character varying(6),
    qty_dn smallint,
    qty_spid smallint,
    cde_tmt_acs character varying(5),
    idx_swt_srv character varying(5),
    cde_clli_swt_srv character varying(11),
    dtx_foc_lnp_ilec timestamp with time zone,
    dtx_due_dre_lsr timestamp with time zone,
    idn_cir_wcom character varying(17),
    idx_spe_asm character varying(20),
    cde_atv_sup_lne character(1),
    cde_atv_dta_lne character varying(3),
    idx_par_chn character varying(5),
    nbr_cbl character varying(5),
    cde_atv_rej character(1),
    cde_sts_ntw_lne character varying(25),
    cde_tsp character varying(12),
    cde_rdt character varying(20),
    cde_crv character varying(4),
    cde_sts_lne_prov character varying(25),
    ind_drc_cll character(1),
    idn_cir_old character varying(10)
);


ALTER TABLE localds2.ossr_acs_lne_04_29_2014 OWNER TO nvoip;

--
-- Name: ossr_acs_lne_svf; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_acs_lne_svf (
    nme_svf character varying(25) NOT NULL,
    idn_lne_acs character varying(12) NOT NULL,
    cde_atn character varying(2) NOT NULL
);


ALTER TABLE localds2.ossr_acs_lne_svf OWNER TO nvoip;

--
-- Name: ossr_adr; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_adr (
    idx_adr character varying(30) NOT NULL,
    nme_tgh character varying(12),
    nme_cty character varying(35),
    cde_zip_exd character varying(9),
    cde_ste character(2) NOT NULL,
    adr_pre_bld character varying(6),
    nbr_bld character varying(15),
    nbr_sfx_bld character varying(5),
    nbr_rom character varying(20),
    nbr_flo_bld character varying(20),
    idx_str_drc_pcd character varying(10),
    nme_str character varying(60),
    idx_str_drc_psd character varying(10),
    des_oth character varying(60),
    adr_one_lne character varying(30),
    adr_two_lne character varying(30),
    nme_cry character varying(25),
    nme_bld character varying(10),
    adr_rom character varying(9),
    cde_typ_adr character varying(10) NOT NULL,
    typ_rom character varying(10),
    typ_flo character varying(10),
    typ_bld character varying(4),
    are_loc_adr_cus character varying(4),
    idx_cmm character varying(4),
    idx_exc character varying(4),
    nbr_box character varying(6),
    idn_cny character varying(6),
    CONSTRAINT ossr_adr_csn02 CHECK (((cde_typ_adr)::text = ANY ((ARRAY['SAG'::character varying, 'MSAG'::character varying, 'Postal Soft'::character varying, 'Generic'::character varying, 'SAV'::character varying])::text[]))),
    CONSTRAINT ossr_adr_csn03 CHECK (((idx_str_drc_pcd)::text = ANY ((ARRAY['E'::character varying, 'N'::character varying, 'W'::character varying, 'S'::character varying, 'NE'::character varying, 'NW'::character varying, 'SE'::character varying, 'SW'::character varying])::text[]))),
    CONSTRAINT ossr_adr_csn04 CHECK (((idx_str_drc_psd)::text = ANY ((ARRAY['E'::character varying, 'N'::character varying, 'W'::character varying, 'S'::character varying, 'NE'::character varying, 'NW'::character varying, 'SE'::character varying, 'SW'::character varying])::text[])))
);


ALTER TABLE localds2.ossr_adr OWNER TO nvoip;

--
-- Name: ossr_adr_rol; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_adr_rol (
    cde_rol_adr character varying(3) NOT NULL,
    des_rol_adr character varying(35) NOT NULL
);


ALTER TABLE localds2.ossr_adr_rol OWNER TO nvoip;

--
-- Name: ossr_atn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_atn (
    cde_atn character varying(2) NOT NULL,
    des_atn character varying(20)
);


ALTER TABLE localds2.ossr_atn OWNER TO nvoip;

--
-- Name: ossr_car; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_car (
    cde_cic character(5) NOT NULL,
    nme_cic character varying(35)
);


ALTER TABLE localds2.ossr_car OWNER TO nvoip;

--
-- Name: ossr_chg_cat; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_chg_cat (
    cat_chg character varying(3) NOT NULL,
    des_cat_chg character varying(35)
);


ALTER TABLE localds2.ossr_chg_cat OWNER TO nvoip;

--
-- Name: ossr_cir_typ; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_cir_typ (
    typ_cir character varying(3) NOT NULL,
    des_typ_cir character varying(12),
    CONSTRAINT ossr_cir_typ_csn01 CHECK (((typ_cir)::text = ANY ((ARRAY['DS0'::character varying, 'DS1'::character varying, 'DS3'::character varying, 'T1'::character varying, 'NA'::character varying])::text[])))
);


ALTER TABLE localds2.ossr_cir_typ OWNER TO nvoip;

--
-- Name: ossr_cpe; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_cpe (
    idn_cpe character varying(18) NOT NULL,
    idx_adr character varying(30) NOT NULL,
    idn_lne_acs character varying(12),
    idx_fer_loc_srv character varying(15),
    nme_typ_cpe character varying(15) NOT NULL,
    idn_t1 character varying(12),
    nme_mfc_cpe character varying(20),
    nme_mdl_cpe character varying(20),
    typ_vdr_cpe character(1),
    nbr_mdl_cpe character varying(20),
    nme_vdr_cpe character varying(50),
    nme_ctc_vdr_cpe character varying(50),
    tnb_ctc_vdr_cpe character varying(20),
    loc_des_cpe character varying(100),
    nme_bld_cpe character varying(9),
    nbr_flo_cpe character varying(9),
    nbr_rom_cpe character varying(9),
    typ_jck character varying(10),
    ind_pvd_mciw character(1),
    CONSTRAINT ossr_cpe_csn01 CHECK ((ind_pvd_mciw = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_cpe OWNER TO nvoip;

--
-- Name: ossr_cpe_dn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_cpe_dn (
    idn_cpe character varying(18) NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    idn_pfl_srv character varying(14)
);


ALTER TABLE localds2.ossr_cpe_dn OWNER TO nvoip;

--
-- Name: ossr_ctc_tnb; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ctc_tnb (
    idx_nme character varying(12) NOT NULL,
    cat_phn character varying(10) DEFAULT 'Work'::character varying NOT NULL,
    tnb_ctc character(10) NOT NULL,
    nbr_phn_ext character varying(4),
    nbr_pin_pgr character varying(7),
    CONSTRAINT ossr_ctc_tnb_csn01 CHECK ((((tnb_ctc)::bigint > 2000000000) AND ((tnb_ctc)::bigint < '9999999999'::bigint)))
);


ALTER TABLE localds2.ossr_ctc_tnb OWNER TO nvoip;

--
-- Name: ossr_ctx_grp; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ctx_grp (
    idx_ord character varying(13) NOT NULL,
    idn_grp_ctx character(8) NOT NULL,
    nbr_grp_sub_ctx smallint NOT NULL,
    cde_atn_grp_ctx character(1) NOT NULL,
    qty_pst_atdnt smallint,
    qty_dig_sta character(1),
    pfx_acs_loc_sta character(1),
    pfx_acs_pri_sta character(1),
    tnb_bil character(10),
    cde_pic smallint,
    cde_lpic smallint,
    ind_smdr character(1),
    cde_cpb_dia character(1),
    qty_path_acs integer,
    ind_pic_frz character(1),
    CONSTRAINT ossr_ctx_grp_csn01 CHECK ((cde_atn_grp_ctx = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_ctx_grp OWNER TO nvoip;

--
-- Name: ossr_ctx_grp_svf; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ctx_grp_svf (
    idx_ord character varying(13) NOT NULL,
    idn_grp_ctx character(8) NOT NULL,
    nbr_grp_sub_ctx smallint NOT NULL,
    cde_svf_ctx character varying(6) NOT NULL,
    typ_pam_svf_ctx character varying(24) NOT NULL,
    val_pam_svf_ctx character varying(18),
    cde_acn_svf_ctx character(1) NOT NULL
);


ALTER TABLE localds2.ossr_ctx_grp_svf OWNER TO nvoip;

--
-- Name: ossr_dir_adr; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_dir_adr (
    idx_tnb character varying(12) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    idx_adr character varying(30) NOT NULL,
    cde_rol_adr character varying(3) NOT NULL,
    ind_dadl character(1) NOT NULL
);


ALTER TABLE localds2.ossr_dir_adr OWNER TO nvoip;

--
-- Name: ossr_dir_asi_lst; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_dir_asi_lst (
    idx_tnb character varying(12) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    ind_adv_dir character(1),
    typ_tra character varying(2),
    typ_rcd character varying(3) NOT NULL,
    typ_lst character varying(2) NOT NULL,
    tnb_prv character(10),
    idx_dsg_lst character varying(12),
    ind_adr_dir_omt character(1),
    cde_sic character varying(6),
    nme_as_lst_plc character varying(80),
    ind_pst_ltr character(1),
    tnb_ref character(10),
    flg_omt_lst_cus character(1),
    flg_omt_adr_dir character(1),
    ind_lst_bus_rsd character(1),
    ind_lst_rsd_bus character(1),
    tnb_alt character varying(40),
    txt_cll_hrs_aft character varying(45),
    sts_jbs character varying(15) NOT NULL,
    dtx_eff_sts timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    ind_atv_asi_dir character(1) NOT NULL,
    ind_aut_exs character(1),
    flg_ath_agn character(1),
    ind_bil_alt character(1),
    txt_capt character varying(20),
    ind_typ_capt character varying(20),
    ind_chg_carr character(1),
    txt_srf character varying(50),
    idx_pon_cus character varying(20),
    ind_nme_fst_dul character(1),
    nme_lst_fst_dul character varying(50),
    ind_hdr character(1),
    idx_hdr character(2),
    txt_hdr character varying(20),
    cde_hdr character varying(6),
    ind_lvl_indt bigint,
    ind_lvl_indt_new character(1),
    txt_indt character varying(50),
    ind_deg_indt bigint,
    txt_adr_indt character varying(100),
    tnb_indt character(10),
    sts_lvl_ind character(1),
    ind_lst_prof character(1),
    ind_exp character(1),
    flg_cut_hto_cor character(1),
    nbr_act_bil_dir character varying(13),
    idn_subs_dir character varying(35),
    txt_dsg_prof character varying(25),
    dtx_snt timestamp with time zone,
    tnb_lst character(10) NOT NULL,
    typ_rec_pcb character(1),
    cde_ist_lst character(4),
    cde_srv_cls_lne character(3),
    flg_lst_ren character(1),
    typ_rqn character(1),
    sts_rqn character(1),
    ind_exm_tax_dir character(1),
    tnb_nonstd character varying(20),
    cde_subsct_dir character varying(14),
    cde_brk_alp character(1),
    ind_ord_crr character(1),
    nbr_qry_ord integer,
    ind_res_lst character(1),
    ind_bus_lst character(1),
    txt_tnb character varying(50),
    txt_spl character varying(50),
    cde_ali_lec character varying(6),
    ind_omt_tnb character(1),
    ind_ord_voip character(1),
    ind_dadl character(1) NOT NULL,
    CONSTRAINT lst_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn01 CHECK (((typ_tra)::text = ANY ((ARRAY['1'::character varying, '2'::character varying, '3'::character varying, '4'::character varying, '5'::character varying, '6'::character varying, '7'::character varying, '8'::character varying])::text[]))),
    CONSTRAINT ossr_dir_asi_lst_csn03 CHECK (((typ_lst)::text = ANY ((ARRAY['1'::character varying, '2'::character varying, '3'::character varying, '4'::character varying, '5'::character varying, '6'::character varying, '7'::character varying, '8'::character varying, '9'::character varying, '10'::character varying, '11'::character varying, '12'::character varying, '13'::character varying, '14'::character varying, '15'::character varying])::text[]))),
    CONSTRAINT ossr_dir_asi_lst_csn04 CHECK ((ind_adv_dir = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn05 CHECK ((((tnb_prv)::bigint > 2000000000) AND ((tnb_prv)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_dir_asi_lst_csn07 CHECK ((ind_adr_dir_omt = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn08 CHECK ((((tnb_ref)::bigint > 2000000000) AND ((tnb_ref)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_dir_asi_lst_csn09 CHECK ((ind_nme_fst_dul = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn10 CHECK ((flg_omt_lst_cus = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn11 CHECK ((flg_omt_adr_dir = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn12 CHECK ((ind_lst_bus_rsd = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn13 CHECK ((ind_lst_rsd_bus = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn14 CHECK ((ind_atv_asi_dir = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'U'::bpchar, 'Z'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn15 CHECK ((ind_aut_exs = ANY (ARRAY['Y'::bpchar, 'N'::bpchar, 'U'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn16 CHECK ((flg_ath_agn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn17 CHECK ((ind_chg_carr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn18 CHECK ((ind_hdr = ANY (ARRAY['e'::bpchar, 'n'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn19 CHECK ((idx_hdr = ANY (ARRAY['ch'::bpchar, 'ci'::bpchar, 'cs'::bpchar, 'sh'::bpchar, 'sl'::bpchar, 'si'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn20 CHECK ((ind_lvl_indt_new = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn21 CHECK (((ind_deg_indt >= 0) AND (ind_deg_indt <= 7))),
    CONSTRAINT ossr_dir_asi_lst_csn22 CHECK ((((tnb_indt)::bigint > 2000000000) AND ((tnb_indt)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_dir_asi_lst_csn23 CHECK ((ind_lst_prof = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn24 CHECK ((ind_exp = ANY (ARRAY['Y'::bpchar, 'F'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn25 CHECK ((flg_cut_hto_cor = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn28 CHECK ((ind_pst_ltr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn30 CHECK (((ind_lvl_indt >= 0) AND (ind_lvl_indt <= 6))),
    CONSTRAINT ossr_dir_asi_lst_csn31 CHECK ((ind_exm_tax_dir = ANY (ARRAY['F'::bpchar, 'S'::bpchar, 'C'::bpchar, 'M'::bpchar, 'A'::bpchar, 'B'::bpchar, 'K'::bpchar, 'D'::bpchar, 'E'::bpchar, 'G'::bpchar, 'H'::bpchar, 'I'::bpchar, 'J'::bpchar, 'L'::bpchar, 'N'::bpchar, 'P'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn32 CHECK ((sts_rqn = ANY (ARRAY['A'::bpchar, 'B'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn33 CHECK ((typ_rqn = ANY (ARRAY['A'::bpchar, 'B'::bpchar, 'C'::bpchar, 'D'::bpchar, 'E'::bpchar, 'F'::bpchar, 'G'::bpchar, 'H'::bpchar, 'J'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn34 CHECK ((flg_lst_ren = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn36 CHECK ((ind_ord_crr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn37 CHECK ((ind_res_lst = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn38 CHECK ((ind_bus_lst = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn42 CHECK ((cde_srv_cls_lne = ANY (ARRAY['FQ1'::bpchar, 'FQ2'::bpchar, 'FQ3'::bpchar, 'FQ4'::bpchar, 'FQ5'::bpchar, 'FQ6'::bpchar, 'FQ7'::bpchar, 'FQ8'::bpchar, 'FQ9'::bpchar, 'FQA'::bpchar, 'CEN'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_csn43 CHECK ((ind_omt_tnb = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_dir_asi_lst OWNER TO nvoip;

--
-- Name: ossr_dir_asi_lst_archive; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_dir_asi_lst_archive (
    idx_tnb character varying(12) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idx_pst_ltr character varying(25),
    qty_dlv_dir_mul bigint,
    qty_wpg_ann bigint,
    qty_ypg_ann bigint,
    qty_wpg_init bigint,
    ind_cct_dlv_new character(1),
    qty_dir_btb bigint,
    qty_ypg_init integer,
    txt_typ_lst character varying(3),
    ind_atv_asi_dir character(1) NOT NULL,
    idx_com character varying(4),
    ind_gov character(1),
    typ_acn character(1),
    flg_lst_for character(1),
    cde_prd_wpg character varying(3)
)
WITH (fillfactor='80');


ALTER TABLE localds2.ossr_dir_asi_lst_archive OWNER TO nvoip;

--
-- Name: ossr_dir_asi_lst_jrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_dir_asi_lst_jrn (
    idx_ord character varying(13) NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    tnb_new_old character(1),
    sts_jbs character varying(15),
    dtx_eff_sts timestamp with time zone,
    dtx_snt timestamp with time zone,
    tnb character varying(12),
    ind_dadl character(1) NOT NULL,
    CONSTRAINT ossr_dir_asi_lst_jrn_csn01 CHECK ((tnb_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar]))),
    CONSTRAINT ossr_dir_asi_lst_jrn_csn02 CHECK ((((tnb)::bigint > 2000000000) AND ((tnb)::bigint < '9999999999'::bigint)))
);


ALTER TABLE localds2.ossr_dir_asi_lst_jrn OWNER TO nvoip;

--
-- Name: ossr_dir_nme; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_dir_nme (
    cde_ali character varying(3) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    idx_nme character varying(12) NOT NULL,
    cde_rol_nme character varying(3) NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    ind_dadl character(1) NOT NULL
);


ALTER TABLE localds2.ossr_dir_nme OWNER TO nvoip;

--
-- Name: ossr_dlv_adr; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_dlv_adr (
    idx_ord character varying(13) NOT NULL,
    ind_adr_dlv_old_new character(1) NOT NULL,
    idx_adr_dlv integer NOT NULL,
    typ_adr_dlv character varying(2) NOT NULL,
    cde_atn_adr_dlv character(1) NOT NULL,
    idx_nme character varying(12) NOT NULL,
    idx_adr character varying(30) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    qty_dlv_cct_new smallint,
    qty_dlv_ann smallint,
    CONSTRAINT ossr_dlv_adr_cs01 CHECK ((cde_atn_adr_dlv = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar]))),
    CONSTRAINT ossr_dlv_adr_cs02 CHECK (((typ_adr_dlv)::text = ANY ((ARRAY['W'::character varying, 'Y'::character varying, 'BB'::character varying, 'O'::character varying])::text[]))),
    CONSTRAINT ossr_dlv_adr_cs03 CHECK ((ind_adr_dlv_old_new = ANY (ARRAY['O'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_dlv_adr OWNER TO nvoip;

--
-- Name: ossr_ei_rcd_vew; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ei_rcd_vew (
    nbr_ord character varying(13),
    idx_org_ord character(1),
    idn_pvd_srv smallint,
    tnb character(10),
    cde_ali character varying(3),
    idx_dir character varying(6),
    idx_lec character varying(3),
    dtx_tsk_ei timestamp with time zone,
    nbr_seq_ei character varying(12),
    ind_drc character(1),
    ind_typ_rsp character(3),
    ind_typ_rcd character(1),
    txt_rcd text
);


ALTER TABLE localds2.ossr_ei_rcd_vew OWNER TO nvoip;

--
-- Name: ossr_err_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_err_cde (
    cde_err character varying(10) NOT NULL,
    nme_src_err character varying(18) NOT NULL,
    des_err character varying(20)
);


ALTER TABLE localds2.ossr_err_cde OWNER TO nvoip;

--
-- Name: ossr_hdg_pge_yel; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_hdg_pge_yel (
    idx_tnb character varying(12) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    cde_hdg_pge_yel character varying(8),
    txt_hdg_pge_yel character varying(200),
    ind_dadl character(1) NOT NULL
);


ALTER TABLE localds2.ossr_hdg_pge_yel OWNER TO nvoip;

--
-- Name: ossr_hg_trm; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_hg_trm (
    idx_ord character varying(13) NOT NULL,
    tnb_plt character(10) NOT NULL,
    nbr_trm character(10) NOT NULL,
    idn_lne_acs character varying(12) NOT NULL,
    cde_atn_trm character(1) NOT NULL,
    nbr_seq_hun integer NOT NULL,
    typ_nbr_trm character(1) NOT NULL,
    tnb_plt_old character(10),
    tnb_svc_nght character varying(11),
    cde_atv_sup_htrm character(1),
    cde_atv_dta_htrm character varying(3),
    CONSTRAINT ossr_hg_trm_csn01 CHECK ((typ_nbr_trm = ANY (ARRAY['T'::bpchar, 'I'::bpchar]))),
    CONSTRAINT ossr_hg_trm_csn02 CHECK ((cde_atn_trm = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_hg_trm_csn03 CHECK ((((tnb_plt_old)::bigint > 2000000000) AND ((tnb_plt_old)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_hg_trm_csn04 CHECK ((cde_atv_sup_htrm = ANY (ARRAY['A'::bpchar, 'N'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar])))
);


ALTER TABLE localds2.ossr_hg_trm OWNER TO nvoip;

--
-- Name: ossr_hun_grp; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_hun_grp (
    idx_ord character varying(13) NOT NULL,
    tnb_plt character(10) NOT NULL,
    des_grp character varying(25),
    cde_atn_grp_hun character(1) NOT NULL,
    typ_hun character varying(3) NOT NULL,
    typ_grp_hun character(3) NOT NULL,
    qty_grp_hun integer NOT NULL,
    idx_grp character varying(10),
    tnb_lod character varying(11),
    cde_atv_sup_hun character(1),
    cde_atv_dta_hun character varying(3),
    CONSTRAINT ossr_hun_grp_csn02 CHECK (((typ_hun)::text = ANY ((ARRAY['CIR'::character varying, 'ROT'::character varying, 'UCD'::character varying, 'SEQ'::character varying, 'ACD'::character varying])::text[]))),
    CONSTRAINT ossr_hun_grp_csn03 CHECK ((typ_grp_hun = ANY (ARRAY['MLH'::bpchar, 'DNH'::bpchar]))),
    CONSTRAINT ossr_hun_grp_csn04 CHECK ((cde_atn_grp_hun = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_hun_grp_csn05 CHECK ((cde_atv_sup_hun = ANY (ARRAY['A'::bpchar, 'N'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar])))
);


ALTER TABLE localds2.ossr_hun_grp OWNER TO nvoip;

--
-- Name: ossr_iasa_process; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_iasa_process (
    idx_ord character varying(13) NOT NULL,
    nbr_sup_tsk_prv_adp character varying(30),
    typ_acc character varying(2),
    cde_clli_swt_srv character varying(11),
    idn_rslr character varying(5),
    tnb character(10),
    cde_atn_tnb character(1),
    cde_atn_sup_tnb character(1),
    nbr_tkg character varying(11),
    cde_pic character(5),
    cde_lpic character(5),
    nbr_tkg_911 character varying(11),
    ind_drc_cll character(1),
    flg_chc_iasa character(1),
    flg_ld_dom_otb_blk character(1),
    flg_ld_interlata_otb_blk character(1),
    flg_ld_intralata_otb_blk character(1),
    flg_local_otb_blk character(1),
    flg_ld_intnl_otb_blk character(1),
    flg_asi_dir_blk character(1),
    flg_otb_all_blk character(1),
    flg_inb_all_blk character(1),
    flg_911_but_all_blk character(1),
    flg_svc_911_blk character(1),
    idx_tri bigint,
    tnb_split_npa character(10),
    nbr_nme_rte_off_npa character varying(14),
    key_tkg_psu_npa character varying(12),
    nbr_tkg_npa character varying(11)
)
WITH (fillfactor='80');


ALTER TABLE localds2.ossr_iasa_process OWNER TO nvoip;

--
-- Name: ossr_inflight_ords_conv; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_inflight_ords_conv (
    idx_ord character varying(13),
    nbr_ord character varying(13),
    idx_spn_ord character varying(3),
    txt_col1 character varying(30),
    txt_col2 character varying(30),
    txt_col3 character varying(30),
    txt_col4 character varying(30),
    txt_col5 character varying(100),
    txt_col6 character varying(100),
    txt_col7 character varying(100),
    txt_col8 character varying(100),
    txt_col9 character varying(100),
    txt_col10 character varying(100)
);


ALTER TABLE localds2.ossr_inflight_ords_conv OWNER TO nvoip;

--
-- Name: ossr_jbs; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_jbs (
    cde_jbs character(6) NOT NULL,
    des_jbs character varying(25),
    CONSTRAINT ossr_jbs_csn01 CHECK ((cde_jbs = ANY (ARRAY['OT35E1'::bpchar, 'OT35E2'::bpchar, 'OT35E3'::bpchar, 'OT35E4'::bpchar, 'OTCOMP'::bpchar, 'OTEAGN'::bpchar])))
);


ALTER TABLE localds2.ossr_jbs OWNER TO nvoip;

--
-- Name: ossr_kar; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_kar (
    idx_tnb character varying(12) NOT NULL,
    cde_cic character(5) NOT NULL,
    ind_jur character(1) NOT NULL,
    ind_pic_rsc_frz character(1) NOT NULL,
    idx_nme character varying(12) NOT NULL,
    ind_los_wng character(1) NOT NULL,
    tnb_wrk character(10) NOT NULL,
    ind_pub character(1),
    idx_spt_imp character(1),
    sts_jbs character varying(15) NOT NULL,
    dtx_eff_sts timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    ind_org_req_pic character(1),
    amt_cha_chg_pic real,
    ind_cha_chg_pic character(1) NOT NULL,
    dtx_snt timestamp with time zone,
    dtx_eff_kar timestamp with time zone,
    cde_atn character(1),
    cde_ste character(2),
    idx_rrn character(10),
    ind_ord_voip character(1),
    CONSTRAINT kar_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_kar_csn01 CHECK ((ind_pic_rsc_frz = ANY (ARRAY['0'::bpchar, '1'::bpchar]))),
    CONSTRAINT ossr_kar_csn02 CHECK ((ind_jur = ANY (ARRAY['A'::bpchar, 'B'::bpchar, 'E'::bpchar]))),
    CONSTRAINT ossr_kar_csn03 CHECK ((ind_los_wng = ANY (ARRAY['L'::bpchar, 'W'::bpchar]))),
    CONSTRAINT ossr_kar_csn04 CHECK ((((tnb_wrk)::bigint > 2000000000) AND ((tnb_wrk)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_kar_csn05 CHECK ((ind_pub = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '5'::bpchar, NULL::bpchar]))),
    CONSTRAINT ossr_kar_csn06 CHECK ((idx_spt_imp = ANY (ARRAY['I'::bpchar, 'E'::bpchar]))),
    CONSTRAINT ossr_kar_csn07 CHECK ((ind_org_req_pic = ANY (ARRAY['1'::bpchar, '2'::bpchar]))),
    CONSTRAINT ossr_kar_csn08 CHECK ((ind_cha_chg_pic = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_kar_csn09 CHECK ((cde_atn = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'D'::bpchar, 'I'::bpchar])))
);


ALTER TABLE localds2.ossr_kar OWNER TO nvoip;

--
-- Name: ossr_kar_jrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_kar_jrn (
    idx_ord character varying(13) NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    ind_jur character(1) NOT NULL,
    ind_los_wng character(1) NOT NULL,
    tnb character varying(12),
    sts_jbs character varying(15),
    tnb_new_old character(1),
    dtx_eff_sts timestamp with time zone,
    dtx_snt timestamp with time zone,
    CONSTRAINT ossr_kar_jrn_csn01 CHECK ((ind_jur = ANY (ARRAY['A'::bpchar, 'B'::bpchar, 'E'::bpchar]))),
    CONSTRAINT ossr_kar_jrn_csn02 CHECK ((ind_los_wng = ANY (ARRAY['L'::bpchar, 'W'::bpchar]))),
    CONSTRAINT ossr_kar_jrn_csn03 CHECK ((((tnb)::bigint > 2000000000) AND ((tnb)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_kar_jrn_csn04 CHECK ((tnb_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar])))
);


ALTER TABLE localds2.ossr_kar_jrn OWNER TO nvoip;

--
-- Name: ossr_lec; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lec (
    idx_lec character varying(3) NOT NULL,
    nme_lec character varying(20)
);


ALTER TABLE localds2.ossr_lec OWNER TO nvoip;

--
-- Name: ossr_lid; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lid (
    idx_tnb character varying(12) NOT NULL,
    cde_cls_cus character(3),
    idx_adr character varying(30),
    cde_bns character(1),
    key_pin character(1),
    cde_atn character(1),
    nbr_pin character(4),
    cde_atn_pin character(1),
    typ_cds character(1),
    qty_cds numeric(38,0),
    ind_spl character(1),
    ind_sty_cds character(1),
    dtx_chg_eff timestamp with time zone,
    sts_jbs character varying(15) NOT NULL,
    dtx_eff_sts timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    flg_lscnb character(1),
    ind_bil_clt_org character(1),
    ind_bil_thr_org character(1),
    ind_cll_lcl_org character(1),
    ind_cds_crd_org character(1),
    ind_daa_fre_org character(1),
    ind_bns_spl_org character(1),
    ind_paid_snt_org character(1),
    ind_intc_org character(1),
    idn_intc_org character(4),
    idn_inlc_org character(4),
    ind_inlc_org character(1),
    typ_atn_nme_cll character(1),
    ind_pve_nme_cll character(1),
    nme_stng_gni character varying(15),
    ind_lag_frg character(2),
    dtx_snt timestamp with time zone,
    cat_eqp_svc character varying(2),
    CONSTRAINT ossr_lid_csn01 CHECK ((cde_cls_cus = ANY (ARRAY['RES'::bpchar, 'BUS'::bpchar, 'PBC'::bpchar, 'PBN'::bpchar, 'SPC'::bpchar, 'SPN'::bpchar]))),
    CONSTRAINT ossr_lid_csn03 CHECK ((key_pin = ANY (ARRAY['0'::bpchar, '1'::bpchar, '2'::bpchar]))),
    CONSTRAINT ossr_lid_csn04 CHECK ((cde_bns = ANY (ARRAY['A'::bpchar, 'B'::bpchar, 'C'::bpchar, 'D'::bpchar]))),
    CONSTRAINT ossr_lid_csn06 CHECK ((cde_atn = ANY (ARRAY['I'::bpchar, 'C'::bpchar, 'D'::bpchar]))),
    CONSTRAINT ossr_lid_csn07 CHECK ((flg_lscnb = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_lid_csn09 CHECK ((ind_intc_org = ANY (ARRAY['I'::bpchar, 'D'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_lid_csn10 CHECK ((ind_inlc_org = ANY (ARRAY['I'::bpchar, 'D'::bpchar, 'N'::bpchar])))
)
WITH (fillfactor='75');


ALTER TABLE localds2.ossr_lid OWNER TO nvoip;

--
-- Name: ossr_lid_911_jrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lid_911_jrn (
    idx_ord character varying(13) NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    tnb character varying(12),
    tnb_new_old character(1),
    sts_jbs_lid character varying(15),
    dtx_eff_sts_lid timestamp with time zone,
    dtx_snt_lid timestamp with time zone,
    sts_jbs_911 character varying(15),
    dtx_eff_sts_911 timestamp with time zone,
    dtx_snt_911 timestamp with time zone,
    idn_cir character varying(36),
    dtx_foc_ilec timestamp with time zone,
    nbr_ord_rlt_ilec character varying(17),
    idn_cir_lec character varying(53),
    idn_lne_acs character varying(12),
    idx_swt_srv character varying(5),
    cde_clli_swt_srv character varying(11),
    idx_por_swt character varying(36),
    cde_cfa character varying(42),
    loc_actl character varying(11),
    cde_nci character varying(12),
    cde_ncc character varying(4),
    cde_nci_scd character varying(12),
    dtx_due_dre_lsr timestamp with time zone,
    dtx_foc_lnp_ilec timestamp with time zone,
    idn_cir_wcom character varying(17),
    cde_atn_dta_tnb character varying(3),
    cde_atv_dta_lne character varying(3),
    idx_par_chn character varying(5),
    nbr_cbl character varying(5),
    cde_sts_ntw_lne character varying(25),
    cde_sts_lne_prov character varying(25),
    CONSTRAINT ossr_lid_911_opr_srv_jrn_csn01 CHECK ((((tnb)::bigint > 2000000000) AND ((tnb)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_lid_911_opr_srv_jrn_csn02 CHECK ((tnb_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar])))
);


ALTER TABLE localds2.ossr_lid_911_jrn OWNER TO nvoip;

--
-- Name: ossr_lid_nme; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lid_nme (
    idx_nme character varying(12) NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    cde_rol_nme character varying(3) NOT NULL
);


ALTER TABLE localds2.ossr_lid_nme OWNER TO nvoip;

--
-- Name: ossr_lne_svf_pam; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lne_svf_pam (
    nme_svf character varying(25) NOT NULL,
    idn_lne_acs character varying(12) NOT NULL,
    typ_pam character varying(25) NOT NULL,
    val_svf_pam character varying(18) NOT NULL
);


ALTER TABLE localds2.ossr_lne_svf_pam OWNER TO nvoip;

--
-- Name: ossr_lne_typ; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lne_typ (
    cde_typ_lne character varying(3) NOT NULL,
    des_typ_lne character varying(25)
);


ALTER TABLE localds2.ossr_lne_typ OWNER TO nvoip;

--
-- Name: ossr_lsr_inf; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lsr_inf (
    idx_ord character varying(13) NOT NULL,
    tnb_bil_lec character(10) NOT NULL,
    idx_adr_sav character varying(30) NOT NULL,
    txt_rmk_lsr character varying(160),
    ind_prj character(1),
    idn_prj character varying(16),
    dtx_foc_lnp_ilec timestamp with time zone,
    ind_ord_voip character(1),
    ind_lsr_spl character(1) NOT NULL,
    idx_nme character varying(12),
    typ_mig_prtl character(1),
    ind_chg_prtl character(1),
    ind_chc character(1),
    ind_trgr_dig_ten character(1),
    cde_atv_sup_lsr character(1),
    cde_atv_dta_lsr character varying(3),
    CONSTRAINT cde_atv_sup_lsr_ck CHECK ((cde_atv_sup_lsr = ANY (ARRAY['A'::bpchar, 'X'::bpchar]))),
    CONSTRAINT ind_chc_check CHECK ((ind_chc = ANY (ARRAY['Y'::bpchar, 'A'::bpchar, 'B'::bpchar]))),
    CONSTRAINT ind_trgr_dig_ten_check CHECK ((ind_trgr_dig_ten = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT lsr_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT lsr_inf_check CHECK ((typ_mig_prtl = ANY (ARRAY['A'::bpchar, 'B'::bpchar, 'C'::bpchar, 'D'::bpchar]))),
    CONSTRAINT ossr_lsr_inf_check CHECK ((ind_chg_prtl = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_lsr_inf OWNER TO nvoip;

--
-- Name: ossr_lsr_jrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lsr_jrn (
    idx_ord character varying(13) NOT NULL,
    idn_fac_acs character varying(12) NOT NULL,
    idn_cir character varying(10) NOT NULL,
    tnb character(10) NOT NULL,
    key_tkg_psu character varying(12),
    idn_cir_lec character varying(53),
    nbr_ord_rlt_ilec character varying(17),
    dtx_foc_ilec timestamp with time zone,
    dtx_foc_lnp_ilec timestamp with time zone,
    CONSTRAINT ossr_lsr_jrn_csn01 CHECK ((((tnb)::bigint > 2000000000) AND ((tnb)::bigint < '9999999999'::bigint)))
);


ALTER TABLE localds2.ossr_lsr_jrn OWNER TO nvoip;

--
-- Name: ossr_lst_txt_typ; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_lst_txt_typ (
    idx_tnb character varying(12) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idn_lst_seq smallint NOT NULL,
    typ_txt_lst character varying(3),
    phr_lst smallint,
    txt_lst character varying(250),
    ind_dadl character(1) NOT NULL,
    CONSTRAINT ossr_lst_txt_typ_cs01 CHECK ((phr_lst = ANY (ARRAY['1'::smallint, '2'::smallint, '3'::smallint, '4'::smallint, '5'::smallint, '6'::smallint, '7'::smallint, '8'::smallint, '9'::smallint, '10'::smallint, '11'::smallint])))
);


ALTER TABLE localds2.ossr_lst_txt_typ OWNER TO nvoip;

--
-- Name: ossr_nme; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_nme (
    idx_nme character varying(12) NOT NULL,
    nme_las character varying(50) NOT NULL,
    nme_fst character varying(35),
    nme_ini_mid character(1),
    nme_lne character varying(12),
    nme_ttl character varying(12),
    nme_two_ttl character varying(12),
    nme_com_ctc character varying(50),
    nme_nck character varying(20),
    adr_eml character varying(50)
);


ALTER TABLE localds2.ossr_nme OWNER TO nvoip;

--
-- Name: ossr_nme_rol; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_nme_rol (
    cde_rol_nme character varying(3) NOT NULL,
    des_rol_nme character varying(25)
);


ALTER TABLE localds2.ossr_nme_rol OWNER TO nvoip;

--
-- Name: ossr_opr_srv_temp; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_opr_srv_temp (
    idx_tnb character varying(12) NOT NULL,
    idx_nme character varying(12) NOT NULL,
    idx_adr character varying(30) NOT NULL,
    cde_car_org character varying(4),
    cde_car character varying(4),
    cde_rqd_vvf character varying(3),
    nbr_acn character varying(10),
    typ_swt character(1),
    idx_cus character varying(13),
    cde_pln_rat character varying(2),
    flg_alw_ovr character(1),
    flg_alw_cof character(1),
    ind_stn_dmt_bil character(8),
    ind_pes_dmt_bil character(8),
    ind_stn_ina_bil character(8),
    ind_pes_ina_bil character(8),
    ind_stn_809_bil character(8),
    ind_pes_809_bil character(8),
    txt_ina_dia character varying(15),
    txt_ist_ata_dia character varying(15),
    txt_ist_800_dia character varying(15),
    txt_ist_lcl_dia character varying(15),
    txt_ist_ops_dia character varying(15),
    tnb_rfd character(10),
    tnb_rpr character(10),
    tnb_srv_cus character(10),
    tnb_bcd_psa character(10) NOT NULL,
    tnb_plc_lcl character(10) NOT NULL,
    tnb_fir_lcl character(10) NOT NULL,
    tnb_she_lcl character(10),
    tnb_plc_ste character(10),
    tnb_emg_oth character(10),
    ind_atv_ops character(1) NOT NULL,
    sts_jbs character varying(15) NOT NULL,
    dtx_eff_sts timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    dtx_snt timestamp with time zone,
    CONSTRAINT ossr_opr_srv_csn01 CHECK ((ind_atv_ops = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'M'::bpchar]))),
    CONSTRAINT ossr_opr_srv_csn02 CHECK ((flg_alw_ovr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_opr_srv_csn03 CHECK ((flg_alw_cof = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_opr_srv_csn10 CHECK ((((tnb_rfd)::bigint > 2000000000) AND ((tnb_rfd)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn11 CHECK ((((tnb_rpr)::bigint > 2000000000) AND ((tnb_rpr)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn12 CHECK ((((tnb_srv_cus)::bigint > 2000000000) AND ((tnb_srv_cus)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn13 CHECK ((((tnb_bcd_psa)::bigint > 2000000000) AND ((tnb_bcd_psa)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn14 CHECK ((((tnb_plc_lcl)::bigint > 2000000000) AND ((tnb_plc_lcl)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn15 CHECK ((((tnb_fir_lcl)::bigint > 2000000000) AND ((tnb_fir_lcl)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn16 CHECK ((((tnb_she_lcl)::bigint > 2000000000) AND ((tnb_she_lcl)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn17 CHECK ((((tnb_plc_ste)::bigint > 2000000000) AND ((tnb_plc_ste)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_opr_srv_csn18 CHECK ((((tnb_emg_oth)::bigint > 2000000000) AND ((tnb_emg_oth)::bigint < '9999999999'::bigint)))
);


ALTER TABLE localds2.ossr_opr_srv_temp OWNER TO nvoip;

--
-- Name: ossr_ord; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ord (
    idx_ord character varying(13) NOT NULL,
    idx_org_ord character(1) DEFAULT '2'::bpchar NOT NULL,
    nbr_ord_rlt character varying(20),
    idx_spn_ord character varying(3) DEFAULT '0'::character varying NOT NULL,
    cde_sts_ord character varying(10) NOT NULL,
    idx_fer_loc_srv character varying(15) NOT NULL,
    ind_atn_ord character(1) NOT NULL,
    cde_lob character varying(3) NOT NULL,
    ind_chc character(1) DEFAULT 'Y'::bpchar,
    nbr_ord character varying(13) NOT NULL,
    typ_ord character varying(3) NOT NULL,
    typ_cus character(1),
    cat_chg character varying(3),
    dtx_due_dre_cus timestamp with time zone,
    flg_exp_ord character(1) DEFAULT 'N'::bpchar NOT NULL,
    flg_rqd_han_man character(1) DEFAULT 'Y'::bpchar,
    ind_trn_ord character(1) DEFAULT 'Y'::bpchar,
    idn_itm_wrk_ext character varying(20),
    idx_cus_ixp character varying(13),
    qty_t1 integer,
    qty_tkg integer,
    dtx_upd_las timestamp with time zone NOT NULL,
    sys_upd_las_idn character(1),
    typ_sal character varying(3),
    ind_exp_lsr character(1),
    nbr_acn_bil character varying(13),
    idn_pvd_srv character varying(4) NOT NULL,
    nbr_ocn character varying(4) NOT NULL,
    idn_ord_pvn_ldn character varying(8),
    typ_bri character(3),
    qty_lne_bri smallint,
    ind_tnb character(1),
    ind_ont_cus character(1) NOT NULL,
    txt_cat_spn character varying(256),
    idn_lsp character varying(4),
    cde_loc_rev character varying(3),
    idn_pvd_srv_los character varying(4),
    nbr_vcm character(10),
    cde_own_swt character(1),
    nbr_sdm integer,
    idx_cus_cis character varying(22),
    idx_adr_cis character varying(22),
    tmx_cut_hot character(4),
    des_rea_exp_lsr character varying(80),
    idn_rslr character varying(5),
    idx_cus_rslr character varying(22),
    dtx_met_vnd timestamp with time zone,
    zne_tmx_cddd character varying(3),
    idn_pvd_srv_gan character varying(4),
    ind_lsr character(2),
    typ_acc character varying(2),
    dtx_foc_pvn timestamp with time zone,
    ind_mig character varying(3),
    idn_pvd_srv_dl character varying(4),
    ind_mov_por character(1),
    dtx_foc_wsp timestamp with time zone,
    nbr_cfm_app character varying(10),
    cde_cty_sls_tcom character varying(3),
    cde_icsc character varying(4),
    nbr_sup_tsk_prv_adp character varying(30),
    ind_cfa_reuse character(1),
    idx_cntr_oe character varying(3),
    idx_cntr_srv_prov character varying(14),
    nbr_rel character varying(5),
    ind_fac_reuse character(1),
    idn_pvd_srv_lup character varying(4),
    idx_wrld_one character varying(9),
    cde_loc_rev_int character varying(3),
    typ_prd_sub character varying(10),
    typ_sdm character varying(2),
    typ_trnspt character varying(2),
    nbr_sup_tsk_prv_t1 character varying(30),
    nbr_sup_tsk_prv_line character varying(30),
    nbr_sup_tsk_prv_chn_trnk character varying(30),
    ind_cfa_chg character(1),
    cls_ord character varying(10),
    ind_int_ext character varying(10),
    ind_svc_site character(1),
    ind_act_por character(1),
    ind_sdi character(1),
    flg_chc_iasa character(1),
    txt_dtx_due_dre_cus character varying(14),
    flg_por_smpl character(1),
    txt_rgn_npac character varying(20),
    gch_id character varying(16),
    svc_inst_id character varying(64),
    CONSTRAINT chk_ossr_ord_flg_por_smpl CHECK ((flg_por_smpl = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn02 CHECK ((flg_exp_ord = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn03 CHECK ((ind_atn_ord = ANY (ARRAY['N'::bpchar, 'C'::bpchar, 'D'::bpchar, 'I'::bpchar, 'J'::bpchar]))),
    CONSTRAINT ossr_ord_csn04 CHECK ((flg_rqd_han_man = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn05 CHECK ((idx_org_ord = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '6'::bpchar, 'E'::bpchar, 'C'::bpchar]))),
    CONSTRAINT ossr_ord_csn06 CHECK ((typ_cus = ANY (ARRAY['B'::bpchar, 'R'::bpchar]))),
    CONSTRAINT ossr_ord_csn07 CHECK ((ind_trn_ord = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn09 CHECK ((ind_chc = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn10 CHECK ((sys_upd_las_idn = ANY (ARRAY['I'::bpchar, 'T'::bpchar, 'W'::bpchar, 'E'::bpchar, 'A'::bpchar, 'S'::bpchar, 'X'::bpchar, 'P'::bpchar, 'L'::bpchar]))),
    CONSTRAINT ossr_ord_csn11 CHECK (((typ_sal)::text = ANY ((ARRAY['CNV'::character varying, 'ISP'::character varying, 'SLS'::character varying, 'ILC'::character varying])::text[]))),
    CONSTRAINT ossr_ord_csn13 CHECK ((ind_exp_lsr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn14 CHECK (((typ_ord)::text = ANY ((ARRAY['LOC'::character varying, 'LUP'::character varying, 'LT1'::character varying, 'LK1'::character varying, 'PRI'::character varying, 'BRI'::character varying, 'CTX'::character varying, 'SSI'::character varying, 'STG'::character varying, 'LL1'::character varying, 'VBL'::character varying, 'VRI'::character varying])::text[]))),
    CONSTRAINT ossr_ord_csn15 CHECK (((cde_lob)::text = ANY ((ARRAY['WLS'::character varying, 'NTL'::character varying, 'CMR'::character varying, 'GLB'::character varying, 'AGT'::character varying, 'RES'::character varying, 'CAP'::character varying, 'MM'::character varying, 'CWE'::character varying, 'CEA'::character varying, 'GED'::character varying, 'SYS'::character varying, 'ISC'::character varying, 'VZI'::character varying, 'VZU'::character varying, 'PRM'::character varying, 'MMT'::character varying, 'GOV'::character varying, 'CAT'::character varying, 'INR'::character varying, 'USE'::character varying, 'INE'::character varying])::text[]))),
    CONSTRAINT ossr_ord_csn16 CHECK ((ind_tnb = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn18 CHECK ((cde_own_swt = ANY (ARRAY['B'::bpchar, 'M'::bpchar, 'W'::bpchar, 'I'::bpchar]))),
    CONSTRAINT ossr_ord_csn19 CHECK ((ind_mov_por = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn20 CHECK ((ind_cfa_reuse = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn22 CHECK ((ind_fac_reuse = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_ord_csn23 CHECK (((typ_prd_sub)::text = ANY ((ARRAY['LINE'::character varying, 'TRUNK'::character varying, 'IPCOMM'::character varying])::text[]))),
    CONSTRAINT ossr_ord_csn24 CHECK (((typ_sdm)::text = ANY ((ARRAY['01'::character varying, '02'::character varying, '03'::character varying, '04'::character varying, '05'::character varying])::text[]))),
    CONSTRAINT ossr_ord_csn25 CHECK (((typ_trnspt)::text = ANY ((ARRAY['01'::character varying, '02'::character varying, '03'::character varying, '04'::character varying, '05'::character varying, '06'::character varying, '07'::character varying, '08'::character varying])::text[]))),
    CONSTRAINT ossr_ord_csn26 CHECK ((ind_svc_site = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_ord_csn27 CHECK ((ind_act_por = ANY (ARRAY['A'::bpchar, 'S'::bpchar, 'I'::bpchar, 'O'::bpchar]))),
    CONSTRAINT ossr_ord_csn28 CHECK ((ind_sdi = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_ord_csn29 CHECK ((flg_chc_iasa = ANY (ARRAY['N'::bpchar, 'Y'::bpchar])))
);


ALTER TABLE localds2.ossr_ord OWNER TO nvoip;

--
-- Name: ossr_ord_rep; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ord_rep (
    idx_nme character varying(12) NOT NULL,
    cde_rol_nme character varying(3) NOT NULL,
    idx_ord character varying(13) NOT NULL
);


ALTER TABLE localds2.ossr_ord_rep OWNER TO nvoip;

--
-- Name: ossr_ord_sts; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_ord_sts (
    cde_sts_ord character varying(10) NOT NULL,
    des_sts_ord character varying(25)
);


ALTER TABLE localds2.ossr_ord_sts OWNER TO nvoip;

--
-- Name: ossr_pam; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_pam (
    typ_pam character varying(25) NOT NULL,
    des_pam character varying(35)
);


ALTER TABLE localds2.ossr_pam OWNER TO nvoip;

--
-- Name: ossr_phn_cat; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_phn_cat (
    cat_phn character varying(10) DEFAULT 'Work'::character varying NOT NULL
);


ALTER TABLE localds2.ossr_phn_cat OWNER TO nvoip;

--
-- Name: ossr_phy_srv_lcn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_phy_srv_lcn (
    idx_fer_loc_srv character varying(15) NOT NULL,
    idn_clli_svco_ilec character varying(8),
    idx_adr_gni character varying(30) NOT NULL,
    idx_adr_sag character varying(30),
    des_pnt_dmc character varying(300),
    idn_col character varying(4),
    cde_clli_col_acs character varying(11),
    cde_bld_col_acs character varying(4),
    cde_clli_col_ubl character varying(11),
    cde_bld_col_ubl character varying(4),
    nme_cny_psap character varying(60),
    nbr_rte_psap character varying(20),
    cde_rate_cen character varying(10),
    cde_rate_cen_ste character(2),
    tnb_rep_lec character(10),
    nme_ocn_lec character varying(50),
    nbr_ocn_lec character varying(4),
    cde_site_bld character varying(4),
    nme_agn_psap character varying(120),
    idx_psap integer,
    cde_cny_fips_geo character varying(5),
    nme_cny_geo character varying(50),
    ind_ord_voip character(1),
    CONSTRAINT ossr_phy_srv_lcn_csn01 CHECK ((((tnb_rep_lec)::bigint > 2000000000) AND ((tnb_rep_lec)::bigint < '9999999999'::bigint))),
    CONSTRAINT phyind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_phy_srv_lcn OWNER TO nvoip;

--
-- Name: ossr_rmk_dira_drl_archive; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_rmk_dira_drl_archive (
    idx_tnb character varying(12) NOT NULL,
    cde_ali character varying(3) NOT NULL,
    idx_dir character varying(6) NOT NULL,
    txt_rmk_dira_drl character varying(200)
);


ALTER TABLE localds2.ossr_rmk_dira_drl_archive OWNER TO nvoip;

--
-- Name: ossr_rsc; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_rsc (
    cde_rsc_tol character varying(5) NOT NULL,
    des_rsc_tol character varying(30)
);


ALTER TABLE localds2.ossr_rsc OWNER TO nvoip;

--
-- Name: ossr_spn_cat; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_spn_cat (
    cat_spn character varying(2) NOT NULL,
    des_cat_spn character varying(25),
    CONSTRAINT ossr_spn_cat_csn01 CHECK (((cat_spn)::text = ANY ((ARRAY['1'::character varying, '2'::character varying, '3'::character varying, '4'::character varying])::text[])))
);


ALTER TABLE localds2.ossr_spn_cat OWNER TO nvoip;

--
-- Name: ossr_svf; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_svf (
    nme_svf character varying(25) NOT NULL,
    des_svf character varying(50)
);


ALTER TABLE localds2.ossr_svf OWNER TO nvoip;

--
-- Name: ossr_svf_pam; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_svf_pam (
    typ_pam character varying(25) NOT NULL,
    nme_svf character varying(25) NOT NULL
);


ALTER TABLE localds2.ossr_svf_pam OWNER TO nvoip;

--
-- Name: ossr_t1; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_t1 (
    idn_t1 character varying(12) NOT NULL,
    typ_fam character varying(3),
    idn_cir_t1 character varying(32),
    cde_lne character varying(4),
    ind_unt_srv_chn character(1) NOT NULL,
    ind_bnk_chn character(1) NOT NULL,
    cde_atv_t1 character(1) NOT NULL,
    typ_jck character varying(10),
    idn_eqp_ofc character varying(36),
    nbr_cas_rte integer,
    key_t1_psu character varying(12) NOT NULL,
    ind_lnd character(1) DEFAULT 'N'::bpchar,
    loc_actl character varying(11),
    cde_ncc character varying(4),
    cde_nci character varying(12),
    cde_nci_scd character varying(12),
    idn_cir_lec character varying(53),
    cde_cfa character varying(42),
    idx_spe_asm character varying(20),
    cde_atv_sup_t1 character(1),
    cde_atv_dta_t1 character varying(3),
    ind_dmc_extd character(1),
    cde_tsp character varying(12),
    idx_ord character varying(13),
    CONSTRAINT ossr_t1_csn01 CHECK (((typ_fam)::text = ANY ((ARRAY['SF'::character varying, 'ESF'::character varying])::text[]))),
    CONSTRAINT ossr_t1_csn02 CHECK (((cde_lne)::text = ANY ((ARRAY['AMI'::character varying, 'B8ZS'::character varying])::text[]))),
    CONSTRAINT ossr_t1_csn03 CHECK ((ind_unt_srv_chn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_t1_csn05 CHECK ((ind_bnk_chn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_t1_csn06 CHECK ((cde_atv_t1 = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_t1_csn07 CHECK ((ind_lnd = ANY (ARRAY['Y'::bpchar, 'N'::bpchar, 'R'::bpchar, 'T'::bpchar, 'S'::bpchar, 'C'::bpchar, 'F'::bpchar]))),
    CONSTRAINT ossr_t1_csn08 CHECK ((cde_atv_sup_t1 = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_t1_csn09 CHECK ((ind_dmc_extd = ANY (ARRAY['H'::bpchar, 'N'::bpchar, 'V'::bpchar])))
);


ALTER TABLE localds2.ossr_t1 OWNER TO nvoip;

--
-- Name: ossr_t1_archive; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_t1_archive (
    idn_t1 character varying(12) NOT NULL,
    tnb_bil_t1 character(10)
)
WITH (fillfactor='80');


ALTER TABLE localds2.ossr_t1_archive OWNER TO nvoip;

--
-- Name: ossr_t1_chn_jrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_t1_chn_jrn (
    idx_ord character varying(13) NOT NULL,
    key_t1_chn_psu character varying(15) NOT NULL,
    idn_eqp_ofc character varying(36),
    idn_cir character varying(32),
    loc_actl character varying(11),
    cde_ncc character varying(4),
    cde_nci character varying(12),
    cde_nci_scd character varying(12),
    idn_cir_lec character varying(53),
    cde_cfa character varying(42),
    cde_atv_dta_t1 character varying(3),
    idn_lne_acs character varying(12),
    cde_atv_dta_chn character varying(3),
    cde_id_ckt_trunk character varying(5)
);


ALTER TABLE localds2.ossr_t1_chn_jrn OWNER TO nvoip;

--
-- Name: ossr_tdir_ste; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tdir_ste (
    cde_ste character(2) NOT NULL,
    des_cde_ste character varying(35)
);


ALTER TABLE localds2.ossr_tdir_ste OWNER TO nvoip;

--
-- Name: ossr_tkg; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tkg (
    idn_tkg character varying(12) NOT NULL,
    idx_ord character varying(13) NOT NULL,
    ind_spv_ans character(1) DEFAULT 'Y'::bpchar,
    cde_rsc_tol character varying(5) NOT NULL,
    tnb_bil_tkg character(10),
    idx_ord_wrk character varying(14),
    ind_cll_by_cll character(1),
    idx_swt_wcom character varying(5),
    ind_lne_cll character(1),
    cde_pln_cll character varying(5),
    idx_fer_loc_srv character varying(15) NOT NULL,
    ind_srv_sus character(1) DEFAULT 'N'::bpchar NOT NULL,
    cde_atv_tkg character(1),
    qty_did smallint,
    cde_drc character(1),
    idn_npnx_ilec_old character varying(18),
    nbr_dig_dnis character varying(2),
    idn_sys_idn_nbr_dia character(1),
    idn_tkg_old character varying(12),
    ind_tkg_exs character(1) NOT NULL,
    flg_tctn character(1) DEFAULT 'Y'::bpchar NOT NULL,
    nbr_tkg_to_ovf character varying(11),
    ind_tkg_new_old character(1),
    typ_hun_mul character varying(10),
    cde_pic_los character varying(5),
    cde_lpic_los character varying(5),
    ind_tkg_ovf character(1) NOT NULL,
    ind_cde_acn_otb character(1) NOT NULL,
    typ_opl character varying(4),
    typ_ipl character varying(4),
    typ_opl_sta character varying(5),
    typ_ipl_sta character varying(5),
    ind_pve character(1),
    idx_org_cll_cus character(1) NOT NULL,
    cde_std_isdn character varying(6),
    nbr_tkg character varying(11),
    typ_sgl_inb character varying(4),
    qty_bchn_incmg_max smallint,
    typ_sgl_otb character varying(4),
    qty_bchn_outgo_max smallint,
    cde_pic_wng character varying(5),
    cde_lpic_wng character varying(5),
    ind_nfas character(1),
    ind_dchn_bkp character(1),
    key_tkg_psu character varying(12) NOT NULL,
    nme_tkg character varying(32),
    key_tkg_psu_ovf character varying(12),
    typ_tnk character(3),
    nbr_cas_rte integer,
    cde_clli_swt_wcom character varying(11),
    idx_swt_srv character varying(5),
    cde_clli_swt_srv character varying(11),
    nbr_ord_rlt_ilec character varying(17),
    dtx_foc_ilec timestamp with time zone,
    nme_tbl_cas_rte character(4),
    dtx_foc_lnp_ilec timestamp with time zone,
    dtx_due_dre_lsr timestamp with time zone,
    idx_spe_asm character varying(20),
    cls_trfc character varying(3),
    grp_trm_lgcl character varying(10),
    key_trm_lgcl smallint,
    cde_atv_sup_tkg character(1),
    ind_ali_ps character(1),
    cde_atv_dta_tkg character varying(3),
    ind_tone_dial character(1),
    flg_merdn character(1),
    cde_pnt_dest character varying(11),
    cde_clli_dest character varying(15),
    nme_grp_ali_ps character varying(6),
    ind_ord_voip character(1),
    CONSTRAINT ossr_tkg_csn03 CHECK ((((tnb_bil_tkg)::bigint > 2000000000) AND ((tnb_bil_tkg)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_tkg_csn04 CHECK ((ind_spv_ans = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn05 CHECK ((cde_atv_tkg = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn06 CHECK (((cde_pln_cll)::text = ANY ((ARRAY['VOICE'::character varying, 'DATA'::character varying, 'BOTH'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn07 CHECK (((nbr_dig_dnis)::text = ANY ((ARRAY['4'::character varying, '7'::character varying, '10'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn09 CHECK ((ind_cll_by_cll = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn10 CHECK ((ind_lne_cll = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn15 CHECK ((ind_srv_sus = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn17 CHECK ((cde_drc = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar]))),
    CONSTRAINT ossr_tkg_csn18 CHECK ((idn_sys_idn_nbr_dia = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn19 CHECK ((ind_tkg_exs = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn21 CHECK ((ind_tkg_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar]))),
    CONSTRAINT ossr_tkg_csn22 CHECK (((typ_hun_mul)::text = ANY ((ARRAY['AS'::character varying, 'DS'::character varying, 'LI'::character varying, 'MI'::character varying, 'SG_CWCTH'::character varying, 'SG_CCWCTH'::character varying, 'CCWCTH'::character varying, 'CWCTH'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn23 CHECK ((ind_tkg_ovf = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn24 CHECK ((ind_cde_acn_otb = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn25 CHECK (((typ_opl)::text = ANY ((ARRAY['DP'::character varying, 'DTMF'::character varying, 'MF'::character varying, 'NP'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn26 CHECK (((typ_ipl)::text = ANY ((ARRAY['DP'::character varying, 'DTMF'::character varying, 'MF'::character varying, 'NP'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn27 CHECK (((typ_opl_sta)::text = ANY ((ARRAY['wink'::character varying, 'immed'::character varying, 'delay'::character varying, 'dtone'::character varying, 'DC'::character varying, 'NO'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn28 CHECK (((typ_ipl_sta)::text = ANY ((ARRAY['wink'::character varying, 'immed'::character varying, 'delay'::character varying, 'dtone'::character varying, 'AD'::character varying, 'DC'::character varying, 'WD'::character varying, 'NO'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn29 CHECK ((ind_pve = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn31 CHECK (((idx_org_cll_cus = 'Y'::bpchar) OR (idx_org_cll_cus = 'N'::bpchar))),
    CONSTRAINT ossr_tkg_csn32 CHECK (((typ_sgl_inb)::text = ANY ((ARRAY['GS'::character varying, 'LS'::character varying, 'E&M'::character varying, 'ISDN'::character varying, 'SS7'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn33 CHECK (((qty_bchn_incmg_max >= 1) AND (qty_bchn_incmg_max <= 479))),
    CONSTRAINT ossr_tkg_csn34 CHECK (((qty_bchn_outgo_max >= 1) AND (qty_bchn_outgo_max <= 479))),
    CONSTRAINT ossr_tkg_csn36 CHECK ((flg_tctn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn37 CHECK ((ind_dchn_bkp = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn38 CHECK (((typ_sgl_otb)::text = ANY ((ARRAY['GS'::character varying, 'LS'::character varying, 'E&M'::character varying, 'ISDN'::character varying, 'SS7'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn40 CHECK (((cls_trfc)::text = ANY ((ARRAY['PBX'::character varying, 'TDM'::character varying, 'SIP'::character varying, 'ISP'::character varying, 'BOO'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_csn41 CHECK ((cde_atv_sup_tkg = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn42 CHECK ((ind_ali_ps = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn43 CHECK ((ind_tone_dial = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tkg_csn44 CHECK ((flg_merdn = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT tkg_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_tkg OWNER TO nvoip;

--
-- Name: ossr_tkg_chn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tkg_chn (
    idn_t1 character varying(12) NOT NULL,
    idn_chn smallint NOT NULL,
    idn_tkg character varying(12),
    idn_cir_chn character varying(32),
    nbr_ass_chn integer,
    ind_dchn character(1),
    cde_atv_chn character(1) NOT NULL,
    idn_cir_pvd_lnd character varying(17),
    idn_eqp_ofc_chn character varying(32),
    key_chn_psu character varying(15) NOT NULL,
    idn_lne_acs character varying(12),
    tnb_line character(10),
    idx_ord_coms character varying(8),
    idx_ckt_mx_coms character varying(20),
    idx_tacm character varying(6),
    cde_atv_sup_chn character(1),
    cde_atv_dta_chn character varying(3),
    ind_reconfig character varying(3),
    cde_id_ckt_trunk character varying(5),
    CONSTRAINT ossr_tkg_chn_csn02 CHECK ((cde_atv_chn = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar, 'M'::bpchar]))),
    CONSTRAINT ossr_tkg_chn_csn05 CHECK (((idn_chn >= 1) AND (idn_chn <= 24))),
    CONSTRAINT ossr_tkg_chn_csn06 CHECK ((ind_dchn = ANY (ARRAY['P'::bpchar, 'B'::bpchar]))),
    CONSTRAINT ossr_tkg_chn_csn08 CHECK (((ind_reconfig)::text = ANY ((ARRAY['L2L'::character varying, 'T2L'::character varying, 'L2T'::character varying])::text[]))),
    CONSTRAINT ossr_tkg_chn_csn09 CHECK ((cde_atv_sup_chn = ANY (ARRAY['A'::bpchar, 'N'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar])))
)
WITH (fillfactor='80');


ALTER TABLE localds2.ossr_tkg_chn OWNER TO nvoip;

--
-- Name: ossr_tkg_jrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tkg_jrn (
    idx_ord character varying(13) NOT NULL,
    idn_tkg character varying(12) NOT NULL,
    key_tkg_psu character varying(12) NOT NULL,
    ind_tkg_new_old character(1),
    nbr_tkg character varying(11),
    nme_tkg character varying(32),
    typ_tnk character(3),
    nme_tbl_cas_rte character(4),
    idx_swt_srv character varying(5),
    cde_clli_swt_srv character varying(11),
    dtx_foc_ilec timestamp with time zone,
    nbr_ord_rlt_ilec character varying(17),
    dtx_foc_lnp_ilec timestamp with time zone,
    dtx_due_dre_lsr timestamp with time zone,
    nbr_cas_rte integer,
    grp_trm_lgcl character varying(10),
    key_trm_lgcl smallint,
    cde_atv_dta_tkg character varying(3),
    cde_pnt_dest character varying(11),
    cde_clli_dest character varying(15),
    CONSTRAINT ossr_tkg_jrn_csn013 CHECK ((ind_tkg_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar])))
);


ALTER TABLE localds2.ossr_tkg_jrn OWNER TO nvoip;

--
-- Name: ossr_tkg_psp; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tkg_psp (
    idn_tkg character varying(12) NOT NULL,
    nbr_rte_psap character varying(20) NOT NULL,
    nme_cny_psap character varying(60) NOT NULL,
    nme_agn_psap character varying(120),
    ind_ord_voip character(1),
    CONSTRAINT psp_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar])))
);


ALTER TABLE localds2.ossr_tkg_psp OWNER TO nvoip;

--
-- Name: ossr_tnb; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tnb (
    idx_tnb character varying(12) NOT NULL,
    idx_lec character varying(3),
    idx_ord character varying(13) NOT NULL,
    idn_lne_acs character varying(12),
    idn_tkg character varying(12),
    idn_grp_ctx character(8),
    nbr_grp_sub_ctx smallint,
    tnb character(10) NOT NULL,
    tnb_bil character(10),
    cde_atn_tnb character(1) NOT NULL,
    idx_opt_pln_cll character varying(20),
    tnb_rcf_inp character(10),
    tnb_rfl_wcm character(10),
    qty_day_rfl_wcm smallint,
    ind_drc_cll character(1) DEFAULT 'B'::bpchar NOT NULL,
    dtx_eff_svf timestamp with time zone,
    idx_tnb_old character varying(12),
    typ_tnb_por character(3),
    ind_tnb_new_old character(1),
    qty_pth_rcf integer,
    dtx_foc_lnp_inp timestamp with time zone,
    tnb_ren_lec character(10),
    ind_tnk_or_lne character(1),
    nbr_dig_pfx character varying(10),
    ind_pos_atdnt smallint,
    nbr_sta_dia integer,
    nme_sta character varying(25),
    cde_tmt_lne smallint,
    flg_req_jck character(1),
    cde_jck character varying(5),
    dig_opl smallint,
    ind_tnb_sec_pri character(1),
    idx_ptn_rgr smallint,
    ind_opt_sts_dtv character(1),
    tnb_bil_lec character(10),
    ind_ali_ps character(1),
    cde_atn_sup_tnb character(1),
    cde_atn_dta_tnb character varying(3),
    idx_rsv_tnb character varying(10),
    tnb_old character(10),
    ind_adr character(1),
    nbr_tkg_911 character varying(11),
    nbr_nme_rte_off character varying(14),
    nbr_nme_rte_off_old character varying(14),
    nbr_to_fwd_vbl character varying(18),
    qty_path_vbl smallint,
    nme_grp_ali_ps character varying(6),
    ind_prty_cll_vbl character varying(7),
    idx_app_cll smallint,
    tnb_pri character(10),
    cde_pic character(5),
    cde_lpic character(5),
    flg_ld_dom_otb_blk character(1),
    flg_ld_interlata_otb_blk character(1),
    flg_ld_intralata_otb_blk character(1),
    flg_local_otb_blk character(1),
    flg_ld_intnl_otb_blk character(1),
    flg_asi_dir_blk character(1),
    flg_otb_all_blk character(1),
    flg_inb_all_blk character(1),
    flg_911_but_all_blk character(1),
    flg_svc_911_blk character(1),
    idx_tri bigint,
    ind_911_unb character(1),
    ind_inv_tnb character(1),
    tnb_split_npa character(10),
    nbr_nme_rte_off_npa character varying(14),
    key_tkg_psu_npa character varying(12),
    nbr_tkg_npa character varying(11),
    nme_grp_ali_ps_npa character varying(6),
    ind_ord_voip character(1),
    tnb_bil_lec_old character(10),
    ind_timr_mdm character(1),
    ali_provider_name character varying(3),
    CONSTRAINT chk_tnb_ind_timr_mdm CHECK ((ind_timr_mdm = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT idx_app_cll CHECK (((idx_app_cll >= 1) AND (idx_app_cll <= 64))),
    CONSTRAINT ind_inv_tnb_ck CHECK ((ind_inv_tnb = ANY (ARRAY['A'::bpchar, 'P'::bpchar]))),
    CONSTRAINT ossr_tnb_csn01 CHECK ((((tnb)::bigint > 2000000000) AND ((tnb)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_tnb_csn07 CHECK ((((tnb_rcf_inp)::bigint > 2000000000) AND ((tnb_rcf_inp)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_tnb_csn09 CHECK ((((tnb_rfl_wcm)::bigint > 2000000000) AND ((tnb_rfl_wcm)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_tnb_csn10 CHECK ((ind_drc_cll = ANY (ARRAY['B'::bpchar, 'I'::bpchar, 'O'::bpchar]))),
    CONSTRAINT ossr_tnb_csn11 CHECK ((ind_tnb_new_old = ANY (ARRAY['N'::bpchar, 'O'::bpchar]))),
    CONSTRAINT ossr_tnb_csn12 CHECK ((typ_tnb_por = ANY (ARRAY['INP'::bpchar, 'LNP'::bpchar]))),
    CONSTRAINT ossr_tnb_csn14 CHECK ((ind_tnk_or_lne = ANY (ARRAY['L'::bpchar, 'T'::bpchar]))),
    CONSTRAINT ossr_tnb_csn15 CHECK (((idx_ptn_rgr >= 1) AND (idx_ptn_rgr <= 4))),
    CONSTRAINT ossr_tnb_csn16 CHECK ((cde_atn_tnb = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'N'::bpchar, 'M'::bpchar]))),
    CONSTRAINT ossr_tnb_csn17 CHECK ((ind_opt_sts_dtv = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '5'::bpchar, '6'::bpchar, '7'::bpchar, '8'::bpchar]))),
    CONSTRAINT ossr_tnb_csn19 CHECK ((ind_ali_ps = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tnb_csn20 CHECK ((cde_atn_sup_tnb = ANY (ARRAY['A'::bpchar, 'C'::bpchar, 'R'::bpchar, 'X'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tnb_csn21 CHECK ((((tnb_old)::bigint > 2000000000) AND ((tnb_old)::bigint < '9999999999'::bigint))),
    CONSTRAINT ossr_tnb_csn22 CHECK ((ind_adr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT ossr_tnb_csn23 CHECK (((ind_prty_cll_vbl)::text = ANY ((ARRAY['ORIG_TN'::character varying, 'VBL_TN'::character varying])::text[]))),
    CONSTRAINT ossr_tnb_csn24 CHECK ((flg_ld_dom_otb_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn25 CHECK ((flg_ld_interlata_otb_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn26 CHECK ((flg_ld_intralata_otb_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn27 CHECK ((flg_local_otb_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn28 CHECK ((flg_ld_intnl_otb_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn29 CHECK ((flg_asi_dir_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn30 CHECK ((flg_otb_all_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn31 CHECK ((flg_inb_all_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn32 CHECK ((flg_911_but_all_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn33 CHECK ((flg_svc_911_blk = ANY (ARRAY['N'::bpchar, 'Y'::bpchar]))),
    CONSTRAINT ossr_tnb_csn34 CHECK ((ind_911_unb = ANY (ARRAY['B'::bpchar, 'U'::bpchar, 'N'::bpchar]))),
    CONSTRAINT tnb_ind_ord_voip_ck CHECK ((ind_ord_voip = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT tnb_pri CHECK ((((tnb_pri)::bigint > 2000000000) AND ((tnb_pri)::bigint < '9999999999'::bigint))),
    CONSTRAINT tnb_split_npa_ck CHECK ((((tnb_split_npa)::bigint >= 2000000000) AND ((tnb_split_npa)::bigint <= '9999999999'::bigint)))
);


ALTER TABLE localds2.ossr_tnb OWNER TO nvoip;

--
-- Name: ossr_tnb_11_15_13; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tnb_11_15_13 (
    idx_tnb character varying(12) NOT NULL,
    idx_lec character varying(3),
    idx_ord character varying(13) NOT NULL,
    idn_lne_acs character varying(12),
    idn_tkg character varying(12),
    idn_grp_ctx character(8),
    nbr_grp_sub_ctx smallint,
    tnb character(10) NOT NULL,
    tnb_bil character(10),
    cde_atn_tnb character(1) NOT NULL,
    idx_opt_pln_cll character varying(20),
    tnb_rcf_inp character(10),
    tnb_rfl_wcm character(10),
    qty_day_rfl_wcm smallint,
    ind_drc_cll character(1) NOT NULL,
    dtx_eff_svf timestamp with time zone,
    idx_tnb_old character varying(12),
    typ_tnb_por character(3),
    ind_tnb_new_old character(1),
    qty_pth_rcf integer,
    dtx_foc_lnp_inp timestamp with time zone,
    tnb_ren_lec character(10),
    ind_tnk_or_lne character(1),
    nbr_dig_pfx character varying(10),
    ind_pos_atdnt smallint,
    nbr_sta_dia integer,
    nme_sta character varying(25),
    cde_tmt_lne smallint,
    flg_req_jck character(1),
    cde_jck character varying(5),
    dig_opl smallint,
    ind_tnb_sec_pri character(1),
    idx_ptn_rgr smallint,
    ind_opt_sts_dtv character(1),
    tnb_bil_lec character(10),
    ind_ali_ps character(1),
    cde_atn_sup_tnb character(1),
    cde_atn_dta_tnb character varying(3),
    idx_rsv_tnb character varying(10),
    tnb_old character(10),
    ind_adr character(1),
    nbr_tkg_911 character varying(11),
    nbr_nme_rte_off character varying(14),
    nbr_nme_rte_off_old character varying(14),
    nbr_to_fwd_vbl character varying(18),
    qty_path_vbl smallint,
    nme_grp_ali_ps character varying(6),
    ind_prty_cll_vbl character varying(7),
    idx_app_cll smallint,
    tnb_pri character(10),
    cde_pic character(5),
    cde_lpic character(5),
    flg_ld_dom_otb_blk character(1),
    flg_ld_interlata_otb_blk character(1),
    flg_ld_intralata_otb_blk character(1),
    flg_local_otb_blk character(1),
    flg_ld_intnl_otb_blk character(1),
    flg_asi_dir_blk character(1),
    flg_otb_all_blk character(1),
    flg_inb_all_blk character(1),
    flg_911_but_all_blk character(1),
    flg_svc_911_blk character(1),
    idx_tri bigint,
    ind_911_unb character(1),
    ind_inv_tnb character(1),
    tnb_split_npa character(10),
    nbr_nme_rte_off_npa character varying(14),
    key_tkg_psu_npa character varying(12),
    nbr_tkg_npa character varying(11),
    nme_grp_ali_ps_npa character varying(6),
    ind_ord_voip character(1),
    tnb_bil_lec_old character(10),
    ind_timr_mdm character(1)
);


ALTER TABLE localds2.ossr_tnb_11_15_13 OWNER TO nvoip;

--
-- Name: ossr_tnb_adr; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tnb_adr (
    idx_adr character varying(30) NOT NULL,
    cde_rol_adr character varying(3) NOT NULL,
    idx_tnb character varying(12) NOT NULL
);


ALTER TABLE localds2.ossr_tnb_adr OWNER TO nvoip;

--
-- Name: ossr_tnb_cmn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tnb_cmn (
    nbr_seq_cmn character varying(15) NOT NULL,
    dtx_cmn timestamp with time zone NOT NULL,
    idx_tnb character varying(12) NOT NULL,
    nme_src_err character varying(18),
    nme_srv_pvn character varying(12),
    cde_err character varying(10),
    txt_cmn character varying(2000),
    cde_svr_err character(5),
    cde_ali character varying(3),
    idx_dir character varying(6),
    CONSTRAINT ossr_tnb_cmn_csn01 CHECK (((nme_srv_pvn)::text = ANY ((ARRAY['DADL'::character varying, 'LIDB'::character varying, 'E911'::character varying, 'CARE'::character varying, 'OPS'::character varying, 'SERVICE ORDER'::character varying, 'FTN'::character varying, 'CNAM'::character varying])::text[])))
);


ALTER TABLE localds2.ossr_tnb_cmn OWNER TO nvoip;

--
-- Name: ossr_tra_log; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tra_log (
    tnb character varying(10) NOT NULL,
    cde_sts_tsk character(1) NOT NULL,
    idx_lec character varying(4) NOT NULL,
    dtx_tra timestamp with time zone NOT NULL,
    idn_tsk_ord character varying(32) NOT NULL,
    nbr_bch numeric(38,0) NOT NULL,
    nbr_ord character varying(13) NOT NULL,
    idx_spn_ord character varying(3) NOT NULL,
    nme_tsk character varying(25) NOT NULL,
    txt_cmn character varying(2000) NOT NULL,
    idx_mgl character varying(15) NOT NULL,
    ind_prs character(1) NOT NULL,
    idx_org_ord character(1) NOT NULL,
    cde_sts_fbk character(1),
    gdt_sts_fbk timestamp with time zone,
    nme_customer character varying(50),
    cde_function character(1),
    cde_atn_cnam character(1),
    cde_rsc_cnam character(1),
    cde_bns character(1),
    key_1_transaction character varying(50),
    txt_record character varying(1000),
    dtx_replication timestamp with time zone,
    CONSTRAINT ossr_tra_log_csn01 CHECK ((cde_sts_fbk = ANY (ARRAY['R'::bpchar, 'T'::bpchar, 'I'::bpchar]))),
    CONSTRAINT ossr_tra_log_csn02 CHECK ((idx_org_ord = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '6'::bpchar, 'E'::bpchar])))
);


ALTER TABLE localds2.ossr_tra_log OWNER TO nvoip;

--
-- Name: ossr_tra_log_his; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tra_log_his (
    tnb character varying(10) NOT NULL,
    cde_sts_tsk character(1) NOT NULL,
    idx_lec character varying(4) NOT NULL,
    nbr_seq_tsk character varying(18) NOT NULL,
    ind_tsk_ord character varying(32) NOT NULL,
    nbr_bch numeric(38,0) NOT NULL,
    nbr_ord character varying(13) NOT NULL,
    idx_spn_ord character varying(3) NOT NULL,
    nme_tsk character varying(25) NOT NULL,
    txt_cmn character varying(2000) NOT NULL,
    idx_mgl character varying(15) NOT NULL,
    ind_prs character(1) NOT NULL,
    dtx_tra timestamp with time zone,
    idx_org_ord character(1) NOT NULL,
    cde_sts_fbk character(1),
    gdt_sts_fbk timestamp with time zone,
    nme_customer character varying(50),
    cde_function character(1),
    cde_atn_cnam character(1),
    cde_rsc_cnam character(1),
    cde_bns character(1),
    key_1_transaction character varying(50),
    txt_record character varying(1000),
    dtx_replication timestamp with time zone,
    seq_his_log_tra numeric(20,0) NOT NULL,
    CONSTRAINT ossr_tra_log_his_csn01 CHECK ((cde_sts_fbk = ANY (ARRAY['R'::bpchar, 'T'::bpchar, 'I'::bpchar]))),
    CONSTRAINT ossr_tra_log_his_csn02 CHECK ((idx_org_ord = ANY (ARRAY['1'::bpchar, '2'::bpchar, '3'::bpchar, '4'::bpchar, '6'::bpchar, 'E'::bpchar])))
);


ALTER TABLE localds2.ossr_tra_log_his OWNER TO nvoip;

--
-- Name: ossr_tsk_dri; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tsk_dri (
    idx_tsk character varying(4) NOT NULL,
    idx_ord character varying(13) NOT NULL,
    cde_sts_tsk character(1) NOT NULL,
    dtx_eff_tsk timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    nme_typ_tsk character varying(75),
    des_typ_tsk character varying(50),
    idn_han_tsk character varying(32),
    idx_spn_oma character varying(3),
    nbr_ver_wkf character varying(3),
    tmx_out_tmx timestamp with time zone,
    dtx_tsk_upd_last timestamp with time zone,
    seq_dri_tsk numeric(20,0) NOT NULL,
    sts_process_tsk character(1),
    process_name character varying(20)
);


ALTER TABLE localds2.ossr_tsk_dri OWNER TO nvoip;

--
-- Name: ossr_tsk_dri_report; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tsk_dri_report (
    idx_tsk character varying(4) NOT NULL,
    idx_ord character varying(13) NOT NULL,
    cde_sts_tsk character(1) NOT NULL,
    dtx_eff_tsk timestamp with time zone NOT NULL,
    nme_typ_tsk character varying(75),
    des_typ_tsk character varying(50),
    idn_han_tsk character varying(32),
    idx_spn_oma character varying(3),
    nbr_ver_wkf character varying(3),
    tmx_out_tmx timestamp with time zone,
    dtx_tsk_upd_last timestamp with time zone,
    seq_dri_tsk numeric(20,0) NOT NULL
);


ALTER TABLE localds2.ossr_tsk_dri_report OWNER TO nvoip;

--
-- Name: ossr_tsk_sts; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_tsk_sts (
    cde_sts_tsk character(1) NOT NULL,
    nme_sts_tsk character varying(25),
    des_sts_tsk character varying(50)
);


ALTER TABLE localds2.ossr_tsk_sts OWNER TO nvoip;

--
-- Name: ossr_wko; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_wko (
    idx_ord_wrk character varying(14) NOT NULL,
    cde_sts_ord_wrk character(2) NOT NULL,
    dtx_atv timestamp with time zone,
    dtx_cmp timestamp with time zone,
    dtx_ent timestamp with time zone,
    txt_err character varying(150)
);


ALTER TABLE localds2.ossr_wko OWNER TO nvoip;

--
-- Name: ossr_wko_sts; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.ossr_wko_sts (
    cde_sts_ord_wrk character(2) NOT NULL,
    des_sts character varying(25)
);


ALTER TABLE localds2.ossr_wko_sts OWNER TO nvoip;

--
-- Name: perseus_log_transaction; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.perseus_log_transaction (
    nbr_ord character varying(13) NOT NULL,
    idx_spn_ord character varying(3) NOT NULL,
    idx_org_ord character(1) NOT NULL,
    nbr_pon character varying(20),
    nbr_version_pon character varying(5),
    dtx_received timestamp with time zone,
    dtx_returned timestamp with time zone,
    cde_error character varying(10),
    txt_error character varying(200),
    CONSTRAINT perseus_log_transaction01 CHECK ((idx_org_ord = ANY (ARRAY['2'::bpchar, '6'::bpchar])))
);


ALTER TABLE localds2.perseus_log_transaction OWNER TO nvoip;

--
-- Name: projects; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.projects (
    cur_month character varying(6) NOT NULL,
    plan_type character varying(40) NOT NULL,
    owner character varying(40) NOT NULL,
    ptn character varying(40) NOT NULL,
    initiative character varying(80),
    seq_nbr integer NOT NULL,
    status character varying(1) NOT NULL,
    saved_by character varying(100),
    saved_date timestamp with time zone,
    files integer,
    fsaved_by character varying(100),
    fsaved_date timestamp with time zone,
    s1 integer,
    s2 integer,
    s3 integer,
    a1 integer,
    a2 integer,
    a3 integer,
    a4 integer,
    a5 integer,
    a6 integer,
    a7 integer,
    a8 integer,
    a9 integer,
    a10 integer,
    a11 integer,
    a12 integer,
    b1 integer,
    b2 integer,
    b3 integer,
    b4 integer,
    b5 integer,
    b6 integer,
    b7 integer,
    b8 integer,
    b9 integer,
    b10 integer,
    b11 integer,
    b12 integer,
    c1 integer,
    c2 integer,
    c3 integer,
    c4 integer,
    c5 integer,
    c6 integer,
    c7 integer,
    c8 integer,
    c9 integer,
    c10 integer,
    c11 integer,
    c12 integer,
    d1 integer,
    d2 integer,
    d3 integer,
    d4 integer,
    d5 integer,
    d6 integer,
    d7 integer,
    d8 integer,
    d9 integer,
    d10 integer,
    d11 integer,
    d12 integer,
    e1 integer,
    e2 integer,
    e3 integer,
    e4 integer,
    e5 integer,
    e6 integer,
    e7 integer,
    e8 integer,
    e9 integer,
    e10 integer,
    e11 integer,
    e12 integer,
    f1 integer,
    f2 integer,
    f3 integer,
    f4 integer,
    t1 character varying(40),
    t2 character varying(40),
    t3 character varying(40),
    t4 character varying(40),
    s4 integer,
    csaved_by character varying(100),
    csaved_date timestamp with time zone,
    vsaved_by character varying(100),
    vsaved_date timestamp with time zone,
    comments character varying(1000),
    baseline character varying(200),
    analyst character varying(100),
    telcoba character varying(100),
    u1 character varying(200),
    u2 character varying(200),
    v1 character varying(1),
    v2 character varying(1)
);


ALTER TABLE localds2.projects OWNER TO nvoip;

--
-- Name: registry_id; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.registry_id
    START WITH 1808
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.registry_id OWNER TO nvoip;

--
-- Name: rehome_am_task_details; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.rehome_am_task_details (
    nbr_order character varying(13) NOT NULL,
    nme_task character varying(254) NOT NULL,
    nbr_handle_task character varying(33) NOT NULL,
    sts_task character varying(10) NOT NULL,
    qty_retry_task smallint,
    dtx_submitted timestamp with time zone,
    sys_submitted character varying(15),
    dtx_upd_last timestamp with time zone,
    sys_upd_last character varying(15),
    CONSTRAINT check_sts_task CHECK (((sts_task)::text = ANY ((ARRAY['READY'::character varying, 'ACQUIRED'::character varying, 'COMPLETED'::character varying])::text[])))
);


ALTER TABLE localds2.rehome_am_task_details OWNER TO nvoip;

--
-- Name: rehome_migration_ord; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.rehome_migration_ord (
    nbr_order character varying(13) NOT NULL,
    typ_order character varying(3) NOT NULL,
    idx_org_order character(1) NOT NULL,
    typ_migration character varying(10) NOT NULL,
    qty_tnb integer NOT NULL,
    flg_exp_tps character(1) NOT NULL,
    dtx_submitted timestamp with time zone,
    sys_submitted character varying(15),
    dtx_upd_last timestamp with time zone,
    sys_upd_last character varying(15),
    CONSTRAINT check_flg_exp_tps CHECK ((flg_exp_tps = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_idx_org_order CHECK ((idx_org_order = '9'::bpchar))
);


ALTER TABLE localds2.rehome_migration_ord OWNER TO nvoip;

--
-- Name: rehome_tnb; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.rehome_tnb (
    nbr_order character varying(13) NOT NULL,
    tnb bigint NOT NULL,
    typ_account character varying(2),
    ind_drc_call character(1),
    cde_pic character(5),
    cde_lpic character(5),
    idx_tri bigint,
    cde_clli_swt_frm character varying(11),
    nbr_tkg_frm character varying(11),
    key_tkg_pseudo_frm character varying(12),
    nbr_nme_rte_office_frm character varying(14),
    nme_grp_psali_frm character varying(6),
    idn_spid_frm character varying(4),
    idn_reseller character varying(5),
    cde_clli_swt_to character varying(11),
    nbr_tkg_to character varying(11),
    key_tkg_pseudo_to character varying(12),
    nbr_nme_rte_office_to character varying(14),
    nme_grp_psali_to character varying(6),
    idn_spid_to character varying(4),
    flg_ld_dom_otb_blk character(1),
    flg_ld_interlata_otb_blk character(1),
    flg_ld_intralata_otb_blk character(1),
    flg_local_otb_blk character(1),
    flg_ld_intnl_otb_blk character(1),
    flg_asi_dir_blk character(1),
    flg_otb_all_blk character(1),
    flg_inb_all_blk character(1),
    flg_911_but_all_blk character(1),
    flg_svc_911_blk character(1),
    dtx_submitted timestamp with time zone,
    sys_submitted character varying(15),
    dtx_upd_last timestamp with time zone,
    sys_upd_last character varying(15),
    ind_act_port character(1),
    CONSTRAINT check_flg_911_but_all_blk CHECK ((flg_911_but_all_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_asi_dir_blk CHECK ((flg_asi_dir_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_inb_all_blk CHECK ((flg_inb_all_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_ld_dom_otb_blk CHECK ((flg_ld_dom_otb_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_ld_interlata_otb_blk CHECK ((flg_ld_interlata_otb_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_ld_intnl_otb_blk CHECK ((flg_ld_intnl_otb_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_ld_intralata_otb_blk CHECK ((flg_ld_intralata_otb_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_local_otb_blk CHECK ((flg_local_otb_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_otb_all_blk CHECK ((flg_otb_all_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_flg_svc_911_blk CHECK ((flg_svc_911_blk = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT check_ind_drc_call CHECK ((ind_drc_call = ANY (ARRAY['I'::bpchar, 'O'::bpchar, 'B'::bpchar]))),
    CONSTRAINT check_typ_account CHECK (((typ_account)::text = ANY ((ARRAY['R'::character varying, 'B'::character varying])::text[])))
);


ALTER TABLE localds2.rehome_tnb OWNER TO nvoip;

--
-- Name: rehome_tnb_status; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.rehome_tnb_status (
    nbr_order character varying(13) NOT NULL,
    tnb bigint NOT NULL,
    cde_action character varying(15) NOT NULL,
    cde_status character varying(10) NOT NULL,
    txt_status character varying(2000),
    qty_retry_action smallint,
    dtx_submitted timestamp with time zone,
    sys_submitted character varying(15),
    dtx_upd_last timestamp with time zone,
    sys_upd_last character varying(15),
    idx_request_tps character varying(33),
    CONSTRAINT check_cde_status CHECK (((cde_status)::text = ANY ((ARRAY['INITIATED'::character varying, 'COMPLETED'::character varying, 'ERRORED'::character varying, 'PARKED'::character varying])::text[])))
);


ALTER TABLE localds2.rehome_tnb_status OWNER TO nvoip;

--
-- Name: sddr_availability_ilec; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_availability_ilec (
    nbr_cic_ilec smallint NOT NULL,
    cde_state character(2) NOT NULL,
    typ_trans character varying(3) NOT NULL,
    day_week character varying(3) NOT NULL,
    time_start character(4) NOT NULL,
    time_end character(4) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_upd_las timestamp with time zone NOT NULL,
    CONSTRAINT sddr_availability_ilec01 CHECK (((typ_trans)::text = ANY ((ARRAY['LSR'::character varying, 'AV'::character varying, 'LQ'::character varying, 'CSR'::character varying, 'ASR'::character varying])::text[]))),
    CONSTRAINT sddr_availability_ilec02 CHECK (((day_week)::text = ANY ((ARRAY['MON'::character varying, 'TUE'::character varying, 'WED'::character varying, 'THU'::character varying, 'FRI'::character varying, 'SAT'::character varying, 'SUN'::character varying])::text[])))
);


ALTER TABLE localds2.sddr_availability_ilec OWNER TO nvoip;

--
-- Name: sddr_cir; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_cir (
    idn_cir_ent_ord character varying(15) NOT NULL,
    idn_cir_pvn character(14),
    dtx_upd_las timestamp with time zone,
    idn_vz_usr_upd_las character varying(10)
)
WITH (fillfactor='80');


ALTER TABLE localds2.sddr_cir OWNER TO nvoip;

--
-- Name: sddr_exception_avail_ilec; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_exception_avail_ilec (
    idn_avail_exception_ilec bigint NOT NULL,
    nbr_cic_ilec smallint NOT NULL,
    cde_state character(2) NOT NULL,
    typ_trans character varying(3) NOT NULL,
    dtx_start timestamp with time zone NOT NULL,
    dtx_end timestamp with time zone NOT NULL,
    rmk_desc character varying(50) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_upd_las timestamp with time zone DEFAULT LOCALTIMESTAMP NOT NULL,
    CONSTRAINT sddr_exception_avail_ilec01 CHECK (((typ_trans)::text = ANY ((ARRAY['LSR'::character varying, 'AV'::character varying, 'LQ'::character varying, 'CSR'::character varying, 'ASR'::character varying])::text[])))
);


ALTER TABLE localds2.sddr_exception_avail_ilec OWNER TO nvoip;

--
-- Name: sddr_info_ilec; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_info_ilec (
    nbr_cic_ilec smallint NOT NULL,
    nme_ilec character varying(50) NOT NULL,
    cde_cic_ilec character varying(3) NOT NULL
);


ALTER TABLE localds2.sddr_info_ilec OWNER TO nvoip;

--
-- Name: sddr_lec_order_key_values; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_lec_order_key_values (
    idx_key_order_lec character varying(8) NOT NULL,
    idx_lec character varying(3) NOT NULL,
    nme_field character varying(20) NOT NULL,
    val_field character varying(30) NOT NULL
);


ALTER TABLE localds2.sddr_lec_order_key_values OWNER TO nvoip;

--
-- Name: sddr_rrn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_rrn (
    cde_ste character(2) NOT NULL,
    idx_rrn character(10) NOT NULL,
    nme_rrn character varying(30) NOT NULL
);


ALTER TABLE localds2.sddr_rrn OWNER TO nvoip;

--
-- Name: sddr_spid_lec_values; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_spid_lec_values (
    idn_spid character varying(4) NOT NULL,
    nme_field character varying(20) NOT NULL,
    val_field character varying(30) NOT NULL
);


ALTER TABLE localds2.sddr_spid_lec_values OWNER TO nvoip;

--
-- Name: sddr_swt_owner_cic; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_swt_owner_cic (
    cde_owner_swt character varying(1) NOT NULL,
    cde_state character varying(2) NOT NULL,
    cde_cic character varying(4) NOT NULL
);


ALTER TABLE localds2.sddr_swt_owner_cic OWNER TO nvoip;

--
-- Name: sddr_tcom_cen_inf; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_tcom_cen_inf (
    idx_cntr_oe character varying(3) NOT NULL,
    idx_cntr_prov character varying(14),
    cde_loc_rev_int character varying(3)
)
WITH (fillfactor='80');


ALTER TABLE localds2.sddr_tcom_cen_inf OWNER TO nvoip;

--
-- Name: sddr_tkg; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_tkg (
    idn_tkg_ent_ord character varying(12) NOT NULL,
    idn_tkg_pvn character varying(11),
    cde_cli_swt character(11),
    idn_swt character(5),
    dtx_upd_las timestamp with time zone,
    idn_vz_usr_upd_las character varying(10)
)
WITH (fillfactor='80');


ALTER TABLE localds2.sddr_tkg OWNER TO nvoip;

--
-- Name: sddr_usr_vzid_lst; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_usr_vzid_lst (
    idn_usr_db character varying(15) NOT NULL,
    idn_vzid_user character varying(10) NOT NULL,
    idn_priv_vzid character varying(5) NOT NULL,
    dtx_upd_las timestamp with time zone NOT NULL,
    idn_usr_upd_las character varying(10) NOT NULL,
    CONSTRAINT ck_idn_priv_vzid CHECK (((idn_priv_vzid)::text = ANY ((ARRAY['S'::character varying, 'SU'::character varying, 'SUD'::character varying])::text[])))
);


ALTER TABLE localds2.sddr_usr_vzid_lst OWNER TO nvoip;

--
-- Name: sddr_ypg_hdr_inf; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sddr_ypg_hdr_inf (
    cde_state character(2) NOT NULL,
    nbr_cic_ilec character varying(4) NOT NULL,
    cde_hdg_pge_yel character varying(8) NOT NULL,
    txt_hdg_pge_yel character varying(75) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
)
WITH (fillfactor='80');


ALTER TABLE localds2.sddr_ypg_hdr_inf OWNER TO nvoip;

--
-- Name: sdmr_ame_err_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_ame_err_cde (
    cde_err character(10) NOT NULL,
    cde_sev character(10) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_err character varying(512) NOT NULL,
    idn_atn character varying(512) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_ame_err_cde OWNER TO nvoip;

--
-- Name: sdmr_ame_err_cde_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_ame_err_cde_vw AS
 SELECT a.cde_err,
    a.cde_sev,
    b.des_err,
    b.idn_atn
   FROM ( SELECT sdmr_ame_err_cde.cde_err,
            sdmr_ame_err_cde.cde_sev,
            max(sdmr_ame_err_cde.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_ame_err_cde
          WHERE (sdmr_ame_err_cde.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_ame_err_cde.cde_err, sdmr_ame_err_cde.cde_sev) a,
    localds2.sdmr_ame_err_cde b
  WHERE ((a.cde_err = b.cde_err) AND (a.cde_sev = b.cde_sev) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_ame_err_cde_vw OWNER TO nvoip;

--
-- Name: sdmr_car_ppt; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_car_ppt (
    nbr_npa character(3) NOT NULL,
    nbr_nxx character(3) NOT NULL,
    nbr_lne_beg character(4) NOT NULL,
    ind_jur character(1) NOT NULL,
    cde_qul character varying(6) NOT NULL,
    nbr_vdr character varying(6) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    idn_pvd_srv character varying(4) NOT NULL,
    ind_agr character(1) DEFAULT 'N'::bpchar NOT NULL,
    dtx_atv_agr timestamp with time zone,
    ind_ppt_bus character(1) DEFAULT 'N'::bpchar,
    ind_ppt_rsd character(1) DEFAULT 'N'::bpchar,
    dtx_tmn_agr timestamp with time zone,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    CONSTRAINT sdmr_car_ppt_csn01 CHECK (((idn_pvd_srv)::text = ANY ((ARRAY['7227'::character varying, '7228'::character varying, '7229'::character varying])::text[]))),
    CONSTRAINT sdmr_car_ppt_csn02 CHECK ((ind_agr = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT sdmr_car_ppt_csn03 CHECK ((ind_ppt_bus = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT sdmr_car_ppt_csn04 CHECK ((ind_ppt_rsd = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT sys_c001286 CHECK (((idn_pvd_srv)::text = ANY ((ARRAY['7227'::character varying, '7228'::character varying, '7229'::character varying])::text[])))
)
WITH (fillfactor='80');


ALTER TABLE localds2.sdmr_car_ppt OWNER TO nvoip;

--
-- Name: sdmr_car_ppt_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_car_ppt_vw AS
 SELECT a.nbr_npa,
    a.nbr_nxx,
    a.nbr_lne_beg,
    a.ind_jur,
    a.cde_qul,
    a.nbr_vdr,
    a.idn_pvd_srv,
    b.ind_agr,
    b.dtx_atv_agr,
    b.ind_ppt_bus,
    b.ind_ppt_rsd,
    b.dtx_tmn_agr
   FROM ( SELECT sdmr_car_ppt.nbr_npa,
            sdmr_car_ppt.nbr_nxx,
            sdmr_car_ppt.nbr_lne_beg,
            sdmr_car_ppt.ind_jur,
            sdmr_car_ppt.cde_qul,
            sdmr_car_ppt.nbr_vdr,
            max(sdmr_car_ppt.dtx_eff) AS dtx_eff,
            sdmr_car_ppt.idn_pvd_srv
           FROM localds2.sdmr_car_ppt
          WHERE (sdmr_car_ppt.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_car_ppt.nbr_npa, sdmr_car_ppt.nbr_nxx, sdmr_car_ppt.nbr_lne_beg, sdmr_car_ppt.ind_jur, sdmr_car_ppt.cde_qul, sdmr_car_ppt.nbr_vdr, sdmr_car_ppt.idn_pvd_srv) a,
    localds2.sdmr_car_ppt b
  WHERE ((a.nbr_npa = b.nbr_npa) AND (a.nbr_nxx = b.nbr_nxx) AND (a.nbr_lne_beg = b.nbr_lne_beg) AND (a.ind_jur = b.ind_jur) AND ((a.cde_qul)::text = (b.cde_qul)::text) AND ((a.nbr_vdr)::text = (b.nbr_vdr)::text) AND ((a.idn_pvd_srv)::text = (b.idn_pvd_srv)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_car_ppt_vw OWNER TO nvoip;

--
-- Name: sdmr_ctc_rol; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_ctc_rol (
    idn_rol_ctc_vdr character varying(15) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_rol_ctc_vdr character(2) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_ctc_rol OWNER TO nvoip;

--
-- Name: sdmr_ctc_rol_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_ctc_rol_vw AS
 SELECT a.idn_rol_ctc_vdr,
    b.des_rol_ctc_vdr
   FROM ( SELECT sdmr_ctc_rol.idn_rol_ctc_vdr
           FROM localds2.sdmr_ctc_rol
          WHERE (sdmr_ctc_rol.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_ctc_rol.idn_rol_ctc_vdr) a,
    localds2.sdmr_ctc_rol b
  WHERE ((a.idn_rol_ctc_vdr)::text = (b.idn_rol_ctc_vdr)::text);


ALTER TABLE localds2.sdmr_ctc_rol_vw OWNER TO nvoip;

--
-- Name: sdmr_cus_pty_srv_grp; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_cus_pty_srv_grp (
    cde_grp_loc_rev character varying(5) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    nme_grp_loc_rev character varying(30),
    dtx_inatv timestamp with time zone,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_cus_pty_srv_grp OWNER TO nvoip;

--
-- Name: sdmr_cus_pty_srv_grp_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_cus_pty_srv_grp_vw AS
 SELECT a.cde_grp_loc_rev,
    b.nme_grp_loc_rev
   FROM ( SELECT sdmr_cus_pty_srv_grp.cde_grp_loc_rev,
            max(sdmr_cus_pty_srv_grp.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_cus_pty_srv_grp
          WHERE (sdmr_cus_pty_srv_grp.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_cus_pty_srv_grp.cde_grp_loc_rev) a,
    localds2.sdmr_cus_pty_srv_grp b
  WHERE (((a.cde_grp_loc_rev)::text = (b.cde_grp_loc_rev)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_cus_pty_srv_grp_vw OWNER TO nvoip;

--
-- Name: sdmr_dfl_val; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_dfl_val (
    idn_tsk character varying(4) NOT NULL,
    idn_atr character varying(60) NOT NULL,
    idn_trdpt character varying(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    idn_pvd_srv character varying(4) NOT NULL,
    val_dfl character varying(100) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    CONSTRAINT sdmr_dfl_val_csn01 CHECK (((idn_pvd_srv)::text = ANY ((ARRAY['7227'::character varying, '7228'::character varying, '7229'::character varying])::text[])))
)
WITH (fillfactor='80');


ALTER TABLE localds2.sdmr_dfl_val OWNER TO nvoip;

--
-- Name: sdmr_dfl_val_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_dfl_val_vw AS
 SELECT a.idn_tsk,
    a.idn_atr,
    a.idn_trdpt,
    a.idn_pvd_srv,
    b.val_dfl
   FROM ( SELECT sdmr_dfl_val.idn_tsk,
            sdmr_dfl_val.idn_atr,
            sdmr_dfl_val.idn_trdpt,
            max(sdmr_dfl_val.dtx_eff) AS dtx_eff,
            sdmr_dfl_val.idn_pvd_srv
           FROM localds2.sdmr_dfl_val
          WHERE (sdmr_dfl_val.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_dfl_val.idn_tsk, sdmr_dfl_val.idn_atr, sdmr_dfl_val.idn_trdpt, sdmr_dfl_val.idn_pvd_srv) a,
    localds2.sdmr_dfl_val b
  WHERE (((a.idn_tsk)::text = (b.idn_tsk)::text) AND ((a.idn_atr)::text = (b.idn_atr)::text) AND ((a.idn_trdpt)::text = (b.idn_trdpt)::text) AND ((a.idn_pvd_srv)::text = (b.idn_pvd_srv)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_dfl_val_vw OWNER TO nvoip;

--
-- Name: sdmr_dir; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_dir (
    idx_dir character varying(6) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    cde_dir character varying(15),
    nme_dir character varying(35),
    dtx_clo_dir timestamp with time zone,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
)
WITH (fillfactor='80');


ALTER TABLE localds2.sdmr_dir OWNER TO nvoip;

--
-- Name: sdmr_dir_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_dir_vw AS
 SELECT a.idx_dir,
    b.cde_dir,
    b.nme_dir,
    b.dtx_clo_dir
   FROM ( SELECT sdmr_dir.idx_dir,
            max(sdmr_dir.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_dir
          WHERE (sdmr_dir.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_dir.idx_dir) a,
    localds2.sdmr_dir b
  WHERE (((a.idx_dir)::text = (b.idx_dir)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_dir_vw OWNER TO nvoip;

--
-- Name: sdmr_e911_cfm_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_e911_cfm_cde (
    cde_cfm character(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    cmn_cfm character varying(100) NOT NULL,
    sts_jbs character varying(15) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_e911_cfm_cde OWNER TO nvoip;

--
-- Name: sdmr_e911_cfm_cde_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_e911_cfm_cde_vw AS
 SELECT a.cde_cfm,
    a.cmn_cfm,
    a.sts_jbs
   FROM ( SELECT sdmr_e911_cfm_cde.cde_cfm,
            max(sdmr_e911_cfm_cde.dtx_eff) AS dtx_eff,
            sdmr_e911_cfm_cde.cmn_cfm,
            sdmr_e911_cfm_cde.sts_jbs
           FROM localds2.sdmr_e911_cfm_cde
          WHERE (sdmr_e911_cfm_cde.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_e911_cfm_cde.cde_cfm, sdmr_e911_cfm_cde.cmn_cfm, sdmr_e911_cfm_cde.sts_jbs) a,
    localds2.sdmr_e911_cfm_cde b
  WHERE ((a.cde_cfm = b.cde_cfm) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_e911_cfm_cde_vw OWNER TO nvoip;

--
-- Name: sdmr_equ_acs_tnb; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_equ_acs_tnb (
    nbr_npa character(3) NOT NULL,
    nbr_nxx character(3) NOT NULL,
    nbr_lne_beg character(4) NOT NULL,
    ind_jur character(1) NOT NULL,
    idn_pvd_srv character varying(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    cde_are_mkt character(3),
    cde_ste character(2),
    dtx_iml timestamp with time zone NOT NULL,
    nbr_com character(3) NOT NULL,
    cde_clli_tdm character varying(11) NOT NULL,
    cde_clli_ofc_end character varying(11) NOT NULL,
    nbr_com_opr character varying(4) NOT NULL,
    nme_com_opr character varying(14) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    CONSTRAINT sdmr_equ_acs_tnb_csn01 CHECK (((idn_pvd_srv)::text = ANY ((ARRAY['7227'::character varying, '7228'::character varying, '7229'::character varying])::text[])))
)
WITH (fillfactor='80');


ALTER TABLE localds2.sdmr_equ_acs_tnb OWNER TO nvoip;

--
-- Name: sdmr_equ_acs_tnb_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_equ_acs_tnb_vw AS
 SELECT a.nbr_npa,
    a.nbr_nxx,
    a.nbr_lne_beg,
    a.ind_jur,
    a.idn_pvd_srv,
    b.cde_are_mkt,
    b.cde_ste,
    b.dtx_iml,
    b.nbr_com,
    b.cde_clli_tdm,
    b.cde_clli_ofc_end,
    b.nbr_com_opr,
    b.nme_com_opr
   FROM ( SELECT sdmr_equ_acs_tnb.nbr_npa,
            sdmr_equ_acs_tnb.nbr_nxx,
            sdmr_equ_acs_tnb.nbr_lne_beg,
            sdmr_equ_acs_tnb.ind_jur,
            sdmr_equ_acs_tnb.idn_pvd_srv
           FROM localds2.sdmr_equ_acs_tnb
          WHERE (sdmr_equ_acs_tnb.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_equ_acs_tnb.nbr_npa, sdmr_equ_acs_tnb.nbr_nxx, sdmr_equ_acs_tnb.nbr_lne_beg, sdmr_equ_acs_tnb.ind_jur, sdmr_equ_acs_tnb.idn_pvd_srv) a,
    localds2.sdmr_equ_acs_tnb b
  WHERE ((a.nbr_npa = b.nbr_npa) AND (a.nbr_nxx = b.nbr_nxx) AND (a.nbr_lne_beg = b.nbr_lne_beg) AND (a.ind_jur = b.ind_jur) AND ((a.idn_pvd_srv)::text = (b.idn_pvd_srv)::text));


ALTER TABLE localds2.sdmr_equ_acs_tnb_vw OWNER TO nvoip;

--
-- Name: sdmr_fax_ctc; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_fax_ctc (
    idn_ctc bigint NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    nme_ctc character varying(60),
    nme_com character varying(60),
    nme_rol_ctc character varying(60),
    nbr_tnb character varying(10),
    nbr_phn_ext character varying(4),
    nbr_fax character varying(10) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_fax_ctc OWNER TO nvoip;

--
-- Name: sdmr_fax_ctc_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_fax_ctc_vw AS
 SELECT a.idn_ctc,
    b.nme_ctc,
    b.nme_com,
    b.nme_rol_ctc,
    b.nbr_tnb,
    b.nbr_phn_ext,
    b.nbr_fax
   FROM ( SELECT sdmr_fax_ctc.idn_ctc,
            max(sdmr_fax_ctc.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_fax_ctc
          WHERE (sdmr_fax_ctc.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_fax_ctc.idn_ctc) a,
    localds2.sdmr_fax_ctc b
  WHERE ((a.idn_ctc = b.idn_ctc) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_fax_ctc_vw OWNER TO nvoip;

--
-- Name: sdmr_fax_idn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_fax_idn (
    idn_fax bigint NOT NULL,
    idn_pvd_srv character varying(4) NOT NULL,
    idn_tsk character varying(4) NOT NULL,
    idn_trdpt character varying(4) NOT NULL,
    txt_dcv_fct character varying(120) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    CONSTRAINT sdmr_fax_idn_csn01 CHECK (((idn_pvd_srv)::text = ANY ((ARRAY['7227'::character varying, '7228'::character varying, '7229'::character varying])::text[])))
);


ALTER TABLE localds2.sdmr_fax_idn OWNER TO nvoip;

--
-- Name: sdmr_fax_idn_ctc; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_fax_idn_ctc (
    idn_fax bigint NOT NULL,
    idn_ctc bigint NOT NULL,
    cde_rte character varying(5) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    CONSTRAINT sdmr_fax_idn_ctc_csn01 CHECK (((cde_rte)::text = ANY ((ARRAY['TO'::character varying, 'FROM'::character varying])::text[])))
);


ALTER TABLE localds2.sdmr_fax_idn_ctc OWNER TO nvoip;

--
-- Name: sdmr_fax_idn_ctc_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_fax_idn_ctc_vw AS
 SELECT a.idn_fax,
    a.idn_ctc,
    a.cde_rte
   FROM ( SELECT sdmr_fax_idn_ctc.idn_fax,
            sdmr_fax_idn_ctc.idn_ctc,
            sdmr_fax_idn_ctc.cde_rte,
            max(sdmr_fax_idn_ctc.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_fax_idn_ctc
          WHERE (sdmr_fax_idn_ctc.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_fax_idn_ctc.idn_fax, sdmr_fax_idn_ctc.idn_ctc, sdmr_fax_idn_ctc.cde_rte) a,
    localds2.sdmr_fax_idn_ctc b
  WHERE ((a.idn_fax = b.idn_fax) AND (a.idn_ctc = b.idn_ctc) AND ((a.cde_rte)::text = (b.cde_rte)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_fax_idn_ctc_vw OWNER TO nvoip;

--
-- Name: sdmr_fax_idn_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_fax_idn_vw AS
 SELECT sdmr_fax_idn.idn_fax,
    sdmr_fax_idn.idn_pvd_srv,
    sdmr_fax_idn.idn_tsk,
    sdmr_fax_idn.idn_trdpt,
    sdmr_fax_idn.txt_dcv_fct
   FROM localds2.sdmr_fax_idn;


ALTER TABLE localds2.sdmr_fax_idn_vw OWNER TO nvoip;

--
-- Name: sdmr_ioc; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_ioc (
    cde_ioc character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_ioc OWNER TO nvoip;

--
-- Name: sdmr_ioc_swt; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_ioc_swt (
    cde_ioc character varying(10) NOT NULL,
    typ_swt character varying(4) NOT NULL,
    nbr_dir bigint,
    nbr_pfl_srv bigint,
    cde_pic_ital character varying(4),
    cde_pic_itel character varying(4),
    flg_clf character varying(1),
    flg_hun character varying(1),
    flg_vcm character varying(1),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    CONSTRAINT sdmr_ioc_swt_csn01 CHECK (((typ_swt)::text = ANY ((ARRAY['5ESS'::character varying, 'AXT'::character varying, 'DMS'::character varying, '5ER'::character varying, '5EXM'::character varying, '5RSM'::character varying, 'EXE'::character varying, 'EWSD'::character varying])::text[]))),
    CONSTRAINT sdmr_ioc_swt_csn02 CHECK (((flg_clf)::text = ANY ((ARRAY['R'::character varying, 'O'::character varying, 'N'::character varying])::text[]))),
    CONSTRAINT sdmr_ioc_swt_csn03 CHECK (((flg_hun)::text = ANY ((ARRAY['R'::character varying, 'O'::character varying, 'N'::character varying])::text[]))),
    CONSTRAINT sdmr_ioc_swt_csn04 CHECK (((flg_vcm)::text = ANY ((ARRAY['R'::character varying, 'O'::character varying, 'N'::character varying])::text[])))
);


ALTER TABLE localds2.sdmr_ioc_swt OWNER TO nvoip;

--
-- Name: sdmr_ioc_swt_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_ioc_swt_vw AS
 SELECT sdmr_ioc_swt.cde_ioc,
    sdmr_ioc_swt.typ_swt,
    sdmr_ioc_swt.nbr_dir,
    sdmr_ioc_swt.nbr_pfl_srv,
    sdmr_ioc_swt.cde_pic_ital,
    sdmr_ioc_swt.cde_pic_itel,
    sdmr_ioc_swt.flg_clf,
    sdmr_ioc_swt.flg_hun,
    sdmr_ioc_swt.flg_vcm
   FROM localds2.sdmr_ioc_swt;


ALTER TABLE localds2.sdmr_ioc_swt_vw OWNER TO nvoip;

--
-- Name: sdmr_ioc_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_ioc_vw AS
 SELECT sdmr_ioc.cde_ioc
   FROM localds2.sdmr_ioc;


ALTER TABLE localds2.sdmr_ioc_vw OWNER TO nvoip;

--
-- Name: sdmr_jbs_sts_dir; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_jbs_sts_dir (
    sts_jbs character varying(15) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    typ_srv_jbs character varying(4) NOT NULL,
    cde_clr_red smallint NOT NULL,
    cde_clr_blu smallint NOT NULL,
    cde_clr_grn smallint NOT NULL,
    des_jbs character varying(25) NOT NULL,
    des_jbs_lon character varying(50),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_jbs_sts_dir OWNER TO nvoip;

--
-- Name: sdmr_jbs_sts_dir_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_jbs_sts_dir_vw AS
 SELECT a.sts_jbs,
    a.typ_srv_jbs,
    a.cde_clr_red,
    a.cde_clr_blu,
    a.cde_clr_grn,
    a.des_jbs,
    a.des_jbs_lon
   FROM ( SELECT sdmr_jbs_sts_dir.sts_jbs,
            max(sdmr_jbs_sts_dir.dtx_eff) AS dtx_eff,
            sdmr_jbs_sts_dir.typ_srv_jbs,
            sdmr_jbs_sts_dir.cde_clr_red,
            sdmr_jbs_sts_dir.cde_clr_blu,
            sdmr_jbs_sts_dir.cde_clr_grn,
            sdmr_jbs_sts_dir.des_jbs,
            sdmr_jbs_sts_dir.des_jbs_lon
           FROM localds2.sdmr_jbs_sts_dir
          WHERE (sdmr_jbs_sts_dir.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_jbs_sts_dir.sts_jbs, sdmr_jbs_sts_dir.typ_srv_jbs, sdmr_jbs_sts_dir.cde_clr_red, sdmr_jbs_sts_dir.cde_clr_blu, sdmr_jbs_sts_dir.cde_clr_grn, sdmr_jbs_sts_dir.des_jbs, sdmr_jbs_sts_dir.des_jbs_lon) a,
    localds2.sdmr_jbs_sts_dir b
  WHERE (((a.sts_jbs)::text = (b.sts_jbs)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_jbs_sts_dir_vw OWNER TO nvoip;

--
-- Name: sdmr_jep_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_jep_cde (
    cde_jep character varying(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_cde_jep character varying(256),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_jep_cde OWNER TO nvoip;

--
-- Name: sdmr_jep_cde_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_jep_cde_vw AS
 SELECT a.cde_jep,
    b.des_cde_jep
   FROM ( SELECT sdmr_jep_cde.cde_jep,
            max(sdmr_jep_cde.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_jep_cde
          WHERE (sdmr_jep_cde.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_jep_cde.cde_jep) a,
    localds2.sdmr_jep_cde b
  WHERE (((a.cde_jep)::text = (b.cde_jep)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_jep_cde_vw OWNER TO nvoip;

--
-- Name: sdmr_lob; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_lob (
    cde_lob character varying(3) NOT NULL,
    des_lob character varying(20),
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    CONSTRAINT sdmr_lob_csn01 CHECK (((cde_lob)::text = ANY ((ARRAY['CMR'::character varying, 'NTL'::character varying, 'WLS'::character varying, 'GLB'::character varying])::text[])))
);


ALTER TABLE localds2.sdmr_lob OWNER TO nvoip;

--
-- Name: sdmr_lob_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_lob_vw AS
 SELECT sdmr_lob.cde_lob,
    sdmr_lob.des_lob
   FROM localds2.sdmr_lob;


ALTER TABLE localds2.sdmr_lob_vw OWNER TO nvoip;

--
-- Name: sdmr_mkt_are; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_mkt_are (
    cde_are_mkt character(3) NOT NULL,
    cde_ste character(2) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    nme_cty character varying(30) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_mkt_are OWNER TO nvoip;

--
-- Name: sdmr_mkt_are_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_mkt_are_vw AS
 SELECT a.cde_are_mkt,
    a.cde_ste,
    b.nme_cty
   FROM ( SELECT sdmr_mkt_are.cde_are_mkt,
            sdmr_mkt_are.cde_ste
           FROM localds2.sdmr_mkt_are
          WHERE (sdmr_mkt_are.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_mkt_are.cde_are_mkt, sdmr_mkt_are.cde_ste) a,
    localds2.sdmr_mkt_are b
  WHERE ((a.cde_are_mkt = b.cde_are_mkt) AND (a.cde_ste = b.cde_ste));


ALTER TABLE localds2.sdmr_mkt_are_vw OWNER TO nvoip;

--
-- Name: sdmr_ocn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_ocn (
    nbr_ocn character varying(4) NOT NULL,
    idn_pvd_srv character varying(4) NOT NULL,
    nme_ocn character varying(50),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    CONSTRAINT sdmr_ocn_csn01 CHECK (((idn_pvd_srv)::text = ANY ((ARRAY['7227'::character varying, '7228'::character varying, '7229'::character varying, '7149'::character varying])::text[])))
);


ALTER TABLE localds2.sdmr_ocn OWNER TO nvoip;

--
-- Name: sdmr_ocn_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_ocn_vw AS
 SELECT sdmr_ocn.nbr_ocn,
    sdmr_ocn.idn_pvd_srv,
    sdmr_ocn.nme_ocn
   FROM localds2.sdmr_ocn;


ALTER TABLE localds2.sdmr_ocn_vw OWNER TO nvoip;

--
-- Name: sdmr_qul_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_qul_cde (
    cde_qul character varying(6) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_cde_qul character varying(30) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_qul_cde OWNER TO nvoip;

--
-- Name: sdmr_qul_cde_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_qul_cde_vw AS
 SELECT a.cde_qul,
    b.des_cde_qul
   FROM ( SELECT sdmr_qul_cde.cde_qul
           FROM localds2.sdmr_qul_cde
          WHERE (sdmr_qul_cde.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_qul_cde.cde_qul) a,
    localds2.sdmr_qul_cde b
  WHERE ((a.cde_qul)::text = (b.cde_qul)::text);


ALTER TABLE localds2.sdmr_qul_cde_vw OWNER TO nvoip;

--
-- Name: sdmr_rev_loc_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_rev_loc_cde (
    cde_loc_rev character varying(3) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    cde_grp_loc_rev character varying(5) NOT NULL,
    grp_loc_rev_dtx_eff timestamp with time zone NOT NULL,
    dtx_inatv timestamp with time zone,
    idn_prs_inatv character(1),
    idn_usr_upd character varying(10),
    dtx_las_upd timestamp with time zone,
    CONSTRAINT sdmr_rev_loc_cde_csn01 CHECK ((idn_prs_inatv = ANY (ARRAY['P'::bpchar, 'U'::bpchar])))
);


ALTER TABLE localds2.sdmr_rev_loc_cde OWNER TO nvoip;

--
-- Name: sdmr_rev_loc_cde_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_rev_loc_cde_vw AS
 SELECT a.cde_loc_rev,
    b.cde_grp_loc_rev
   FROM ( SELECT sdmr_rev_loc_cde.cde_loc_rev,
            max(sdmr_rev_loc_cde.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_rev_loc_cde
          WHERE (sdmr_rev_loc_cde.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_rev_loc_cde.cde_loc_rev) a,
    localds2.sdmr_rev_loc_cde b
  WHERE (((a.cde_loc_rev)::text = (b.cde_loc_rev)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_rev_loc_cde_vw OWNER TO nvoip;

--
-- Name: sdmr_srv_exc_cde; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_srv_exc_cde (
    nbr_npa character varying(3) NOT NULL,
    nbr_nxx character varying(3) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    cde_ste character varying(2),
    nbr_hdg_pge_yel character varying(3),
    cde_exc character varying(4),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_srv_exc_cde OWNER TO nvoip;

--
-- Name: sdmr_srv_exc_cde_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_srv_exc_cde_vw AS
 SELECT a.nbr_npa,
    a.nbr_nxx,
    b.cde_ste,
    b.nbr_hdg_pge_yel,
    b.cde_exc
   FROM ( SELECT sdmr_srv_exc_cde.nbr_npa,
            sdmr_srv_exc_cde.nbr_nxx
           FROM localds2.sdmr_srv_exc_cde
          WHERE (sdmr_srv_exc_cde.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_srv_exc_cde.nbr_npa, sdmr_srv_exc_cde.nbr_nxx) a,
    localds2.sdmr_srv_exc_cde b
  WHERE (((a.nbr_npa)::text = (b.nbr_npa)::text) AND ((a.nbr_nxx)::text = (b.nbr_nxx)::text));


ALTER TABLE localds2.sdmr_srv_exc_cde_vw OWNER TO nvoip;

--
-- Name: sdmr_srv_pvd; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_srv_pvd (
    idn_pvd_srv character varying(4) NOT NULL,
    des_pvd_srv character varying(50),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    typ_pvd_srv character(1) NOT NULL,
    idx_lec character varying(3)
);


ALTER TABLE localds2.sdmr_srv_pvd OWNER TO nvoip;

--
-- Name: sdmr_srv_pvd_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_srv_pvd_vw AS
 SELECT sdmr_srv_pvd.idn_pvd_srv,
    sdmr_srv_pvd.typ_pvd_srv,
    sdmr_srv_pvd.des_pvd_srv,
    sdmr_srv_pvd.idx_lec
   FROM localds2.sdmr_srv_pvd;


ALTER TABLE localds2.sdmr_srv_pvd_vw OWNER TO nvoip;

--
-- Name: sdmr_tbl_idn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_tbl_idn (
    typ_tbl character varying(30) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_tbl character varying(50) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_tbl_idn OWNER TO nvoip;

--
-- Name: sdmr_tbl_idn_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_tbl_idn_vw AS
 SELECT sdmr_tbl_idn.typ_tbl,
    sdmr_tbl_idn.des_tbl
   FROM localds2.sdmr_tbl_idn;


ALTER TABLE localds2.sdmr_tbl_idn_vw OWNER TO nvoip;

--
-- Name: sdmr_tnl; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_tnl (
    idn_tsk character varying(4) NOT NULL,
    idn_atr character varying(60) NOT NULL,
    val_wcm character varying(100) NOT NULL,
    idn_trdpt character varying(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    val_otp character varying(100) NOT NULL,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
)
WITH (fillfactor='80');


ALTER TABLE localds2.sdmr_tnl OWNER TO nvoip;

--
-- Name: sdmr_tnl_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_tnl_vw AS
 SELECT a.idn_tsk,
    a.idn_atr,
    a.val_wcm,
    a.idn_trdpt,
    b.val_otp
   FROM ( SELECT sdmr_tnl.idn_tsk,
            sdmr_tnl.idn_atr,
            sdmr_tnl.val_wcm,
            sdmr_tnl.idn_trdpt,
            max(sdmr_tnl.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_tnl
          WHERE (sdmr_tnl.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_tnl.idn_tsk, sdmr_tnl.idn_atr, sdmr_tnl.val_wcm, sdmr_tnl.idn_trdpt) a,
    localds2.sdmr_tnl b
  WHERE (((a.idn_tsk)::text = (b.idn_tsk)::text) AND ((a.idn_atr)::text = (b.idn_atr)::text) AND ((a.val_wcm)::text = (b.val_wcm)::text) AND ((a.idn_trdpt)::text = (b.idn_trdpt)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_tnl_vw OWNER TO nvoip;

--
-- Name: sdmr_tra_sts; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_tra_sts (
    cde_tcsi character(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_tcsi character varying(35) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_tra_sts OWNER TO nvoip;

--
-- Name: sdmr_tra_sts_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_tra_sts_vw AS
 SELECT a.cde_tcsi,
    b.des_tcsi
   FROM ( SELECT sdmr_tra_sts.cde_tcsi,
            max(sdmr_tra_sts.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_tra_sts
          WHERE (sdmr_tra_sts.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_tra_sts.cde_tcsi) a,
    localds2.sdmr_tra_sts b
  WHERE ((a.cde_tcsi = b.cde_tcsi) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_tra_sts_vw OWNER TO nvoip;

--
-- Name: sdmr_trdpt; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_trdpt (
    idn_trdpt character varying(4) NOT NULL,
    des_trdpt character varying(50),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_trdpt OWNER TO nvoip;

--
-- Name: sdmr_trdpt_hol; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_trdpt_hol (
    idn_trdpt character varying(4) NOT NULL,
    dtx_hol timestamp with time zone NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_hol character varying(25),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_trdpt_hol OWNER TO nvoip;

--
-- Name: sdmr_trdpt_hol_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_trdpt_hol_vw AS
 SELECT a.idn_trdpt,
    a.dtx_hol,
    a.des_hol
   FROM ( SELECT sdmr_trdpt_hol.idn_trdpt,
            max(sdmr_trdpt_hol.dtx_eff) AS dtx_eff,
            sdmr_trdpt_hol.dtx_hol,
            sdmr_trdpt_hol.des_hol
           FROM localds2.sdmr_trdpt_hol
          WHERE (sdmr_trdpt_hol.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_trdpt_hol.idn_trdpt, sdmr_trdpt_hol.dtx_hol, sdmr_trdpt_hol.des_hol) a,
    localds2.sdmr_trdpt_hol b
  WHERE (((a.idn_trdpt)::text = (b.idn_trdpt)::text) AND (a.dtx_eff = b.dtx_eff) AND (a.dtx_hol = b.dtx_hol));


ALTER TABLE localds2.sdmr_trdpt_hol_vw OWNER TO nvoip;

--
-- Name: sdmr_trdpt_tat; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_trdpt_tat (
    idn_trdpt character varying(4) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    cde_typ_msg character varying(4) NOT NULL,
    cde_uom_tat character varying(3) NOT NULL,
    nbr_frq_tat bigint NOT NULL,
    cde_zon_tmx character varying(2),
    ind_ppt_dsv character(1),
    tmx_sta timestamp with time zone,
    tmx_end timestamp with time zone,
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    CONSTRAINT sdmr_trdpt_tat_csn01 CHECK (((cde_typ_msg)::text = ANY ((ARRAY['CONF'::character varying, 'DECC'::character varying, 'REF'::character varying])::text[]))),
    CONSTRAINT sdmr_trdpt_tat_csn02 CHECK (((cde_uom_tat)::text = ANY ((ARRAY['DAY'::character varying, 'HR'::character varying, 'MIN'::character varying])::text[]))),
    CONSTRAINT sdmr_trdpt_tat_csn03 CHECK (((cde_zon_tmx)::text = ANY ((ARRAY['ET'::character varying, 'CT'::character varying, 'MT'::character varying, 'PT'::character varying])::text[])))
);


ALTER TABLE localds2.sdmr_trdpt_tat OWNER TO nvoip;

--
-- Name: sdmr_trdpt_tat_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_trdpt_tat_vw AS
 SELECT a.idn_trdpt,
    a.cde_typ_msg,
    a.cde_uom_tat,
    a.nbr_frq_tat,
    a.cde_zon_tmx,
    a.ind_ppt_dsv,
    a.tmx_sta,
    a.tmx_end
   FROM ( SELECT sdmr_trdpt_tat.idn_trdpt,
            max(sdmr_trdpt_tat.dtx_eff) AS dtx_eff,
            sdmr_trdpt_tat.cde_typ_msg,
            sdmr_trdpt_tat.cde_uom_tat,
            sdmr_trdpt_tat.nbr_frq_tat,
            sdmr_trdpt_tat.cde_zon_tmx,
            sdmr_trdpt_tat.ind_ppt_dsv,
            sdmr_trdpt_tat.tmx_sta,
            sdmr_trdpt_tat.tmx_end
           FROM localds2.sdmr_trdpt_tat
          WHERE (sdmr_trdpt_tat.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_trdpt_tat.idn_trdpt, sdmr_trdpt_tat.cde_typ_msg, sdmr_trdpt_tat.cde_uom_tat, sdmr_trdpt_tat.nbr_frq_tat, sdmr_trdpt_tat.cde_zon_tmx, sdmr_trdpt_tat.ind_ppt_dsv, sdmr_trdpt_tat.tmx_sta, sdmr_trdpt_tat.tmx_end) a,
    localds2.sdmr_trdpt_tat b
  WHERE (((a.idn_trdpt)::text = (b.idn_trdpt)::text) AND (a.dtx_eff = b.dtx_eff) AND ((a.cde_typ_msg)::text = (b.cde_typ_msg)::text));


ALTER TABLE localds2.sdmr_trdpt_tat_vw OWNER TO nvoip;

--
-- Name: sdmr_trdpt_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_trdpt_vw AS
 SELECT sdmr_trdpt.idn_trdpt,
    sdmr_trdpt.des_trdpt
   FROM localds2.sdmr_trdpt;


ALTER TABLE localds2.sdmr_trdpt_vw OWNER TO nvoip;

--
-- Name: sdmr_ttb; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_ttb (
    typ_tbl character varying(30) NOT NULL,
    val_tbl character varying(50) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    des_val character varying(512) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL,
    idn_usr_upd character varying(10) NOT NULL
);


ALTER TABLE localds2.sdmr_ttb OWNER TO nvoip;

--
-- Name: sdmr_ttb_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_ttb_vw AS
 SELECT a.typ_tbl,
    a.val_tbl,
    b.des_val
   FROM ( SELECT sdmr_ttb.typ_tbl,
            sdmr_ttb.val_tbl,
            max(sdmr_ttb.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_ttb
          WHERE (sdmr_ttb.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_ttb.typ_tbl, sdmr_ttb.val_tbl) a,
    localds2.sdmr_ttb b
  WHERE (((a.typ_tbl)::text = (b.typ_tbl)::text) AND ((a.val_tbl)::text = (b.val_tbl)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_ttb_vw OWNER TO nvoip;

--
-- Name: sdmr_vdr_ctc; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_vdr_ctc (
    nbr_vdr character varying(6) NOT NULL,
    idn_rol_ctc_vdr character varying(15) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    nme_ctc_vdr character varying(30) NOT NULL,
    adr_one_lne character varying(25),
    adr_two_lne character varying(25),
    nme_cty_vdr character varying(15),
    cde_ste_vdr character(2),
    cde_zip_vdr character(10),
    tnb_vdr character(10),
    nbr_fax_vdr character(10),
    dtx_las_upd timestamp with time zone,
    idn_usr_upd character varying(10)
);


ALTER TABLE localds2.sdmr_vdr_ctc OWNER TO nvoip;

--
-- Name: sdmr_vdr_ctc_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_vdr_ctc_vw AS
 SELECT a.nbr_vdr,
    a.idn_rol_ctc_vdr,
    b.nme_ctc_vdr,
    b.adr_one_lne,
    b.adr_two_lne,
    b.nme_cty_vdr,
    b.cde_ste_vdr,
    b.cde_zip_vdr,
    b.tnb_vdr,
    b.nbr_fax_vdr
   FROM ( SELECT sdmr_vdr_ctc.nbr_vdr,
            sdmr_vdr_ctc.idn_rol_ctc_vdr,
            max(sdmr_vdr_ctc.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_vdr_ctc
          WHERE (sdmr_vdr_ctc.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_vdr_ctc.nbr_vdr, sdmr_vdr_ctc.idn_rol_ctc_vdr) a,
    localds2.sdmr_vdr_ctc b
  WHERE (((a.nbr_vdr)::text = (b.nbr_vdr)::text) AND ((a.idn_rol_ctc_vdr)::text = (b.idn_rol_ctc_vdr)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_vdr_ctc_vw OWNER TO nvoip;

--
-- Name: sdmr_vdr_idn; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_vdr_idn (
    nbr_vdr character varying(6) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    nme_vdr character varying(25) NOT NULL,
    cde_cic_vdr character(5) NOT NULL,
    idn_com_vdr character(4) NOT NULL,
    nbr_acn_vdr character varying(15) NOT NULL,
    idn_acna_vdr character(4) NOT NULL,
    dtx_las_upd timestamp with time zone,
    idn_usr_upd character varying(10)
);


ALTER TABLE localds2.sdmr_vdr_idn OWNER TO nvoip;

--
-- Name: sdmr_vdr_idn_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_vdr_idn_vw AS
 SELECT a.nbr_vdr,
    b.nme_vdr,
    b.cde_cic_vdr,
    b.idn_com_vdr,
    b.nbr_acn_vdr,
    b.idn_acna_vdr
   FROM ( SELECT sdmr_vdr_idn.nbr_vdr
           FROM localds2.sdmr_vdr_idn
          WHERE (sdmr_vdr_idn.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_vdr_idn.nbr_vdr) a,
    localds2.sdmr_vdr_idn b
  WHERE ((a.nbr_vdr)::text = (b.nbr_vdr)::text);


ALTER TABLE localds2.sdmr_vdr_idn_vw OWNER TO nvoip;

--
-- Name: sdmr_vdr_qul; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_vdr_qul (
    nbr_vdr character varying(6) NOT NULL,
    cde_qul character varying(6) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    idn_rqd_cde_qul character(1) NOT NULL,
    val_cde_qul character(3) NOT NULL,
    dtx_las_upd timestamp with time zone,
    idn_usr_upd character varying(10)
);


ALTER TABLE localds2.sdmr_vdr_qul OWNER TO nvoip;

--
-- Name: sdmr_vdr_qul_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_vdr_qul_vw AS
 SELECT a.nbr_vdr,
    a.cde_qul,
    b.idn_rqd_cde_qul,
    b.val_cde_qul
   FROM ( SELECT sdmr_vdr_qul.nbr_vdr,
            sdmr_vdr_qul.cde_qul,
            max(sdmr_vdr_qul.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_vdr_qul
          WHERE (sdmr_vdr_qul.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_vdr_qul.nbr_vdr, sdmr_vdr_qul.cde_qul) a,
    localds2.sdmr_vdr_qul b
  WHERE (((a.nbr_vdr)::text = (b.nbr_vdr)::text) AND ((a.cde_qul)::text = (b.cde_qul)::text) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_vdr_qul_vw OWNER TO nvoip;

--
-- Name: sdmr_wls_opr_srv; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.sdmr_wls_opr_srv (
    idn_lsp character varying(4) NOT NULL,
    cde_loc_pln_rat character(2) NOT NULL,
    dtx_eff timestamp with time zone NOT NULL,
    nme_lsp character varying(25),
    cde_car character varying(4) NOT NULL,
    cde_pln_rat character varying(2),
    tnb_srv_cus character(10),
    tnb_rfd character(10),
    tnb_rpr character(10),
    idn_usr_upd character varying(10) NOT NULL,
    dtx_las_upd timestamp with time zone NOT NULL
);


ALTER TABLE localds2.sdmr_wls_opr_srv OWNER TO nvoip;

--
-- Name: sdmr_wls_opr_srv_vw; Type: VIEW; Schema: localds2; Owner: nvoip
--

CREATE VIEW localds2.sdmr_wls_opr_srv_vw AS
 SELECT a.idn_lsp,
    a.cde_loc_pln_rat,
    b.nme_lsp,
    b.cde_car,
    b.cde_pln_rat,
    b.tnb_srv_cus,
    b.tnb_rfd,
    b.tnb_rpr
   FROM ( SELECT sdmr_wls_opr_srv.idn_lsp,
            sdmr_wls_opr_srv.cde_loc_pln_rat,
            max(sdmr_wls_opr_srv.dtx_eff) AS dtx_eff
           FROM localds2.sdmr_wls_opr_srv
          WHERE (sdmr_wls_opr_srv.dtx_eff <= LOCALTIMESTAMP)
          GROUP BY sdmr_wls_opr_srv.idn_lsp, sdmr_wls_opr_srv.cde_loc_pln_rat) a,
    localds2.sdmr_wls_opr_srv b
  WHERE (((a.idn_lsp)::text = (b.idn_lsp)::text) AND (a.cde_loc_pln_rat = b.cde_loc_pln_rat) AND (a.dtx_eff = b.dtx_eff));


ALTER TABLE localds2.sdmr_wls_opr_srv_vw OWNER TO nvoip;

--
-- Name: seq_comment_seq; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_comment_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_comment_seq OWNER TO nvoip;

--
-- Name: seq_hist_nbr_seq_tsk; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_hist_nbr_seq_tsk
    START WITH 315685346
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 20;


ALTER TABLE localds2.seq_hist_nbr_seq_tsk OWNER TO nvoip;

--
-- Name: seq_idn_bar; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idn_bar
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idn_bar OWNER TO nvoip;

--
-- Name: seq_idn_cpe; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idn_cpe
    START WITH 160736
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idn_cpe OWNER TO nvoip;

--
-- Name: seq_idn_t1; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idn_t1
    START WITH 2173222
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idn_t1 OWNER TO nvoip;

--
-- Name: seq_idn_tkg; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idn_tkg
    START WITH 28512452
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idn_tkg OWNER TO nvoip;

--
-- Name: seq_idx_adr; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_adr
    START WITH 421585308
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_adr OWNER TO nvoip;

--
-- Name: seq_idx_dir; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_dir
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_dir OWNER TO nvoip;

--
-- Name: seq_idx_fer_loc_srv; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_fer_loc_srv
    START WITH 22490663
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_fer_loc_srv OWNER TO nvoip;

--
-- Name: seq_idx_lne_acs; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_lne_acs
    START WITH 5840221
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_lne_acs OWNER TO nvoip;

--
-- Name: seq_idx_nme; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_nme
    START WITH 689800350
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_nme OWNER TO nvoip;

--
-- Name: seq_idx_ord; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_ord
    START WITH 22489326
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_ord OWNER TO nvoip;

--
-- Name: seq_idx_ord_wrk; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_ord_wrk
    START WITH 22438474
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_ord_wrk OWNER TO nvoip;

--
-- Name: seq_idx_reject; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_reject
    START WITH 12838735
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_reject OWNER TO nvoip;

--
-- Name: seq_idx_response; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_response
    START WITH 23825429
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_response OWNER TO nvoip;

--
-- Name: seq_idx_tnb; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_idx_tnb
    START WITH 276637101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_idx_tnb OWNER TO nvoip;

--
-- Name: seq_lsr_admin_response; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_admin_response
    START WITH 21715316
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_admin_response OWNER TO nvoip;

--
-- Name: seq_lsr_am_task_info; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_am_task_info
    START WITH 13708665
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_am_task_info OWNER TO nvoip;

--
-- Name: seq_lsr_am_task_info_report; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_am_task_info_report
    START WITH 132015938
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_am_task_info_report OWNER TO nvoip;

--
-- Name: seq_lsr_dl_response; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_dl_response
    START WITH 6261687
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_dl_response OWNER TO nvoip;

--
-- Name: seq_lsr_np_response; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_np_response
    START WITH 6736392
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_np_response OWNER TO nvoip;

--
-- Name: seq_lsr_pon_tracking; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_pon_tracking
    START WITH 5634480
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_pon_tracking OWNER TO nvoip;

--
-- Name: seq_lsr_pon_tracking_report; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_pon_tracking_report
    START WITH 22315199
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_pon_tracking_report OWNER TO nvoip;

--
-- Name: seq_lsr_reject_detail; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_reject_detail
    START WITH 11692441
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_reject_detail OWNER TO nvoip;

--
-- Name: seq_lsr_rsp_audit_trck; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_lsr_rsp_audit_trck
    START WITH 23648361
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_lsr_rsp_audit_trck OWNER TO nvoip;

--
-- Name: seq_nbr_ord_ei; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_nbr_ord_ei
    START WITH 23219447
    INCREMENT BY 1
    MINVALUE 1000
    MAXVALUE 999999999
    CACHE 20
    CYCLE;


ALTER TABLE localds2.seq_nbr_ord_ei OWNER TO nvoip;

--
-- Name: seq_nbr_seq_comments; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_nbr_seq_comments
    START WITH 34380864
    INCREMENT BY 1
    MINVALUE 1000
    MAXVALUE 999999999
    CACHE 20
    CYCLE;


ALTER TABLE localds2.seq_nbr_seq_comments OWNER TO nvoip;

--
-- Name: seq_nbr_seq_history; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_nbr_seq_history
    START WITH 45206934
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 20;


ALTER TABLE localds2.seq_nbr_seq_history OWNER TO nvoip;

--
-- Name: seq_ossr_tra_log_his; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_ossr_tra_log_his
    START WITH 184859548
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_ossr_tra_log_his OWNER TO nvoip;

--
-- Name: seq_ossr_tsk_dri; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_ossr_tsk_dri
    START WITH 19468935
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_ossr_tsk_dri OWNER TO nvoip;

--
-- Name: seq_ossr_tsk_dri_report; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_ossr_tsk_dri_report
    START WITH 54609260
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 25;


ALTER TABLE localds2.seq_ossr_tsk_dri_report OWNER TO nvoip;

--
-- Name: seq_tnb_cmn; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.seq_tnb_cmn
    START WITH 191877240
    INCREMENT BY 1
    MINVALUE 100
    MAXVALUE 999999999999999
    CACHE 25
    CYCLE;


ALTER TABLE localds2.seq_tnb_cmn OWNER TO nvoip;

--
-- Name: seqnumtrack; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.seqnumtrack (
    name character varying(50),
    value bigint
);


ALTER TABLE localds2.seqnumtrack OWNER TO nvoip;

--
-- Name: soistatehosts; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.soistatehosts (
    login character varying(50) NOT NULL,
    hostip character varying(50) NOT NULL,
    state character varying(50) NOT NULL,
    seqno bigint NOT NULL,
    transmission_flag character varying(1),
    last_modified timestamp with time zone NOT NULL,
    groupno bigint,
    comments character varying(1000),
    sequences character varying(1000),
    upload_dir character varying(1000),
    download_dir character varying(1000),
    env character varying(10)
);


ALTER TABLE localds2.soistatehosts OWNER TO nvoip;

--
-- Name: tds_event; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.tds_event (
    event_id bigint NOT NULL,
    user_id character varying(20),
    event_type character varying(50),
    method_name character varying(100),
    key character varying(20),
    inserted timestamp with time zone,
    initiating_event_id bigint
);


ALTER TABLE localds2.tds_event OWNER TO nvoip;

--
-- Name: tds_event_seq; Type: SEQUENCE; Schema: localds2; Owner: nvoip
--

CREATE SEQUENCE localds2.tds_event_seq
    START WITH 1095839488
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 20;


ALTER TABLE localds2.tds_event_seq OWNER TO nvoip;

--
-- Name: temp_ossr_tnb_11_15_13; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.temp_ossr_tnb_11_15_13 (
    ind_opt_sts_dtv character(1),
    idn_grp_ctx character(8),
    tnb_bil character(10),
    tnb_rcf_inp character(10),
    qty_day_rfl_wcm smallint,
    idx_tnb_old character varying(12),
    qty_pth_rcf integer,
    tnb_ren_lec character(10),
    nbr_sta_dia integer,
    flg_req_jck character(1),
    ind_tnb_sec_pri character(1),
    idx_tnb character varying(12) NOT NULL,
    idx_lec character varying(3),
    idx_ord character varying(13) NOT NULL,
    idn_lne_acs character varying(12),
    idn_tkg character varying(12),
    nbr_grp_sub_ctx smallint,
    tnb character(10) NOT NULL,
    cde_atn_tnb character(1) NOT NULL,
    idx_opt_pln_cll character varying(20),
    tnb_rfl_wcm character(10),
    ind_drc_cll character(1) NOT NULL,
    dtx_eff_svf timestamp with time zone,
    typ_tnb_por character(3),
    ind_tnb_new_old character(1),
    dtx_foc_lnp_inp timestamp with time zone,
    ind_tnk_or_lne character(1),
    nbr_dig_pfx character varying(10),
    ind_pos_atdnt smallint,
    nme_sta character varying(25),
    cde_tmt_lne smallint,
    cde_jck character varying(5),
    dig_opl smallint,
    idx_ptn_rgr smallint,
    nme_lec character varying(20),
    tnb_bil_lec character(10),
    ind_ali_ps character(1),
    cde_atn_sup_tnb character(1),
    cde_atn_dta_tnb character varying(3),
    idx_rsv_tnb character varying(10),
    tnb_old character(10),
    ind_adr character(1),
    nbr_tkg_911 character varying(11),
    nbr_nme_rte_off character varying(14),
    nbr_nme_rte_off_old character varying(14),
    nbr_to_fwd_vbl character varying(18),
    qty_path_vbl smallint,
    nme_grp_ali_ps character varying(6),
    ind_prty_cll_vbl character varying(7),
    idx_app_cll smallint,
    tnb_pri character(10),
    cde_pic character(5),
    cde_lpic character(5),
    flg_ld_dom_otb_blk character(1),
    flg_ld_interlata_otb_blk character(1),
    flg_ld_intralata_otb_blk character(1),
    flg_local_otb_blk character(1),
    flg_ld_intnl_otb_blk character(1),
    flg_asi_dir_blk character(1),
    flg_otb_all_blk character(1),
    flg_inb_all_blk character(1),
    flg_911_but_all_blk character(1),
    flg_svc_911_blk character(1),
    idx_tri bigint,
    ind_911_unb character(1),
    ind_inv_tnb character(1),
    tnb_split_npa character(10),
    nbr_nme_rte_off_npa character varying(14),
    key_tkg_psu_npa character varying(12),
    nbr_tkg_npa character varying(11),
    nme_grp_ali_ps_npa character varying(6),
    ind_ord_voip character(1),
    tnb_bil_lec_old character(10),
    ind_timr_mdm character(1)
);


ALTER TABLE localds2.temp_ossr_tnb_11_15_13 OWNER TO nvoip;

--
-- Name: tnb_frontier_chng_4302020; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.tnb_frontier_chng_4302020 (
    idx_tnb character varying(12) NOT NULL,
    idx_lec character varying(3),
    idx_ord character varying(13) NOT NULL,
    idn_lne_acs character varying(12),
    idn_tkg character varying(12),
    idn_grp_ctx character(8),
    nbr_grp_sub_ctx smallint,
    tnb character(10) NOT NULL,
    tnb_bil character(10),
    cde_atn_tnb character(1) NOT NULL,
    idx_opt_pln_cll character varying(20),
    tnb_rcf_inp character(10),
    tnb_rfl_wcm character(10),
    qty_day_rfl_wcm smallint,
    ind_drc_cll character(1) NOT NULL,
    dtx_eff_svf timestamp with time zone,
    idx_tnb_old character varying(12),
    typ_tnb_por character(3),
    ind_tnb_new_old character(1),
    qty_pth_rcf integer,
    dtx_foc_lnp_inp timestamp with time zone,
    tnb_ren_lec character(10),
    ind_tnk_or_lne character(1),
    nbr_dig_pfx character varying(10),
    ind_pos_atdnt smallint,
    nbr_sta_dia integer,
    nme_sta character varying(25),
    cde_tmt_lne smallint,
    flg_req_jck character(1),
    cde_jck character varying(5),
    dig_opl smallint,
    ind_tnb_sec_pri character(1),
    idx_ptn_rgr smallint,
    ind_opt_sts_dtv character(1),
    tnb_bil_lec character(10),
    ind_ali_ps character(1),
    cde_atn_sup_tnb character(1),
    cde_atn_dta_tnb character varying(3),
    idx_rsv_tnb character varying(10),
    tnb_old character(10),
    ind_adr character(1),
    nbr_tkg_911 character varying(11),
    nbr_nme_rte_off character varying(14),
    nbr_nme_rte_off_old character varying(14),
    nbr_to_fwd_vbl character varying(18),
    qty_path_vbl smallint,
    nme_grp_ali_ps character varying(6),
    ind_prty_cll_vbl character varying(7),
    idx_app_cll smallint,
    tnb_pri character(10),
    cde_pic character(5),
    cde_lpic character(5),
    flg_ld_dom_otb_blk character(1),
    flg_ld_interlata_otb_blk character(1),
    flg_ld_intralata_otb_blk character(1),
    flg_local_otb_blk character(1),
    flg_ld_intnl_otb_blk character(1),
    flg_asi_dir_blk character(1),
    flg_otb_all_blk character(1),
    flg_inb_all_blk character(1),
    flg_911_but_all_blk character(1),
    flg_svc_911_blk character(1),
    idx_tri bigint,
    ind_911_unb character(1),
    ind_inv_tnb character(1),
    tnb_split_npa character(10),
    nbr_nme_rte_off_npa character varying(14),
    key_tkg_psu_npa character varying(12),
    nbr_tkg_npa character varying(11),
    nme_grp_ali_ps_npa character varying(6),
    ind_ord_voip character(1),
    tnb_bil_lec_old character(10),
    ind_timr_mdm character(1),
    ali_provider_name character varying(3)
);


ALTER TABLE localds2.tnb_frontier_chng_4302020 OWNER TO nvoip;

--
-- Name: user_login_audit; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.user_login_audit (
    user_id character varying(20) NOT NULL,
    login_desc character varying(20),
    login_time timestamp without time zone
);


ALTER TABLE localds2.user_login_audit OWNER TO nvoip;

--
-- Name: users; Type: TABLE; Schema: localds2; Owner: nvoip
--

CREATE TABLE localds2.users (
    owner character varying(40) NOT NULL,
    user_id character varying(100) NOT NULL,
    status character varying(1) NOT NULL
);


ALTER TABLE localds2.users OWNER TO nvoip;

--
-- Name: acela_admin_his_chg acela_admin_his_chg_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_admin_his_chg
    ADD CONSTRAINT acela_admin_his_chg_pkey PRIMARY KEY (idn_his_chg);


--
-- Name: acela_admin_org acela_admin_org_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_admin_org
    ADD CONSTRAINT acela_admin_org_pkey PRIMARY KEY (nme_org);


--
-- Name: acela_admin_org_to_staffadmin acela_admin_org_to_staffadmin_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_admin_org_to_staffadmin
    ADD CONSTRAINT acela_admin_org_to_staffadmin_pkey PRIMARY KEY (idn_admin_staff, nme_org);


--
-- Name: acela_admin_org_to_workpool acela_admin_org_to_workpool_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_admin_org_to_workpool
    ADD CONSTRAINT acela_admin_org_to_workpool_pkey PRIMARY KEY (nme_org, nme_pool_wrk);


--
-- Name: acela_admin_staffadmin acela_admin_staffadmin_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_admin_staffadmin
    ADD CONSTRAINT acela_admin_staffadmin_pkey PRIMARY KEY (idn_admin_staff);


--
-- Name: acela_am_exception_info acela_am_exception_info_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_am_exception_info
    ADD CONSTRAINT acela_am_exception_info_pkey PRIMARY KEY (nbr_order, nbr_supp_order, idn_origin_order, idn_exception, nme_element);


--
-- Name: acela_am_exception acela_am_exception_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_am_exception
    ADD CONSTRAINT acela_am_exception_pkey PRIMARY KEY (nbr_order, nbr_supp_order, idn_origin_order, idn_exception);


--
-- Name: acela_am_version acela_am_version_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_am_version
    ADD CONSTRAINT acela_am_version_pkey PRIMARY KEY (nbr_order, nbr_supp_order, idn_origin_order);


--
-- Name: acela_det_org acela_det_org_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_det_org
    ADD CONSTRAINT acela_det_org_pkey PRIMARY KEY (nme_sys_failed, cde_sys_failed, nme_tsk_failed);


--
-- Name: acela_det_pool_org acela_det_pool_org_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_det_pool_org
    ADD CONSTRAINT acela_det_pool_org_pkey PRIMARY KEY (nme_org, nbr_parameter);


--
-- Name: acela_det_pool_work acela_det_pool_work_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_det_pool_work
    ADD CONSTRAINT acela_det_pool_work_pkey PRIMARY KEY (nme_org, nbr_pool_wrk);


--
-- Name: acela_ord_comment acela_ord_comment_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_ord_comment
    ADD CONSTRAINT acela_ord_comment_pkey PRIMARY KEY (nbr_order, nbr_supp_order, idn_origin_order, seq_comment);


--
-- Name: acela_ord_status acela_ord_status_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_ord_status
    ADD CONSTRAINT acela_ord_status_pkey PRIMARY KEY (idn_response);


--
-- Name: acela_proc_workflow acela_proc_workflow_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_proc_workflow
    ADD CONSTRAINT acela_proc_workflow_pkey PRIMARY KEY (nbr_order, idn_origin_order, nbr_supp_order);


--
-- Name: acela_prov_order acela_prov_order_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_prov_order
    ADD CONSTRAINT acela_prov_order_pkey PRIMARY KEY (nbr_order, cde_svc_prov, cde_atn_prov);


--
-- Name: acela_reg_input acela_reg_input_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_reg_input
    ADD CONSTRAINT acela_reg_input_pkey PRIMARY KEY (idn_registry);


--
-- Name: acela_sequence acela_sequence_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_sequence
    ADD CONSTRAINT acela_sequence_pkey PRIMARY KEY (nme_sequence);


--
-- Name: acela_sys_outage acela_sys_outage_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_sys_outage
    ADD CONSTRAINT acela_sys_outage_pkey PRIMARY KEY (nme_system, dtx_start, dtx_end);


--
-- Name: acela_tcoms_return_code acela_tcoms_return_code_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_tcoms_return_code
    ADD CONSTRAINT acela_tcoms_return_code_pkey PRIMARY KEY (cde_return);


--
-- Name: acela_tsk_response acela_tsk_response_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_tsk_response
    ADD CONSTRAINT acela_tsk_response_pkey PRIMARY KEY (nbr_order, idn_origin_order, nbr_supp_order, nme_task);


--
-- Name: acela_tsk_workflow acela_tsk_workflow_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.acela_tsk_workflow
    ADD CONSTRAINT acela_tsk_workflow_pkey PRIMARY KEY (nbr_order, idn_origin_order, nbr_supp_order, nme_task);


--
-- Name: ei_911_vali_order_comments ei_911_vali_order_comments_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ei_911_vali_order_comments
    ADD CONSTRAINT ei_911_vali_order_comments_pkey PRIMARY KEY (nbr_seq_comments);


--
-- Name: ei_911_vali_order_his ei_911_vali_order_his_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ei_911_vali_order_his
    ADD CONSTRAINT ei_911_vali_order_his_pkey PRIMARY KEY (nbr_seq_history);


--
-- Name: ei_911_vali_order ei_911_vali_order_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ei_911_vali_order
    ADD CONSTRAINT ei_911_vali_order_pkey PRIMARY KEY (nbr_ord_ei);


--
-- Name: lsr_admin_response lsr_admin_response_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_admin_response
    ADD CONSTRAINT lsr_admin_response_pkey PRIMARY KEY (idx_response);


--
-- Name: lsr_am_task_info lsr_am_task_info_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_am_task_info
    ADD CONSTRAINT lsr_am_task_info_pkey PRIMARY KEY (idx_task_am, dtx_task);


--
-- Name: lsr_dl_response lsr_dl_response_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_dl_response
    ADD CONSTRAINT lsr_dl_response_pkey PRIMARY KEY (nbr_pon, nbr_supp_order, nbr_line_dl);


--
-- Name: lsr_lec_sla lsr_lec_sla_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_lec_sla
    ADD CONSTRAINT lsr_lec_sla_pkey PRIMARY KEY (nme_lec, sts_task, nbr_sla);


--
-- Name: lsr_ls_response_info lsr_ls_response_info_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_ls_response_info
    ADD CONSTRAINT lsr_ls_response_info_pkey PRIMARY KEY (idx_response, nbr_lnum);


--
-- Name: lsr_ls_response lsr_ls_response_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_ls_response
    ADD CONSTRAINT lsr_ls_response_pkey PRIMARY KEY (nbr_pon, nbr_supp_order, nbr_line_ls);


--
-- Name: lsr_lsnp_response lsr_lsnp_response_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_lsnp_response
    ADD CONSTRAINT lsr_lsnp_response_pkey PRIMARY KEY (nbr_pon, nbr_supp_order, nbr_line_lsnp);


--
-- Name: lsr_np_response lsr_np_response_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_np_response
    ADD CONSTRAINT lsr_np_response_pkey PRIMARY KEY (nbr_pon, nbr_supp_order, nbr_line_np);


--
-- Name: lsr_pon_tracking lsr_pon_tracking_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_pon_tracking
    ADD CONSTRAINT lsr_pon_tracking_pkey PRIMARY KEY (nbr_pon, tnb_bil_lec, nbr_supp_order);


--
-- Name: lsr_reject_detail lsr_reject_detail_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_reject_detail
    ADD CONSTRAINT lsr_reject_detail_pkey PRIMARY KEY (idx_response, idx_reject);


--
-- Name: lsr_tsk_sts lsr_tsk_sts_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.lsr_tsk_sts
    ADD CONSTRAINT lsr_tsk_sts_pkey PRIMARY KEY (cde_task);


--
-- Name: npar_bas npar_bas_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.npar_bas
    ADD CONSTRAINT npar_bas_pkey PRIMARY KEY (nme_bas);


--
-- Name: npar_bch npar_bch_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.npar_bch
    ADD CONSTRAINT npar_bch_pkey PRIMARY KEY (nbr_bch);


--
-- Name: npar_spi_apl npar_spi_apl_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.npar_spi_apl
    ADD CONSTRAINT npar_spi_apl_pkey PRIMARY KEY (nbr_npa_old, nbr_nxx, nme_bas, nme_tbl, nbr_seq_apl);


--
-- Name: npar_spi npar_spi_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.npar_spi
    ADD CONSTRAINT npar_spi_pkey PRIMARY KEY (nbr_npa_old, nbr_nxx, nbr_npa_new);


--
-- Name: npar_tbl npar_tbl_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.npar_tbl
    ADD CONSTRAINT npar_tbl_pkey PRIMARY KEY (nme_bas, nme_tbl);


--
-- Name: npar_voip_spi npar_voip_spi_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.npar_voip_spi
    ADD CONSTRAINT npar_voip_spi_pkey PRIMARY KEY (cde_sts_split, nbr_npa_from, nbr_nxx_from, key_tkg_psu_from);


--
-- Name: ossr_800_tol_fre ossr_800_tol_fre_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_800_tol_fre
    ADD CONSTRAINT ossr_800_tol_fre_pkey PRIMARY KEY (idx_tnb, tnb_fre_tol);


--
-- Name: ossr_911 ossr_911_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_911
    ADD CONSTRAINT ossr_911_pkey PRIMARY KEY (idx_tnb);


--
-- Name: ossr_acs_lne ossr_acs_lne_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_pkey PRIMARY KEY (idn_lne_acs);


--
-- Name: ossr_acs_lne_svf ossr_acs_lne_svf_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_acs_lne_svf
    ADD CONSTRAINT ossr_acs_lne_svf_pkey PRIMARY KEY (nme_svf, idn_lne_acs);


--
-- Name: ossr_adr ossr_adr_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_adr
    ADD CONSTRAINT ossr_adr_pkey PRIMARY KEY (idx_adr);


--
-- Name: ossr_adr_rol ossr_adr_rol_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_adr_rol
    ADD CONSTRAINT ossr_adr_rol_pkey PRIMARY KEY (cde_rol_adr);


--
-- Name: ossr_atn ossr_atn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_atn
    ADD CONSTRAINT ossr_atn_pkey PRIMARY KEY (cde_atn);


--
-- Name: ossr_car ossr_car_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_car
    ADD CONSTRAINT ossr_car_pkey PRIMARY KEY (cde_cic);


--
-- Name: ossr_chg_cat ossr_chg_cat_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_chg_cat
    ADD CONSTRAINT ossr_chg_cat_pkey PRIMARY KEY (cat_chg);


--
-- Name: ossr_cir_typ ossr_cir_typ_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_cir_typ
    ADD CONSTRAINT ossr_cir_typ_pkey PRIMARY KEY (typ_cir);


--
-- Name: ossr_cpe_dn ossr_cpe_dn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_cpe_dn
    ADD CONSTRAINT ossr_cpe_dn_pkey PRIMARY KEY (idn_cpe, idx_tnb);


--
-- Name: ossr_cpe ossr_cpe_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_cpe
    ADD CONSTRAINT ossr_cpe_pkey PRIMARY KEY (idn_cpe);


--
-- Name: ossr_ctc_tnb ossr_ctc_tnb_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_ctc_tnb
    ADD CONSTRAINT ossr_ctc_tnb_pkey PRIMARY KEY (idx_nme, cat_phn);


--
-- Name: ossr_ctx_grp ossr_ctx_grp_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_ctx_grp
    ADD CONSTRAINT ossr_ctx_grp_pkey PRIMARY KEY (idx_ord, idn_grp_ctx, nbr_grp_sub_ctx);


--
-- Name: ossr_ctx_grp_svf ossr_ctx_grp_svf_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_ctx_grp_svf
    ADD CONSTRAINT ossr_ctx_grp_svf_pkey PRIMARY KEY (idx_ord, idn_grp_ctx, nbr_grp_sub_ctx, cde_svf_ctx, typ_pam_svf_ctx);


--
-- Name: ossr_dir_adr ossr_dir_adr_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_dir_adr
    ADD CONSTRAINT ossr_dir_adr_pkey PRIMARY KEY (idx_tnb, cde_ali, idx_dir, cde_rol_adr, ind_dadl);


--
-- Name: ossr_dir_asi_lst_jrn ossr_dir_asi_lst_jrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_dir_asi_lst_jrn
    ADD CONSTRAINT ossr_dir_asi_lst_jrn_pkey PRIMARY KEY (idx_ord, idx_tnb, cde_ali, idx_dir, ind_dadl);


--
-- Name: ossr_dir_asi_lst ossr_dir_asi_lst_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_dir_asi_lst
    ADD CONSTRAINT ossr_dir_asi_lst_pkey PRIMARY KEY (idx_tnb, cde_ali, idx_dir, ind_dadl);


--
-- Name: ossr_dir_nme ossr_dir_nme_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_dir_nme
    ADD CONSTRAINT ossr_dir_nme_pkey PRIMARY KEY (idx_tnb, cde_ali, idx_dir, cde_rol_nme, ind_dadl);


--
-- Name: ossr_dlv_adr ossr_dlv_adr_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_dlv_adr
    ADD CONSTRAINT ossr_dlv_adr_pkey PRIMARY KEY (idx_ord, ind_adr_dlv_old_new, idx_adr_dlv, typ_adr_dlv);


--
-- Name: ossr_err_cde ossr_err_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_err_cde
    ADD CONSTRAINT ossr_err_cde_pkey PRIMARY KEY (cde_err, nme_src_err);


--
-- Name: ossr_hdg_pge_yel ossr_hdg_pge_yel_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_hdg_pge_yel
    ADD CONSTRAINT ossr_hdg_pge_yel_pkey PRIMARY KEY (idx_tnb, cde_ali, idx_dir, ind_dadl);


--
-- Name: ossr_hg_trm ossr_hg_trm_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_hg_trm
    ADD CONSTRAINT ossr_hg_trm_pkey PRIMARY KEY (idx_ord, tnb_plt, nbr_trm);


--
-- Name: ossr_hun_grp ossr_hun_grp_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_hun_grp
    ADD CONSTRAINT ossr_hun_grp_pkey PRIMARY KEY (idx_ord, tnb_plt);


--
-- Name: ossr_jbs ossr_jbs_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_jbs
    ADD CONSTRAINT ossr_jbs_pkey PRIMARY KEY (cde_jbs);


--
-- Name: ossr_kar_jrn ossr_kar_jrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_kar_jrn
    ADD CONSTRAINT ossr_kar_jrn_pkey PRIMARY KEY (idx_ord, idx_tnb, ind_jur, ind_los_wng);


--
-- Name: ossr_kar ossr_kar_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_kar
    ADD CONSTRAINT ossr_kar_pkey PRIMARY KEY (idx_tnb, ind_jur, ind_los_wng);


--
-- Name: ossr_lec ossr_lec_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lec
    ADD CONSTRAINT ossr_lec_pkey PRIMARY KEY (idx_lec);


--
-- Name: ossr_lid_911_jrn ossr_lid_911_jrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lid_911_jrn
    ADD CONSTRAINT ossr_lid_911_jrn_pkey PRIMARY KEY (idx_ord, idx_tnb);


--
-- Name: ossr_lid_nme ossr_lid_nme_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lid_nme
    ADD CONSTRAINT ossr_lid_nme_pkey PRIMARY KEY (idx_tnb, cde_rol_nme);


--
-- Name: ossr_lid ossr_lid_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lid
    ADD CONSTRAINT ossr_lid_pkey PRIMARY KEY (idx_tnb);


--
-- Name: ossr_lne_svf_pam ossr_lne_svf_pam_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lne_svf_pam
    ADD CONSTRAINT ossr_lne_svf_pam_pkey PRIMARY KEY (nme_svf, idn_lne_acs, typ_pam);


--
-- Name: ossr_lne_typ ossr_lne_typ_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lne_typ
    ADD CONSTRAINT ossr_lne_typ_pkey PRIMARY KEY (cde_typ_lne);


--
-- Name: ossr_lsr_inf ossr_lsr_inf_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lsr_inf
    ADD CONSTRAINT ossr_lsr_inf_pkey PRIMARY KEY (idx_ord, tnb_bil_lec, ind_lsr_spl);


--
-- Name: ossr_lsr_jrn ossr_lsr_jrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lsr_jrn
    ADD CONSTRAINT ossr_lsr_jrn_pkey PRIMARY KEY (idx_ord, idn_fac_acs);


--
-- Name: ossr_lst_txt_typ ossr_lst_txt_typ_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_lst_txt_typ
    ADD CONSTRAINT ossr_lst_txt_typ_pkey PRIMARY KEY (idx_tnb, cde_ali, idx_dir, idn_lst_seq, ind_dadl);


--
-- Name: ossr_nme ossr_nme_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_nme
    ADD CONSTRAINT ossr_nme_pkey PRIMARY KEY (idx_nme);


--
-- Name: ossr_nme_rol ossr_nme_rol_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_nme_rol
    ADD CONSTRAINT ossr_nme_rol_pkey PRIMARY KEY (cde_rol_nme);


--
-- Name: ossr_opr_srv_temp ossr_opr_srv_temp_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_opr_srv_temp
    ADD CONSTRAINT ossr_opr_srv_temp_pkey PRIMARY KEY (idx_tnb);


--
-- Name: ossr_ord ossr_ord_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_ord
    ADD CONSTRAINT ossr_ord_pkey PRIMARY KEY (idx_ord);


--
-- Name: ossr_ord_rep ossr_ord_rep_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_ord_rep
    ADD CONSTRAINT ossr_ord_rep_pkey PRIMARY KEY (idx_ord, cde_rol_nme);


--
-- Name: ossr_ord_sts ossr_ord_sts_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_ord_sts
    ADD CONSTRAINT ossr_ord_sts_pkey PRIMARY KEY (cde_sts_ord);


--
-- Name: ossr_pam ossr_pam_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_pam
    ADD CONSTRAINT ossr_pam_pkey PRIMARY KEY (typ_pam);


--
-- Name: ossr_phn_cat ossr_phn_cat_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_phn_cat
    ADD CONSTRAINT ossr_phn_cat_pkey PRIMARY KEY (cat_phn);


--
-- Name: ossr_phy_srv_lcn ossr_phy_srv_lcn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_phy_srv_lcn
    ADD CONSTRAINT ossr_phy_srv_lcn_pkey PRIMARY KEY (idx_fer_loc_srv);


--
-- Name: ossr_rmk_dira_drl_archive ossr_rmk_dira_drl_archive_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_rmk_dira_drl_archive
    ADD CONSTRAINT ossr_rmk_dira_drl_archive_pkey PRIMARY KEY (idx_tnb, cde_ali, idx_dir);


--
-- Name: ossr_rsc ossr_rsc_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_rsc
    ADD CONSTRAINT ossr_rsc_pkey PRIMARY KEY (cde_rsc_tol);


--
-- Name: ossr_spn_cat ossr_spn_cat_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_spn_cat
    ADD CONSTRAINT ossr_spn_cat_pkey PRIMARY KEY (cat_spn);


--
-- Name: ossr_svf_pam ossr_svf_pam_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_svf_pam
    ADD CONSTRAINT ossr_svf_pam_pkey PRIMARY KEY (typ_pam, nme_svf);


--
-- Name: ossr_svf ossr_svf_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_svf
    ADD CONSTRAINT ossr_svf_pkey PRIMARY KEY (nme_svf);


--
-- Name: ossr_t1_chn_jrn ossr_t1_chn_jrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_t1_chn_jrn
    ADD CONSTRAINT ossr_t1_chn_jrn_pkey PRIMARY KEY (idx_ord, key_t1_chn_psu);


--
-- Name: ossr_t1 ossr_t1_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_t1
    ADD CONSTRAINT ossr_t1_pkey PRIMARY KEY (idn_t1);


--
-- Name: ossr_tdir_ste ossr_tdir_ste_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tdir_ste
    ADD CONSTRAINT ossr_tdir_ste_pkey PRIMARY KEY (cde_ste);


--
-- Name: ossr_tkg_chn ossr_tkg_chn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tkg_chn
    ADD CONSTRAINT ossr_tkg_chn_pkey PRIMARY KEY (idn_t1, idn_chn);


--
-- Name: ossr_tkg_jrn ossr_tkg_jrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tkg_jrn
    ADD CONSTRAINT ossr_tkg_jrn_pkey PRIMARY KEY (idx_ord, idn_tkg);


--
-- Name: ossr_tkg ossr_tkg_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tkg
    ADD CONSTRAINT ossr_tkg_pkey PRIMARY KEY (idn_tkg);


--
-- Name: ossr_tkg_psp ossr_tkg_psp_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tkg_psp
    ADD CONSTRAINT ossr_tkg_psp_pkey PRIMARY KEY (idn_tkg, nbr_rte_psap, nme_cny_psap);


--
-- Name: ossr_tnb_adr ossr_tnb_adr_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tnb_adr
    ADD CONSTRAINT ossr_tnb_adr_pkey PRIMARY KEY (idx_tnb, cde_rol_adr);


--
-- Name: ossr_tnb_cmn ossr_tnb_cmn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tnb_cmn
    ADD CONSTRAINT ossr_tnb_cmn_pkey PRIMARY KEY (nbr_seq_cmn);


--
-- Name: ossr_tnb ossr_tnb_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tnb
    ADD CONSTRAINT ossr_tnb_pkey PRIMARY KEY (idx_tnb);


--
-- Name: ossr_tra_log_his ossr_tra_log_his_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tra_log_his
    ADD CONSTRAINT ossr_tra_log_his_pkey PRIMARY KEY (nbr_ord, idx_spn_ord, tnb, cde_sts_tsk, idx_lec, nbr_seq_tsk);


--
-- Name: ossr_tra_log ossr_tra_log_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tra_log
    ADD CONSTRAINT ossr_tra_log_pkey PRIMARY KEY (nbr_ord, idx_spn_ord, tnb, cde_sts_tsk, idx_lec);


--
-- Name: ossr_tsk_dri ossr_tsk_dri_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tsk_dri
    ADD CONSTRAINT ossr_tsk_dri_pkey PRIMARY KEY (idx_ord, idx_tsk, dtx_eff_tsk);


--
-- Name: ossr_tsk_sts ossr_tsk_sts_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_tsk_sts
    ADD CONSTRAINT ossr_tsk_sts_pkey PRIMARY KEY (cde_sts_tsk);


--
-- Name: ossr_wko ossr_wko_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_wko
    ADD CONSTRAINT ossr_wko_pkey PRIMARY KEY (idx_ord_wrk);


--
-- Name: ossr_wko_sts ossr_wko_sts_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.ossr_wko_sts
    ADD CONSTRAINT ossr_wko_sts_pkey PRIMARY KEY (cde_sts_ord_wrk);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (cur_month, plan_type, owner, ptn);


--
-- Name: rehome_am_task_details rehome_am_task_details_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.rehome_am_task_details
    ADD CONSTRAINT rehome_am_task_details_pkey PRIMARY KEY (nbr_order, nme_task);


--
-- Name: rehome_migration_ord rehome_migration_ord_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.rehome_migration_ord
    ADD CONSTRAINT rehome_migration_ord_pkey PRIMARY KEY (nbr_order);


--
-- Name: rehome_tnb rehome_tnb_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.rehome_tnb
    ADD CONSTRAINT rehome_tnb_pkey PRIMARY KEY (nbr_order, tnb);


--
-- Name: rehome_tnb_status rehome_tnb_status_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.rehome_tnb_status
    ADD CONSTRAINT rehome_tnb_status_pkey PRIMARY KEY (nbr_order, tnb, cde_action);


--
-- Name: sddr_availability_ilec sddr_availability_ilec_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_availability_ilec
    ADD CONSTRAINT sddr_availability_ilec_pkey PRIMARY KEY (nbr_cic_ilec, cde_state, typ_trans, day_week);


--
-- Name: sddr_cir sddr_cir_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_cir
    ADD CONSTRAINT sddr_cir_pkey PRIMARY KEY (idn_cir_ent_ord);


--
-- Name: sddr_exception_avail_ilec sddr_exception_avail_ilec_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_exception_avail_ilec
    ADD CONSTRAINT sddr_exception_avail_ilec_pkey PRIMARY KEY (idn_avail_exception_ilec);


--
-- Name: sddr_info_ilec sddr_info_ilec_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_info_ilec
    ADD CONSTRAINT sddr_info_ilec_pkey PRIMARY KEY (nbr_cic_ilec);


--
-- Name: sddr_lec_order_key_values sddr_lec_order_key_values_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_lec_order_key_values
    ADD CONSTRAINT sddr_lec_order_key_values_pkey PRIMARY KEY (idx_key_order_lec, idx_lec, nme_field);


--
-- Name: sddr_rrn sddr_rrn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_rrn
    ADD CONSTRAINT sddr_rrn_pkey PRIMARY KEY (cde_ste, idx_rrn);


--
-- Name: sddr_spid_lec_values sddr_spid_lec_values_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_spid_lec_values
    ADD CONSTRAINT sddr_spid_lec_values_pkey PRIMARY KEY (idn_spid, nme_field);


--
-- Name: sddr_swt_owner_cic sddr_swt_owner_cic_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_swt_owner_cic
    ADD CONSTRAINT sddr_swt_owner_cic_pkey PRIMARY KEY (cde_owner_swt, cde_state);


--
-- Name: sddr_tcom_cen_inf sddr_tcom_cen_inf_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_tcom_cen_inf
    ADD CONSTRAINT sddr_tcom_cen_inf_pkey PRIMARY KEY (idx_cntr_oe);


--
-- Name: sddr_tkg sddr_tkg_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_tkg
    ADD CONSTRAINT sddr_tkg_pkey PRIMARY KEY (idn_tkg_ent_ord);


--
-- Name: sddr_usr_vzid_lst sddr_usr_vzid_lst_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_usr_vzid_lst
    ADD CONSTRAINT sddr_usr_vzid_lst_pkey PRIMARY KEY (idn_usr_db, idn_vzid_user);


--
-- Name: sddr_ypg_hdr_inf sddr_ypg_hdr_inf_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sddr_ypg_hdr_inf
    ADD CONSTRAINT sddr_ypg_hdr_inf_pkey PRIMARY KEY (cde_state, nbr_cic_ilec, cde_hdg_pge_yel);


--
-- Name: sdmr_ame_err_cde sdmr_ame_err_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_ame_err_cde
    ADD CONSTRAINT sdmr_ame_err_cde_pkey PRIMARY KEY (cde_err, cde_sev, dtx_eff);


--
-- Name: sdmr_car_ppt sdmr_car_ppt_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_car_ppt
    ADD CONSTRAINT sdmr_car_ppt_pkey PRIMARY KEY (nbr_npa, nbr_nxx, nbr_lne_beg, ind_jur, cde_qul, nbr_vdr, dtx_eff, idn_pvd_srv);


--
-- Name: sdmr_ctc_rol sdmr_ctc_rol_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_ctc_rol
    ADD CONSTRAINT sdmr_ctc_rol_pkey PRIMARY KEY (idn_rol_ctc_vdr);


--
-- Name: sdmr_cus_pty_srv_grp sdmr_cus_pty_srv_grp_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_cus_pty_srv_grp
    ADD CONSTRAINT sdmr_cus_pty_srv_grp_pkey PRIMARY KEY (cde_grp_loc_rev, dtx_eff);


--
-- Name: sdmr_dfl_val sdmr_dfl_val_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_dfl_val
    ADD CONSTRAINT sdmr_dfl_val_pkey PRIMARY KEY (idn_tsk, idn_atr, idn_trdpt, dtx_eff, idn_pvd_srv);


--
-- Name: sdmr_dir sdmr_dir_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_dir
    ADD CONSTRAINT sdmr_dir_pkey PRIMARY KEY (idx_dir, dtx_eff);


--
-- Name: sdmr_e911_cfm_cde sdmr_e911_cfm_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_e911_cfm_cde
    ADD CONSTRAINT sdmr_e911_cfm_cde_pkey PRIMARY KEY (cde_cfm, dtx_eff);


--
-- Name: sdmr_equ_acs_tnb sdmr_equ_acs_tnb_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_equ_acs_tnb
    ADD CONSTRAINT sdmr_equ_acs_tnb_pkey PRIMARY KEY (nbr_npa, nbr_nxx, nbr_lne_beg, ind_jur, idn_pvd_srv);


--
-- Name: sdmr_fax_ctc sdmr_fax_ctc_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_fax_ctc
    ADD CONSTRAINT sdmr_fax_ctc_pkey PRIMARY KEY (idn_ctc, dtx_eff);


--
-- Name: sdmr_fax_idn_ctc sdmr_fax_idn_ctc_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_fax_idn_ctc
    ADD CONSTRAINT sdmr_fax_idn_ctc_pkey PRIMARY KEY (idn_fax, idn_ctc, cde_rte, dtx_eff);


--
-- Name: sdmr_fax_idn sdmr_fax_idn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_fax_idn
    ADD CONSTRAINT sdmr_fax_idn_pkey PRIMARY KEY (idn_fax);


--
-- Name: sdmr_ioc sdmr_ioc_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_ioc
    ADD CONSTRAINT sdmr_ioc_pkey PRIMARY KEY (cde_ioc);


--
-- Name: sdmr_ioc_swt sdmr_ioc_swt_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_ioc_swt
    ADD CONSTRAINT sdmr_ioc_swt_pkey PRIMARY KEY (cde_ioc, typ_swt);


--
-- Name: sdmr_jbs_sts_dir sdmr_jbs_sts_dir_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_jbs_sts_dir
    ADD CONSTRAINT sdmr_jbs_sts_dir_pkey PRIMARY KEY (sts_jbs, dtx_eff);


--
-- Name: sdmr_jep_cde sdmr_jep_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_jep_cde
    ADD CONSTRAINT sdmr_jep_cde_pkey PRIMARY KEY (cde_jep, dtx_eff);


--
-- Name: sdmr_lob sdmr_lob_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_lob
    ADD CONSTRAINT sdmr_lob_pkey PRIMARY KEY (cde_lob);


--
-- Name: sdmr_mkt_are sdmr_mkt_are_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_mkt_are
    ADD CONSTRAINT sdmr_mkt_are_pkey PRIMARY KEY (cde_are_mkt, cde_ste);


--
-- Name: sdmr_ocn sdmr_ocn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_ocn
    ADD CONSTRAINT sdmr_ocn_pkey PRIMARY KEY (nbr_ocn);


--
-- Name: sdmr_qul_cde sdmr_qul_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_qul_cde
    ADD CONSTRAINT sdmr_qul_cde_pkey PRIMARY KEY (cde_qul);


--
-- Name: sdmr_rev_loc_cde sdmr_rev_loc_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_rev_loc_cde
    ADD CONSTRAINT sdmr_rev_loc_cde_pkey PRIMARY KEY (cde_loc_rev, dtx_eff);


--
-- Name: sdmr_srv_exc_cde sdmr_srv_exc_cde_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_srv_exc_cde
    ADD CONSTRAINT sdmr_srv_exc_cde_pkey PRIMARY KEY (nbr_npa, nbr_nxx);


--
-- Name: sdmr_srv_pvd sdmr_srv_pvd_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_srv_pvd
    ADD CONSTRAINT sdmr_srv_pvd_pkey PRIMARY KEY (idn_pvd_srv);


--
-- Name: sdmr_tbl_idn sdmr_tbl_idn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_tbl_idn
    ADD CONSTRAINT sdmr_tbl_idn_pkey PRIMARY KEY (typ_tbl);


--
-- Name: sdmr_tnl sdmr_tnl_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_tnl
    ADD CONSTRAINT sdmr_tnl_pkey PRIMARY KEY (idn_tsk, idn_atr, val_wcm, idn_trdpt, dtx_eff);


--
-- Name: sdmr_tra_sts sdmr_tra_sts_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_tra_sts
    ADD CONSTRAINT sdmr_tra_sts_pkey PRIMARY KEY (cde_tcsi, dtx_eff);


--
-- Name: sdmr_trdpt_hol sdmr_trdpt_hol_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_trdpt_hol
    ADD CONSTRAINT sdmr_trdpt_hol_pkey PRIMARY KEY (idn_trdpt, dtx_eff, dtx_hol);


--
-- Name: sdmr_trdpt sdmr_trdpt_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_trdpt
    ADD CONSTRAINT sdmr_trdpt_pkey PRIMARY KEY (idn_trdpt);


--
-- Name: sdmr_trdpt_tat sdmr_trdpt_tat_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_trdpt_tat
    ADD CONSTRAINT sdmr_trdpt_tat_pkey PRIMARY KEY (idn_trdpt, dtx_eff, cde_typ_msg);


--
-- Name: sdmr_ttb sdmr_ttb_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_ttb
    ADD CONSTRAINT sdmr_ttb_pkey PRIMARY KEY (typ_tbl, val_tbl, dtx_eff);


--
-- Name: sdmr_vdr_ctc sdmr_vdr_ctc_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_vdr_ctc
    ADD CONSTRAINT sdmr_vdr_ctc_pkey PRIMARY KEY (nbr_vdr, idn_rol_ctc_vdr, dtx_eff);


--
-- Name: sdmr_vdr_idn sdmr_vdr_idn_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_vdr_idn
    ADD CONSTRAINT sdmr_vdr_idn_pkey PRIMARY KEY (nbr_vdr);


--
-- Name: sdmr_vdr_qul sdmr_vdr_qul_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_vdr_qul
    ADD CONSTRAINT sdmr_vdr_qul_pkey PRIMARY KEY (nbr_vdr, cde_qul, dtx_eff);


--
-- Name: sdmr_wls_opr_srv sdmr_wls_opr_srv_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.sdmr_wls_opr_srv
    ADD CONSTRAINT sdmr_wls_opr_srv_pkey PRIMARY KEY (idn_lsp, cde_loc_pln_rat, dtx_eff);


--
-- Name: soistatehosts soistatehosts_login_key; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_login_key UNIQUE (login);


--
-- Name: soistatehosts soistatehosts_login_key1; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_login_key1 UNIQUE (login);


--
-- Name: soistatehosts soistatehosts_login_key2; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_login_key2 UNIQUE (login);


--
-- Name: soistatehosts soistatehosts_login_key3; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_login_key3 UNIQUE (login);


--
-- Name: soistatehosts soistatehosts_login_key4; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_login_key4 UNIQUE (login);


--
-- Name: soistatehosts soistatehosts_state_key; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_state_key UNIQUE (state);


--
-- Name: soistatehosts soistatehosts_state_key1; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_state_key1 UNIQUE (state);


--
-- Name: soistatehosts soistatehosts_state_key2; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_state_key2 UNIQUE (state);


--
-- Name: soistatehosts soistatehosts_state_key3; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_state_key3 UNIQUE (state);


--
-- Name: soistatehosts soistatehosts_state_key4; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.soistatehosts
    ADD CONSTRAINT soistatehosts_state_key4 UNIQUE (state);


--
-- Name: tds_event tds_event_pkey; Type: CONSTRAINT; Schema: localds2; Owner: nvoip
--

ALTER TABLE ONLY localds2.tds_event
    ADD CONSTRAINT tds_event_pkey PRIMARY KEY (event_id);


--
-- Name: acela_admin_his_chg_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX acela_admin_his_chg_ndx01 ON localds2.acela_admin_his_chg USING btree (idn_admin_staff);


--
-- Name: acela_am_exception_info_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX acela_am_exception_info_ndx01 ON localds2.acela_am_exception_info USING btree (nbr_order, nbr_supp_order, idn_origin_order, idn_exception);


--
-- Name: acela_reg_input_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX acela_reg_input_ndx01 ON localds2.acela_reg_input USING btree (idn_source, cde_status);


--
-- Name: ei_911_vali_order_comm_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ei_911_vali_order_comm_ndx02 ON localds2.ei_911_vali_order_comments USING btree (nbr_ord_ei);


--
-- Name: ei_911_vali_order_his_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ei_911_vali_order_his_ndx01 ON localds2.ei_911_vali_order_his USING btree (nbr_ord_ei);


--
-- Name: ei_911_vali_order_his_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ei_911_vali_order_his_ndx02 ON localds2.ei_911_vali_order_his USING btree (tnb);


--
-- Name: ei_911_vali_order_his_ndx03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ei_911_vali_order_his_ndx03 ON localds2.ei_911_vali_order_his USING btree (nbr_ord_external);


--
-- Name: ei_911_vali_order_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ei_911_vali_order_ndx01 ON localds2.ei_911_vali_order USING btree (tnb);


--
-- Name: ei_911_vali_order_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ei_911_vali_order_ndx02 ON localds2.ei_911_vali_order USING btree (nbr_ord_external);


--
-- Name: lsr_admin_response_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_admin_response_ndx01 ON localds2.lsr_admin_response USING btree (nbr_pon, nbr_supp_order);


--
-- Name: lsr_admin_response_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_admin_response_ndx02 ON localds2.lsr_admin_response USING btree (seq_resp_admin);


--
-- Name: lsr_am_task_info_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_am_task_info_ndx01 ON localds2.lsr_am_task_info USING btree (nbr_order, idn_origin_order, nbr_supp_order);


--
-- Name: lsr_am_task_info_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_am_task_info_ndx02 ON localds2.lsr_am_task_info USING btree (sts_tsk_order);


--
-- Name: lsr_am_task_info_ndx03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_am_task_info_ndx03 ON localds2.lsr_am_task_info USING btree (seq_info_task_am);


--
-- Name: lsr_am_task_info_ndx04; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_am_task_info_ndx04 ON localds2.lsr_am_task_info USING btree (sts_process_task);


--
-- Name: lsr_am_task_info_report_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_am_task_info_report_ndx01 ON localds2.lsr_am_task_info_report USING btree (seq_info_task_am);


--
-- Name: lsr_dl_response_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_dl_response_ndx01 ON localds2.lsr_dl_response USING btree (seq_resp_dl);


--
-- Name: lsr_np_response_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_np_response_ndx01 ON localds2.lsr_np_response USING btree (seq_resp_np);


--
-- Name: lsr_pon_tracking_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_pon_tracking_ndx01 ON localds2.lsr_pon_tracking USING btree (nbr_order);


--
-- Name: lsr_pon_tracking_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_pon_tracking_ndx02 ON localds2.lsr_pon_tracking USING btree (seq_track_pon);


--
-- Name: lsr_pon_tracking_report_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_pon_tracking_report_ndx01 ON localds2.lsr_pon_tracking_report USING btree (seq_track_pon);


--
-- Name: lsr_reject_detail_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_reject_detail_ndx01 ON localds2.lsr_reject_detail USING btree (nbr_order);


--
-- Name: lsr_reject_detail_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_reject_detail_ndx02 ON localds2.lsr_reject_detail USING btree (seq_detl_reject);


--
-- Name: lsr_response_audit_track_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_response_audit_track_ndx01 ON localds2.lsr_response_audit_tracking USING btree (nbr_order);


--
-- Name: lsr_response_audit_track_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX lsr_response_audit_track_ndx02 ON localds2.lsr_response_audit_tracking USING btree (nbr_pon);


--
-- Name: lsr_response_audit_track_ndx03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX lsr_response_audit_track_ndx03 ON localds2.lsr_response_audit_tracking USING btree (seq_track_audit);


--
-- Name: npar_bch_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX npar_bch_ndx01 ON localds2.npar_bch USING btree (dtx_pmv_beg, dtx_pmv_end);


--
-- Name: npar_spi_ak01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX npar_spi_ak01 ON localds2.npar_spi USING btree (nbr_bch, nbr_npa_new, nbr_nxx);


--
-- Name: npar_spi_apl_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX npar_spi_apl_ndx01 ON localds2.npar_spi_apl USING btree (nme_bas, nbr_npa_old, nbr_nxx);


--
-- Name: npar_spi_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX npar_spi_ndx01 ON localds2.npar_spi USING btree (dtx_cut);


--
-- Name: ossr_800_tol_fre_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_800_tol_fre_fk01 ON localds2.ossr_800_tol_fre USING btree (idx_tnb);


--
-- Name: ossr_911_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_911_fk01 ON localds2.ossr_911 USING btree (idx_adr);


--
-- Name: ossr_911_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_911_fk02 ON localds2.ossr_911 USING btree (idx_nme);


--
-- Name: ossr_acs_lne_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk01 ON localds2.ossr_acs_lne USING btree (idx_fer_loc_srv);


--
-- Name: ossr_acs_lne_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk02 ON localds2.ossr_acs_lne USING btree (idx_ord_wrk);


--
-- Name: ossr_acs_lne_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk03 ON localds2.ossr_acs_lne USING btree (idx_swt_wcom);


--
-- Name: ossr_acs_lne_fk04; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk04 ON localds2.ossr_acs_lne USING btree (cde_rsc_tol);


--
-- Name: ossr_acs_lne_fk05; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk05 ON localds2.ossr_acs_lne USING btree (idx_lne_acs_old);


--
-- Name: ossr_acs_lne_fk06; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk06 ON localds2.ossr_acs_lne USING btree (cde_typ_lne);


--
-- Name: ossr_acs_lne_fk07; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk07 ON localds2.ossr_acs_lne USING btree (typ_cir);


--
-- Name: ossr_acs_lne_fk08; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_fk08 ON localds2.ossr_acs_lne USING btree (idx_ord);


--
-- Name: ossr_acs_lne_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_ndx01 ON localds2.ossr_acs_lne USING btree (idx_por_swt);


--
-- Name: ossr_acs_lne_svf_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_svf_fk01 ON localds2.ossr_acs_lne_svf USING btree (nme_svf);


--
-- Name: ossr_acs_lne_svf_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_svf_fk02 ON localds2.ossr_acs_lne_svf USING btree (idn_lne_acs);


--
-- Name: ossr_acs_lne_svf_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_acs_lne_svf_fk03 ON localds2.ossr_acs_lne_svf USING btree (cde_atn);


--
-- Name: ossr_adr_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_adr_fk01 ON localds2.ossr_adr USING btree (cde_ste);


--
-- Name: ossr_cpe_dn_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_cpe_dn_fk01 ON localds2.ossr_cpe_dn USING btree (idx_tnb);


--
-- Name: ossr_cpe_dn_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_cpe_dn_fk02 ON localds2.ossr_cpe_dn USING btree (idn_cpe);


--
-- Name: ossr_cpe_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_cpe_fk01 ON localds2.ossr_cpe USING btree (idn_t1);


--
-- Name: ossr_cpe_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_cpe_fk02 ON localds2.ossr_cpe USING btree (idx_fer_loc_srv);


--
-- Name: ossr_cpe_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_cpe_fk03 ON localds2.ossr_cpe USING btree (idn_lne_acs);


--
-- Name: ossr_cpe_fk05; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_cpe_fk05 ON localds2.ossr_cpe USING btree (idx_adr);


--
-- Name: ossr_ctc_tnb_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ctc_tnb_fk01 ON localds2.ossr_ctc_tnb USING btree (idx_nme);


--
-- Name: ossr_ctc_tnb_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ctc_tnb_fk02 ON localds2.ossr_ctc_tnb USING btree (cat_phn);


--
-- Name: ossr_ctx_grp_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ctx_grp_fk01 ON localds2.ossr_ctx_grp USING btree (idx_ord);


--
-- Name: ossr_ctx_grp_svf_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ctx_grp_svf_fk01 ON localds2.ossr_ctx_grp_svf USING btree (idx_ord, idn_grp_ctx, nbr_grp_sub_ctx);


--
-- Name: ossr_dir_adr_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_adr_fk01 ON localds2.ossr_dir_adr USING btree (cde_ali, idx_dir, idx_tnb);


--
-- Name: ossr_dir_adr_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_adr_fk02 ON localds2.ossr_dir_adr USING btree (idx_adr);


--
-- Name: ossr_dir_adr_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_adr_fk03 ON localds2.ossr_dir_adr USING btree (cde_rol_adr);


--
-- Name: ossr_dir_asi_lst_archive_ndx; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_dir_asi_lst_archive_ndx ON localds2.ossr_dir_asi_lst_archive USING btree (idx_tnb, idx_dir, cde_ali);


--
-- Name: ossr_dir_asi_lst_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_asi_lst_fk01 ON localds2.ossr_dir_asi_lst USING btree (idx_tnb);


--
-- Name: ossr_dir_asi_lst_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_asi_lst_ndx01 ON localds2.ossr_dir_asi_lst USING btree (idx_dir);


--
-- Name: ossr_dir_nme_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_nme_fk01 ON localds2.ossr_dir_nme USING btree (cde_ali, idx_dir, idx_tnb);


--
-- Name: ossr_dir_nme_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_nme_fk02 ON localds2.ossr_dir_nme USING btree (idx_nme);


--
-- Name: ossr_dir_nme_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dir_nme_fk03 ON localds2.ossr_dir_nme USING btree (cde_rol_nme);


--
-- Name: ossr_dlv_adr_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dlv_adr_fk01 ON localds2.ossr_dlv_adr USING btree (idx_ord);


--
-- Name: ossr_dlv_adr_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dlv_adr_fk02 ON localds2.ossr_dlv_adr USING btree (idx_nme);


--
-- Name: ossr_dlv_adr_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_dlv_adr_fk03 ON localds2.ossr_dlv_adr USING btree (idx_adr);


--
-- Name: ossr_ei_rcd_vew_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ei_rcd_vew_ndx01 ON localds2.ossr_ei_rcd_vew USING btree (idx_lec, idn_pvd_srv, nbr_ord, tnb);


--
-- Name: ossr_ei_rcd_vew_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ei_rcd_vew_ndx02 ON localds2.ossr_ei_rcd_vew USING btree (dtx_tsk_ei);


--
-- Name: ossr_hg_trm_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_hg_trm_fk01 ON localds2.ossr_hg_trm USING btree (idx_ord, tnb_plt);


--
-- Name: ossr_hg_trm_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_hg_trm_fk03 ON localds2.ossr_hg_trm USING btree (idn_lne_acs);


--
-- Name: ossr_hg_trm_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_hg_trm_ndx01 ON localds2.ossr_hg_trm USING btree (nbr_trm);


--
-- Name: ossr_hun_grp_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_hun_grp_fk01 ON localds2.ossr_hun_grp USING btree (idx_ord);


--
-- Name: ossr_iasa_process_idx; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_iasa_process_idx ON localds2.ossr_iasa_process USING btree (idx_ord);


--
-- Name: ossr_inflight_ords_conv_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_inflight_ords_conv_ndx01 ON localds2.ossr_inflight_ords_conv USING btree (idx_ord);


--
-- Name: ossr_inflight_ords_conv_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_inflight_ords_conv_ndx02 ON localds2.ossr_inflight_ords_conv USING btree (nbr_ord, idx_spn_ord);


--
-- Name: ossr_kar_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_kar_fk01 ON localds2.ossr_kar USING btree (idx_nme);


--
-- Name: ossr_kar_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_kar_fk02 ON localds2.ossr_kar USING btree (cde_cic);


--
-- Name: ossr_kar_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_kar_fk03 ON localds2.ossr_kar USING btree (idx_tnb);


--
-- Name: ossr_lid_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lid_fk01 ON localds2.ossr_lid USING btree (idx_adr);


--
-- Name: ossr_lid_nme_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lid_nme_fk01 ON localds2.ossr_lid_nme USING btree (idx_tnb);


--
-- Name: ossr_lid_nme_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lid_nme_fk02 ON localds2.ossr_lid_nme USING btree (idx_nme);


--
-- Name: ossr_lid_nme_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lid_nme_fk03 ON localds2.ossr_lid_nme USING btree (cde_rol_nme);


--
-- Name: ossr_lne_svf_pam_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lne_svf_pam_fk01 ON localds2.ossr_lne_svf_pam USING btree (nme_svf, idn_lne_acs);


--
-- Name: ossr_lne_svf_pam_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lne_svf_pam_fk02 ON localds2.ossr_lne_svf_pam USING btree (nme_svf, typ_pam);


--
-- Name: ossr_lne_svf_pam_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lne_svf_pam_ndx01 ON localds2.ossr_lne_svf_pam USING btree (idn_lne_acs);


--
-- Name: ossr_lsr_inf_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lsr_inf_fk01 ON localds2.ossr_lsr_inf USING btree (tnb_bil_lec);


--
-- Name: ossr_lsr_inf_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lsr_inf_ndx01 ON localds2.ossr_lsr_inf USING btree (idx_adr_sav);


--
-- Name: ossr_lst_txt_typ_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_lst_txt_typ_fk01 ON localds2.ossr_lst_txt_typ USING btree (idx_tnb, cde_ali, idx_dir);


--
-- Name: ossr_opr_srv_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_opr_srv_fk01 ON localds2.ossr_opr_srv_temp USING btree (idx_adr);


--
-- Name: ossr_opr_srv_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_opr_srv_fk02 ON localds2.ossr_opr_srv_temp USING btree (idx_nme);


--
-- Name: ossr_ord_ak1; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_ord_ak1 ON localds2.ossr_ord USING btree (idx_org_ord, nbr_ord, idx_spn_ord);


--
-- Name: ossr_ord_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_fk01 ON localds2.ossr_ord USING btree (cde_sts_ord);


--
-- Name: ossr_ord_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_fk02 ON localds2.ossr_ord USING btree (cat_chg);


--
-- Name: ossr_ord_fk05; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_fk05 ON localds2.ossr_ord USING btree (idx_fer_loc_srv);


--
-- Name: ossr_ord_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_ndx01 ON localds2.ossr_ord USING btree (nbr_ord);


--
-- Name: ossr_ord_rep_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_rep_fk01 ON localds2.ossr_ord_rep USING btree (idx_ord);


--
-- Name: ossr_ord_rep_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_rep_fk02 ON localds2.ossr_ord_rep USING btree (idx_nme);


--
-- Name: ossr_ord_rep_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_ord_rep_fk03 ON localds2.ossr_ord_rep USING btree (cde_rol_nme);


--
-- Name: ossr_phy_srv_lcn_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_phy_srv_lcn_fk02 ON localds2.ossr_phy_srv_lcn USING btree (idx_adr_gni);


--
-- Name: ossr_phy_srv_lcn_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_phy_srv_lcn_fk03 ON localds2.ossr_phy_srv_lcn USING btree (idx_adr_sag);


--
-- Name: ossr_rmk_dira_drl_archive_ndx; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_rmk_dira_drl_archive_ndx ON localds2.ossr_rmk_dira_drl_archive USING btree (idx_tnb, idx_dir, cde_ali);


--
-- Name: ossr_svf_pam_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_svf_pam_fk01 ON localds2.ossr_svf_pam USING btree (nme_svf);


--
-- Name: ossr_svf_pam_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_svf_pam_fk02 ON localds2.ossr_svf_pam USING btree (typ_pam);


--
-- Name: ossr_t1_archive_ndx; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_t1_archive_ndx ON localds2.ossr_t1_archive USING btree (idn_t1);


--
-- Name: ossr_t1_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_t1_ndx01 ON localds2.ossr_t1 USING btree (idx_ord);


--
-- Name: ossr_tkg_chn_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_chn_fk01 ON localds2.ossr_tkg_chn USING btree (idn_tkg);


--
-- Name: ossr_tkg_chn_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_chn_fk02 ON localds2.ossr_tkg_chn USING btree (idn_t1);


--
-- Name: ossr_tkg_chn_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_chn_ndx01 ON localds2.ossr_tkg_chn USING btree (idn_lne_acs);


--
-- Name: ossr_tkg_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_fk01 ON localds2.ossr_tkg USING btree (idx_ord);


--
-- Name: ossr_tkg_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_fk02 ON localds2.ossr_tkg USING btree (idx_ord_wrk);


--
-- Name: ossr_tkg_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_fk03 ON localds2.ossr_tkg USING btree (cde_rsc_tol);


--
-- Name: ossr_tkg_fk05; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_fk05 ON localds2.ossr_tkg USING btree (idn_tkg_old);


--
-- Name: ossr_tkg_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_ndx01 ON localds2.ossr_tkg USING btree (idx_fer_loc_srv);


--
-- Name: ossr_tkg_psp_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tkg_psp_fk01 ON localds2.ossr_tkg_psp USING btree (idn_tkg);


--
-- Name: ossr_tnb_adr_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_adr_fk01 ON localds2.ossr_tnb_adr USING btree (idx_tnb);


--
-- Name: ossr_tnb_adr_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_adr_fk02 ON localds2.ossr_tnb_adr USING btree (idx_adr);


--
-- Name: ossr_tnb_adr_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_adr_fk03 ON localds2.ossr_tnb_adr USING btree (cde_rol_adr);


--
-- Name: ossr_tnb_cmn_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_cmn_fk01 ON localds2.ossr_tnb_cmn USING btree (idx_tnb);


--
-- Name: ossr_tnb_cmn_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_cmn_fk02 ON localds2.ossr_tnb_cmn USING btree (cde_err, nme_src_err);


--
-- Name: ossr_tnb_cmn_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_cmn_ndx01 ON localds2.ossr_tnb_cmn USING btree (idx_tnb, dtx_cmn);


--
-- Name: ossr_tnb_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_fk01 ON localds2.ossr_tnb USING btree (idx_ord);


--
-- Name: ossr_tnb_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_fk02 ON localds2.ossr_tnb USING btree (idx_ord, idn_grp_ctx, nbr_grp_sub_ctx);


--
-- Name: ossr_tnb_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_fk03 ON localds2.ossr_tnb USING btree (idn_tkg);


--
-- Name: ossr_tnb_fk04; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_fk04 ON localds2.ossr_tnb USING btree (idx_lec);


--
-- Name: ossr_tnb_fk05; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_fk05 ON localds2.ossr_tnb USING btree (idx_tnb_old);


--
-- Name: ossr_tnb_fk06; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_fk06 ON localds2.ossr_tnb USING btree (idn_lne_acs);


--
-- Name: ossr_tnb_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tnb_ndx01 ON localds2.ossr_tnb USING btree (tnb);


--
-- Name: ossr_tra_log_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tra_log_fk01 ON localds2.ossr_tra_log USING btree (cde_sts_tsk);


--
-- Name: ossr_tra_log_his_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tra_log_his_ndx01 ON localds2.ossr_tra_log_his USING btree (idx_org_ord);


--
-- Name: ossr_tra_log_his_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tra_log_his_ndx02 ON localds2.ossr_tra_log_his USING btree (cde_sts_fbk);


--
-- Name: ossr_tra_log_his_ndx03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_tra_log_his_ndx03 ON localds2.ossr_tra_log_his USING btree (seq_his_log_tra);


--
-- Name: ossr_tra_log_his_ndx04; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tra_log_his_ndx04 ON localds2.ossr_tra_log_his USING btree (ind_prs);


--
-- Name: ossr_tra_log_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tra_log_ndx01 ON localds2.ossr_tra_log USING btree (nbr_bch);


--
-- Name: ossr_tra_log_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tra_log_ndx02 ON localds2.ossr_tra_log USING btree (tnb);


--
-- Name: ossr_tsk_dri_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tsk_dri_fk01 ON localds2.ossr_tsk_dri USING btree (idx_ord);


--
-- Name: ossr_tsk_dri_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tsk_dri_fk02 ON localds2.ossr_tsk_dri USING btree (cde_sts_tsk);


--
-- Name: ossr_tsk_dri_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tsk_dri_ndx01 ON localds2.ossr_tsk_dri USING btree (dtx_eff_tsk);


--
-- Name: ossr_tsk_dri_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tsk_dri_ndx02 ON localds2.ossr_tsk_dri USING btree (idx_ord, idx_tsk, idx_spn_oma, nbr_ver_wkf);


--
-- Name: ossr_tsk_dri_ndx03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_tsk_dri_ndx03 ON localds2.ossr_tsk_dri USING btree (idn_han_tsk);


--
-- Name: ossr_tsk_dri_ndx04; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_tsk_dri_ndx04 ON localds2.ossr_tsk_dri USING btree (seq_dri_tsk);


--
-- Name: ossr_tsk_dri_report_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX ossr_tsk_dri_report_ndx01 ON localds2.ossr_tsk_dri_report USING btree (seq_dri_tsk);


--
-- Name: ossr_wko_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX ossr_wko_fk01 ON localds2.ossr_wko USING btree (cde_sts_ord_wrk);


--
-- Name: perseus_log_transaction_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX perseus_log_transaction_ndx01 ON localds2.perseus_log_transaction USING btree (nbr_ord, idx_spn_ord, idx_org_ord);


--
-- Name: perseus_log_transaction_ndx02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX perseus_log_transaction_ndx02 ON localds2.perseus_log_transaction USING btree (nbr_pon, nbr_version_pon);


--
-- Name: rehome_tnb_status_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX rehome_tnb_status_ndx01 ON localds2.rehome_tnb_status USING btree (cde_status);


--
-- Name: sddr_cir_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sddr_cir_ndx01 ON localds2.sddr_cir USING btree (idn_cir_pvn);


--
-- Name: sddr_tkg_ndx01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sddr_tkg_ndx01 ON localds2.sddr_tkg USING btree (idn_tkg_pvn, cde_cli_swt);


--
-- Name: sdmr_car_ppt_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_car_ppt_fk01 ON localds2.sdmr_car_ppt USING btree (cde_qul);


--
-- Name: sdmr_car_ppt_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_car_ppt_fk02 ON localds2.sdmr_car_ppt USING btree (nbr_npa, nbr_nxx, nbr_lne_beg, ind_jur, idn_pvd_srv);


--
-- Name: sdmr_car_ppt_fk03; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_car_ppt_fk03 ON localds2.sdmr_car_ppt USING btree (nbr_vdr);


--
-- Name: sdmr_equ_acs_tnb_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_equ_acs_tnb_fk01 ON localds2.sdmr_equ_acs_tnb USING btree (cde_are_mkt, cde_ste);


--
-- Name: sdmr_equ_acs_tnb_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_equ_acs_tnb_fk02 ON localds2.sdmr_equ_acs_tnb USING btree (idn_pvd_srv);


--
-- Name: sdmr_fax_idn_ctc_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_fax_idn_ctc_fk01 ON localds2.sdmr_fax_idn_ctc USING btree (idn_fax);


--
-- Name: sdmr_fax_idn_ctc_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_fax_idn_ctc_fk02 ON localds2.sdmr_fax_idn_ctc USING btree (idn_ctc, dtx_eff);


--
-- Name: sdmr_fax_idn_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_fax_idn_fk01 ON localds2.sdmr_fax_idn USING btree (idn_pvd_srv);


--
-- Name: sdmr_ioc_swt_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_ioc_swt_fk01 ON localds2.sdmr_ioc_swt USING btree (cde_ioc);


--
-- Name: sdmr_ocn_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_ocn_fk01 ON localds2.sdmr_ocn USING btree (idn_pvd_srv);


--
-- Name: sdmr_rev_loc_cde_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_rev_loc_cde_fk01 ON localds2.sdmr_rev_loc_cde USING btree (cde_grp_loc_rev, grp_loc_rev_dtx_eff);


--
-- Name: sdmr_ttb_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_ttb_fk01 ON localds2.sdmr_ttb USING btree (typ_tbl);


--
-- Name: sdmr_vdr_ctc_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_vdr_ctc_fk01 ON localds2.sdmr_vdr_ctc USING btree (idn_rol_ctc_vdr);


--
-- Name: sdmr_vdr_ctc_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_vdr_ctc_fk02 ON localds2.sdmr_vdr_ctc USING btree (nbr_vdr);


--
-- Name: sdmr_vdr_qul_fk01; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_vdr_qul_fk01 ON localds2.sdmr_vdr_qul USING btree (cde_qul);


--
-- Name: sdmr_vdr_qul_fk02; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX sdmr_vdr_qul_fk02 ON localds2.sdmr_vdr_qul USING btree (nbr_vdr);


--
-- Name: sdmr_wls_opr_srv_ak1; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE UNIQUE INDEX sdmr_wls_opr_srv_ak1 ON localds2.sdmr_wls_opr_srv USING btree (cde_car);


--
-- Name: tds_event_initiating_event_id; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX tds_event_initiating_event_id ON localds2.tds_event USING btree (initiating_event_id);


--
-- Name: tds_event_inserted; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX tds_event_inserted ON localds2.tds_event USING btree (inserted);


--
-- Name: tds_event_key; Type: INDEX; Schema: localds2; Owner: nvoip
--

CREATE INDEX tds_event_key ON localds2.tds_event USING btree (key);


--
-- Name: ossr_tra_log tra_log_trig; Type: TRIGGER; Schema: localds2; Owner: nvoip
--

-- MJV PG 10 must use EXECUTE PROCEDURE syntax
-- CREATE TRIGGER tra_log_trig BEFORE INSERT ON localds2.ossr_tra_log FOR EACH ROW EXECUTE FUNCTION localds2.trigger_fct_tra_log_trig();
CREATE TRIGGER tra_log_trig BEFORE INSERT ON localds2.ossr_tra_log FOR EACH ROW EXECUTE PROCEDURE localds2.trigger_fct_tra_log_trig();

ALTER TABLE ONLY localds2.acela_admin_his_chg
    ADD CONSTRAINT acela_admin_his_chg_fk01 FOREIGN KEY (idn_admin_staff) REFERENCES localds2.acela_admin_staffadmin(idn_admin_staff);
--
-- Name: acela_admin_org_to_workpool acela_admin_workpool_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.acela_admin_org_to_workpool
    ADD CONSTRAINT acela_admin_workpool_fk01 FOREIGN KEY (nme_org) REFERENCES localds2.acela_admin_org(nme_org);


--
-- Name: acela_am_exception_info acela_am_exception_info_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.acela_am_exception_info
    ADD CONSTRAINT acela_am_exception_info_fk01 FOREIGN KEY (nbr_order, nbr_supp_order, idn_origin_order, idn_exception) REFERENCES localds2.acela_am_exception(nbr_order, nbr_supp_order, idn_origin_order, idn_exception);


--
-- Name: acela_admin_org_to_staffadmin acela_to_staffadmin_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.acela_admin_org_to_staffadmin
    ADD CONSTRAINT acela_to_staffadmin_fk01 FOREIGN KEY (idn_admin_staff) REFERENCES localds2.acela_admin_staffadmin(idn_admin_staff);


--
-- Name: acela_admin_org_to_staffadmin acela_to_staffadmin_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.acela_admin_org_to_staffadmin
    ADD CONSTRAINT acela_to_staffadmin_fk02 FOREIGN KEY (nme_org) REFERENCES localds2.acela_admin_org(nme_org);


--
-- Name: npar_spi_apl npar_spi_apl_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.npar_spi_apl
    ADD CONSTRAINT npar_spi_apl_fk02 FOREIGN KEY (nme_bas, nme_tbl) REFERENCES localds2.npar_tbl(nme_bas, nme_tbl);


--
-- Name: npar_spi npar_spi_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.npar_spi
    ADD CONSTRAINT npar_spi_fk01 FOREIGN KEY (nbr_bch) REFERENCES localds2.npar_bch(nbr_bch);


--
-- Name: ossr_800_tol_fre ossr_800_tol_fre_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_800_tol_fre
    ADD CONSTRAINT ossr_800_tol_fre_fk01 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb) ON DELETE CASCADE;


--
-- Name: ossr_911 ossr_911_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_911
    ADD CONSTRAINT ossr_911_fk01 FOREIGN KEY (idx_adr) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_911 ossr_911_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_911
    ADD CONSTRAINT ossr_911_fk02 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme);


--
-- Name: ossr_911 ossr_911_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_911
    ADD CONSTRAINT ossr_911_fk03 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb) ON DELETE CASCADE;


--
-- Name: ossr_acs_lne ossr_acs_lne_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_fk02 FOREIGN KEY (idx_ord_wrk) REFERENCES localds2.ossr_wko(idx_ord_wrk);


--
-- Name: ossr_acs_lne ossr_acs_lne_fk04; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_fk04 FOREIGN KEY (cde_rsc_tol) REFERENCES localds2.ossr_rsc(cde_rsc_tol);


--
-- Name: ossr_acs_lne ossr_acs_lne_fk05; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_fk05 FOREIGN KEY (idx_lne_acs_old) REFERENCES localds2.ossr_acs_lne(idn_lne_acs);


--
-- Name: ossr_acs_lne ossr_acs_lne_fk06; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_fk06 FOREIGN KEY (cde_typ_lne) REFERENCES localds2.ossr_lne_typ(cde_typ_lne);


--
-- Name: ossr_acs_lne ossr_acs_lne_fk07; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_fk07 FOREIGN KEY (typ_cir) REFERENCES localds2.ossr_cir_typ(typ_cir);


--
-- Name: ossr_acs_lne ossr_acs_lne_fk08; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne
    ADD CONSTRAINT ossr_acs_lne_fk08 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord);


--
-- Name: ossr_acs_lne_svf ossr_acs_lne_svf_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne_svf
    ADD CONSTRAINT ossr_acs_lne_svf_fk01 FOREIGN KEY (nme_svf) REFERENCES localds2.ossr_svf(nme_svf);


--
-- Name: ossr_acs_lne_svf ossr_acs_lne_svf_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne_svf
    ADD CONSTRAINT ossr_acs_lne_svf_fk02 FOREIGN KEY (idn_lne_acs) REFERENCES localds2.ossr_acs_lne(idn_lne_acs) ON DELETE CASCADE;


--
-- Name: ossr_acs_lne_svf ossr_acs_lne_svf_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_acs_lne_svf
    ADD CONSTRAINT ossr_acs_lne_svf_fk03 FOREIGN KEY (cde_atn) REFERENCES localds2.ossr_atn(cde_atn);


--
-- Name: ossr_adr ossr_adr_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_adr
    ADD CONSTRAINT ossr_adr_fk01 FOREIGN KEY (cde_ste) REFERENCES localds2.ossr_tdir_ste(cde_ste);


--
-- Name: ossr_cpe_dn ossr_cpe_dn_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_cpe_dn
    ADD CONSTRAINT ossr_cpe_dn_fk01 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb) ON DELETE CASCADE;


--
-- Name: ossr_cpe_dn ossr_cpe_dn_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_cpe_dn
    ADD CONSTRAINT ossr_cpe_dn_fk02 FOREIGN KEY (idn_cpe) REFERENCES localds2.ossr_cpe(idn_cpe);


--
-- Name: ossr_cpe ossr_cpe_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_cpe
    ADD CONSTRAINT ossr_cpe_fk01 FOREIGN KEY (idn_t1) REFERENCES localds2.ossr_t1(idn_t1) ON DELETE CASCADE;


--
-- Name: ossr_cpe ossr_cpe_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_cpe
    ADD CONSTRAINT ossr_cpe_fk02 FOREIGN KEY (idx_fer_loc_srv) REFERENCES localds2.ossr_phy_srv_lcn(idx_fer_loc_srv);


--
-- Name: ossr_cpe ossr_cpe_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_cpe
    ADD CONSTRAINT ossr_cpe_fk03 FOREIGN KEY (idn_lne_acs) REFERENCES localds2.ossr_acs_lne(idn_lne_acs);


--
-- Name: ossr_cpe ossr_cpe_fk05; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_cpe
    ADD CONSTRAINT ossr_cpe_fk05 FOREIGN KEY (idx_adr) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_ctc_tnb ossr_ctc_tnb_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ctc_tnb
    ADD CONSTRAINT ossr_ctc_tnb_fk01 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme) ON DELETE CASCADE;


--
-- Name: ossr_ctc_tnb ossr_ctc_tnb_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ctc_tnb
    ADD CONSTRAINT ossr_ctc_tnb_fk02 FOREIGN KEY (cat_phn) REFERENCES localds2.ossr_phn_cat(cat_phn);


--
-- Name: ossr_ctx_grp ossr_ctx_grp_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ctx_grp
    ADD CONSTRAINT ossr_ctx_grp_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord);


--
-- Name: ossr_ctx_grp_svf ossr_ctx_grp_svf_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ctx_grp_svf
    ADD CONSTRAINT ossr_ctx_grp_svf_fk01 FOREIGN KEY (idx_ord, idn_grp_ctx, nbr_grp_sub_ctx) REFERENCES localds2.ossr_ctx_grp(idx_ord, idn_grp_ctx, nbr_grp_sub_ctx) ON DELETE CASCADE;


--
-- Name: ossr_dir_adr ossr_dir_adr_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_adr
    ADD CONSTRAINT ossr_dir_adr_fk01 FOREIGN KEY (idx_tnb, cde_ali, idx_dir, ind_dadl) REFERENCES localds2.ossr_dir_asi_lst(idx_tnb, cde_ali, idx_dir, ind_dadl) ON DELETE CASCADE;


--
-- Name: ossr_dir_adr ossr_dir_adr_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_adr
    ADD CONSTRAINT ossr_dir_adr_fk02 FOREIGN KEY (idx_adr) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_dir_adr ossr_dir_adr_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_adr
    ADD CONSTRAINT ossr_dir_adr_fk03 FOREIGN KEY (cde_rol_adr) REFERENCES localds2.ossr_adr_rol(cde_rol_adr);


--
-- Name: ossr_dir_asi_lst ossr_dir_asi_lst_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_asi_lst
    ADD CONSTRAINT ossr_dir_asi_lst_fk01 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb);


--
-- Name: ossr_dir_nme ossr_dir_nme_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_nme
    ADD CONSTRAINT ossr_dir_nme_fk01 FOREIGN KEY (idx_tnb, cde_ali, idx_dir, ind_dadl) REFERENCES localds2.ossr_dir_asi_lst(idx_tnb, cde_ali, idx_dir, ind_dadl) ON DELETE CASCADE;


--
-- Name: ossr_dir_nme ossr_dir_nme_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_nme
    ADD CONSTRAINT ossr_dir_nme_fk02 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme);


--
-- Name: ossr_dir_nme ossr_dir_nme_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dir_nme
    ADD CONSTRAINT ossr_dir_nme_fk03 FOREIGN KEY (cde_rol_nme) REFERENCES localds2.ossr_nme_rol(cde_rol_nme);


--
-- Name: ossr_dlv_adr ossr_dlv_adr_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dlv_adr
    ADD CONSTRAINT ossr_dlv_adr_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord) ON DELETE CASCADE;


--
-- Name: ossr_dlv_adr ossr_dlv_adr_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dlv_adr
    ADD CONSTRAINT ossr_dlv_adr_fk02 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme);


--
-- Name: ossr_dlv_adr ossr_dlv_adr_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_dlv_adr
    ADD CONSTRAINT ossr_dlv_adr_fk03 FOREIGN KEY (idx_adr) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_hdg_pge_yel ossr_hdg_pge_yel_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_hdg_pge_yel
    ADD CONSTRAINT ossr_hdg_pge_yel_fk01 FOREIGN KEY (idx_tnb, cde_ali, idx_dir, ind_dadl) REFERENCES localds2.ossr_dir_asi_lst(idx_tnb, cde_ali, idx_dir, ind_dadl) ON DELETE CASCADE;


--
-- Name: ossr_hg_trm ossr_hg_trm_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_hg_trm
    ADD CONSTRAINT ossr_hg_trm_fk01 FOREIGN KEY (idx_ord, tnb_plt) REFERENCES localds2.ossr_hun_grp(idx_ord, tnb_plt) ON DELETE CASCADE;


--
-- Name: ossr_hg_trm ossr_hg_trm_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_hg_trm
    ADD CONSTRAINT ossr_hg_trm_fk03 FOREIGN KEY (idn_lne_acs) REFERENCES localds2.ossr_acs_lne(idn_lne_acs);


--
-- Name: ossr_hun_grp ossr_hun_grp_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_hun_grp
    ADD CONSTRAINT ossr_hun_grp_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord);


--
-- Name: ossr_kar ossr_kar_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_kar
    ADD CONSTRAINT ossr_kar_fk01 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme);


--
-- Name: ossr_kar ossr_kar_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_kar
    ADD CONSTRAINT ossr_kar_fk02 FOREIGN KEY (cde_cic) REFERENCES localds2.ossr_car(cde_cic);


--
-- Name: ossr_kar ossr_kar_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_kar
    ADD CONSTRAINT ossr_kar_fk03 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb) ON DELETE CASCADE;


--
-- Name: ossr_lid ossr_lid_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lid
    ADD CONSTRAINT ossr_lid_fk01 FOREIGN KEY (idx_adr) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_lid ossr_lid_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lid
    ADD CONSTRAINT ossr_lid_fk02 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb) ON DELETE CASCADE;


--
-- Name: ossr_lid_nme ossr_lid_nme_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lid_nme
    ADD CONSTRAINT ossr_lid_nme_fk01 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_lid(idx_tnb);


--
-- Name: ossr_lid_nme ossr_lid_nme_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lid_nme
    ADD CONSTRAINT ossr_lid_nme_fk02 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme);


--
-- Name: ossr_lid_nme ossr_lid_nme_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lid_nme
    ADD CONSTRAINT ossr_lid_nme_fk03 FOREIGN KEY (cde_rol_nme) REFERENCES localds2.ossr_nme_rol(cde_rol_nme);


--
-- Name: ossr_lne_svf_pam ossr_lne_svf_pam_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lne_svf_pam
    ADD CONSTRAINT ossr_lne_svf_pam_fk01 FOREIGN KEY (nme_svf, idn_lne_acs) REFERENCES localds2.ossr_acs_lne_svf(nme_svf, idn_lne_acs);


--
-- Name: ossr_lne_svf_pam ossr_lne_svf_pam_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lne_svf_pam
    ADD CONSTRAINT ossr_lne_svf_pam_fk02 FOREIGN KEY (typ_pam, nme_svf) REFERENCES localds2.ossr_svf_pam(typ_pam, nme_svf);


--
-- Name: ossr_lsr_inf ossr_lsr_inf_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lsr_inf
    ADD CONSTRAINT ossr_lsr_inf_fk01 FOREIGN KEY (idx_adr_sav) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_lsr_inf ossr_lsr_inf_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lsr_inf
    ADD CONSTRAINT ossr_lsr_inf_fk02 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord) ON DELETE CASCADE;


--
-- Name: ossr_lst_txt_typ ossr_lst_txt_typ_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_lst_txt_typ
    ADD CONSTRAINT ossr_lst_txt_typ_fk01 FOREIGN KEY (idx_tnb, cde_ali, idx_dir, ind_dadl) REFERENCES localds2.ossr_dir_asi_lst(idx_tnb, cde_ali, idx_dir, ind_dadl) ON DELETE CASCADE;


--
-- Name: ossr_ord ossr_ord_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ord
    ADD CONSTRAINT ossr_ord_fk01 FOREIGN KEY (cde_sts_ord) REFERENCES localds2.ossr_ord_sts(cde_sts_ord);


--
-- Name: ossr_ord ossr_ord_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ord
    ADD CONSTRAINT ossr_ord_fk02 FOREIGN KEY (cat_chg) REFERENCES localds2.ossr_chg_cat(cat_chg);


--
-- Name: ossr_ord ossr_ord_fk05; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ord
    ADD CONSTRAINT ossr_ord_fk05 FOREIGN KEY (idx_fer_loc_srv) REFERENCES localds2.ossr_phy_srv_lcn(idx_fer_loc_srv);


--
-- Name: ossr_ord_rep ossr_ord_rep_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ord_rep
    ADD CONSTRAINT ossr_ord_rep_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord) ON DELETE CASCADE;


--
-- Name: ossr_ord_rep ossr_ord_rep_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ord_rep
    ADD CONSTRAINT ossr_ord_rep_fk02 FOREIGN KEY (idx_nme) REFERENCES localds2.ossr_nme(idx_nme) ON DELETE CASCADE;


--
-- Name: ossr_ord_rep ossr_ord_rep_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_ord_rep
    ADD CONSTRAINT ossr_ord_rep_fk03 FOREIGN KEY (cde_rol_nme) REFERENCES localds2.ossr_nme_rol(cde_rol_nme) ON DELETE CASCADE;


--
-- Name: ossr_phy_srv_lcn ossr_phy_srv_lcn_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_phy_srv_lcn
    ADD CONSTRAINT ossr_phy_srv_lcn_fk02 FOREIGN KEY (idx_adr_gni) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_phy_srv_lcn ossr_phy_srv_lcn_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_phy_srv_lcn
    ADD CONSTRAINT ossr_phy_srv_lcn_fk03 FOREIGN KEY (idx_adr_sag) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_svf_pam ossr_svf_pam_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_svf_pam
    ADD CONSTRAINT ossr_svf_pam_fk01 FOREIGN KEY (nme_svf) REFERENCES localds2.ossr_svf(nme_svf);


--
-- Name: ossr_svf_pam ossr_svf_pam_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_svf_pam
    ADD CONSTRAINT ossr_svf_pam_fk02 FOREIGN KEY (typ_pam) REFERENCES localds2.ossr_pam(typ_pam);


--
-- Name: ossr_t1 ossr_t1_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_t1
    ADD CONSTRAINT ossr_t1_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord);


--
-- Name: ossr_tkg_chn ossr_tkg_chn_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg_chn
    ADD CONSTRAINT ossr_tkg_chn_fk01 FOREIGN KEY (idn_tkg) REFERENCES localds2.ossr_tkg(idn_tkg) ON DELETE CASCADE;


--
-- Name: ossr_tkg_chn ossr_tkg_chn_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg_chn
    ADD CONSTRAINT ossr_tkg_chn_fk02 FOREIGN KEY (idn_t1) REFERENCES localds2.ossr_t1(idn_t1) ON DELETE CASCADE;


--
-- Name: ossr_tkg_chn ossr_tkg_chn_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg_chn
    ADD CONSTRAINT ossr_tkg_chn_fk03 FOREIGN KEY (idn_lne_acs) REFERENCES localds2.ossr_acs_lne(idn_lne_acs);


--
-- Name: ossr_tkg ossr_tkg_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg
    ADD CONSTRAINT ossr_tkg_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord);


--
-- Name: ossr_tkg ossr_tkg_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg
    ADD CONSTRAINT ossr_tkg_fk02 FOREIGN KEY (idx_ord_wrk) REFERENCES localds2.ossr_wko(idx_ord_wrk);


--
-- Name: ossr_tkg ossr_tkg_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg
    ADD CONSTRAINT ossr_tkg_fk03 FOREIGN KEY (cde_rsc_tol) REFERENCES localds2.ossr_rsc(cde_rsc_tol);


--
-- Name: ossr_tkg ossr_tkg_fk05; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg
    ADD CONSTRAINT ossr_tkg_fk05 FOREIGN KEY (idn_tkg_old) REFERENCES localds2.ossr_tkg(idn_tkg);


--
-- Name: ossr_tkg_psp ossr_tkg_psp_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tkg_psp
    ADD CONSTRAINT ossr_tkg_psp_fk01 FOREIGN KEY (idn_tkg) REFERENCES localds2.ossr_tkg(idn_tkg) ON DELETE CASCADE;


--
-- Name: ossr_tnb_adr ossr_tnb_adr_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb_adr
    ADD CONSTRAINT ossr_tnb_adr_fk01 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb);


--
-- Name: ossr_tnb_adr ossr_tnb_adr_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb_adr
    ADD CONSTRAINT ossr_tnb_adr_fk02 FOREIGN KEY (idx_adr) REFERENCES localds2.ossr_adr(idx_adr);


--
-- Name: ossr_tnb_adr ossr_tnb_adr_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb_adr
    ADD CONSTRAINT ossr_tnb_adr_fk03 FOREIGN KEY (cde_rol_adr) REFERENCES localds2.ossr_adr_rol(cde_rol_adr);


--
-- Name: ossr_tnb_cmn ossr_tnb_cmn_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb_cmn
    ADD CONSTRAINT ossr_tnb_cmn_fk01 FOREIGN KEY (idx_tnb) REFERENCES localds2.ossr_tnb(idx_tnb) ON DELETE CASCADE;


--
-- Name: ossr_tnb ossr_tnb_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb
    ADD CONSTRAINT ossr_tnb_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord) ON DELETE CASCADE;


--
-- Name: ossr_tnb ossr_tnb_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb
    ADD CONSTRAINT ossr_tnb_fk02 FOREIGN KEY (idx_ord, idn_grp_ctx, nbr_grp_sub_ctx) REFERENCES localds2.ossr_ctx_grp(idx_ord, idn_grp_ctx, nbr_grp_sub_ctx);


--
-- Name: ossr_tnb ossr_tnb_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb
    ADD CONSTRAINT ossr_tnb_fk03 FOREIGN KEY (idn_tkg) REFERENCES localds2.ossr_tkg(idn_tkg);


--
-- Name: ossr_tnb ossr_tnb_fk05; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb
    ADD CONSTRAINT ossr_tnb_fk05 FOREIGN KEY (idx_tnb_old) REFERENCES localds2.ossr_tnb(idx_tnb);


--
-- Name: ossr_tnb ossr_tnb_fk06; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tnb
    ADD CONSTRAINT ossr_tnb_fk06 FOREIGN KEY (idn_lne_acs) REFERENCES localds2.ossr_acs_lne(idn_lne_acs);


--
-- Name: ossr_tra_log ossr_tra_log_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tra_log
    ADD CONSTRAINT ossr_tra_log_fk01 FOREIGN KEY (cde_sts_tsk) REFERENCES localds2.ossr_tsk_sts(cde_sts_tsk);


--
-- Name: ossr_tsk_dri ossr_tsk_dri_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tsk_dri
    ADD CONSTRAINT ossr_tsk_dri_fk01 FOREIGN KEY (idx_ord) REFERENCES localds2.ossr_ord(idx_ord);


--
-- Name: ossr_tsk_dri ossr_tsk_dri_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_tsk_dri
    ADD CONSTRAINT ossr_tsk_dri_fk02 FOREIGN KEY (cde_sts_tsk) REFERENCES localds2.ossr_tsk_sts(cde_sts_tsk);


--
-- Name: ossr_wko ossr_wko_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.ossr_wko
    ADD CONSTRAINT ossr_wko_fk01 FOREIGN KEY (cde_sts_ord_wrk) REFERENCES localds2.ossr_wko_sts(cde_sts_ord_wrk);


--
-- Name: rehome_am_task_details rehome_am_task_details_fk; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.rehome_am_task_details
    ADD CONSTRAINT rehome_am_task_details_fk FOREIGN KEY (nbr_order) REFERENCES localds2.rehome_migration_ord(nbr_order) ON DELETE CASCADE;


--
-- Name: rehome_tnb rehome_tnb_fk; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.rehome_tnb
    ADD CONSTRAINT rehome_tnb_fk FOREIGN KEY (nbr_order) REFERENCES localds2.rehome_migration_ord(nbr_order) ON DELETE CASCADE;


--
-- Name: rehome_tnb_status rehome_tnb_status_nbr_order_fk; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.rehome_tnb_status
    ADD CONSTRAINT rehome_tnb_status_nbr_order_fk FOREIGN KEY (nbr_order, tnb) REFERENCES localds2.rehome_tnb(nbr_order, tnb) ON DELETE CASCADE;


--
-- Name: sddr_availability_ilec sddr_availability_ilec_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sddr_availability_ilec
    ADD CONSTRAINT sddr_availability_ilec_fk01 FOREIGN KEY (nbr_cic_ilec) REFERENCES localds2.sddr_info_ilec(nbr_cic_ilec);


--
-- Name: sddr_exception_avail_ilec sddr_exception_avail_ilec_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sddr_exception_avail_ilec
    ADD CONSTRAINT sddr_exception_avail_ilec_fk01 FOREIGN KEY (nbr_cic_ilec) REFERENCES localds2.sddr_info_ilec(nbr_cic_ilec);


--
-- Name: sdmr_car_ppt sdmr_car_ppt_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_car_ppt
    ADD CONSTRAINT sdmr_car_ppt_fk01 FOREIGN KEY (cde_qul) REFERENCES localds2.sdmr_qul_cde(cde_qul);


--
-- Name: sdmr_car_ppt sdmr_car_ppt_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_car_ppt
    ADD CONSTRAINT sdmr_car_ppt_fk02 FOREIGN KEY (nbr_npa, nbr_nxx, nbr_lne_beg, ind_jur, idn_pvd_srv) REFERENCES localds2.sdmr_equ_acs_tnb(nbr_npa, nbr_nxx, nbr_lne_beg, ind_jur, idn_pvd_srv);


--
-- Name: sdmr_car_ppt sdmr_car_ppt_fk03; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_car_ppt
    ADD CONSTRAINT sdmr_car_ppt_fk03 FOREIGN KEY (nbr_vdr) REFERENCES localds2.sdmr_vdr_idn(nbr_vdr);


--
-- Name: sdmr_equ_acs_tnb sdmr_equ_acs_tnb_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_equ_acs_tnb
    ADD CONSTRAINT sdmr_equ_acs_tnb_fk01 FOREIGN KEY (cde_are_mkt, cde_ste) REFERENCES localds2.sdmr_mkt_are(cde_are_mkt, cde_ste);


--
-- Name: sdmr_equ_acs_tnb sdmr_equ_acs_tnb_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_equ_acs_tnb
    ADD CONSTRAINT sdmr_equ_acs_tnb_fk02 FOREIGN KEY (idn_pvd_srv) REFERENCES localds2.sdmr_srv_pvd(idn_pvd_srv);


--
-- Name: sdmr_fax_idn_ctc sdmr_fax_idn_ctc_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_fax_idn_ctc
    ADD CONSTRAINT sdmr_fax_idn_ctc_fk01 FOREIGN KEY (idn_fax) REFERENCES localds2.sdmr_fax_idn(idn_fax);


--
-- Name: sdmr_fax_idn_ctc sdmr_fax_idn_ctc_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_fax_idn_ctc
    ADD CONSTRAINT sdmr_fax_idn_ctc_fk02 FOREIGN KEY (idn_ctc, dtx_eff) REFERENCES localds2.sdmr_fax_ctc(idn_ctc, dtx_eff);


--
-- Name: sdmr_fax_idn sdmr_fax_idn_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_fax_idn
    ADD CONSTRAINT sdmr_fax_idn_fk01 FOREIGN KEY (idn_pvd_srv) REFERENCES localds2.sdmr_srv_pvd(idn_pvd_srv);


--
-- Name: sdmr_ioc_swt sdmr_ioc_swt_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_ioc_swt
    ADD CONSTRAINT sdmr_ioc_swt_fk01 FOREIGN KEY (cde_ioc) REFERENCES localds2.sdmr_ioc(cde_ioc);


--
-- Name: sdmr_ocn sdmr_ocn_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_ocn
    ADD CONSTRAINT sdmr_ocn_fk01 FOREIGN KEY (idn_pvd_srv) REFERENCES localds2.sdmr_srv_pvd(idn_pvd_srv);


--
-- Name: sdmr_rev_loc_cde sdmr_rev_loc_cde_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_rev_loc_cde
    ADD CONSTRAINT sdmr_rev_loc_cde_fk01 FOREIGN KEY (cde_grp_loc_rev, grp_loc_rev_dtx_eff) REFERENCES localds2.sdmr_cus_pty_srv_grp(cde_grp_loc_rev, dtx_eff);


--
-- Name: sdmr_trdpt_hol sdmr_trdpt_hol_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_trdpt_hol
    ADD CONSTRAINT sdmr_trdpt_hol_fk01 FOREIGN KEY (idn_trdpt) REFERENCES localds2.sdmr_trdpt(idn_trdpt);


--
-- Name: sdmr_trdpt_tat sdmr_trdpt_tat_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_trdpt_tat
    ADD CONSTRAINT sdmr_trdpt_tat_fk01 FOREIGN KEY (idn_trdpt) REFERENCES localds2.sdmr_trdpt(idn_trdpt);


--
-- Name: sdmr_ttb sdmr_ttb_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_ttb
    ADD CONSTRAINT sdmr_ttb_fk01 FOREIGN KEY (typ_tbl) REFERENCES localds2.sdmr_tbl_idn(typ_tbl);


--
-- Name: sdmr_vdr_ctc sdmr_vdr_ctc_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_vdr_ctc
    ADD CONSTRAINT sdmr_vdr_ctc_fk01 FOREIGN KEY (idn_rol_ctc_vdr) REFERENCES localds2.sdmr_ctc_rol(idn_rol_ctc_vdr);


--
-- Name: sdmr_vdr_ctc sdmr_vdr_ctc_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_vdr_ctc
    ADD CONSTRAINT sdmr_vdr_ctc_fk02 FOREIGN KEY (nbr_vdr) REFERENCES localds2.sdmr_vdr_idn(nbr_vdr);


--
-- Name: sdmr_vdr_qul sdmr_vdr_qul_fk01; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_vdr_qul
    ADD CONSTRAINT sdmr_vdr_qul_fk01 FOREIGN KEY (cde_qul) REFERENCES localds2.sdmr_qul_cde(cde_qul);


--
-- Name: sdmr_vdr_qul sdmr_vdr_qul_fk02; Type: FK CONSTRAINT; Schema: localds2; Owner: dbadmin
--

ALTER TABLE ONLY localds2.sdmr_vdr_qul
    ADD CONSTRAINT sdmr_vdr_qul_fk02 FOREIGN KEY (nbr_vdr) REFERENCES localds2.sdmr_vdr_idn(nbr_vdr);


-- MJV added all privs to localds objects to nvoip user.
GRANT USAGE on SCHEMA localds2 to nvoip;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA localds2 TO nvoip;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds2 GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO nvoip;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA localds2 TO nvoip;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds2 GRANT USAGE ON SEQUENCES TO nvoip;

--
-- Name: LANGUAGE plpgsql; Type: ACL; Schema: -; Owner: nvoip
--

-- REVOKE ALL ON LANGUAGE plpgsql FROM PUBLIC;


--
-- nvoipQL database dump complete
--
