-- Create the main object owner, dbowner.
-- CREATE ROLE dbowner WITH LOGIN PASSWORD 'ReNw00dB' CREATEDB CREATEROLE;
-- Create the database and schemas
-- assumes the connect database already exists!!!
--CREATE DATABASE connectdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8' OWNER = postgres;
-- psql connectdb -a < ./roles.sql
-- psql connectdb -a < ./roles2.sql
-- psql connectdb -a < ./permissions.sql

ALTER ROLE dbadmin WITH PASSWORD 'Junk0101';
ALTER ROLE dbowner WITH PASSWORD 'ReNw00dB';
ALTER ROLE pgbouncer WITH PASSWORD 'pBb0youNseer';
ALTER ROLE postgres WITH PASSWORD 'Xr#wq31q';
ALTER ROLE replicator WITH PASSWORD 'Rr#ag32g';


CREATE SCHEMA IF NOT EXISTS activn   AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS bill     AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS audit    AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS config   AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS etl      AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS infra    AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS ordng    AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS svcinv   AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS tninv    AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS topology AUTHORIZATION postgres;
CREATE SCHEMA IF NOT EXISTS uui      AUTHORIZATION postgres;

-- Create the nonlogin schema roles
CREATE ROLE offshore NOLOGIN;
CREATE ROLE ldapuser NOLOGIN;
CREATE ROLE connectgrp NOLOGIN;
CREATE ROLE activn_ro;
CREATE ROLE activn_rw;
CREATE ROLE audit_ro;
CREATE ROLE audit_rw;
CREATE ROLE bill_ro;
CREATE ROLE bill_rw;
CREATE ROLE config_ro;
CREATE ROLE config_rw;
CREATE ROLE etl_ro;
CREATE ROLE etl_rw;
CREATE ROLE infra_ro;
CREATE ROLE infra_rw;
CREATE ROLE localds_ro;
CREATE ROLE localds_rw;
CREATE ROLE ordng_ro;
CREATE ROLE ordng_rw;
CREATE ROLE svcinv_ro;
CREATE ROLE svcinv_rw;
CREATE ROLE tninv_ro;
CREATE ROLE tninv_rw;
CREATE ROLE topology_ro;
CREATE ROLE topology_rw;
CREATE ROLE uui_ro;
CREATE ROLE uui_rw;

CREATE ROLE readers;
CREATE ROLE writers;

-- Now create login roles that map to their respective schemas
CREATE ROLE activn_app_reader LOGIN;
CREATE ROLE activn_app_writer LOGIN;
CREATE ROLE audit_app_reader LOGIN;  
CREATE ROLE audit_app_writer LOGIN;  
CREATE ROLE bill_app_reader LOGIN;   
CREATE ROLE bill_app_writer LOGIN;   
CREATE ROLE config_app_reader LOGIN;
CREATE ROLE config_app_writer LOGIN; 
CREATE ROLE infra_app_reader LOGIN;  
CREATE ROLE infra_app_writer LOGIN;  
CREATE ROLE localds_app_reader LOGIN;
CREATE ROLE localds_app_writer LOGIN;
CREATE ROLE ordng_app_reader LOGIN;  
CREATE ROLE ordng_app_writer LOGIN;  
CREATE ROLE svcinv_app_reader LOGIN; 
CREATE ROLE svcinv_app_writer LOGIN; 
CREATE ROLE tninv_app_reader LOGIN;  
CREATE ROLE tninv_app_writer LOGIN;  
CREATE ROLE topology_app_reader LOGIN;
CREATE ROLE topology_app_writer LOGIN;
CREATE ROLE uui_app_reader LOGIN;    
CREATE ROLE uui_app_writer LOGIN;    
CREATE ROLE flyway_app LOGIN;
CREATE ROLE etl_app LOGIN;

ALTER ROLE ROLE activn_app_reader WITH PASSWORD 'AppPassAAR';
ALTER ROLE activn_app_writer WITH PASSWORD 'AppPassAAW';
ALTER ROLE audit_app_reader WITH PASSWORD 'AppPass_AAR2';
ALTER ROLE audit_app_writer WITH PASSWORD 'AppPass_AAR2';
ALTER ROLE bill_app_reader WITH PASSWORD 'AppPass_BAR';
ALTER ROLE bill_app_writer WITH PASSWORD 'AppPass_BAW';
ALTER ROLE config_app_reader WITH PASSWORD 'AppPass_CAR';
ALTER ROLE config_app_writer WITH PASSWORD 'AppPass_CAW';
ALTER ROLE etl_app WITH PASSWORD 'AppPass_EA';
ALTER ROLE flyway_app WITH PASSWORD 'AppPass_FA';
ALTER ROLE infra_app_reader WITH PASSWORD 'AppPass_IAR';
ALTER ROLE infra_app_writer WITH PASSWORD 'AppPass_IAW';
ALTER ROLE localds_app_reader WITH PASSWORD 'AppPass_LAR';
ALTER ROLE localds_app_writer WITH PASSWORD 'AppPass_LAW';
ALTER ROLE ordng_app_reader WITH PASSWORD 'AppPass_OAR';
ALTER ROLE ordng_app_writer WITH PASSWORD 'AppPass_OAW';
ALTER ROLE svcinv_app_reader WITH PASSWORD 'AppPass_SAR';
ALTER ROLE svcinv_app_writer WITH PASSWORD 'AppPass_SAW';
ALTER ROLE tninv_app_reader WITH PASSWORD 'AppPass_TAR';
ALTER ROLE tninv_app_writer WITH PASSWORD 'AppPass_TAW';
ALTER ROLE topology_app_reader WITH PASSWORD 'AppPass_TAR2';
ALTER ROLE topology_app_writer WITH PASSWORD 'AppPass_TAW2';
ALTER ROLE uui_app_reader WITH PASSWORD 'AppPass_UAR';
ALTER ROLE uui_app_writer WITH PASSWORD 'AppPass_UAW';

-- this query gets list of users that are not offshore and can have their passwords reset and readded to ldapuser group.
select usename from pg_user where not usesuper and usename not like '%reader' and usename not like '%writer' and usename not like '%app' and usename not in ('v000094','v027041','v093804','v160866','v399971', 'v474870','v490255','v525450','v530285', 'v591000','v647889','v748300','shaam72','hakeemo','guptra4','dbowner','replicator') order by usename;

select 'ALTER ROLE ' || usename || ' PASSWORD null;' as achange from pg_user where not usesuper and usename not like '%reader' and usename not like '%writer' and usename not like '%app' and usename not in ('v000094','v027041','v093804','v160866','v399971', 'v474870','v490255','v525450','v530285', 'v591000','v647889','v748300','shaam72','hakeemo','guptra4','dbowner','replicator') order by usename;
 
-- after executing that script, re-add them to ldapuser group;
select 'GRANT ldapuser TO ' || usename || ';' as achange from pg_user where not usesuper and usename not like '%reader' and usename not like '%writer' and usename not like '%app' and usename not in ('v000094','v027041','v093804','v160866','v399971', 'v474870','v490255','v525450','v530285', 'v591000','v647889','v748300','shaam72','hakeemo','guptra4','dbowner','replicator') order by usename;





-- -------------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------

-- revoke all privileges on public schema
REVOKE ALL ON DATABASE connectdb FROM PUBLIC;
REVOKE USAGE ON LANGUAGE plpgsql FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM public;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

-- revoke all privs for login roles
revoke all privileges on all tables in schema activn, audit, bill, config, infra, ordng, svcinv, tninv, topology, uui from activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
REVOKE ALL ON DATABASE connectdb FROM activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
REVOKE ALL on schema activn, audit, bill, config, infra, ordng, svcinv, tninv, topology, uui from activn_ro, activn_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA activn, audit, bill, config, infra, ordng, svcinv, tninv, topology, uui FROM activn_ro, activn_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA activn, audit, bill, config, infra, ordng, svcinv, tninv, topology, uui REVOKE ALL ON TABLES FROM activn_ro, activn_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON SCHEMAS FROM activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON TABLES FROM activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON SEQUENCES FROM activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;
ALTER DEFAULT PRIVILEGES REVOKE ALL ON FUNCTIONS FROM activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;

-- add basic privs on PUBLIC to all
GRANT USAGE ON SCHEMA public TO activn_ro, audit_ro, bill_ro, config_ro, infra_ro, localds_ro, ordng_ro, svcinv_ro, tninv_ro, topology_ro, uui_ro;

-- Grant usage on all schemas to all schema non-login roles
GRANT USAGE ON SCHEMA activn, audit, bill, config, infra, localds, ordng, svcinv, tninv, topology, uui TO activn_ro, activn_rw, audit_ro, audit_rw, bill_ro, bill_rw, config_ro, config_rw, infra_ro, infra_rw, localds_ro, localds_rw, ordng_ro, ordng_rw, svcinv_ro, svcinv_rw, tninv_ro, tninv_rw, topology_ro, topology_rw, uui_ro, uui_rw;

-- Grant SELECT permissions for schema/schema user ro pairs
GRANT SELECT ON ALL TABLES IN SCHEMA activn TO activn_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA activn TO activn_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA activn GRANT USAGE,SELECT ON SEQUENCES TO activn_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA activn GRANT SELECT ON TABLES TO activn_ro;
ALTER ROLE activn_ro SET search_path TO 'activn, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA audit TO audit_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA audit TO audit_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT USAGE,SELECT ON SEQUENCES TO audit_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT SELECT ON TABLES TO audit_ro;
ALTER ROLE activn_ro SET search_path TO 'audit, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA bill TO bill_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA bill TO bill_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA bill GRANT USAGE,SELECT ON SEQUENCES TO bill_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA bill GRANT SELECT ON TABLES TO bill_ro;
ALTER ROLE bill_ro SET search_path TO 'bill, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA config TO config_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA config TO config_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA config GRANT USAGE,SELECT ON SEQUENCES TO config_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA config GRANT SELECT ON TABLES TO config_ro;
ALTER ROLE config_ro SET search_path TO 'config, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA etl TO etl_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA etl TO etl_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA etl GRANT USAGE,SELECT ON SEQUENCES TO etl_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA etl GRANT SELECT ON TABLES TO etl_ro;
ALTER ROLE etl_ro SET search_path TO 'etl, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA infra TO infra_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA infra TO infra_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA infra GRANT USAGE,SELECT ON SEQUENCES TO infra_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA infra GRANT SELECT ON TABLES TO infra_ro;
ALTER ROLE infra_ro SET search_path TO 'infra, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA localds TO localds_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA localds TO localds_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds GRANT USAGE,SELECT ON SEQUENCES TO localds_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds GRANT SELECT ON TABLES TO localds_ro;
ALTER ROLE localds_ro SET search_path TO 'localds, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA ordng TO ordng_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA ordng TO ordng_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA ordng GRANT USAGE,SELECT ON SEQUENCES TO ordng_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA ordng GRANT SELECT ON TABLES TO ordng_ro;
ALTER ROLE ordng_ro SET search_path TO 'ordng, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA svcinv TO svcinv_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA svcinv TO svcinv_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA svcinv GRANT USAGE,SELECT ON SEQUENCES TO svcinv_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA svcinv GRANT SELECT ON TABLES TO svcinv_ro;
ALTER ROLE svcinv_ro SET search_path TO 'svcinv, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA tninv TO tninv_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA tninv TO tninv_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA tninv GRANT USAGE,SELECT ON SEQUENCES TO tninv_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA tninv GRANT SELECT ON TABLES TO tninv_ro;
ALTER ROLE tninv_ro SET search_path TO 'tninv, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA topology TO topology_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA topology TO topology_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA topology GRANT USAGE,SELECT ON SEQUENCES TO topology_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA topology GRANT SELECT ON TABLES TO topology_ro;
ALTER ROLE topology_ro SET search_path TO 'topology, pg_catalog';

GRANT SELECT ON ALL TABLES IN SCHEMA uui TO uui_ro;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA uui TO uui_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA uui GRANT USAGE,SELECT ON SEQUENCES TO uui_ro;
ALTER DEFAULT PRIVILEGES IN SCHEMA uui GRANT SELECT ON TABLES TO uui_ro;
ALTER ROLE uui_ro SET search_path TO 'uui, pg_catalog';

-- Grant ro roles to rw roles
-- activn, config, infra, ordng, svcinv, tninv, topology, uui
GRANT activn_ro to activn_rw;
GRANT audit_ro to audit_rw;
GRANT bill_ro  to bill_rw;
GRANT config_ro to config_rw;
GRANT etl_ro TO etl_rw;
GRANT infra_ro to infra_rw;
GRANT localds_ro to localds_rw;
GRANT ordng_ro to ordng_rw;
GRANT svcinv_ro to svcinv_rw;
GRANT tninv_ro to tninv_rw;
GRANT topology_ro to topology_rw;
GRANT uui_ro to uui_rw;

-- Give RW pris to the rw roles
GRANT ALL ON ALL TABLES IN SCHEMA activn TO activn_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA activn TO activn_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA activn to activn_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA activn GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO activn_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA activn GRANT ALL ON TABLES TO activn_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA activn GRANT EXECUTE ON FUNCTIONS TO activn_rw;
ALTER DEFAULT PRIVILEGES IN schema activn grant all ON types to activn_rw;
ALTER ROLE activn_rw SET search_path TO 'activn, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA audit TO audit_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA audit TO audit_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA audit to audit_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO audit_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT ALL ON TABLES TO audit_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA audit GRANT EXECUTE ON FUNCTIONS TO audit_rw;
ALTER DEFAULT PRIVILEGES IN schema audit grant all ON types to audit_rw;
ALTER ROLE audit_rw SET search_path TO 'audit, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA bill TO bill_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA bill TO bill_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA bill to bill_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA bill GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO bill_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA bill GRANT ALL ON TABLES TO bill_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA bill GRANT EXECUTE ON FUNCTIONS TO bill_rw;
ALTER DEFAULT PRIVILEGES IN schema bill grant all ON types to bill_rw;
ALTER ROLE bill_rw SET search_path TO 'bill, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA config TO config_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA config TO config_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA config to config_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA config GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO config_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA config GRANT ALL ON TABLES TO config_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA config GRANT EXECUTE ON FUNCTIONS TO config_rw;
ALTER DEFAULT PRIVILEGES IN schema config grant all ON types to config_rw;
ALTER ROLE config_rw SET search_path TO 'config, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA etl TO etl_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA etl TO etl_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA etl to etl_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA etl GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO etl_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA etl GRANT ALL ON TABLES TO etl_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA etl GRANT EXECUTE ON FUNCTIONS TO etl_rw;
ALTER DEFAULT PRIVILEGES IN schema etl grant all ON types to etl_rw;
ALTER ROLE etl_rw SET search_path TO 'etl, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA infra TO infra_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA infra TO infra_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA infra to infra_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA infra GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO infra_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA infra GRANT ALL ON TABLES TO infra_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA infra GRANT EXECUTE ON FUNCTIONS TO infra_rw;
ALTER DEFAULT PRIVILEGES IN schema infra grant all ON types to infra_rw;
ALTER ROLE infra_rw SET search_path TO 'infra, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA localds TO localds_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA localds TO localds_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA localds to localds_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO localds_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds GRANT ALL ON TABLES TO localds_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA localds GRANT EXECUTE ON FUNCTIONS TO localds_rw;
ALTER DEFAULT PRIVILEGES IN schema localds grant all ON types to localds_rw;
ALTER ROLE localds_rw SET search_path TO 'localds, pg_catalog';


GRANT ALL ON ALL TABLES IN SCHEMA ordng TO ordng_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA ordng TO ordng_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA ordng to ordng_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA ordng GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO ordng_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA ordng GRANT ALL ON TABLES TO ordng_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA ordng GRANT EXECUTE ON FUNCTIONS TO ordng_rw;
ALTER DEFAULT PRIVILEGES IN schema ordng grant all ON types to ordng_rw;
ALTER ROLE ordng_rw SET search_path TO 'ordng, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA svcinv TO svcinv_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA svcinv TO svcinv_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA svcinv to svcinv_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA svcinv GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO svcinv_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA svcinv GRANT ALL ON TABLES TO svcinv_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA svcinv GRANT EXECUTE ON FUNCTIONS TO svcinv_rw;
ALTER DEFAULT PRIVILEGES IN schema svcinv grant all ON types to svcinv_rw;
ALTER ROLE svcinv_rw SET search_path TO 'svcinv, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA tninv TO tninv_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA tninv TO tninv_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA tninv to tninv_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA tninv GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO tninv_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA tninv GRANT ALL ON TABLES TO tninv_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA tninv GRANT EXECUTE ON FUNCTIONS TO tninv_rw;
ALTER DEFAULT PRIVILEGES IN schema tninv grant all ON types to tninv_rw;
ALTER ROLE tninv_rw SET search_path TO 'tninv, pg_catalog';

GRANT ALL ON ALL TABLES IN SCHEMA topology TO topology_rw;
GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA topology TO topology_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA topology to topology_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA topology GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO topology_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA topology GRANT ALL ON TABLES TO topology_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA topology GRANT EXECUTE ON FUNCTIONS TO topology_rw;
ALTER DEFAULT PRIVILEGES IN schema topology grant all ON types to topology_rw;
ALTER ROLE topology_rw SET search_path TO 'topology, pg_catalog';

GRANT USAGE,SELECT,UPDATE ON ALL SEQUENCES IN SCHEMA uui TO uui_rw;
GRANT ALL PRIVILEGES ON ALL functions IN SCHEMA uui to uui_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA uui GRANT USAGE,SELECT,UPDATE ON SEQUENCES TO uui_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA uui GRANT ALL ON TABLES TO uui_rw;
ALTER DEFAULT PRIVILEGES IN SCHEMA uui GRANT EXECUTE ON FUNCTIONS TO uui_rw;
ALTER DEFAULT PRIVILEGES IN schema uui grant all ON types to uui_rw;
ALTER ROLE uui_rw SET search_path TO 'uui, pg_catalog';

-- create top level read and readwrite users for pg_hba.conf authentication
-- REVOKE readers from activn_ro, audit_ro, bill_ro, config_ro, infra_ro, ordng_ro, svcinv_ro, tninv_ro, topology_ro, uui_ro;
-- REVOKE writers from activn_rw, audit_rw, bill_rw, config_rw, infra_rw, ordng_rw, svcinv_rw, tninv_rw, topology_rw, uui_rw;
GRANT activn_ro, audit_ro, bill_ro, config_ro, infra_ro, localds_ro, ordng_ro, svcinv_ro, tninv_ro, topology_ro, uui_ro to readers;
GRANT activn_rw, audit_rw, bill_rw, config_rw, infra_rw, localds_rw, ordng_rw, svcinv_rw, tninv_rw, topology_rw, uui_rw to writers;
GRANT CONNECT ON DATABASE connectdb to readers,writers, connectgrp;

--REVOKE CONNECT ON DATABASE connectdb FROM bishma2,hyderri,mohamu9,nagasa6,perura3,rajesa6,raviva,sahoan5,v000094,v027041,v093804,v399971,v474870,v490255,v530285,v647889,v748300,v864498;
GRANT activn_ro TO activn_app_reader;
GRANT activn_rw TO activn_app_writer;
GRANT audit_ro TO audit_app_reader;
GRANT audit_rw TO audit_app_writer;
GRANT bill_ro TO bill_app_reader;
GRANT bill_rw TO bill_app_writer;
GRANT config_ro TO config_app_reader;
GRANT config_rw TO config_app_writer;
GRANT infra_ro TO infra_app_reader;
GRANT infra_rw TO infra_app_writer;
GRANT ordng_ro TO ordng_app_reader;
GRANT ordng_rw TO ordng_app_writer;
GRANT svcinv_ro TO svcinv_app_reader;
GRANT svcinv_rw TO svcinv_app_writer;
GRANT tninv_ro TO tninv_app_reader;
GRANT tninv_rw TO tninv_app_writer;
GRANT topology_ro TO topology_app_reader;
GRANT topology_rw TO topology_app_writer;
GRANT uui_ro TO uui_app_reader;
GRANT uui_rw TO uui_app_writer;

GRANT CONNECT ON DATABASE connectdb to activn_ro, audit_ro, bill_ro, config_ro, infra_ro, ordng_ro, svcinv_ro, tninv_ro, topology_ro, uui_ro;
GRANT connectgrp TO activn_ro, audit_ro, bill_ro, config_ro, infra_ro, ordng_ro, svcinv_ro, tninv_ro, topology_ro, uui_ro;

-- Create app-related login roles: flyway_usr, etl_usr that have readwrite access to all schemas
GRANT writers to flyway_app, etl_app;
GRANT etl_ro, etl_rw TO etl_app;
GRANT tninv_rw TO etl_app;
ALTER ROLE flyway_app WITH CREATEDB;
ALTER ROLE etl_app WITH CREATEDB;
GRANT USAGE, CREATE ON SCHEMA activn, audit, bill, config, etl, infra, localds, ordng, svcinv, tninv, topology, uui TO flyway_app, etl_app;

GRANT localds_ro, connectgrp TO localds_app_reader;
GRANT localds_rw, connectgrp TO localds_app_writer;

-- need this for login users to create tables and give ownership to dbowner
GRANT dbowner to flyway_app, etl_app;

-- test this out for dbadmin and vitalmi
GRANT ldapuser TO connectgrp;

-- CREATE ROLE vitalmi WITH LOGIN PASSWORD 'vitalemi';
CREATE ROLE vitalmi WITH LOGIN
GRANT connectgrp to vitalmi;

-- -------------------------------------------------------------------------------------------------------------------------------------------------
-- ALTER DEFAULT PRIVS for flyway and dbowner for all schemas. re-execute DDL below for both dbowner and flyway_app.  Run this as the dbadmin user.
-- -------------------------------------------------------------------------------------------------------------------------------------------------

-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: activn; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn GRANT SELECT,USAGE ON SEQUENCES  TO activn_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn GRANT ALL ON SEQUENCES  TO activn_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: activn; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn GRANT SELECT ON TABLES  TO activn_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn GRANT ALL ON TABLES  TO activn_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA activn GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: bill; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill GRANT SELECT,USAGE ON SEQUENCES  TO bill_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill GRANT ALL ON SEQUENCES  TO bill_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: bill; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill GRANT ALL ON TABLES  TO dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill GRANT SELECT ON TABLES  TO bill_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA bill GRANT ALL ON TABLES  TO bill_rw;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: config; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config GRANT SELECT,USAGE ON SEQUENCES  TO config_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config GRANT ALL ON SEQUENCES  TO config_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: config; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config GRANT SELECT ON TABLES  TO config_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config GRANT ALL ON TABLES  TO config_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA config GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: infra; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra GRANT SELECT,USAGE ON SEQUENCES  TO infra_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra GRANT ALL ON SEQUENCES  TO infra_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: infra; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra GRANT SELECT ON TABLES  TO infra_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra GRANT ALL ON TABLES  TO infra_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA infra GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: localds; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds GRANT SELECT,USAGE ON SEQUENCES  TO localds_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds GRANT ALL ON SEQUENCES  TO localds_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: localds; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds GRANT ALL ON TABLES  TO dbadmin;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds GRANT SELECT ON TABLES  TO localds_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA localds GRANT ALL ON TABLES  TO localds_rw;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: ordng; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng GRANT SELECT,USAGE ON SEQUENCES  TO ordng_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng GRANT ALL ON SEQUENCES  TO ordng_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: ordng; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng GRANT SELECT ON TABLES  TO ordng_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng GRANT ALL ON TABLES  TO ordng_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA ordng GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA public REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA public GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: svcinv; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv GRANT SELECT,USAGE ON SEQUENCES  TO svcinv_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv GRANT ALL ON SEQUENCES  TO svcinv_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: svcinv; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv GRANT SELECT ON TABLES  TO svcinv_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv GRANT ALL ON TABLES  TO svcinv_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA svcinv GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: tninv; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv GRANT SELECT,USAGE ON SEQUENCES  TO tninv_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv GRANT ALL ON SEQUENCES  TO tninv_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: tninv; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv GRANT SELECT ON TABLES  TO tninv_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv GRANT ALL ON TABLES  TO tninv_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA tninv GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: topology; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology GRANT SELECT,USAGE ON SEQUENCES  TO topology_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology GRANT ALL ON SEQUENCES  TO topology_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: topology; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology GRANT SELECT ON TABLES  TO topology_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology GRANT ALL ON TABLES  TO topology_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA topology GRANT ALL ON TABLES  TO dbowner;
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: uui; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA uui REVOKE ALL ON SEQUENCES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA uui GRANT SELECT,USAGE ON SEQUENCES  TO uui_ro;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA uui GRANT ALL ON SEQUENCES  TO uui_rw;
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: uui; Owner: dbowner
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA uui REVOKE ALL ON TABLES  FROM dbowner;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA uui GRANT ALL ON TABLES  TO uui_rw;
ALTER DEFAULT PRIVILEGES FOR ROLE dbowner IN SCHEMA uui GRANT ALL ON TABLES  TO dbowner;


-- -------------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------

-- REVOKE activn_ro, audit_ro, bill_ro, config_ro, infra_ro, ordng_ro, svcinv_ro, tninv_ro, topology_ro, uui_ro FROM MOHAMU9, v399971, bishma2, sahoan5, "2629230", v027041, v474870, v748300, v647889, v093804, nagasa6, hyderri, RAJESA6;

-- Grant permissions to the database for the login roles;
-- SELECT 'GRANT CONNECT ON DATABASE connectdb TO ' || string_agg(usename, ',' order by usename) || ';' from pg_user order by 1;
-- GRANT CONNECT ON DATABASE connectdb TO bishma2,dbadmin,hyderri,mohamu9,nagasa6,perura3,pgbouncer,postgres,rajesa6,raviva,repuser,sahoan5,v000094,v027041,v093804,v399971,v474870,v490255,v530285,v647889,v748300,v864498;

-- set owner of all objects in all schemas to postgres;
--tables
SELECT 'Alter table ' || n.nspname || '.' || c.relname || ' owner to postgres;' as ddl FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('r','') AND n.nspname in ( 'activn','config','infra','ordng','svcinv','tninv','topology','uui')  ORDER BY n.nspname, c.relname;
-- schemas
SELECT 'ALTER SCHEMA ' || n.nspname || ' OWNER TO postgres;' as ddl FROM pg_catalog.pg_namespace n WHERE n.nspname !~ '^pg_' AND n.nspname not in ('information_schema') ORDER BY 1;
-- sequences
SELECT 'ALTER SEQUENCE ' || n.nspname || '.' || c.relname || ' OWNER TO postgres;' FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('S','s','') AND n.nspname !~ '^pg_toast' AND n.nspname not in ('information_schema') ORDER BY n.nspname, c.relname;
-- views
SELECT 'ALTER VIEW ' || c.relname || ' OWNER TO postgres;' FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('v','s','') AND n.nspname not in ('pg_catalog', 'pg_toast','information_schema') order by 1;
-- materialized views
SELECT 'ALTER MATERIALIZED VIEW ' || n.nspname || '.' || c.relname || ' OWNER TO postgres;' as ddl FROM pg_catalog.pg_class c LEFT JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace WHERE c.relkind IN ('m','s','') AND n.nspname not in ('pg_catalog', 'pg_toast','information_schema') ORDER BY n.nspname, c.relname;
-- types
SELECT 'ALTER TYPE ' || pg_catalog.format_type(t.oid, NULL) || ';' FROM pg_catalog.pg_type t LEFT JOIN pg_catalog.pg_namespace n ON n.oid = t.typnamespace WHERE (t.typrelid = 0 OR (SELECT c.relkind = 'c' FROM pg_catalog.pg_class c WHERE c.oid = t.typrelid))   AND NOT EXISTS(SELECT 1 FROM pg_catalog.pg_type el WHERE el.oid = t.typelem AND el.typarray = t.oid) AND n.nspname not in ('pg_catalog', 'pg_toast','information_schema') order by 1;
-- functions
 SELECT  a.rolname as owner, n.nspname, p.proname, p.pronargs, p.proargtypes, p.proallargtypes FROM pg_catalog.pg_namespace n JOIN pg_catalog.pg_proc p ON p.pronamespace = n.oid JOIN pg_authid a ON (p.proowner = a.oid) and n.nspname in ('tninv') order by p.proname limit 1;
 owner   | nspname |       proname       | pronargs | proargtypes | proallargtypes
---------+---------+---------------------+----------+-------------+----------------
 dbadmin | tninv   | delete_data_connect |        0 |             |
ALTER FUNCTION tninv.delete_data_connect() OWNER TO postgres;


-- user passwords list based on above access control rules definitions:
flyway_app 'v34E2231'
etl_app 'ETLapp3423'

-- -------------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------------------------------

-- need this for login users to create tables and give ownership to dbowner
-- Then flyway_app creates the table and sets owner
-- alter table activn.t3 owner to dbowner
-- then privileges show up
-- but if set role dbowner, and then create the table, privs dont show up

-- -------------------------------------------------------------------------------------------------------------------------------
-- INDIVIDUAL LOGIN ROLES
-- -------------------------------------------------------------------------------------------------------------------------------

-- query to detect wrong stuff and set it correctly, ie no reader or writer permissions for individual login users.
select a1.rolname, string_agg(a2.rolname,',' order by a2.rolname) from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' and a2.rolname in ('ldapuser','readers','writers','offshore','connectgrp') group by a1.rolname order by a1.rolname;
-- After correcting stuff, then do the queries to generate the DDL below

-- Create all individual login roles:
select 'CREATE ROLE ' || a1.rolname || ' LOGIN;' as changes from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' and a2.rolname in ('ldapuser','readers','writers','offshore','connectgrp') group by a1.rolname order by a1.rolname;
 CREATE ROLE amatsu3 LOGIN;
 CREATE ROLE annamve LOGIN;
 CREATE ROLE appiaja LOGIN;
 CREATE ROLE archve3 LOGIN;
 CREATE ROLE avalara LOGIN;
 CREATE ROLE babugpr LOGIN;
 CREATE ROLE baigkh LOGIN;
 CREATE ROLE balanpr LOGIN;
 CREATE ROLE bandlka LOGIN;
 CREATE ROLE bishma2 LOGIN;
 CREATE ROLE bodduve LOGIN;
 CREATE ROLE chanmo8 LOGIN;
 CREATE ROLE chatrma LOGIN;
 CREATE ROLE chattni LOGIN;
 CREATE ROLE chitudi9 LOGIN;
 CREATE ROLE chowksr LOGIN;
 CREATE ROLE dangka8 LOGIN;
 CREATE ROLE dasal LOGIN;
 CREATE ROLE daspi2i LOGIN;
 CREATE ROLE dhatcdh LOGIN;
 CREATE ROLE dodlave LOGIN;
 CREATE ROLE ekamvi2 LOGIN;
 CREATE ROLE elumadi LOGIN;
 CREATE ROLE gangan1 LOGIN;
 CREATE ROLE gangan5 LOGIN;
 CREATE ROLE gummara LOGIN;
 CREATE ROLE guptra4 LOGIN;
 CREATE ROLE hakeemo LOGIN;
 CREATE ROLE hyderri LOGIN;
 CREATE ROLE jainri9 LOGIN;
 CREATE ROLE jhabr LOGIN;
 CREATE ROLE kalagsu LOGIN;
 CREATE ROLE kanumve LOGIN;
 CREATE ROLE kavalgo LOGIN;
 CREATE ROLE kja4vd8 LOGIN;
 CREATE ROLE koduran LOGIN;
 CREATE ROLE kollasa LOGIN;
 CREATE ROLE kondaga LOGIN;
 CREATE ROLE konjeve LOGIN;
 CREATE ROLE kotaan8 LOGIN;
 CREATE ROLE koyyale LOGIN;
 CREATE ROLE krissh8 LOGIN;
 CREATE ROLE krisud4 LOGIN;
 CREATE ROLE kumari3 LOGIN;
 CREATE ROLE kumsu1b LOGIN;
 CREATE ROLE madhuar LOGIN;
 CREATE ROLE makira8 LOGIN;
 CREATE ROLE malra41 LOGIN;
 CREATE ROLE mha212c LOGIN;
 CREATE ROLE mohakh9 LOGIN;
 CREATE ROLE mohamu9 LOGIN;
 CREATE ROLE moosa9d LOGIN;
 CREATE ROLE mri2nks LOGIN;
 CREATE ROLE mudadva LOGIN;
 CREATE ROLE muruksa LOGIN;
 CREATE ROLE muthira LOGIN;
 CREATE ROLE nagasa6 LOGIN;
 CREATE ROLE opr1kxz LOGIN;
 CREATE ROLE pandade LOGIN;
 CREATE ROLE pasupli LOGIN;
 CREATE ROLE perura3 LOGIN;
 CREATE ROLE rahaso LOGIN;
 CREATE ROLE rajamsa LOGIN;
 CREATE ROLE rajesa6 LOGIN;
 CREATE ROLE ramase6 LOGIN;
 CREATE ROLE ratnamo LOGIN;
 CREATE ROLE raviva LOGIN;
 CREATE ROLE rba3gha LOGIN;
 CREATE ROLE rohit LOGIN;
 CREATE ROLE sahoan5 LOGIN;
 CREATE ROLE sahuam LOGIN;
 CREATE ROLE saraba5 LOGIN;
 CREATE ROLE sethsu5 LOGIN;
 CREATE ROLE shaam72 LOGIN;
 CREATE ROLE singhic LOGIN;
 CREATE ROLE singive LOGIN;
 CREATE ROLE sivabsh LOGIN;
 CREATE ROLE spvi LOGIN;
 CREATE ROLE sundra7 LOGIN;
 CREATE ROLE suresi4 LOGIN;
 CREATE ROLE swamish LOGIN;
 CREATE ROLE thanaka LOGIN;
 CREATE ROLE thanka LOGIN;
 CREATE ROLE thora9z LOGIN;
 CREATE ROLE udumafa LOGIN;
 CREATE ROLE v000094 LOGIN;
 CREATE ROLE v027041 LOGIN;
 CREATE ROLE v093804 LOGIN;
 CREATE ROLE v160866 LOGIN;
 CREATE ROLE v399971 LOGIN;
 CREATE ROLE v474870 LOGIN;
 CREATE ROLE v490255 LOGIN;
 CREATE ROLE v525226 LOGIN;
 CREATE ROLE v525450 LOGIN;
 CREATE ROLE v530285 LOGIN;
 CREATE ROLE v591000 LOGIN;
 CREATE ROLE v647889 LOGIN;
 CREATE ROLE v748300 LOGIN;
 CREATE ROLE v864498 LOGIN;
 CREATE ROLE varadar LOGIN;
 CREATE ROLE varmab7 LOGIN;
 CREATE ROLE vitalmi LOGIN;
 CREATE ROLE yadasu3 LOGIN;
 CREATE ROLE yagneti LOGIN;
 CREATE ROLE yalavba LOGIN;
 CREATE ROLE yarrusa LOGIN;
 CREATE ROLE z054447 LOGIN;
 CREATE ROLE z889123 LOGIN;

-- generate list of offshore roles whose password is their VZID to add their passwords;
select a1.rolname, string_agg(a2.rolname,',' order by a2.rolname) from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' and a2.rolname in ('offshore') group by a1.rolname order by a1.rolname;
select 'ALTER ROLE ' || a1.rolname || ' WITH PASSWORD ''' || a1.rolname || ''';' from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' and a2.rolname in ('offshore') group by a1.rolname order by a1.rolname;
 ALTER ROLE amatsu3 WITH PASSWORD 'amatsu3';
 ALTER ROLE archve3 WITH PASSWORD 'archve3';
 ALTER ROLE avalara WITH PASSWORD 'avalara';
 ALTER ROLE babugpr WITH PASSWORD 'babugpr';
 ALTER ROLE baigkh WITH PASSWORD 'baigkh';
 ALTER ROLE balanpr WITH PASSWORD 'balanpr';
 ALTER ROLE bandlka WITH PASSWORD 'bandlka';
 ALTER ROLE chanmo8 WITH PASSWORD 'chanmo8';
 ALTER ROLE chowksr WITH PASSWORD 'chowksr';
 ALTER ROLE dasal WITH PASSWORD 'dasal';
 ALTER ROLE dodlave WITH PASSWORD 'dodlave';
 ALTER ROLE ekamvi2 WITH PASSWORD 'ekamvi2';
 ALTER ROLE elumadi WITH PASSWORD 'elumadi';
 ALTER ROLE gangan1 WITH PASSWORD 'gangan1';
 ALTER ROLE gangan5 WITH PASSWORD 'gangan5';
 ALTER ROLE guptra4 WITH PASSWORD 'guptra4';
 ALTER ROLE hakeemo WITH PASSWORD 'hakeemo';
 ALTER ROLE hyderri WITH PASSWORD 'hyderri';
 ALTER ROLE jhabr WITH PASSWORD 'jhabr';
 ALTER ROLE kavalgo WITH PASSWORD 'kavalgo';
 ALTER ROLE kja4vd8 WITH PASSWORD 'kja4vd8';
 ALTER ROLE kollasa WITH PASSWORD 'kollasa';
 ALTER ROLE konjeve WITH PASSWORD 'konjeve';
 ALTER ROLE kotaan8 WITH PASSWORD 'kotaan8';
 ALTER ROLE koyyale WITH PASSWORD 'koyyale';
 ALTER ROLE krisud4 WITH PASSWORD 'krisud4';
 ALTER ROLE madhuar WITH PASSWORD 'madhuar';
 ALTER ROLE makira8 WITH PASSWORD 'makira8';
 ALTER ROLE malra41 WITH PASSWORD 'malra41';
 ALTER ROLE mha212c WITH PASSWORD 'mha212c';
 ALTER ROLE mohakh9 WITH PASSWORD 'mohakh9';
 ALTER ROLE moosa9d WITH PASSWORD 'moosa9d';
 ALTER ROLE mri2nks WITH PASSWORD 'mri2nks';
 ALTER ROLE muthira WITH PASSWORD 'muthira';
 ALTER ROLE opr1kxz WITH PASSWORD 'opr1kxz';
 ALTER ROLE pasupli WITH PASSWORD 'pasupli';
 ALTER ROLE rahaso WITH PASSWORD 'rahaso';
 ALTER ROLE ramase6 WITH PASSWORD 'ramase6';
 ALTER ROLE ratnamo WITH PASSWORD 'ratnamo';
 ALTER ROLE rba3gha WITH PASSWORD 'rba3gha';
 ALTER ROLE saraba5 WITH PASSWORD 'saraba5';
 ALTER ROLE shaam72 WITH PASSWORD 'shaam72';
 ALTER ROLE sivabsh WITH PASSWORD 'sivabsh';
 ALTER ROLE spvi WITH PASSWORD 'spvi';
 ALTER ROLE sundra7 WITH PASSWORD 'sundra7';
 ALTER ROLE suresi4 WITH PASSWORD 'suresi4';
 ALTER ROLE swamish WITH PASSWORD 'swamish';
 ALTER ROLE thanka WITH PASSWORD 'thanka';
 ALTER ROLE udumafa WITH PASSWORD 'udumafa';
 ALTER ROLE v000094 WITH PASSWORD 'v000094';
 ALTER ROLE v027041 WITH PASSWORD 'v027041';
 ALTER ROLE v093804 WITH PASSWORD 'v093804';
 ALTER ROLE v160866 WITH PASSWORD 'v160866';
 ALTER ROLE v399971 WITH PASSWORD 'v399971';
 ALTER ROLE v474870 WITH PASSWORD 'v474870';
 ALTER ROLE v490255 WITH PASSWORD 'v490255';
 ALTER ROLE v525226 WITH PASSWORD 'v525226';
 ALTER ROLE v525450 WITH PASSWORD 'v525450';
 ALTER ROLE v530285 WITH PASSWORD 'v530285';
 ALTER ROLE v591000 WITH PASSWORD 'v591000';
 ALTER ROLE v647889 WITH PASSWORD 'v647889';
 ALTER ROLE v748300 WITH PASSWORD 'v748300';
 ALTER ROLE v864498 WITH PASSWORD 'v864498';
 ALTER ROLE varadar WITH PASSWORD 'varadar';
 ALTER ROLE varmab7 WITH PASSWORD 'varmab7';
 ALTER ROLE yadasu3 WITH PASSWORD 'yadasu3';
 ALTER ROLE yagneti WITH PASSWORD 'yagneti';
 ALTER ROLE yalavba WITH PASSWORD 'yalavba';
 ALTER ROLE z054447 WITH PASSWORD 'z054447';


WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select m.user, m.groups from members m where m.groups like '%ldapuser%' and m.groups like '%readers%';

-- grant ldapuser,readers
WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select 'GRANT ldapuser, readers TO ' || m.user || ';' as changes from members m where m.groups like '%ldapuser%' and m.groups like '%readers%';
 GRANT ldapuser, readers TO annamve;
 GRANT ldapuser, readers TO appiaja;
 GRANT ldapuser, readers TO bishma2;
 GRANT ldapuser, readers TO bodduve;
 GRANT ldapuser, readers TO chatrma;
 GRANT ldapuser, readers TO chitudi9;
 GRANT ldapuser, readers TO dangka8;
 GRANT ldapuser, readers TO dhatcdh;
 GRANT ldapuser, readers TO gummara;
 GRANT ldapuser, readers TO kalagsu;
 GRANT ldapuser, readers TO koduran;
 GRANT ldapuser, readers TO kondaga;
 GRANT ldapuser, readers TO krissh8;
 GRANT ldapuser, readers TO kumari3;
 GRANT ldapuser, readers TO kumsu1b;
 GRANT ldapuser, readers TO mohamu9;
 GRANT ldapuser, readers TO mudadva;
 GRANT ldapuser, readers TO muruksa;
 GRANT ldapuser, readers TO nagasa6;
 GRANT ldapuser, readers TO pandade;
 GRANT ldapuser, readers TO perura3;
 GRANT ldapuser, readers TO rajamsa;
 GRANT ldapuser, readers TO rajesa6;
 GRANT ldapuser, readers TO raviva;
 GRANT ldapuser, readers TO sahoan5;
 GRANT ldapuser, readers TO sahuam;
 GRANT ldapuser, readers TO sethsu5;
 GRANT ldapuser, readers TO singhic;
 GRANT ldapuser, readers TO thanaka;
 GRANT ldapuser, readers TO thora9z;
 GRANT ldapuser, readers TO vitalmi;
 GRANT ldapuser, readers TO z889123;

-- grant ldapuser,writers
WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select 'GRANT ldapuser, writers TO ' || m.user || ';' as changes from members m where m.groups like '%ldapuser%' and m.groups like '%writers%';
 GRANT ldapuser, writers TO chattni;
 GRANT ldapuser, writers TO daspi2i;
 GRANT ldapuser, writers TO dhatcdh;
 GRANT ldapuser, writers TO jainri9;
 GRANT ldapuser, writers TO kanumve;
 GRANT ldapuser, writers TO perura3;
 GRANT ldapuser, writers TO raviva;
 GRANT ldapuser, writers TO singive;
 GRANT ldapuser, writers TO yarrusa;

-- Grant offshore, readers
WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select m.user, m.groups from members m where m.groups like '%offshore%' and m.groups like '%readers%';

WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select 'GRANT offshore, readers TO ' || m.user || ';' as changes from members m where m.groups like '%offshore%' and m.groups like '%readers%';
 GRANT offshore, readers TO amatsu3;
 GRANT offshore, readers TO avalara;
 GRANT offshore, readers TO babugpr;
 GRANT offshore, readers TO baigkh;
 GRANT offshore, readers TO balanpr;
 GRANT offshore, readers TO bandlka;
 GRANT offshore, readers TO chanmo8;
 GRANT offshore, readers TO chowksr;
 GRANT offshore, readers TO dasal;
 GRANT offshore, readers TO dodlave;
 GRANT offshore, readers TO ekamvi2;
 GRANT offshore, readers TO elumadi;
 GRANT offshore, readers TO gangan1;
 GRANT offshore, readers TO gangan5;
 GRANT offshore, readers TO guptra4;
 GRANT offshore, readers TO hakeemo;
 GRANT offshore, readers TO hyderri;
 GRANT offshore, readers TO jhabr;
 GRANT offshore, readers TO kavalgo;
 GRANT offshore, readers TO kja4vd8;
 GRANT offshore, readers TO kollasa;
 GRANT offshore, readers TO konjeve;
 GRANT offshore, readers TO kotaan8;
 GRANT offshore, readers TO koyyale;
 GRANT offshore, readers TO krisud4;
 GRANT offshore, readers TO madhuar;
 GRANT offshore, readers TO makira8;
 GRANT offshore, readers TO malra41;
 GRANT offshore, readers TO mha212c;
 GRANT offshore, readers TO mohakh9;
 GRANT offshore, readers TO moosa9d;
 GRANT offshore, readers TO mri2nks;
 GRANT offshore, readers TO muthira;
 GRANT offshore, readers TO opr1kxz;
 GRANT offshore, readers TO pasupli;
 GRANT offshore, readers TO rahaso;
 GRANT offshore, readers TO ramase6;
 GRANT offshore, readers TO ratnamo;
 GRANT offshore, readers TO rba3gha;
 GRANT offshore, readers TO saraba5;
 GRANT offshore, readers TO shaam72;
 GRANT offshore, readers TO sivabsh;
 GRANT offshore, readers TO spvi;
 GRANT offshore, readers TO sundra7;
 GRANT offshore, readers TO suresi4;
 GRANT offshore, readers TO swamish;
 GRANT offshore, readers TO thanka;
 GRANT offshore, readers TO udumafa;
 GRANT offshore, readers TO v000094;
 GRANT offshore, readers TO v027041;
 GRANT offshore, readers TO v093804;
 GRANT offshore, readers TO v160866;
 GRANT offshore, readers TO v399971;
 GRANT offshore, readers TO v474870;
 GRANT offshore, readers TO v490255;
 GRANT offshore, readers TO v525226;
 GRANT offshore, readers TO v525450;
 GRANT offshore, readers TO v530285;
 GRANT offshore, readers TO v591000;
 GRANT offshore, readers TO v647889;
 GRANT offshore, readers TO v748300;
 GRANT offshore, readers TO v864498;
 GRANT offshore, readers TO varadar;
 GRANT offshore, readers TO varmab7;
 GRANT offshore, readers TO yadasu3;
 GRANT offshore, readers TO yagneti;
 GRANT offshore, readers TO yalavba;
 GRANT offshore, readers TO z054447;

-- Grant offshore, writers
WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select m.user, m.groups from members m where m.groups like '%offshore%' and m.groups like '%writers%';

WITH members as 
(select a1.rolname as user, string_agg(a2.rolname,',' order by a2.rolname) as groups from pg_authid a1, pg_authid a2, pg_auth_members am where am.roleid = a2.oid and am.member = a1.oid and a1.rolcanlogin and not a1.rolsuper and not a1.rolcreaterole and not a1.rolreplication and a1.rolname not like '%_app%' group by a1.rolname order by a1.rolname) 
select 'GRANT offshore, writers TO ' || m.user || ';' as changes from members m where m.groups like '%offshore%' and m.groups like '%writers%';
 GRANT offshore, writers TO krisud4;
 GRANT offshore, writers TO rahaso;
 GRANT offshore, writers TO saraba5;
 GRANT offshore, writers TO spvi;
 GRANT offshore, writers TO v000094;
 GRANT offshore, writers TO v490255;
 GRANT offshore, writers TO v530285;
 GRANT offshore, writers TO v864498;
 GRANT offshore, writers TO z054447;

-- Finally make all login users members of the connectgrp
select * from pg_user where not usecreatedb and not usesuper and not userepl and usename not like '%_app%' order by 1;
select 'GRANT connectgrp TO ' || usename || ';' as changes from pg_user where not usecreatedb and not usesuper and not userepl and usename not like '%_app%' order by 1;
 GRANT connectgrp TO 2629230;
 GRANT connectgrp TO am_user;
 GRANT connectgrp TO amatsu3;
 GRANT connectgrp TO annamve;
 GRANT connectgrp TO appiaja;
 GRANT connectgrp TO archve3;
 GRANT connectgrp TO avalara;
 GRANT connectgrp TO babugpr;
 GRANT connectgrp TO baigkh;
 GRANT connectgrp TO balanpr;
 GRANT connectgrp TO bandlka;
 GRANT connectgrp TO bishma2;
 GRANT connectgrp TO bodduve;
 GRANT connectgrp TO chanmo8;
 GRANT connectgrp TO chatrma;
 GRANT connectgrp TO chattni;
 GRANT connectgrp TO chitudi9;
 GRANT connectgrp TO chowksr;
 GRANT connectgrp TO dangka8;
 GRANT connectgrp TO dasal;
 GRANT connectgrp TO daspi2i;
 GRANT connectgrp TO dhatcdh;
 GRANT connectgrp TO dodlave;
 GRANT connectgrp TO ekamvi2;
 GRANT connectgrp TO elumadi;
 GRANT connectgrp TO gangan1;
 GRANT connectgrp TO gangan5;
 GRANT connectgrp TO gummara;
 GRANT connectgrp TO guptra4;
 GRANT connectgrp TO hakeemo;
 GRANT connectgrp TO hyderri;
 GRANT connectgrp TO jainri9;
 GRANT connectgrp TO jhabr;
 GRANT connectgrp TO kalagsu;
 GRANT connectgrp TO kanumve;
 GRANT connectgrp TO kavalgo;
 GRANT connectgrp TO kja4vd8;
 GRANT connectgrp TO koduran;
 GRANT connectgrp TO kollasa;
 GRANT connectgrp TO kondaga;
 GRANT connectgrp TO konjeve;
 GRANT connectgrp TO kotaan8;
 GRANT connectgrp TO koyyale;
 GRANT connectgrp TO krissh8;
 GRANT connectgrp TO krisud4;
 GRANT connectgrp TO kumari3;
 GRANT connectgrp TO kumsu1b;
 GRANT connectgrp TO madhuar;
 GRANT connectgrp TO makira8;
 GRANT connectgrp TO malra41;
 GRANT connectgrp TO mha212c;
 GRANT connectgrp TO mohakh9;
 GRANT connectgrp TO mohamu9;
 GRANT connectgrp TO moosa9d;
 GRANT connectgrp TO mri2nks;
 GRANT connectgrp TO mudadva;
 GRANT connectgrp TO muruksa;
 GRANT connectgrp TO muthira;
 GRANT connectgrp TO nagasa6;
 GRANT connectgrp TO opr1kxz;
 GRANT connectgrp TO oss_user;
 GRANT connectgrp TO pandade;
 GRANT connectgrp TO pasupli;
 GRANT connectgrp TO perura3;
 GRANT connectgrp TO poluser;
 GRANT connectgrp TO rahaso;
 GRANT connectgrp TO rajamsa;
 GRANT connectgrp TO rajesa6;
 GRANT connectgrp TO ramase6;
 GRANT connectgrp TO ratnamo;
 GRANT connectgrp TO raviva;
 GRANT connectgrp TO rba3gha;
 GRANT connectgrp TO rohit;
 GRANT connectgrp TO sahoan5;
 GRANT connectgrp TO sahuam;
 GRANT connectgrp TO saraba5;
 GRANT connectgrp TO sethsu5;
 GRANT connectgrp TO shaam72;
 GRANT connectgrp TO singhic;
 GRANT connectgrp TO singive;
 GRANT connectgrp TO sivabsh;
 GRANT connectgrp TO spvi;
 GRANT connectgrp TO sundra7;
 GRANT connectgrp TO suresi4;
 GRANT connectgrp TO swamish;
 GRANT connectgrp TO thanaka;
 GRANT connectgrp TO thanka;
 GRANT connectgrp TO theopgo;
 GRANT connectgrp TO thora9z;
 GRANT connectgrp TO udumafa;
 GRANT connectgrp TO v000094;
 GRANT connectgrp TO v027041;
 GRANT connectgrp TO v093804;
 GRANT connectgrp TO v160866;
 GRANT connectgrp TO v399971;
 GRANT connectgrp TO v474870;
 GRANT connectgrp TO v490255;
 GRANT connectgrp TO v525226;
 GRANT connectgrp TO v525450;
 GRANT connectgrp TO v530285;
 GRANT connectgrp TO v591000;
 GRANT connectgrp TO v647889;
 GRANT connectgrp TO v748300;
 GRANT connectgrp TO v864498;
 GRANT connectgrp TO varadar;
 GRANT connectgrp TO varmab7;
 GRANT connectgrp TO vitalmi;
 GRANT connectgrp TO yadasu3;
 GRANT connectgrp TO yagneti;
 GRANT connectgrp TO yalavba;
 GRANT connectgrp TO yarrusa;
 GRANT connectgrp TO z054447;
 GRANT connectgrp TO z889123;


******************************************************************************************
GRANT connectgrp, offshore TO avalara,chanmo8 ,dasal   ,gangan1 ,gangan5 ,kavalgo ,kja4vd8 ,koyyale ,madhuar ,moosa9d ,rahaso  ,spvi    ,suresi4 ,thanka  ,yagneti ,yalavba ,amatsu3 
,archve3,babugpr ,baigkh  ,balanpr ,bandlka ,chowksr ,dodlave ,ekamvi2 ,elumadi ,guptra4 ,hakeemo ,hyderri ,jhabr   ,kollasa ,konjeve ,kotaan8 ,krisud4 ,makira8 ,malra41 ,mha212c ,mohakh9 ,mri2nks 
,muthira ,opr1kxz ,pasupli ,ramase6 ,ratnamo ,rba3gha ,saraba5 ,shaam72 ,sivabsh ,sundra7 ,swamish ,udumafa ,v000094 ,v027041 ,v093804 ,v160866 ,v399971 ,v474870 ,v490255 ,v525450 ,v530285 
,v591000 ,v647889 ,v748300 ,v864498 ,varadar ,varmab7 ,yadasu3 ,z054447, amatsu3, babugpr,baigkh,  bandlka,elumadi,guptra4,hakeemo,hyderri,jhabr,   kotaan8,krisud4,muthira,ramase6,ratnamo,rba3gha,saraba5,shaam72,sundra7,
v000094,v027041,v093804,v160866,v399971,v474870,v490255,v525450,v530285,v591000,v647889,v748300,v864498,varadar,z054447;

-- select 'GRANT readers TO ' || string_agg(usename,',') || ';' from pg_user;
GRANT readers TO v591000, vitalmi, dasal, gangan5,gangan1,madhuar,varadar,yalavba,baigkh, bodduve,chitudi9,pandade,babugpr,singhic,kja4vd8,bandlka,dangka8,thanaka,kavalgo,koduran,kotaan8,koyyale, chanmo8,ratnamo,mudadva,z889123,muthira,avalara,kumari3,v647889,moosa9d,v525450,v748300,ramase6,v160866,suresi4,kalagsu,thora9z,yagneti, v864498,raviva,v490255,v000094,perura3,v530285,mohamu9,v399971,bishma2,sahoan5,v027041,v474870,v748300,v647889,v093804,nagasa6,hyderri,rajesa6,thanaka,yalavba,ramase6,gummara,sahuam,muthira,varadar,ratnamo,chanmo8,krisud4,kumsu1b,gangan5,rajamsa,koyyale,krissh8,annamve,suresi4,dasal,avalara,gangan1,z054447,dhatcdh,chatrma,muruksa,yagneti,bandlka,saraba5,spvi,rahaso, MOHAMU9, v399971, bishma2, sahoan5, v027041, v474870, v748300, v647889, v093804, nagasa6, hyderri, RAJESA6, hakeemo, appiaja, shaam72, kondaga, yalavba, RAMASE6, gummara, sahuam , MUTHIRA, VARADAR, ratnamo, CHANMO8, kumsu1b, GANGAN5, rajamsa, koyyale, krissh8, annamve, SURESI4, DASAL, avalara, GANGAN1, chatrma, muruksa, yagneti, bandlka;

GRANT writers to saraba5,chattni,z054447,jainri9,kanumve, daspi2i,singive,v864498,rahaso,krisud4,spvi,yarrusa, KRISUD4, Z054447, DHATCDH, saraba5, SPVI, rahaso, v864498, raviva, v490255, v000094, perura3, v530285;

GRANT ldapuser to dasal, gangan5,gangan1,madhuar,varadar,yalavba,baigkh, bodduve,chitudi9,pandade,babugpr,singhic,kja4vd8,bandlka,dangka8,thanaka,kavalgo,koduran,kotaan8,koyyale, chanmo8,ratnamo,mudadva,z889123,muthira,avalara,kumari3,v647889,moosa9d,v525450,v748300,ramase6,v160866,suresi4,kalagsu,thora9z,yagneti, v864498,raviva,v490255,v000094,perura3,v530285,mohamu9,v399971,bishma2,sahoan5,v027041,v474870,v748300,v647889,v093804,nagasa6,hyderri,rajesa6,thanaka,yalavba,ramase6,gummara,sahuam,muthira,varadar,ratnamo,chanmo8,krisud4,kumsu1b,gangan5,rajamsa,koyyale,krissh8,annamve,suresi4,dasal,avalara,gangan1,z054447,dhatcdh,chatrma,muruksa,yagneti,bandlka,saraba5,spvi,rahaso, MOHAMU9, v399971, bishma2, sahoan5, v027041, v474870, v748300, v647889, v093804, nagasa6, hyderri, RAJESA6, hakeemo, appiaja, shaam72, kondaga, yalavba, RAMASE6, gummara, sahuam , MUTHIRA, VARADAR, ratnamo, CHANMO8, kumsu1b, GANGAN5, rajamsa, koyyale, krissh8, annamve, SURESI4, DASAL, avalara, GANGAN1, chatrma, muruksa, yagneti, bandlka, saraba5,chattni,z054447,jainri9,kanumve, daspi2i,singive,v864498,rahaso,krisud4,spvi,yarrusa, KRISUD4, Z054447, DHATCDH, saraba5, SPVI, rahaso, v864498, raviva, v490255, v000094, perura3, v530285;
	   
ALTER ROLE vitalmi WITH PASSWORD 'vitalmiii';	   



