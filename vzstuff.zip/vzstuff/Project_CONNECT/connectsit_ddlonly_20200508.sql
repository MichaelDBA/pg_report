--
-- PostgreSQL database dump
--

-- Dumped from database version 10.6
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

COMMENT ON SCHEMA activn IS 'DB Domain for Activation related Tables (Network Domain)';
COMMENT ON SCHEMA audit IS 'Databse Schema for Audit/Report Domain';
COMMENT ON SCHEMA config IS 'DB Schema for Configuration Domain';
COMMENT ON SCHEMA infra IS 'Infrastructure Domain DATA';
COMMENT ON SCHEMA ordng IS 'ordering schema';
COMMENT ON SCHEMA svcinv IS 'Database Schema for Service Inventory Domain';
COMMENT ON SCHEMA tninv IS 'TN Inventory Schema';
COMMENT ON SCHEMA uui IS 'User Interface Schema';
COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';

CREATE TYPE localds.flg AS ENUM (
    'Y',
    'N'
);

ALTER TYPE localds.flg OWNER TO postgres;

--
-- Name: delete_data_connect(); Type: FUNCTION; Schema: tninv; Owner: connectsit
--

CREATE FUNCTION tninv.delete_data_connect() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN

DELETE from tninv."TN_INVENTORY_ATTRIBUTE" where "TN_INV_ID" = OLD."TN_ID";
   DELETE FROM TNINV."TN_INVENTORY"  where "TN_INV_ID" = OLD."TN_ID";
      RETURN NEW;
   END;
$$;


ALTER FUNCTION tninv.delete_data_connect() OWNER TO postgres;

--
-- Name: insert_data_connect(); Type: FUNCTION; Schema: tninv; Owner: connectsit
--

CREATE FUNCTION tninv.insert_data_connect() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
   tn_text_val text;
   tn_actual_val jsonb;
   sub_text_val text;
   sub_text_actual jsonb;
      trunk_text_val text;
   trunk_text_actual jsonb;
   BEGIN
  -- tn_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "TN_POOL_ID", "specValue": "'||new."TN_ID"||'", "specValueId": null } ] }';
  tn_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "TN_POOL_ID", "specValue": "'||new."TN_ID"||'", "specValueId": null }, { "specName": "STATUS", "specValue": "'||new."STATUS"||'", "specValueId": null } ] }';
   sub_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "SUBSCRIBER_ID", "specValue": "'||new."SUBSCRIBER_ID"||'", "specValueId": null }, { "specName": "SUBSCRIBER_NAME", "specValue": "'||new."SUBSCRIBER_NAME"||'", "specValueId": null }, { "specName": "SUBSCRIBER_STATUS", "specValue": "'||new."SUBSCRIBER_STATUS"||'", "specValueId": null },  { "specName": "SUB_ADDRESS", "specValue": "'||new."SUB_ADDRESS"||'", "specValueId": null } ] }';
   trunk_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "TRUNK_ID", "specValue": "'||new."TRUNK_ID"||'", "specValueId": null }, { "specName": "GROUP_NAME", "specValue": "'||new."GROUP_NAME"||'", "specValueId": null }, { "specName": "GROUP_STATUS", "specValue": "'||new."GROUP_STATUS"||'", "specValueId": null },  { "specName": "NETWORK_STATUS", "specValue": "'||new."NETWORK_STATUS"||'", "specValueId": null } ] }';
  /*  insert into TNINV."TN_INVENTORY"("TN_INV_ID","TN","TN_STATUS") values(new."TN_ID",new."TN",new."STATUS");
          INSERT INTO tninv."TN_INVENTORY_ATTRIBUTE"(
         "TN_INV_ID", "ATTRIBUTE_KEY", "ATTRIBUTE_VALUE")
        VALUES ( new."TN_ID", 'TN_POOL', CAST ('{ "attributeKey": null, "attributeValue": [
{ "specName": "TN_ID", "specValue": "'||NEW."TN_ID"||'", "specValueId": null }
{ "specName": "TN", "specValue": "'||NEW."TN"||'", "specValueId": null }
{ "specName": "STATUS", "specValue": "'||NEW."STATUS"||'", "specValueId": null }
] }' AS jsonB));*/
tn_actual_val= cast(tn_text_val as jsonb);
sub_text_actual= cast(sub_text_val as jsonb);
trunk_text_actual= cast(trunk_text_val as jsonb);
   insert into TNINV."TN_INVENTORY"("TN_INV_ID","TN","TN_STATUS") values(new."TN_ID",new."TN",new."STATUS");
          INSERT INTO tninv."TN_INVENTORY_ATTRIBUTE"(
         "TN_INV_ID", "ATTRIBUTE_KEY", "ATTRIBUTE_VALUE")
        VALUES ( new."TN_ID", 'TN_POOL', tn_actual_val);
         INSERT INTO tninv."TN_INVENTORY_ATTRIBUTE"(
         "TN_INV_ID", "ATTRIBUTE_KEY", "ATTRIBUTE_VALUE")
        VALUES ( new."TN_ID", 'SUBSCRIBER', sub_text_actual);
                 INSERT INTO tninv."TN_INVENTORY_ATTRIBUTE"(
         "TN_INV_ID", "ATTRIBUTE_KEY", "ATTRIBUTE_VALUE")
        VALUES ( new."TN_ID", 'TRUNK_TN_INFO', trunk_text_actual);
      RETURN NEW;
   END;
$$;


ALTER FUNCTION tninv.insert_data_connect() OWNER TO postgres;

--
-- Name: update_data_connect(); Type: FUNCTION; Schema: tninv; Owner: connectsit
--

CREATE FUNCTION tninv.update_data_connect() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
   tn_text_val text;
   tn_actual_val jsonb;
   sub_text_val text;
   sub_text_actual jsonb;
      trunk_text_val text;
   trunk_text_actual jsonb;
   BEGIN
   tn_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "TN_POOL_ID", "specValue": "'||new."TN_ID"||'", "specValueId": null }, { "specName": "STATUS", "specValue": "'||new."STATUS"||'", "specValueId": null } ] }';
   sub_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "SUBSCRIBER_ID", "specValue": "'||new."SUBSCRIBER_ID"||'", "specValueId": null }, { "specName": "SUBSCRIBER_NAME", "specValue": "'||new."SUBSCRIBER_NAME"||'", "specValueId": null }, { "specName": "SUBSCRIBER_STATUS", "specValue": "'||new."SUBSCRIBER_STATUS"||'", "specValueId": null },  { "specName": "SUB_ADDRESS", "specValue": "'||new."SUB_ADDRESS"||'", "specValueId": null } ] }';
   trunk_text_val = '{ "attributeKey": null, "attributeValue": [ { "specName": "TRUNK_ID", "specValue": "'||new."TRUNK_ID"||'", "specValueId": null }, { "specName": "GROUP_NAME", "specValue": "'||new."GROUP_NAME"||'", "specValueId": null }, { "specName": "GROUP_STATUS", "specValue": "'||new."GROUP_STATUS"||'", "specValueId": null },  { "specName": "NETWORK_STATUS", "specValue": "'||new."NETWORK_STATUS"||'", "specValueId": null } ] }';
tn_actual_val= cast(tn_text_val as jsonb);
sub_text_actual= cast(sub_text_val as jsonb);
trunk_text_actual= cast(trunk_text_val as jsonb);
UPDATE TNINV."TN_INVENTORY" SET "TN_STATUS"= NEW."STATUS" where "TN_INV_ID" = new."TN_ID";
update tninv."TN_INVENTORY_ATTRIBUTE" set "ATTRIBUTE_VALUE" = tn_actual_val where "TN_INV_ID" = new."TN_ID" AND "ATTRIBUTE_KEY" =  'TN_POOL';
update tninv."TN_INVENTORY_ATTRIBUTE" set "ATTRIBUTE_VALUE" = sub_text_actual where "TN_INV_ID" = new."TN_ID" AND "ATTRIBUTE_KEY" =  'SUBSCRIBER';
update tninv."TN_INVENTORY_ATTRIBUTE" set "ATTRIBUTE_VALUE" = trunk_text_actual where "TN_INV_ID" = new."TN_ID" AND "ATTRIBUTE_KEY" =  'TRUNK_TN_INFO';
      RETURN NEW;
   END;
$$;


ALTER FUNCTION tninv.update_data_connect() OWNER TO postgres;

--
-- Name: activation_id_seq; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.activation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE activn.activation_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE activation_id_seq; Type: COMMENT; Schema: activn; Owner: connectsit
--

COMMENT ON SEQUENCE activn.activation_id_seq IS 'Sequence for activation_id column of the t_activation_command table';


--
-- Name: blocking_id_seq; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.blocking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE activn.blocking_id_seq OWNER TO postgres;

--
-- Name: blocking_location_id_seq; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.blocking_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE activn.blocking_location_id_seq OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: flyway_schema_history; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE activn.flyway_schema_history OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE activn.hibernate_sequence OWNER TO postgres;

--
-- Name: nsrs_order_id_seq; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.nsrs_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE activn.nsrs_order_id_seq OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE activn.schema_version OWNER TO postgres;

--
-- Name: sql_id_seq; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.sql_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE activn.sql_id_seq OWNER TO postgres;

--
-- Name: t_activation_command; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_activation_command (
    activation_id bigint DEFAULT nextval('activn.activation_id_seq'::regclass) NOT NULL,
    lob character varying(20),
    entity_order_id bigint,
    batch integer,
    action character varying(50),
    network_element text,
    entity character varying(50),
    status text,
    request_command text,
    rollback_command text,
    request_command_response text,
    rollback_command_response text,
    prepare_date timestamp(4) without time zone,
    activation_date timestamp(4) without time zone,
    activation_attributes jsonb,
    update_date timestamp without time zone,
    creation_date timestamp without time zone,
    created_by character varying(32),
    update_by character varying(32),
    work_order_number character varying(32),
    work_order_version integer,
    start_index integer,
    end_index integer,
    tn_count integer,
    is_r2r_order boolean
);


ALTER TABLE activn.t_activation_command OWNER TO postgres;

--
-- Name: t_blocking_locations; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_blocking_locations (
    blocking_location_id bigint DEFAULT nextval('activn.blocking_location_id_seq'::regclass) NOT NULL,
    blocking_id bigint NOT NULL,
    enterprise_id character varying(32),
    location_id character varying(32),
    switch_clli character varying(20) NOT NULL,
    status character varying(24),
    status_message text,
    modified_time timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone NOT NULL
);


ALTER TABLE activn.t_blocking_locations OWNER TO postgres;

--
-- Name: t_call_blocking; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_call_blocking (
    blocking_id bigint DEFAULT nextval('activn.blocking_id_seq'::regclass) NOT NULL,
    block_type character varying(24) NOT NULL,
    created_by character varying(32),
    created_time timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone NOT NULL,
    status character varying(24),
    schedule_date timestamp without time zone,
    blocking_data jsonb NOT NULL
);


ALTER TABLE activn.t_call_blocking OWNER TO postgres;

--
-- Name: t_db_service_config; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_db_service_config (
    sql_id bigint DEFAULT nextval('activn.sql_id_seq'::regclass) NOT NULL,
    sql_key text NOT NULL,
    source_service character varying(40) NOT NULL,
    operation character varying(20) NOT NULL,
    sql_text text NOT NULL,
    tables_involved text,
    columns_involved text,
    update_timestamp timestamp with time zone,
    modified_by character varying(50),
    update_date timestamp without time zone,
    creation_date timestamp without time zone,
    created_by character varying(32),
    update_by character varying(32)
);


ALTER TABLE activn.t_db_service_config OWNER TO postgres;

--
-- Name: t_domain_exception_retry; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_domain_exception_retry (
    transaction_id text NOT NULL,
    entity_order_id character varying(50),
    batch_id character varying(50),
    exception_attributes jsonb,
    raw_data_type character varying(50),
    raw_processing_data text,
    order_exception_data_mapping jsonb,
    error_code character varying(50),
    error_description character varying(50),
    created_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone NOT NULL,
    current_status character varying(50) NOT NULL
);


ALTER TABLE activn.t_domain_exception_retry OWNER TO postgres;

--
-- Name: t_feed_transaction; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_feed_transaction (
    transaction_id text NOT NULL,
    work_order_number text,
    work_order_version text,
    feed_name text NOT NULL,
    feed_destination text NOT NULL,
    entity_type text NOT NULL,
    feed_attributes jsonb NOT NULL,
    feed_request text NOT NULL,
    feed_ack_transaction_id text,
    feed_response text,
    prepare_date text NOT NULL,
    execution_date text,
    status_code text,
    status_description text,
    retry_count bigint DEFAULT 0 NOT NULL,
    max_retry bigint NOT NULL,
    created_by text,
    creation_date timestamp without time zone,
    update_by text,
    update_date timestamp without time zone
);


ALTER TABLE activn.t_feed_transaction OWNER TO postgres;

--
-- Name: t_ipcom_connect_shadow_trans; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_ipcom_connect_shadow_trans (
    orderid integer NOT NULL,
    host text,
    cmd character varying(12),
    rs_table_name character varying(20),
    rs_table_num_keys integer,
    status character varying(15),
    priority integer,
    message text,
    release character varying(10) DEFAULT 'both'::character varying NOT NULL,
    feature character varying(10),
    feature_trans_id integer,
    key1 text,
    key2 text,
    key3 text,
    key4 text,
    key5 text,
    old_rs_field_mappings jsonb,
    new_rs_field_mappings jsonb,
    system_user text,
    post_timestamp timestamp without time zone NOT NULL,
    update_timestamp character varying(25)
);


ALTER TABLE activn.t_ipcom_connect_shadow_trans OWNER TO postgres;

--
-- Name: t_ipcom_iasa_rs_template; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_ipcom_iasa_rs_template (
    rs_table_id character varying(4) NOT NULL,
    rs_table_name character varying(50) NOT NULL,
    rs_column_name character varying(50) NOT NULL,
    rs_column_default_value character varying(50),
    rs_column_nullable character(1) NOT NULL,
    rs_key_column character(1) NOT NULL,
    rs_old_key character(1) NOT NULL,
    rs_new_key character(1) NOT NULL,
    rs_column_condition character varying(30),
    rs_column_order integer NOT NULL,
    system_user character varying(50),
    update_timestamp timestamp without time zone NOT NULL
);


ALTER TABLE activn.t_ipcom_iasa_rs_template OWNER TO postgres;

--
-- Name: tn_activation_id_seq; Type: SEQUENCE; Schema: activn; Owner: connectsit
--

CREATE SEQUENCE activn.tn_activation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE activn.tn_activation_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE tn_activation_id_seq; Type: COMMENT; Schema: activn; Owner: connectsit
--

COMMENT ON SEQUENCE activn.tn_activation_id_seq IS 'Sequence for the column tn_activation_is in table t_tn_act_details';


--
-- Name: t_tn_act_details; Type: TABLE; Schema: activn; Owner: connectsit
--

CREATE TABLE activn.t_tn_act_details (
    tn_activation_id bigint DEFAULT nextval('activn.tn_activation_id_seq'::regclass) NOT NULL,
    activation_id bigint,
    location_id bigint,
    batch integer,
    action character(50),
    tn character(21),
    tn_skip integer,
    provision_status character(50)
);


ALTER TABLE activn.t_tn_act_details OWNER TO postgres;

--
-- Name: TABLE t_tn_act_details; Type: COMMENT; Schema: activn; Owner: connectsit
--

COMMENT ON TABLE activn.t_tn_act_details IS 'Table which contains  TN details for TSO Migration flow';


--
-- Name: audit_id_seq; Type: SEQUENCE; Schema: audit; Owner: connectsit
--

CREATE SEQUENCE audit.audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE audit.audit_id_seq OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: audit; Owner: connectsit
--

CREATE TABLE audit.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE audit.schema_version OWNER TO postgres;

--
-- Name: t_audit_info; Type: TABLE; Schema: audit; Owner: connectsit
--

CREATE TABLE audit.t_audit_info (
    audit_id bigint DEFAULT nextval('audit.audit_id_seq'::regclass) NOT NULL,
    lob character varying(24) NOT NULL,
    source_sys character varying(64) NOT NULL,
    destination_sys character varying(64) NOT NULL,
    region character varying(32) NOT NULL,
    audit_data jsonb NOT NULL,
    audit_date date NOT NULL,
    audit_by character varying(64) NOT NULL,
    entity_id character varying(96) NOT NULL,
    entity_type character varying(96) NOT NULL
);


ALTER TABLE audit.t_audit_info OWNER TO postgres;

--
-- Name: bs_command_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

CREATE SEQUENCE config.bs_command_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config.bs_command_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE bs_command_id_seq; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON SEQUENCE config.bs_command_id_seq IS 'Sequence for field bs_command_id in table t_bs_command_list';


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

CREATE SEQUENCE config.config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config.config_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE config_id_seq; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON SEQUENCE config.config_id_seq IS 'Sequence for config_id in t_config_properties';


--
-- Name: flyway_schema_history; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE config.flyway_schema_history OWNER TO postgres;

--
-- Name: network_communication_details_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

CREATE SEQUENCE config.network_communication_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config.network_communication_details_id_seq OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE config.schema_version OWNER TO postgres;

--
-- Name: sql_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

CREATE SEQUENCE config.sql_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config.sql_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE sql_id_seq; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON SEQUENCE config.sql_id_seq IS 'Sequence for sql_id column of t_db_service_config table';


--
-- Name: t_bs_command_list; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_bs_command_list (
    bs_command_id bigint DEFAULT nextval('config.bs_command_id_seq'::regclass) NOT NULL,
    wf_task_name text NOT NULL,
    bs_command_name text NOT NULL,
    command_seq integer,
    update_date timestamp without time zone,
    creation_date timestamp without time zone,
    created_by character varying(32),
    update_by character varying(32)
);


ALTER TABLE config.t_bs_command_list OWNER TO postgres;

--
-- Name: TABLE t_bs_command_list; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON TABLE config.t_bs_command_list IS 'Table with Broadsoft command list for a particular BS workflow task';


--
-- Name: t_cli_type; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_cli_type (
    cli_type_id bigint NOT NULL,
    cli_type text NOT NULL,
    cli_type_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_cli_type OWNER TO postgres;

--
-- Name: t_cli_type_cli_type_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

ALTER TABLE config.t_cli_type ALTER COLUMN cli_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME config.t_cli_type_cli_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: template_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

CREATE SEQUENCE config.template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config.template_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE template_id_seq; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON SEQUENCE config.template_id_seq IS 'Sequence for template_id in t_command_template table';


--
-- Name: t_command_template; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_command_template (
    template_id bigint DEFAULT nextval('config.template_id_seq'::regclass) NOT NULL,
    template_name text NOT NULL,
    lob character varying(10),
    network_element text,
    template_group text,
    template_attributes jsonb,
    command_template text NOT NULL,
    update_date timestamp without time zone,
    creation_date timestamp without time zone,
    created_by character varying(32),
    update_by character varying(32)
);


ALTER TABLE config.t_command_template OWNER TO postgres;

--
-- Name: TABLE t_command_template; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON TABLE config.t_command_template IS 'Table to store templates for Activation commands to be sent to downstream systems like BroadSoft, NS/RS, VM, CS2K etc.';


--
-- Name: t_config_properties; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_config_properties (
    config_id bigint DEFAULT nextval('config.config_id_seq'::regclass) NOT NULL,
    lob character varying(10),
    domain_name character varying(50),
    prop_group character varying(50),
    prop_name character varying(50) NOT NULL,
    prop_value text NOT NULL,
    prop_details jsonb,
    update_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    modified_by character varying(50),
    created_by character varying(32),
    creation_date timestamp without time zone
);


ALTER TABLE config.t_config_properties OWNER TO postgres;

--
-- Name: TABLE t_config_properties; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON TABLE config.t_config_properties IS 'Table to store configurable properties, which will be used by code and can be changed on the fly from database,';


--
-- Name: t_country; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_country (
    country_alpha2_code text NOT NULL,
    country_alpha3_code text NOT NULL,
    country_name text NOT NULL,
    region text NOT NULL,
    e164_code text NOT NULL,
    country_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_country OWNER TO postgres;

--
-- Name: t_country_province; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_country_province (
    country_province_id bigint,
    region character varying(10),
    region_id bigint,
    country_name character varying(50),
    province_name character varying(50),
    country_code character varying(10),
    province_code character varying(10),
    created_by character varying(50),
    creation_date timestamp without time zone,
    update_by character varying(32),
    update_date timestamp without time zone
);


ALTER TABLE config.t_country_province OWNER TO postgres;

--
-- Name: t_cps_option_reference; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_cps_option_reference (
    cps_option_id bigint NOT NULL,
    cps_option bigint NOT NULL,
    ptt_option text,
    country_alpha2_code text NOT NULL,
    cps_option_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_cps_option_reference OWNER TO postgres;

--
-- Name: t_cps_option_reference_cps_option_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

ALTER TABLE config.t_cps_option_reference ALTER COLUMN cps_option_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME config.t_cps_option_reference_cps_option_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_cps_request_reference; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_cps_request_reference (
    cps_request bigint NOT NULL,
    cli_request bigint,
    country_alpha2_code text NOT NULL,
    ptt_request text,
    cli_type_id bigint,
    retail_type_id bigint,
    cps_request_attributes jsonb,
    cps_request_flags jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_cps_request_reference OWNER TO postgres;

--
-- Name: t_cps_request_reference_cps_request_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

ALTER TABLE config.t_cps_request_reference ALTER COLUMN cps_request ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME config.t_cps_request_reference_cps_request_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_db_service_config; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_db_service_config (
    sql_id bigint DEFAULT nextval('config.sql_id_seq'::regclass) NOT NULL,
    sql_key text NOT NULL,
    lob character varying(10),
    source_domain character varying(50),
    source_service text,
    sql_text text NOT NULL,
    sql_details jsonb,
    update_timestamp timestamp with time zone,
    modified_by character varying(50),
    creation_date timestamp without time zone,
    created_by character varying(32)
);


ALTER TABLE config.t_db_service_config OWNER TO postgres;

--
-- Name: TABLE t_db_service_config; Type: COMMENT; Schema: config; Owner: connectsit
--

COMMENT ON TABLE config.t_db_service_config IS 'Table to store configurable SQL Queries, which can be changed on the fly.';


--
-- Name: t_feed_features; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_feed_features (
    feed_name text,
    feature_code text,
    feed_propagating_system text,
    lob character varying(16),
    entity_type text,
    feed_attributes jsonb
);


ALTER TABLE config.t_feed_features OWNER TO postgres;

--
-- Name: t_network_communication_details; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_network_communication_details (
    network_communication_details_id bigint DEFAULT nextval('config.network_communication_details_id_seq'::regclass) NOT NULL,
    region character varying(10),
    lob character varying(20),
    source_system text,
    service_type character varying(50),
    network_type character varying(50),
    network_element character varying(50),
    action character varying(50),
    action_sub_task_sequence character varying(50),
    action_sub_task character varying(50),
    action_sub_task_attributes jsonb,
    update_date timestamp without time zone,
    creation_date timestamp without time zone,
    created_by character varying(32),
    update_by character varying(32),
    flow character(50)
);


ALTER TABLE config.t_network_communication_details OWNER TO postgres;

--
-- Name: t_province; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_province (
    province_id bigint NOT NULL,
    province_code text,
    province_name text NOT NULL,
    country_alpha2_code text NOT NULL,
    province_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_province OWNER TO postgres;

--
-- Name: t_province_province_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

ALTER TABLE config.t_province ALTER COLUMN province_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME config.t_province_province_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_retail_type; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_retail_type (
    retail_type_id bigint NOT NULL,
    retail_type text NOT NULL,
    retail_type_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_retail_type OWNER TO postgres;

--
-- Name: t_retail_type_retail_type_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

ALTER TABLE config.t_retail_type ALTER COLUMN retail_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME config.t_retail_type_retail_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_service_provider; Type: TABLE; Schema: config; Owner: connectsit
--

CREATE TABLE config.t_service_provider (
    service_provider_id bigint NOT NULL,
    service_provider_name text NOT NULL,
    service_provider_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE config.t_service_provider OWNER TO postgres;

--
-- Name: t_service_provider_service_provider_id_seq; Type: SEQUENCE; Schema: config; Owner: connectsit
--

ALTER TABLE config.t_service_provider ALTER COLUMN service_provider_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME config.t_service_provider_service_provider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cache_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.cache_id_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.cache_id_seq OWNER TO postgres;

--
-- Name: child_validation_rule_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.child_validation_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.child_validation_rule_id_seq OWNER TO postgres;

--
-- Name: connect_bau_wf_mapping_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.connect_bau_wf_mapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.connect_bau_wf_mapping_id_seq OWNER TO postgres;

--
-- Name: device_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE infra.device_id_seq OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE infra.flyway_schema_history OWNER TO postgres;

--
-- Name: milestone_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.milestone_id_seq
    START WITH 2
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.milestone_id_seq OWNER TO postgres;

--
-- Name: milestone_manager_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.milestone_manager_id_seq
    START WITH 13
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.milestone_manager_id_seq OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE infra.schema_version OWNER TO postgres;

--
-- Name: t_cache_config; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_cache_config (
    cache_id bigint NOT NULL,
    end_point text NOT NULL,
    end_point_method text NOT NULL,
    path_param_key text,
    query_param_key text,
    post_request text,
    multiple_result boolean,
    cache_schema character varying(8) DEFAULT 'infra'::character varying NOT NULL,
    cache_timeout integer DEFAULT 30 NOT NULL
);


ALTER TABLE infra.t_cache_config OWNER TO postgres;

--
-- Name: t_cache_config_cache_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

ALTER TABLE infra.t_cache_config ALTER COLUMN cache_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME infra.t_cache_config_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_cache_table; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_cache_table (
    cache_id bigint DEFAULT nextval('infra.cache_id_seq'::regclass) NOT NULL,
    cache_key text NOT NULL,
    cache_value jsonb NOT NULL
);


ALTER TABLE infra.t_cache_table OWNER TO postgres;

--
-- Name: t_child_validation_rule_config; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_child_validation_rule_config (
    child_validation_rule_id integer DEFAULT nextval('infra.child_validation_rule_id_seq'::regclass) NOT NULL,
    api_name text NOT NULL,
    param_name text NOT NULL,
    validation_key text NOT NULL,
    child_validation_key text NOT NULL,
    child_validation_method text,
    child_validation_criteria text,
    created_by text NOT NULL,
    creation_time timestamp without time zone NOT NULL,
    modified_by text,
    modification_time timestamp without time zone,
    code character varying(24),
    code_desc text
);


ALTER TABLE infra.t_child_validation_rule_config OWNER TO postgres;

--
-- Name: t_connect_bau_wf_mapping; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_connect_bau_wf_mapping (
    connect_bau_wf_mapping_id bigint DEFAULT nextval('infra.connect_bau_wf_mapping_id_seq'::regclass) NOT NULL,
    connect_wf_task_name text NOT NULL,
    esap_wf_service_name text NOT NULL
);


ALTER TABLE infra.t_connect_bau_wf_mapping OWNER TO postgres;

--
-- Name: t_db_service_config; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_db_service_config (
    sql_id bigint NOT NULL,
    sql_key text NOT NULL,
    source_service character varying(40) NOT NULL,
    operation character varying(20) NOT NULL,
    sql_text text NOT NULL,
    tables_involved text,
    columns_involved text,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    modified_by text,
    update_timestamp timestamp with time zone
);


ALTER TABLE infra.t_db_service_config OWNER TO postgres;

--
-- Name: t_db_service_config_sql_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

ALTER TABLE infra.t_db_service_config ALTER COLUMN sql_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME infra.t_db_service_config_sql_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_device_monitor; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_device_monitor (
    device_id bigint DEFAULT nextval('infra.device_id_seq'::regclass) NOT NULL,
    device character varying(24) NOT NULL,
    device_type character varying(24) NOT NULL,
    clli character varying(24) NOT NULL,
    status character varying(24) NOT NULL,
    last_activity_time date
);


ALTER TABLE infra.t_device_monitor OWNER TO postgres;

--
-- Name: t_generic_validation_rule; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_generic_validation_rule (
    rule_id integer NOT NULL,
    rule text NOT NULL,
    description text NOT NULL,
    rule_type text NOT NULL,
    created_by text NOT NULL,
    creation_date timestamp without time zone NOT NULL,
    modified_by text,
    modification_date timestamp without time zone
);


ALTER TABLE infra.t_generic_validation_rule OWNER TO postgres;

--
-- Name: t_generic_validation_rule_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.t_generic_validation_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.t_generic_validation_rule_id_seq OWNER TO postgres;

--
-- Name: t_generic_validation_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.t_generic_validation_rule_id_seq OWNED BY infra.t_generic_validation_rule.rule_id;


--
-- Name: t_interface_service_template; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_interface_service_template (
    originating_system text NOT NULL,
    service_type text NOT NULL,
    camel_template jsonb NOT NULL,
    order_header_rules jsonb NOT NULL,
    common_specifications_rules jsonb NOT NULL,
    service_capability_rules jsonb NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE infra.t_interface_service_template OWNER TO postgres;

--
-- Name: t_milestone_config; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_milestone_config (
    milsetone_config_id bigint DEFAULT nextval('infra.milestone_id_seq'::regclass) NOT NULL,
    entity_type text NOT NULL,
    order_type text NOT NULL,
    milestone text NOT NULL,
    tasks text NOT NULL,
    created_by text NOT NULL,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by text,
    update_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE infra.t_milestone_config OWNER TO postgres;

--
-- Name: t_milestone_manager; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_milestone_manager (
    milestone_manager_id bigint DEFAULT nextval('infra.milestone_manager_id_seq'::regclass) NOT NULL,
    order_number text NOT NULL,
    order_version integer NOT NULL,
    milestone_id integer NOT NULL,
    milestone_process_flag boolean NOT NULL,
    created_by text NOT NULL,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_by text,
    update_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE infra.t_milestone_manager OWNER TO postgres;

--
-- Name: t_task_configuration_task_configuration_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.t_task_configuration_task_configuration_id_seq
    START WITH 38
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.t_task_configuration_task_configuration_id_seq OWNER TO postgres;

--
-- Name: t_task_configuration; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_task_configuration (
    task_configuration_id bigint DEFAULT nextval('infra.t_task_configuration_task_configuration_id_seq'::regclass) NOT NULL,
    task_name character varying(50) NOT NULL,
    device_type character varying(24),
    batch_size bigint,
    parallel_call_allowed boolean DEFAULT true,
    max_parallel_call bigint,
    task_process_endpoint text,
    timeoutvalue bigint,
    response_topic text NOT NULL,
    created_by text NOT NULL,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    modified_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    http_method character varying(24) DEFAULT 'POST'::character varying
);


ALTER TABLE infra.t_task_configuration OWNER TO postgres;

--
-- Name: task_order_status_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.task_order_status_id_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.task_order_status_id_seq OWNER TO postgres;

--
-- Name: t_task_order_status; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_task_order_status (
    task_order_status_id bigint DEFAULT nextval('infra.task_order_status_id_seq'::regclass) NOT NULL,
    work_order_number text,
    work_order_version text,
    entity_order_id bigint,
    task_name text,
    task_status character varying(20),
    is_tasks_execution_for_entity_completed character varying(5)
);


ALTER TABLE infra.t_task_order_status OWNER TO postgres;

--
-- Name: transaction_error_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.transaction_error_id_seq
    START WITH 6
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE infra.transaction_error_id_seq OWNER TO postgres;

--
-- Name: t_transaction_error; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_transaction_error (
    transaction_error_id bigint DEFAULT nextval('infra.transaction_error_id_seq'::regclass) NOT NULL,
    lob character varying(24) NOT NULL,
    domain character varying(24) NOT NULL,
    error_code character varying(24) NOT NULL,
    pg_error_code character varying(24) NOT NULL,
    pg_error_description text NOT NULL,
    retry_count bigint NOT NULL,
    workflow_taskname character varying(24),
    priority integer
);


ALTER TABLE infra.t_transaction_error OWNER TO postgres;

--
-- Name: transaction_error_manager_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.transaction_error_manager_id_seq
    START WITH 5
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.transaction_error_manager_id_seq OWNER TO postgres;

--
-- Name: t_transaction_error_manager; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_transaction_error_manager (
    transaction_error_manager_id bigint DEFAULT nextval('infra.transaction_error_manager_id_seq'::regclass) NOT NULL,
    transaction_id character varying(48) NOT NULL,
    lob character varying(24) NOT NULL,
    domain character varying(24) NOT NULL,
    entity character varying(24) NOT NULL,
    order_id character varying(24) NOT NULL,
    order_version character varying(24) NOT NULL,
    failure_pointer character varying(24),
    batch character varying(24),
    domain_batch character varying(24),
    request text NOT NULL,
    response text NOT NULL,
    exception text,
    tn_list text,
    update_date timestamp(4) without time zone NOT NULL,
    modified_by text,
    transaction_error_id bigint NOT NULL,
    creation_date timestamp without time zone,
    created_by character varying(32)
);


ALTER TABLE infra.t_transaction_error_manager OWNER TO postgres;

--
-- Name: t_transaction_manager; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_transaction_manager (
    trans_manager_id bigint NOT NULL,
    device_id bigint,
    transaction_id text NOT NULL,
    order_id text NOT NULL,
    entity_order_id text,
    order_version character varying(24),
    workflow_taskname text,
    clli character varying(24) NOT NULL,
    priority bigint NOT NULL,
    batch character varying(24) NOT NULL,
    request jsonb,
    response jsonb,
    status character varying(24) NOT NULL,
    transaction_end_time timestamp without time zone,
    transaction_start_time timestamp without time zone,
    retry_flag boolean,
    update_date timestamp without time zone,
    creation_date timestamp without time zone,
    created_by character varying(32),
    update_by character varying(32)
);


ALTER TABLE infra.t_transaction_manager OWNER TO postgres;

--
-- Name: t_transaction_manager_trans_manager_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.t_transaction_manager_trans_manager_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.t_transaction_manager_trans_manager_id_seq OWNER TO postgres;

--
-- Name: t_transaction_manager_trans_manager_id_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.t_transaction_manager_trans_manager_id_seq OWNED BY infra.t_transaction_manager.trans_manager_id;


--
-- Name: t_validation_error_msg_mapper; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_validation_error_msg_mapper (
    validation_error_msg_id bigint NOT NULL,
    validation_key text,
    api_name character varying(24),
    error_message text,
    created_by character varying(24),
    creation_time timestamp without time zone
);


ALTER TABLE infra.t_validation_error_msg_mapper OWNER TO postgres;

--
-- Name: t_validation_manager; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_validation_manager (
    validation_manager_id bigint NOT NULL,
    order_id character varying(24),
    order_version bigint,
    transaction_id character varying(24),
    param_name text,
    param_value text,
    failure_description text,
    validation_method text,
    validation_key text,
    api_name character varying(24),
    success_description text,
    entity character varying(24),
    transaction_timestamp timestamp without time zone,
    child_validation_key text,
    entity_value character varying(24),
    code character varying(24)
);


ALTER TABLE infra.t_validation_manager OWNER TO postgres;

--
-- Name: t_validation_method_mapper; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_validation_method_mapper (
    validation_method_mapper_id bigint NOT NULL,
    validation_key text,
    validaiton_method_key text NOT NULL,
    validaiton_method_name text NOT NULL,
    last_updated_by character varying(24) NOT NULL,
    last_updated_time timestamp without time zone NOT NULL
);


ALTER TABLE infra.t_validation_method_mapper OWNER TO postgres;

--
-- Name: t_validation_param_map; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_validation_param_map (
    validation_param_id bigint NOT NULL,
    source_system character varying(24) NOT NULL,
    src_param_name text NOT NULL,
    destination_system character varying(24) NOT NULL,
    des_param_name text NOT NULL,
    created_by character varying(24) NOT NULL,
    modified_by character varying(24),
    creation_time timestamp without time zone NOT NULL,
    modification_time timestamp without time zone,
    is_mandatory boolean NOT NULL,
    api_name character varying(50) NOT NULL,
    gen_rule_id integer
);


ALTER TABLE infra.t_validation_param_map OWNER TO postgres;

--
-- Name: t_validation_rule_config; Type: TABLE; Schema: infra; Owner: connectsit
--

CREATE TABLE infra.t_validation_rule_config (
    validation_rule_id bigint NOT NULL,
    api_name text NOT NULL,
    param_name text NOT NULL,
    validation_type text NOT NULL,
    validation_key text NOT NULL,
    validation_method text,
    validation_criteria text,
    validation_input_pname text,
    extract_pname text,
    entity character varying(24),
    domain character varying(24) NOT NULL,
    sequence_no bigint,
    parallel_allowed boolean NOT NULL,
    created_by character varying(24) NOT NULL,
    modified_by character varying(24),
    creation_time timestamp without time zone NOT NULL,
    modification_time timestamp without time zone,
    has_children boolean DEFAULT false NOT NULL,
    code character varying(24),
    code_desc text
);


ALTER TABLE infra.t_validation_rule_config OWNER TO postgres;

--
-- Name: transaction_error_id_new_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.transaction_error_id_new_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.transaction_error_id_new_seq OWNER TO postgres;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE infra.transaction_id_seq OWNER TO postgres;

--
-- Name: validation_error_msg_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.validation_error_msg_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.validation_error_msg_seq OWNER TO postgres;

--
-- Name: validation_error_msg_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.validation_error_msg_seq OWNED BY infra.t_validation_error_msg_mapper.validation_error_msg_id;


--
-- Name: validation_manager_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.validation_manager_id_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.validation_manager_id_seq OWNER TO postgres;

--
-- Name: validation_manager_id_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.validation_manager_id_seq OWNED BY infra.t_validation_manager.validation_manager_id;


--
-- Name: validation_method_map_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.validation_method_map_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.validation_method_map_seq OWNER TO postgres;

--
-- Name: validation_method_map_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.validation_method_map_seq OWNED BY infra.t_validation_method_mapper.validation_method_mapper_id;


--
-- Name: validation_param_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.validation_param_id_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.validation_param_id_seq OWNER TO postgres;

--
-- Name: validation_param_id_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.validation_param_id_seq OWNED BY infra.t_validation_param_map.validation_param_id;


--
-- Name: validation_rule_id_seq; Type: SEQUENCE; Schema: infra; Owner: connectsit
--

CREATE SEQUENCE infra.validation_rule_id_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    NO MAXVALUE
    CACHE 1;


ALTER TABLE infra.validation_rule_id_seq OWNER TO postgres;

--
-- Name: validation_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: infra; Owner: connectsit
--

ALTER SEQUENCE infra.validation_rule_id_seq OWNED BY infra.t_validation_rule_config.validation_rule_id;


--
-- Name: country_province_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.country_province_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ordng.country_province_id_seq OWNER TO postgres;

--
-- Name: db_service_config_sql_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.db_service_config_sql_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ordng.db_service_config_sql_id_seq OWNER TO postgres;

--
-- Name: entity_order_detail_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.entity_order_detail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ordng.entity_order_detail_id_seq OWNER TO postgres;

--
-- Name: entity_order_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.entity_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ordng.entity_order_id_seq OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE ordng.flyway_schema_history OWNER TO postgres;

--
-- Name: master_order_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.master_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ordng.master_order_id_seq OWNER TO postgres;

--
-- Name: raw_data_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.raw_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ordng.raw_data_id_seq OWNER TO postgres;

--
-- Name: SEQUENCE raw_data_id_seq; Type: COMMENT; Schema: ordng; Owner: connectsit
--

COMMENT ON SEQUENCE ordng.raw_data_id_seq IS 'Sequence for raw_data_id column of t_raw_data table';


--
-- Name: schema_version; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE ordng.schema_version OWNER TO postgres;

--
-- Name: t_db_service_config; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_db_service_config (
    sql_id bigint DEFAULT nextval('ordng.db_service_config_sql_id_seq'::regclass) NOT NULL,
    sql_key text NOT NULL,
    source_service character varying(40) NOT NULL,
    operation character varying(20) NOT NULL,
    sql_text text NOT NULL,
    tables_involved text,
    columns_involved text,
    update_timestamp timestamp with time zone,
    modified_by character varying(50)
);


ALTER TABLE ordng.t_db_service_config OWNER TO postgres;

--
-- Name: t_entity_order; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_entity_order (
    entity_order_id bigint DEFAULT nextval('ordng.entity_order_id_seq'::regclass) NOT NULL,
    master_order_id bigint,
    parent_entity_order_id bigint,
    order_status character varying(32) NOT NULL,
    entity_type_name character varying(24) NOT NULL,
    start_date timestamp without time zone NOT NULL,
    completion_date timestamp without time zone,
    failed_date timestamp without time zone,
    updated_date timestamp without time zone,
    entity_action character varying(8) NOT NULL,
    error_code text,
    common_order_details jsonb,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_modified_date timestamp without time zone,
    modified_by character varying(32),
    processing_type character varying(32),
    created_by character varying(32) DEFAULT 'CONNECT'::character varying NOT NULL
);


ALTER TABLE ordng.t_entity_order OWNER TO postgres;

--
-- Name: t_entity_order_details; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_entity_order_details (
    entity_order_detail_id bigint DEFAULT nextval('ordng.entity_order_detail_id_seq'::regclass) NOT NULL,
    entity_order_id bigint,
    order_status character varying(32) NOT NULL,
    entity_order_details jsonb,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_modified_date timestamp without time zone,
    modified_by character varying(32),
    processing_type character varying(32),
    created_by character varying(32) DEFAULT 'CONNECT'::character varying NOT NULL,
    migration_batch_number bigint,
    entity_order_details_package_features jsonb,
    prev_pass_order_status character varying(32),
    prev_pass_entity_order_id bigint
);


ALTER TABLE ordng.t_entity_order_details OWNER TO postgres;

--
-- Name: t_entity_spec_mapping; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_entity_spec_mapping (
    entity_spec_mapping_id bigint NOT NULL,
    field_name text,
    entity_name text,
    spec_code text,
    spec_value_type text,
    spec_value text,
    spec_value_formula text,
    spec_value_details jsonb,
    in_object_type text,
    order_type text,
    region text,
    service_type text,
    lob text,
    product_type text,
    source text,
    flow text,
    destination_feature_mapping jsonb,
    destination_spec_mapping jsonb,
    spec_code_parent text,
    is_active character varying(24),
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE ordng.t_entity_spec_mapping OWNER TO postgres;

--
-- Name: t_entity_spec_mapping_entity_spec_mapping_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

ALTER TABLE ordng.t_entity_spec_mapping ALTER COLUMN entity_spec_mapping_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME ordng.t_entity_spec_mapping_entity_spec_mapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_entity_spec_mapping_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.t_entity_spec_mapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ordng.t_entity_spec_mapping_id_seq OWNER TO postgres;

--
-- Name: t_master_order; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_master_order (
    master_order_id bigint DEFAULT nextval('ordng.master_order_id_seq'::regclass) NOT NULL,
    prev_pass_master_order_id bigint,
    source_system character varying(24) NOT NULL,
    work_order_number text NOT NULL,
    work_order_version text NOT NULL,
    master_order_number text,
    region character varying(16) NOT NULL,
    source_addr text,
    received_date timestamp without time zone NOT NULL,
    due_date timestamp without time zone NOT NULL,
    completion_date timestamp without time zone,
    order_type character varying(32) NOT NULL,
    minor_order_type character varying(24),
    order_status character varying(32) NOT NULL,
    order_priority character varying(32),
    order_category text,
    order_classify text NOT NULL,
    service_type character varying(24),
    created_by character varying(32) DEFAULT 'CONNECT'::character varying NOT NULL,
    order_lock_date timestamp without time zone,
    order_locked_by character varying(32),
    last_modified_date timestamp without time zone,
    modified_by character varying(32),
    lob character varying(16),
    product_type text,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    master_order_details jsonb
);


ALTER TABLE ordng.t_master_order OWNER TO postgres;

--
-- Name: t_order_priority_setting; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_order_priority_setting (
    project_id text,
    priority text NOT NULL,
    expedite text,
    source text,
    order_type text,
    region text,
    service_type text,
    lob text,
    product_type text,
    flow text,
    priority_setting_attributes text,
    created_by text NOT NULL,
    creation_date timestamp without time zone NOT NULL,
    modified_by text,
    last_modified_date timestamp without time zone
);


ALTER TABLE ordng.t_order_priority_setting OWNER TO postgres;

--
-- Name: t_parent_orders; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_parent_orders (
    entity_order_detail_id bigint,
    parent_order_detail_id bigint,
    parent_pending character varying(1)
);


ALTER TABLE ordng.t_parent_orders OWNER TO postgres;

--
-- Name: t_raw_order; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_raw_order (
    raw_data_id bigint DEFAULT nextval('ordng.raw_data_id_seq'::regclass) NOT NULL,
    transaction_id text NOT NULL,
    order_number text NOT NULL,
    order_version bigint NOT NULL,
    source_system text,
    raw_data text NOT NULL,
    raw_data_type character varying(24) NOT NULL,
    request_details text,
    start_index bigint,
    end_index bigint,
    status text,
    entity_order_type text,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by character varying(32) DEFAULT 'CONNECT'::character varying NOT NULL,
    last_modified_date timestamp without time zone,
    modified_by character varying(32),
    unique_identifier character varying(15)
);


ALTER TABLE ordng.t_raw_order OWNER TO postgres;

--
-- Name: TABLE t_raw_order; Type: COMMENT; Schema: ordng; Owner: connectsit
--

COMMENT ON TABLE ordng.t_raw_order IS 'This table will store the raw order information as obtained from the upstream system';


--
-- Name: t_source_feat_spec_jpath_mapping_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.t_source_feat_spec_jpath_mapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE ordng.t_source_feat_spec_jpath_mapping_id_seq OWNER TO postgres;

--
-- Name: t_source_feat_spec_jpath_mapping; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_source_feat_spec_jpath_mapping (
    source_feat_spec_jpath_mapping_id bigint DEFAULT nextval('ordng.t_source_feat_spec_jpath_mapping_id_seq'::regclass) NOT NULL,
    target_field_name text,
    source_class_name text,
    source_feat_code text,
    source_spec_code text,
    value_type text,
    source_mapping_value text,
    value_formula text,
    value_details jsonb,
    in_object_type text,
    order_type text,
    region text,
    service_type text,
    lob text,
    product_type text,
    source text,
    flow text,
    creation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by character varying(32) DEFAULT 'CONNECT'::character varying NOT NULL,
    last_modified_date timestamp without time zone,
    modified_by character varying(32)
);


ALTER TABLE ordng.t_source_feat_spec_jpath_mapping OWNER TO postgres;

--
-- Name: t_wf_task_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.t_wf_task_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 10000
    CACHE 1;


ALTER TABLE ordng.t_wf_task_seq OWNER TO postgres;

--
-- Name: t_wf_task; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_wf_task (
    task_id bigint DEFAULT nextval('ordng.t_wf_task_seq'::regclass) NOT NULL,
    task_name text,
    parent_task_name text,
    reverse_task_name text,
    task_type text,
    entity_type_name text,
    entity_action text,
    order_type text,
    product text,
    region text,
    function_code text,
    lob text,
    created_by text,
    modified_by text,
    last_modified_date timestamp without time zone,
    creation_date timestamp without time zone,
    service_type text,
    active_indicator text,
    supp_indicator text,
    default_task text,
    source_system text
);


ALTER TABLE ordng.t_wf_task OWNER TO postgres;

--
-- Name: t_wf_task_entity_action_metrix_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.t_wf_task_entity_action_metrix_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 1000
    CACHE 1;


ALTER TABLE ordng.t_wf_task_entity_action_metrix_seq OWNER TO postgres;

--
-- Name: t_wf_task_entity_action_metrix; Type: TABLE; Schema: ordng; Owner: connectsit
--

CREATE TABLE ordng.t_wf_task_entity_action_metrix (
    metrix_id bigint DEFAULT nextval('ordng.t_wf_task_entity_action_metrix_seq'::regclass) NOT NULL,
    previous_pass_entity_action character varying(10),
    current_pass_entity_action character varying(10),
    previous_pass_task character varying(50),
    on_failure_of_prev_pass_task character varying(50),
    active_indicator character varying(10),
    created_by character varying(50),
    creation_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone,
    modified_by character varying(50),
    last_modification_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone,
    current_pass_task text
);


ALTER TABLE ordng.t_wf_task_entity_action_metrix OWNER TO postgres;

--
-- Name: template_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.template_id_seq
    START WITH 6
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ordng.template_id_seq OWNER TO postgres;

--
-- Name: tn_bod_seq_id; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.tn_bod_seq_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ordng.tn_bod_seq_id OWNER TO postgres;

--
-- Name: SEQUENCE tn_bod_seq_id; Type: COMMENT; Schema: ordng; Owner: connectsit
--

COMMENT ON SEQUENCE ordng.tn_bod_seq_id IS 'Sequence to store the tn_bod_id in table t_eodb_tn_bod';


--
-- Name: wf_order_id_seq; Type: SEQUENCE; Schema: ordng; Owner: connectsit
--

CREATE SEQUENCE ordng.wf_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ordng.wf_order_id_seq OWNER TO postgres;

--
-- Name: test; Type: TABLE; Schema: public; Owner: connectsit
--

CREATE TABLE public.test (
    a bigint
);


ALTER TABLE public.test OWNER TO postgres;

--
-- Name: db_service_config_sql_id_seq; Type: SEQUENCE; Schema: svcinv; Owner: connectsit
--

CREATE SEQUENCE svcinv.db_service_config_sql_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE svcinv.db_service_config_sql_id_seq OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: svcinv; Owner: connectsit
--

CREATE TABLE svcinv.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE svcinv.flyway_schema_history OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: svcinv; Owner: connectsit
--

CREATE TABLE svcinv.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE svcinv.schema_version OWNER TO postgres;

--
-- Name: t_db_service_config; Type: TABLE; Schema: svcinv; Owner: connectsit
--

CREATE TABLE svcinv.t_db_service_config (
    sql_id bigint NOT NULL,
    sql_key text NOT NULL,
    source_service character varying(40) NOT NULL,
    operation character varying(20) NOT NULL,
    sql_text text NOT NULL,
    tables_involved text,
    columns_involved text,
    update_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    modified_by text
);


ALTER TABLE svcinv.t_db_service_config OWNER TO postgres;

--
-- Name: t_db_service_config_sql_id_seq; Type: SEQUENCE; Schema: svcinv; Owner: connectsit
--

ALTER TABLE svcinv.t_db_service_config ALTER COLUMN sql_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME svcinv.t_db_service_config_sql_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_service_feature; Type: TABLE; Schema: svcinv; Owner: connectsit
--

CREATE TABLE svcinv.t_service_feature (
    feature_id bigint NOT NULL,
    feature_name text NOT NULL,
    feature_description text,
    platform_indicator text NOT NULL,
    feature_reference jsonb,
    feature_billing_attributes jsonb,
    feature_display_attributes jsonb,
    feature_level_attributes jsonb,
    feature_attributes jsonb,
    service_type_supported jsonb NOT NULL,
    product_type_supported jsonb NOT NULL,
    region_supported jsonb NOT NULL,
    lob_supported jsonb NOT NULL,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    modification_date timestamp with time zone
);


ALTER TABLE svcinv.t_service_feature OWNER TO postgres;

--
-- Name: t_service_feature_feature_id_seq; Type: SEQUENCE; Schema: svcinv; Owner: connectsit
--

ALTER TABLE svcinv.t_service_feature ALTER COLUMN feature_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME svcinv.t_service_feature_feature_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_service_feature_package; Type: TABLE; Schema: svcinv; Owner: connectsit
--

CREATE TABLE svcinv.t_service_feature_package (
    package_name text NOT NULL,
    package_features jsonb NOT NULL,
    package_attributes jsonb,
    service_type_supported jsonb NOT NULL,
    product_type_supported jsonb NOT NULL,
    region_supported jsonb NOT NULL,
    lob_supported jsonb NOT NULL,
    status character varying(50) NOT NULL,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    modification_date timestamp with time zone
);


ALTER TABLE svcinv.t_service_feature_package OWNER TO postgres;

--
-- Name: t_service_inventory; Type: TABLE; Schema: svcinv; Owner: connectsit
--

CREATE TABLE svcinv.t_service_inventory (
    entity_id text NOT NULL,
    entity_type text NOT NULL,
    entity_name text NOT NULL,
    lob text NOT NULL,
    region text NOT NULL,
    country_code text NOT NULL,
    entity_reference jsonb,
    entity_attributes jsonb,
    entity_topology_attributes jsonb,
    entity_billing_attributes jsonb,
    sensitivity_flag jsonb,
    entity_activation_status text,
    entity_billing_status text,
    created_by text NOT NULL,
    creation_date timestamp without time zone NOT NULL,
    modified_by text,
    modification_date timestamp without time zone NOT NULL,
    entity_packages jsonb,
    entity_features jsonb
);


ALTER TABLE svcinv.t_service_inventory OWNER TO postgres;

--
-- Name: t_service_inventory; Type: TABLE; Schema: svcinv1; Owner: connectsit
--

CREATE TABLE svcinv1.t_service_inventory (
    entity_id character varying(100) NOT NULL,
    entity_type character varying(100) NOT NULL,
    entity_name character varying(100) NOT NULL,
    lob character varying(100) NOT NULL,
    region character varying(100) NOT NULL,
    country_code character varying(100) NOT NULL,
    entity_reference jsonb,
    entity_attributes jsonb,
    entity_topology_attributes jsonb,
    entity_billing_attributes jsonb,
    sensitivity_flag jsonb,
    entity_activation_status character varying(100),
    entity_billing_status character varying(100),
    created_by character varying(100) NOT NULL,
    creation_date timestamp without time zone NOT NULL,
    modified_by character varying(100),
    modification_date timestamp without time zone NOT NULL,
    entity_packages jsonb,
    entity_features jsonb
);


ALTER TABLE svcinv1.t_service_inventory OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE tninv.flyway_schema_history OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description text NOT NULL,
    type character varying(20) NOT NULL,
    script text NOT NULL,
    checksum integer,
    installed_by text NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE tninv.schema_version OWNER TO postgres;

--
-- Name: sql_id_seq; Type: SEQUENCE; Schema: tninv; Owner: connectsit
--

CREATE SEQUENCE tninv.sql_id_seq
    START WITH 1000
    INCREMENT BY 1
    MINVALUE 1000
    MAXVALUE 999999999999999
    CACHE 20;


ALTER TABLE tninv.sql_id_seq OWNER TO postgres;

--
-- Name: t_carrier; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_carrier (
    carrier_id bigint NOT NULL,
    carrier_name text NOT NULL,
    carrier_code text NOT NULL,
    province_id bigint,
    country_alpha2_code text NOT NULL,
    service_provider_id jsonb,
    carrier_interface_mapping jsonb,
    carrier_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE tninv.t_carrier OWNER TO postgres;

--
-- Name: t_carrier_carrier_id_seq; Type: SEQUENCE; Schema: tninv; Owner: connectsit
--

ALTER TABLE tninv.t_carrier ALTER COLUMN carrier_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME tninv.t_carrier_carrier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_db_service_config; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_db_service_config (
    sql_id integer DEFAULT nextval('tninv.sql_id_seq'::regclass) NOT NULL,
    sql_key text NOT NULL,
    source_service character varying(40) NOT NULL,
    operation character varying(20) NOT NULL,
    sql_text text NOT NULL,
    tables_involved text,
    columns_involved text,
    update_timestamp timestamp with time zone,
    modified_by character varying(50)
);


ALTER TABLE tninv.t_db_service_config OWNER TO postgres;

--
-- Name: t_domain_exception_retry; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_domain_exception_retry (
    transaction_id character varying(100) NOT NULL,
    entity_order_id character varying(50),
    batch_id character varying(50),
    exception_attributes jsonb,
    raw_data_type character varying(50),
    raw_processing_data character varying(100),
    order_exception_data_mapping jsonb,
    error_code character varying(50),
    error_description character varying(50),
    current_status character varying(50) NOT NULL,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE tninv.t_domain_exception_retry OWNER TO postgres;

--
-- Name: t_tn_feature_package; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_tn_feature_package (
    package_name text NOT NULL,
    package_features jsonb NOT NULL,
    package_attributes jsonb,
    service_type_supported jsonb NOT NULL,
    product_type_supported jsonb NOT NULL,
    region_supported jsonb NOT NULL,
    lob_supported jsonb NOT NULL,
    status character varying(32) NOT NULL,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE tninv.t_tn_feature_package OWNER TO postgres;

--
-- Name: t_tn_features; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_tn_features (
    feature_id bigint NOT NULL,
    feature_name text NOT NULL,
    feature_description text,
    platform_indicator character varying(1),
    feature_reference jsonb,
    feature_billing_attributes jsonb,
    feature_display_attributes jsonb,
    feature_level_attributes jsonb,
    feature_attributes jsonb,
    service_type_supported jsonb NOT NULL,
    product_type_supported jsonb NOT NULL,
    region_supported jsonb NOT NULL,
    lob_supported jsonb NOT NULL,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE tninv.t_tn_features OWNER TO postgres;

--
-- Name: t_tn_inventory; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_tn_inventory (
    tn character varying(24) NOT NULL,
    tn_status character varying(24),
    customer_id character varying(24),
    location_id character varying(32),
    ban character varying(24),
    lob character varying(16),
    region character varying(16),
    country_code character varying(16),
    rate_center character varying(32),
    porting_status character varying(32),
    tn_attributes jsonb,
    created_by text NOT NULL,
    creation_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone NOT NULL,
    modified_by text,
    last_modified_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone,
    address_id text,
    entity_features jsonb
);


ALTER TABLE tninv.t_tn_inventory OWNER TO postgres;

--
-- Name: t_tn_property_country_mapping; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_tn_property_country_mapping (
    country_mapping_id bigint NOT NULL,
    country_alpha2_code text NOT NULL,
    tn_lenght_attribute jsonb,
    std_code_attributes jsonb,
    tn_property_country_attributes jsonb,
    created_by text DEFAULT CURRENT_USER NOT NULL,
    creation_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    modified_by text,
    last_modified_date timestamp with time zone
);


ALTER TABLE tninv.t_tn_property_country_mapping OWNER TO postgres;

--
-- Name: t_tn_property_country_mapping_country_mapping_id_seq; Type: SEQUENCE; Schema: tninv; Owner: connectsit
--

ALTER TABLE tninv.t_tn_property_country_mapping ALTER COLUMN country_mapping_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME tninv.t_tn_property_country_mapping_country_mapping_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: t_tninv_migration; Type: TABLE; Schema: tninv; Owner: connectsit
--

CREATE TABLE tninv.t_tninv_migration (
    batch_id bigint NOT NULL,
    entity_order_id character varying(24) NOT NULL,
    command_name character varying(24) NOT NULL,
    status character varying(32) NOT NULL,
    start_index bigint,
    end_index bigint,
    command_request_payload text NOT NULL,
    command_response_payload text,
    provision_attributes text,
    prepare_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone NOT NULL,
    provision_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone,
    created_by text NOT NULL,
    creation_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone NOT NULL,
    modified_by text,
    last_modified_date timestamp without time zone DEFAULT (clock_timestamp())::timestamp(0) without time zone
);


ALTER TABLE tninv.t_tninv_migration OWNER TO postgres;

--
-- Name: tn_attribute_id_seq; Type: SEQUENCE; Schema: tninv; Owner: connectsit
--

CREATE SEQUENCE tninv.tn_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE tninv.tn_attribute_id_seq OWNER TO postgres;

--
-- Name: tn_inv_id_seq; Type: SEQUENCE; Schema: tninv; Owner: connectsit
--

CREATE SEQUENCE tninv.tn_inv_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE tninv.tn_inv_id_seq OWNER TO postgres;

--
-- Name: tn_order_attribute_mapping_seq; Type: SEQUENCE; Schema: tninv; Owner: connectsit
--

CREATE SEQUENCE tninv.tn_order_attribute_mapping_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tninv.tn_order_attribute_mapping_seq OWNER TO postgres;

--
-- Name: blocking_id_seq; Type: SEQUENCE; Schema: topology; Owner: connectsit
--

CREATE SEQUENCE topology.blocking_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE topology.blocking_id_seq OWNER TO postgres;

--
-- Name: blocking_location_id_seq; Type: SEQUENCE; Schema: topology; Owner: connectsit
--

CREATE SEQUENCE topology.blocking_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE topology.blocking_location_id_seq OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: topology; Owner: connectsit
--

CREATE TABLE topology.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE topology.flyway_schema_history OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: topology; Owner: connectsit
--

CREATE TABLE topology.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE topology.schema_version OWNER TO postgres;

--
-- Name: switch_id_seq; Type: SEQUENCE; Schema: topology; Owner: connectsit
--

CREATE SEQUENCE topology.switch_id_seq
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE topology.switch_id_seq OWNER TO postgres;

--
-- Name: t_switch_info; Type: TABLE; Schema: topology; Owner: connectsit
--

CREATE TABLE topology.t_switch_info (
    switch_id bigint DEFAULT nextval('topology.switch_id_seq'::regclass) NOT NULL,
    clli character varying(20) NOT NULL,
    switch_var character varying(20),
    switch_type character varying(20),
    drop_timeout bigint,
    loopback_on bigint,
    retry_limit bigint,
    retry_interval bigint,
    async_flag bigint,
    async_volume bigint,
    status character varying(20),
    lob character varying(20),
    region_mapping jsonb,
    connection_info jsonb,
    additional_attributes jsonb,
    created_by character varying(20),
    creation_date date DEFAULT CURRENT_TIMESTAMP,
    modify_by character varying(20),
    modification_date date DEFAULT CURRENT_TIMESTAMP,
    task_name character varying(50)
);


ALTER TABLE topology.t_switch_info OWNER TO postgres;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: uui; Owner: connectsit
--

CREATE TABLE uui.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE uui.flyway_schema_history OWNER TO postgres;

--
-- Name: schema_version; Type: TABLE; Schema: uui; Owner: connectsit
--

CREATE TABLE uui.schema_version (
    version_rank integer NOT NULL,
    installed_rank integer NOT NULL,
    version character varying(50) NOT NULL,
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE uui.schema_version OWNER TO postgres;

--
-- Name: t_db_service_config; Type: TABLE; Schema: uui; Owner: connectsit
--

CREATE TABLE uui.t_db_service_config (
    sql_id double precision,
    sql_key character varying(256) NOT NULL,
    source_service character varying(40) NOT NULL,
    operation character varying(20) NOT NULL,
    sql_text text,
    tables_involved character varying(1024),
    columns_involved character varying(1024)
);


ALTER TABLE uui.t_db_service_config OWNER TO postgres;

--
-- Name: t_generic_validation_rule rule_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_generic_validation_rule ALTER COLUMN rule_id SET DEFAULT nextval('infra.t_generic_validation_rule_id_seq'::regclass);


--
-- Name: t_transaction_manager trans_manager_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_transaction_manager ALTER COLUMN trans_manager_id SET DEFAULT nextval('infra.t_transaction_manager_trans_manager_id_seq'::regclass);


--
-- Name: t_validation_error_msg_mapper validation_error_msg_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_error_msg_mapper ALTER COLUMN validation_error_msg_id SET DEFAULT nextval('infra.validation_error_msg_seq'::regclass);


--
-- Name: t_validation_manager validation_manager_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_manager ALTER COLUMN validation_manager_id SET DEFAULT nextval('infra.validation_manager_id_seq'::regclass);


--
-- Name: t_validation_method_mapper validation_method_mapper_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_method_mapper ALTER COLUMN validation_method_mapper_id SET DEFAULT nextval('infra.validation_method_map_seq'::regclass);


--
-- Name: t_validation_param_map validation_param_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_param_map ALTER COLUMN validation_param_id SET DEFAULT nextval('infra.validation_param_id_seq'::regclass);


--
-- Name: t_validation_rule_config validation_rule_id; Type: DEFAULT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_rule_config ALTER COLUMN validation_rule_id SET DEFAULT nextval('infra.validation_rule_id_seq'::regclass);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_activation_command t_activation_command_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_activation_command
    ADD CONSTRAINT t_activation_command_pkey PRIMARY KEY (activation_id);


--
-- Name: t_blocking_locations t_blocking_locations_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_blocking_locations
    ADD CONSTRAINT t_blocking_locations_pkey PRIMARY KEY (blocking_location_id);


--
-- Name: t_call_blocking t_call_blocking_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_call_blocking
    ADD CONSTRAINT t_call_blocking_pkey PRIMARY KEY (blocking_id);


--
-- Name: t_db_service_config t_db_service_config_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_db_service_config
    ADD CONSTRAINT t_db_service_config_pkey PRIMARY KEY (sql_id);


--
-- Name: t_feed_transaction t_feed_transaction_compkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_feed_transaction
    ADD CONSTRAINT t_feed_transaction_compkey PRIMARY KEY (transaction_id, feed_destination);


--
-- Name: t_ipcom_connect_shadow_trans t_ipcom_connect_shadow_trans_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_ipcom_connect_shadow_trans
    ADD CONSTRAINT t_ipcom_connect_shadow_trans_pkey PRIMARY KEY (orderid);


--
-- Name: t_ipcom_iasa_rs_template t_ipcom_iasa_rs_template_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_ipcom_iasa_rs_template
    ADD CONSTRAINT t_ipcom_iasa_rs_template_pkey PRIMARY KEY (rs_table_id);


--
-- Name: t_tn_act_details t_tso_tn_migration_pkey; Type: CONSTRAINT; Schema: activn; Owner: connectsit
--

ALTER TABLE ONLY activn.t_tn_act_details
    ADD CONSTRAINT t_tso_tn_migration_pkey PRIMARY KEY (tn_activation_id);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: audit; Owner: connectsit
--

ALTER TABLE ONLY audit.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_audit_info t_audit_info_pkey; Type: CONSTRAINT; Schema: audit; Owner: connectsit
--

ALTER TABLE ONLY audit.t_audit_info
    ADD CONSTRAINT t_audit_info_pkey PRIMARY KEY (audit_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_bs_command_list t_bs_command_list_pkey; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_bs_command_list
    ADD CONSTRAINT t_bs_command_list_pkey PRIMARY KEY (bs_command_id);


--
-- Name: t_bs_command_list t_bs_command_list_unique; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_bs_command_list
    ADD CONSTRAINT t_bs_command_list_unique UNIQUE (wf_task_name, bs_command_name);


--
-- Name: t_cli_type t_cli_type_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cli_type
    ADD CONSTRAINT t_cli_type_pk PRIMARY KEY (cli_type_id);


--
-- Name: t_command_template t_command_template_pkey; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_command_template
    ADD CONSTRAINT t_command_template_pkey PRIMARY KEY (template_id);


--
-- Name: t_config_properties t_config_properties_pkey; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_config_properties
    ADD CONSTRAINT t_config_properties_pkey PRIMARY KEY (config_id);


--
-- Name: t_country t_country_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_country
    ADD CONSTRAINT t_country_pk PRIMARY KEY (country_alpha2_code);


--
-- Name: t_cps_request_reference t_cps_request_reference_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cps_request_reference
    ADD CONSTRAINT t_cps_request_reference_pk PRIMARY KEY (cps_request);


--
-- Name: t_db_service_config t_db_service_config_pkey; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_db_service_config
    ADD CONSTRAINT t_db_service_config_pkey PRIMARY KEY (sql_id);


--
-- Name: t_network_communication_details t_network_communication_detail_pkey; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_network_communication_details
    ADD CONSTRAINT t_network_communication_detail_pkey PRIMARY KEY (network_communication_details_id);


--
-- Name: t_province t_province_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_province
    ADD CONSTRAINT t_province_pk PRIMARY KEY (province_id);


--
-- Name: t_retail_type t_retail_type_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_retail_type
    ADD CONSTRAINT t_retail_type_pk PRIMARY KEY (retail_type_id);


--
-- Name: t_service_provider t_service_provider_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_service_provider
    ADD CONSTRAINT t_service_provider_pk PRIMARY KEY (service_provider_id);


--
-- Name: t_cps_option_reference t_t_cps_option_reference_pk; Type: CONSTRAINT; Schema: config; Owner: connectsit
--

ALTER TABLE ONLY config.t_cps_option_reference
    ADD CONSTRAINT t_t_cps_option_reference_pk PRIMARY KEY (cps_option_id);


--
-- Name: t_cache_table cache_table_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_cache_table
    ADD CONSTRAINT cache_table_pkey PRIMARY KEY (cache_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_cache_config t_cache_config_end_point_end_point_method_path_param_key_qu_key; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_cache_config
    ADD CONSTRAINT t_cache_config_end_point_end_point_method_path_param_key_qu_key UNIQUE (end_point, end_point_method, path_param_key, query_param_key);


--
-- Name: t_cache_config t_cache_config_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_cache_config
    ADD CONSTRAINT t_cache_config_pkey PRIMARY KEY (cache_id);


--
-- Name: t_child_validation_rule_config t_child_validation_rule_config_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_child_validation_rule_config
    ADD CONSTRAINT t_child_validation_rule_config_pkey PRIMARY KEY (child_validation_rule_id);


--
-- Name: t_connect_bau_wf_mapping t_connect_bau_wf_mapping_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_connect_bau_wf_mapping
    ADD CONSTRAINT t_connect_bau_wf_mapping_pk PRIMARY KEY (connect_bau_wf_mapping_id);


--
-- Name: t_device_monitor t_device_monitor_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_device_monitor
    ADD CONSTRAINT t_device_monitor_pkey PRIMARY KEY (device_id);


--
-- Name: t_generic_validation_rule t_generic_validation_rule_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_generic_validation_rule
    ADD CONSTRAINT t_generic_validation_rule_pk PRIMARY KEY (rule_id);


--
-- Name: t_interface_service_template t_interface_service_template_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_interface_service_template
    ADD CONSTRAINT t_interface_service_template_pkey PRIMARY KEY (originating_system, service_type);


--
-- Name: t_milestone_config t_milestone_config_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_milestone_config
    ADD CONSTRAINT t_milestone_config_pk PRIMARY KEY (milsetone_config_id);


--
-- Name: t_milestone_manager t_milestone_manager_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_milestone_manager
    ADD CONSTRAINT t_milestone_manager_pk PRIMARY KEY (milestone_manager_id);


--
-- Name: t_task_configuration t_task_configuration_pk; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_task_configuration
    ADD CONSTRAINT t_task_configuration_pk PRIMARY KEY (task_configuration_id);


--
-- Name: t_transaction_error_manager t_transaction_error_maneger_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_transaction_error_manager
    ADD CONSTRAINT t_transaction_error_maneger_pkey PRIMARY KEY (transaction_error_manager_id);


--
-- Name: t_transaction_error t_transaction_error_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_transaction_error
    ADD CONSTRAINT t_transaction_error_pkey PRIMARY KEY (transaction_error_id);


--
-- Name: t_transaction_manager t_transaction_manager1_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_transaction_manager
    ADD CONSTRAINT t_transaction_manager1_pkey PRIMARY KEY (trans_manager_id);


--
-- Name: t_validation_rule_config t_validation_rule_config_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_validation_rule_config
    ADD CONSTRAINT t_validation_rule_config_pkey PRIMARY KEY (validation_rule_id);


--
-- Name: t_task_order_status task_order_status_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_task_order_status
    ADD CONSTRAINT task_order_status_pkey PRIMARY KEY (task_order_status_id);


--
-- Name: t_db_service_config tbl_db_service_config_pkey; Type: CONSTRAINT; Schema: infra; Owner: connectsit
--

ALTER TABLE ONLY infra.t_db_service_config
    ADD CONSTRAINT tbl_db_service_config_pkey PRIMARY KEY (sql_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_entity_order_details t_entity_order_details_pkey; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_entity_order_details
    ADD CONSTRAINT t_entity_order_details_pkey PRIMARY KEY (entity_order_detail_id);


--
-- Name: t_entity_order t_entity_order_pkey; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_entity_order
    ADD CONSTRAINT t_entity_order_pkey PRIMARY KEY (entity_order_id);


--
-- Name: t_entity_spec_mapping t_entity_spec_mapping_pk; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_entity_spec_mapping
    ADD CONSTRAINT t_entity_spec_mapping_pk PRIMARY KEY (entity_spec_mapping_id);


--
-- Name: t_master_order t_master_order_pkey; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_master_order
    ADD CONSTRAINT t_master_order_pkey PRIMARY KEY (master_order_id);


--
-- Name: t_raw_order t_raw_order_pk; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_raw_order
    ADD CONSTRAINT t_raw_order_pk PRIMARY KEY (raw_data_id);


--
-- Name: t_source_feat_spec_jpath_mapping t_source_feat_spec_jpath_mapping_pkey; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_source_feat_spec_jpath_mapping
    ADD CONSTRAINT t_source_feat_spec_jpath_mapping_pkey PRIMARY KEY (source_feat_spec_jpath_mapping_id);


--
-- Name: t_wf_task_entity_action_metrix t_wf_task_entity_action_metrix_pkey; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_wf_task_entity_action_metrix
    ADD CONSTRAINT t_wf_task_entity_action_metrix_pkey PRIMARY KEY (metrix_id);


--
-- Name: t_wf_task t_wf_task_pkey; Type: CONSTRAINT; Schema: ordng; Owner: connectsit
--

ALTER TABLE ONLY ordng.t_wf_task
    ADD CONSTRAINT t_wf_task_pkey PRIMARY KEY (task_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: svcinv; Owner: connectsit
--

ALTER TABLE ONLY svcinv.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: svcinv; Owner: connectsit
--

ALTER TABLE ONLY svcinv.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_db_service_config t_db_service_config_key; Type: CONSTRAINT; Schema: svcinv; Owner: connectsit
--

ALTER TABLE ONLY svcinv.t_db_service_config
    ADD CONSTRAINT t_db_service_config_key PRIMARY KEY (sql_id);


--
-- Name: t_service_feature_package t_service_feature_package_pkey; Type: CONSTRAINT; Schema: svcinv; Owner: connectsit
--

ALTER TABLE ONLY svcinv.t_service_feature_package
    ADD CONSTRAINT t_service_feature_package_pkey PRIMARY KEY (package_name);


--
-- Name: t_service_feature t_service_features_pkey; Type: CONSTRAINT; Schema: svcinv; Owner: connectsit
--

ALTER TABLE ONLY svcinv.t_service_feature
    ADD CONSTRAINT t_service_features_pkey PRIMARY KEY (feature_id);


--
-- Name: t_service_inventory t_service_inventory_compkey; Type: CONSTRAINT; Schema: svcinv; Owner: connectsit
--

ALTER TABLE ONLY svcinv.t_service_inventory
    ADD CONSTRAINT t_service_inventory_compkey PRIMARY KEY (entity_id, entity_type);


--
-- Name: t_service_inventory t_service_inventory_compkey; Type: CONSTRAINT; Schema: svcinv1; Owner: connectsit
--

ALTER TABLE ONLY svcinv1.t_service_inventory
    ADD CONSTRAINT t_service_inventory_compkey PRIMARY KEY (entity_id, entity_type);


--
-- Name: t_db_service_config TBL_DB_SERVICE_CONFIG_pkey; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_db_service_config
    ADD CONSTRAINT "TBL_DB_SERVICE_CONFIG_pkey" PRIMARY KEY (sql_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_carrier t_carrier_pk; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_carrier
    ADD CONSTRAINT t_carrier_pk PRIMARY KEY (carrier_id);


--
-- Name: t_domain_exception_retry t_domain_exception_retry_new_pkey; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_domain_exception_retry
    ADD CONSTRAINT t_domain_exception_retry_new_pkey PRIMARY KEY (transaction_id);


--
-- Name: t_tn_feature_package t_tn_feature_package_pkey; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_tn_feature_package
    ADD CONSTRAINT t_tn_feature_package_pkey PRIMARY KEY (package_name);


--
-- Name: t_tn_features t_tn_features_pkey; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_tn_features
    ADD CONSTRAINT t_tn_features_pkey PRIMARY KEY (feature_id);


--
-- Name: t_tn_inventory t_tn_inventory_pkey1; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_tn_inventory
    ADD CONSTRAINT t_tn_inventory_pkey1 PRIMARY KEY (tn);


--
-- Name: t_tn_property_country_mapping t_tn_property_country_mapping_pk; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_tn_property_country_mapping
    ADD CONSTRAINT t_tn_property_country_mapping_pk PRIMARY KEY (country_mapping_id);


--
-- Name: t_tninv_migration t_tninv_migration_pkey; Type: CONSTRAINT; Schema: tninv; Owner: connectsit
--

ALTER TABLE ONLY tninv.t_tninv_migration
    ADD CONSTRAINT t_tninv_migration_pkey PRIMARY KEY (batch_id, entity_order_id, command_name);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: topology; Owner: connectsit
--

ALTER TABLE ONLY topology.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: topology; Owner: connectsit
--

ALTER TABLE ONLY topology.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: t_switch_info t_switch_info_pkey; Type: CONSTRAINT; Schema: topology; Owner: connectsit
--

ALTER TABLE ONLY topology.t_switch_info
    ADD CONSTRAINT t_switch_info_pkey PRIMARY KEY (switch_id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: uui; Owner: connectsit
--

ALTER TABLE ONLY uui.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: schema_version schema_version_pk; Type: CONSTRAINT; Schema: uui; Owner: connectsit
--

ALTER TABLE ONLY uui.schema_version
    ADD CONSTRAINT schema_version_pk PRIMARY KEY (version);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: activn; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON activn.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: activn; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON activn.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: activn; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON activn.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: activn; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON activn.schema_version USING btree (version_rank);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: audit; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON audit.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: audit; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON audit.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: audit; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON audit.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: config; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON config.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: config; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON config.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: config; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON config.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: config; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON config.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: infra; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON infra.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: infra; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON infra.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: infra; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON infra.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: infra; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON infra.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON ordng.flyway_schema_history USING btree (success);


--
-- Name: idx_eodi_eoi; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_eodi_eoi ON ordng.t_entity_order_details USING btree (entity_order_detail_id, entity_order_id);


--
-- Name: idx_eoi_mod; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_eoi_mod ON ordng.t_entity_order USING btree (entity_order_id, master_order_id);


--
-- Name: idx_etn_ea; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_etn_ea ON ordng.t_entity_order USING btree (entity_type_name, entity_action);


--
-- Name: idx_etn_os; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_etn_os ON ordng.t_entity_order USING btree (entity_type_name, order_status);


--
-- Name: idx_teo_cod_jsonb; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_teo_cod_jsonb ON ordng.t_entity_order USING gin (common_order_details);


--
-- Name: idx_teod_eod_jsonb; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_teod_eod_jsonb ON ordng.t_entity_order_details USING gin (entity_order_details);


--
-- Name: idx_tid_tak; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_tid_tak ON ordng.t_master_order USING btree (work_order_number, master_order_number);


--
-- Name: idx_tro_ti; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX idx_tro_ti ON ordng.t_raw_order USING btree (transaction_id);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON ordng.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON ordng.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: ordng; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON ordng.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: svcinv; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON svcinv.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: svcinv; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON svcinv.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: svcinv; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON svcinv.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: svcinv; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON svcinv.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: tninv; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON tninv.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: tninv; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON tninv.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: tninv; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON tninv.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: tninv; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON tninv.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: topology; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON topology.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: topology; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON topology.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: topology; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON topology.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: topology; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON topology.schema_version USING btree (version_rank);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: uui; Owner: connectsit
--

CREATE INDEX flyway_schema_history_s_idx ON uui.flyway_schema_history USING btree (success);


--
-- Name: schema_version_ir_idx; Type: INDEX; Schema: uui; Owner: connectsit
--

CREATE INDEX schema_version_ir_idx ON uui.schema_version USING btree (installed_rank);


--
-- Name: schema_version_s_idx; Type: INDEX; Schema: uui; Owner: connectsit
--

CREATE INDEX schema_version_s_idx ON uui.schema_version USING btree (success);


--
-- Name: schema_version_vr_idx; Type: INDEX; Schema: uui; Owner: connectsit
--

CREATE INDEX schema_version_vr_idx ON uui.schema_version USING btree (version_rank);


--
-- Name: t_blocking_locations t_blocking_locations_blocking_id_fkey; Type: FK CONSTRAINT; Schema: activn; Owner: connectsit
--

-- FOREIGN KEYS IN ANOTHER FILE!!!!!!!

--
-- PostgreSQL database dump complete
--
