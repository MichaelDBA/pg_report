export ORASCHEMA=OSSOWN
export TARGET=/apps/opt/postgres/oracle_export/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting types..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t TYPE       -n $ORASCHEMA -N localds -o types.sql       -b $TARGET -l $TARGET/types.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting packages..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t PACKAGE    -n $ORASCHEMA -N localds -o packages.sql    -b $TARGET -l $TARGET/packages.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting functions..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t FUNCTION   -n $ORASCHEMA -N localds -o functions.sql   -b $TARGET -l $TARGET/functions.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting procedures..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t PROCEDURE  -n $ORASCHEMA -N localds -o procedures.sql  -b $TARGET -l $TARGET/procedures.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting mat views..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t MVIEW      -n $ORASCHEMA -N localds -o mviews.sql      -b $TARGET -l $TARGET/mviews.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting views..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t VIEW       -n $ORASCHEMA -N localds -o views.sql       -b $TARGET -l $TARGET/views.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting triggers..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t TRIGGER    -n $ORASCHEMA -N localds -o triggers.sql    -b $TARGET -l $TARGET/triggers.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting grants..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t GRANT      -n $ORASCHEMA -N localds -o grants.sql      -b $TARGET -l $TARGET/grants.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting synonyms..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t SYNONYM    -n $ORASCHEMA -N localds -o synonyms.sql    -b $TARGET -l $TARGET/synonyms.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting sequences..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t SEQUENCE   -n $ORASCHEMA -N localds -o sequences.sql   -b $TARGET -l $TARGET/sequences.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting tables..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t TABLE      -n $ORASCHEMA -N localds -o tables.sql      -b $TARGET -l $TARGET/tables.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting partitions..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t PARTITION  -n $ORASCHEMA -N localds -o partitions.sql  -b $TARGET -l $TARGET/partitions.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting Foreign Server..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t DBLINK     -n $ORASCHEMA -N localds -o dblinks.sql      -b $TARGET -l $TARGET/dblinks.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/oracle_export/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log
echo ">`date +'%Y-%m-%d %H:%M:%S'` Finished."
exit 0
POSTMAN>
