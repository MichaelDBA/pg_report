export ORASCHEMA=SDDOWN
export TARGET=/apps/opt/postgres/oracle_export/$ORASCHEMA
echo "Importing Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Types..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1 -a < $TARGET/types.sql  > $TARGET/typesIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Types Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Sequences..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/sequences.sql > $TARGET/sequencesIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Sequences Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Tables..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/tables.sql > $TARGET/tablesIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Tables Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Triggers..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/triggers.sql > $TARGET/triggersIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Triggers Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Views..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/views.sql > $TARGET/viewsIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Views Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Mat. Views..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/mviews.sql > $TARGET/mviewsIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Mviews Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Partitions..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/partitions.sql > $TARGET/partitionsIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Partitions Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Bypassing Synonyms..."
#echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Synonyms..."
#psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1 -a < $TARGET/synonyms.sql > $TARGET/synonymsIMP.log 2>&1
#exitcode=$?
#if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Synonyms Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Bypassing Functions, Procedures, Packages..."
#echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Functions..."
#psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/functions.sql > $TARGET/functionsIMP.log 2>&1
#exitcode=$?
#if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Functions Import Error"; exit 1; fi

#echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Procedures..."
#psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/procedures.sql > $TARGET/proceduresIMP.log 2>&1
#exitcode=$?
#if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Procedures Import Error"; exit 1; fi

#echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Packages..."
#psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/packages.sql > $TARGET/packagesIMP.log 2>&1
#exitcode=$?
#if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Packages Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Indexes..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/INDEXES_tables.sql > $TARGET/INDEXES_tablesIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Indexes Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Constraints..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/CONSTRAINTS_tables.sql > $TARGET/CONSTRAINTS_tablesIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Constraints Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Bypassing dblinks..."
#echo ">`date +'%Y-%m-%d %H:%M:%S'` Importing dblink..."
#psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/dblinks.sql > $TARGET/dblinks.log 2>&1
#exitcode=$?
#if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode DBLinks Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Data..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/data.sql > $TARGET/dataIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Data Import Error"; exit 1; fi

echo "`date +'%Y-%m-%d %H:%M:%S'` Importing Foreign Keys..."
psql -d connectdb -U dbadmin -p 5432 -v ON_ERROR_STOP=1  -a < $TARGET/FKEYS_tables.sql > $TARGET/FKEYS_tablesIMP.log 2>&1
exitcode=$?
if [ $exitcode -ne 0 ]; then echo "ERROR `date`: $exitcode Foreign Keys Import Error"; exit 1; fi

echo ">`date +'%Y-%m-%d %H:%M:%S'` Finished."
exit 0

