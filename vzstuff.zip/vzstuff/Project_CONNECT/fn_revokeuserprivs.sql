-- DROP FUNCTION dbadmin.revokeuserprivs(text, text, text, boolean);
-- select dbadmin.revokeuserprivs('v000094','dbowner','connectdb', false);
-- run next command to see what user privs are
-- /ddp v000094
-- may not be able to drop a role due to ownership in other databases.  Last resort: drop objects owned by user --> DROP OWNED BY v000094;
CREATE OR REPLACE FUNCTION dbadmin.revokeuserprivs(p_username text, p_owner text, p_database text, removeroles boolean)
RETURNS text AS
$BODY$
DECLARE
v_cnt   integer;
v_diag1 text;
v_diag2 text;
v_diag3 text;
v_diag4 text;
v_ret text;
BEGIN
    -- verify user already exists.
    select count(*) into v_cnt from pg_user where usename = p_username;
    IF v_cnt = 0 THEN
        v_ret := 'User does not exist: ' || p_username;
	Return v_ret;
    END IF;
    
    -- create the non-login role, disabled_users, if not exists
    select count(*) into v_cnt from pg_roles where rolcanlogin and not rolsuper and rolname = p_username;
    IF v_cnt = 0 THEN
        v_ret := 'Cannot revoke privs for superuser or nonlogin role: ' || p_username;
	Return v_ret;
    END IF;    
    
    -- re-assign objects owned to specified role
    EXECUTE FORMAT('REASSIGN OWNED BY "%I" TO "%I"', p_username, p_owner);
   
    -- revoke privs
    EXECUTE FORMAT('REVOKE ALL ON DATABASE "%I" FROM "%I"',p_database, p_username);
    EXECUTE FORMAT('REVOKE USAGE ON LANGUAGE plpgsql FROM "%I"', p_username);
    EXECUTE FORMAT('REVOKE ALL ON SCHEMA public FROM "%I"', p_username);
    EXECUTE FORMAT('REVOKE CREATE ON SCHEMA public FROM "%I"', p_username);
    EXECUTE FORMAT('REVOKE ALL PRIVILEGES on all tables in schema activn, audit, bill, config, etl, infra, localds, ordng, svcinv, tninv, topology, uui from "%I"', p_username);
	EXECUTE FORMAT('REVOKE ALL on schema activn, audit, bill, config, etl, infra, localds, ordng, svcinv, tninv, topology, uui FROM "%I"', p_username);
    EXECUTE FORMAT('REVOKE ALL ON ALL SEQUENCES IN SCHEMA activn, audit, bill, config, etl, infra, localds, ordng, svcinv, tninv, topology, uui FROM "%I"', p_username);
    EXECUTE FORMAT('ALTER DEFAULT PRIVILEGES IN SCHEMA activn, audit, bill, config, etl, infra, localds, ordng, svcinv, tninv, topology, uui REVOKE ALL ON TABLES FROM "%I"', p_username);
    EXECUTE FORMAT('ALTER DEFAULT PRIVILEGES REVOKE ALL ON SCHEMAS FROM "%I"', p_username);
    EXECUTE FORMAT('ALTER DEFAULT PRIVILEGES REVOKE ALL ON TABLES FROM "%I"', p_username);
    EXECUTE FORMAT('ALTER DEFAULT PRIVILEGES REVOKE ALL ON SEQUENCES FROM "%I"', p_username);
	EXECUTE FORMAT('ALTER DEFAULT PRIVILEGES REVOKE ALL ON FUNCTIONS FROM "%I"', p_username);
    
	--TODO: remove role memberships if dictated
	IF removeroles THEN
	    RAISE INFO 'Removing role memberships...';
	END IF;
	
    RETURN 'User ' || p_username || ' successfully removed all privileges.';
    
    EXCEPTION
        WHEN others THEN
            GET STACKED DIAGNOSTICS v_diag1 = MESSAGE_TEXT, v_diag2 = PG_EXCEPTION_DETAIL, v_diag3 = PG_EXCEPTION_HINT, v_diag4 = RETURNED_SQLSTATE;
            v_ret := v_diag4 || '. ' || v_diag1 || ' .' || v_diag2 || ' .' || v_diag3;
            RAISE WARNING '%',v_ret;
    	    -- no need to rollback anything explicitly since functions are implicitly transactional
            RETURN v_ret;
END;
$BODY$
LANGUAGE plpgsql STRICT VOLATILE COST 100;
