export ORASCHEMA=ACELAOWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=EILSROWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=OSSOWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=PERSEUSOWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=RMOWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=SDDOWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=SDMOWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

export ORASCHEMA=TSIDROWN
export TARGET=/apps/opt/postgres/migrate_OSST6/$ORASCHEMA
echo "Exporting Oracle Schema ($ORASCHEMA) using target location ($TARGET)"
echo ">`date +'%Y-%m-%d %H:%M:%S'` Exporting data..."
ora2pg -c /apps/opt/postgres/migrate_OSST6/ora2pg.conf   -t COPY       -n $ORASCHEMA -N localds -o data.sql        -b $TARGET -l $TARGET/data.log

echo ">`date +'%Y-%m-%d %H:%M:%S'` Finished."
exit 0



