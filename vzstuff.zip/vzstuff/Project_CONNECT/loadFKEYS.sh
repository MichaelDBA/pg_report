psql connectdb -U dbadmin -a < ./ACELAOWN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./EILSROWNN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./PERSEUSOWN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./RMOWN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./SDDOWN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./SDMOWN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./TSIDROWN/FKEYS_tables.sql
psql connectdb -U dbadmin -a < ./OSSOWN/FKEYS_tables.sql
