#!/bin/ksh
export PATH=$PATH:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/apps/opt/postgres/usr/pgsql-9.6/bin
# Get the DB log files

REGION=us-east-1

export HTTPS_PROXY=http://proxy.ebiz.verizon.com:80

log () {
    echo "`date +%Y%m%d-%H%M%S`: ${@}"
}

cat pulllog.conf | while read VSAD DB_INSTANCE
do
  echo "Working on => $VSAD and $DB_INSTANCE"
   if [ -f $VSAD.$DB_INSTANCE.lastrun ]
   then
      echo " Found lastrun"
      let LASTRUN=$(cat $VSAD.$DB_INSTANCE.lastrun)
   else
      echo "  lastrun NOT Found"
     LASTRUN=0;
     echo "Value $LAST"
   fi
  echo "creating logfile list"
    aws --region $REGION rds describe-db-log-files --db-instance-identifier $DB_INSTANCE --file-last-written $LASTRUN --no-paginate --output text  > logfile.lst

  cat logfile.lst | while read TYPE LASTUPD FILE SIZE
do
        LOGFILE=$(echo $FILE|cut -d '/' -f2 )
        log "Downloading Logfile = $LOGFILE"
        aws --region $REGION rds download-db-log-file-portion --db-instance-identifier $DB_INSTANCE --output text --starting-token 0 --log-file-name $FILE > /apps/opt/logs/$VSAD/$VSAD.$DB_INSTANCE.$LOGFILE
   echo $LASTUPD > $VSAD.$DB_INSTANCE.lastrun
   done
done
log "RDS Logs download completed."
echo
~
~
~
